import fetch from 'node-fetch';
import { config } from './config.js';

// Kirim ke Telegram
export async function sendToTelegram(text) {
  const token = config.TOKEN;
  const chatId = config.OWNER_ID;
  const url = `https://api.telegram.org/bot${token}/sendMessage`;

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'Markdown'
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      console.error('❌ Gagal kirim ke Telegram:', err);
      return false;
    }

    return true;
  } catch (err) {
    console.error('❌ Gagal kirim ke Telegram (network):', err);
    return false;
  }
}

// Kirim ke Discord via Webhook
export async function sendToDiscordWebhook(text) {
  const url = config.DISCORD_WEBHOOK_URL;
  if (!url || !url.startsWith('https://discord.com/api/webhooks/')) {
    console.error('❌ DISCORD_WEBHOOK_URL tidak valid atau belum disetel di config.js');
    return false;
  }

  // Hapus karakter format Markdown Telegram yang umum (* _ ` ~)
  const cleanText = text.replace(/[*_`~]/g, '');

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: cleanText }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      console.error('❌ Gagal kirim ke Discord:', err);
      return false;
    }

    return true;
  } catch (err) {
    console.error('❌ Gagal kirim ke Discord (network):', err);
    return false;
  }
}