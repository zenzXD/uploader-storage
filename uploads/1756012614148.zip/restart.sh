#!/bin/bash
while true; do
  echo "[🟢] Starting bot..."
  node LinQiye.js
  echo "[🔁] Bot exited. Restarting in 2s..."
  sleep 2
done
