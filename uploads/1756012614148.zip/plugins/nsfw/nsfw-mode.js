import { config } from '../../config.js'

let nsfwMode = true

function getStatus() {
  return nsfwMode
}

function setStatus(status) {
  nsfwMode = status
}

export default {
  command: ['nsfwon', 'nsfwoff'],
  tags: ['nsfw'],
  desc: '🔞 Aktifkan / Nonaktifkan mode NSFW (khusus Owner)',

  async handler(ctx, bot) {
    const { OWNER_ID } = (await import('../../config.js')).config
    const userId = ctx.from.id.toString()
    const isOwner = Array.isArray(OWNER_ID)
      ? OWNER_ID.map(String).includes(userId)
      : userId === String(OWNER_ID)

    const isOn = ctx.command === 'nsfwon'

    if (!isOwner) {
      return ctx.reply(
        `🚫 *Akses ditolak!*\n\nPerintah ini hanya dapat dijalankan oleh *Owner Bot*.`,
        { parse_mode: 'Markdown' }
      )
    }

    setStatus(isOn)

    await ctx.reply(
      `╭──〔 🔞 *NSFW MODE DIUBAH* 〕──╮
│ ✅ Status Baru: *${isOn ? 'AKTIF' : 'NONAKTIF'}*
│ 🧑‍💼 Oleh: ${ctx.from.first_name}
│ 🕒 ${new Date().toLocaleString('id-ID')}
╰────────────────────────────╯`,
      { parse_mode: 'Markdown' }
    )

    // Opsional: kirim notifikasi ke Owner sendiri
    const notif = `
🔧 *NSFW Mode Diubah!*
🧩 *Status:* ${isOn ? 'AKTIF ✅' : 'NONAKTIF ❌'}
👤 *Oleh:* ${ctx.from.first_name}
🆔 *ID:* \`${ctx.from.id}\`
🕒 ${new Date().toLocaleString('id-ID')}`.trim()

    try {
      await bot.telegram.sendMessage(userId, notif, { parse_mode: 'Markdown' })
    } catch (err) {
      console.warn('❗ Gagal kirim notifikasi ke Owner:', err.message)
    }
  },

  getStatus,
  setStatus
}