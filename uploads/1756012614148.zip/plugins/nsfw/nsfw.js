import fetch from 'node-fetch'
import { config } from '../../config.js'
import nsfwModeModule from './nsfw-mode.js'

const nsfwCommands = [
  'gay', 'ahegao', 'ass', 'bdsm', 'blowjob', 'cuckold', 'cum', 'ero',
  'femdom', 'foot', 'gangbang', 'glasses', 'hentai', 'gifs', 'jahy',
  'manga', 'masturbation', 'neko', 'neko2', 'orgy', 'panties', 'pussy',
  'tentacles', 'thighs', 'yuri', 'zettai'
]

export default {
  command: nsfwCommands,
  tags: ['nsfw'],
  premium: true,
  limit: true,
  desc: '🔞 Menampilkan gambar NSFW berdasarkan kategori tertentu',

  async handler(ctx) {
    const { text, from, message_id } = ctx
    const cmd = text?.split(' ')[0]?.replace('/', '')

    // 🔒 Cek status NSFW Mode
    const nsfwIsActive = nsfwModeModule.getStatus?.() // safe call
    if (!nsfwIsActive) {
      return ctx.reply(`🚫 *NSFW Mode saat ini dinonaktifkan oleh Owner.*\n\nSilakan hubungi Owner untuk mengaktifkannya.`, {
        parse_mode: 'Markdown',
        reply_to_message_id: message_id
      })
    }

    // ❌ Validasi command
    if (!nsfwCommands.includes(cmd)) {
      return ctx.reply('❌ Perintah NSFW tidak dikenali.', {
        reply_to_message_id: message_id
      })
    }

    // 📤 Kirim notifikasi ke Owner
    const ownerId = Array.isArray(config.OWNER_ID)
      ? config.OWNER_ID[0]
      : config.OWNER_ID

    const username = from?.username
      ? `@${from.username}`
      : from?.first_name || 'Unknown User'

    const notif = `
╭━━━〔 🚨 *PERMINTAAN NSFW* 〕━━⬣
┃👤 *User:* ${username}
┃🧩 *Command:* /${cmd}
╰━━━━━━━━━━━━━━━━━━━━━━⬣`.trim()

    try {
      await ctx.telegram.sendMessage(ownerId.toString(), notif, {
        parse_mode: 'Markdown'
      })
    } catch (err) {
      console.warn('⚠️ Gagal kirim notifikasi owner:', err.message)
    }

    // 🔍 Ambil gambar dari API
    try {
      await ctx.reply('🔍 Sedang mencari gambar NSFW, mohon tunggu...', {
        reply_to_message_id: message_id
      })

      const apiUrl = `https://api.botcahx.eu.org/api/nsfw/${cmd}?apikey=${config.BOTCAHX_API_KEY}`
      const res = await fetch(apiUrl)

      if (!res.ok) throw new Error('❌ Gagal mengambil konten dari API.')

      const buffer = await res.buffer()

      await ctx.replyWithPhoto(
        { source: buffer },
        {
          caption: `
╭───〔 🔞 *NSFW Result* 〕───⬣
🧩 *Kategori:* \`${cmd}\`
🙋 *Permintaan:* ${username}
╰━━━━━━━━━━━━━━━━━━━━━━⬣`.trim(),
          parse_mode: 'Markdown',
          reply_to_message_id: message_id
        }
      )
    } catch (err) {
      console.error('❌ Error NSFW API:', err)
      await ctx.reply('❌ Gagal mengambil konten NSFW. Silakan coba lagi nanti.', {
        reply_to_message_id: message_id
      })
    }
  }
}