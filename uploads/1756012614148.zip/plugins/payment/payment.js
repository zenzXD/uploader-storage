import { config } from '../../config.js'
import { readFile } from 'fs/promises'

export default {
  command: ['payment', 'pembayaran', 'pay'],
  tags: ['payment'],
  desc: '💰 Menampilkan metode pembayaran dan donasi otomatis',

  async handler(ctx) {
    const teks = `
╭━━━〔 💰 *PEMBAYARAN OTOMATIS* 〕━━━╮

📌 *Donasi ke bot ini agar tetap aktif dan terus berkembang!*

📤 *Metode Pembayaran Tersedia:*
• Dana: ${config.DANA || '081234567890'}
• OVO: ${config.OVO || '081234567890'}
• ShopeePay: ${config.SHOPEEPAY || '081234567890'}
• LinkAja: ${config.LINKAJA || '081234567890'}
• QRIS: tekan tombol di bawah!

📷 Untuk metode QRIS atau bukti transfer, klik tombol "Kirim Bukti"

🔐 Donasi akan diverifikasi otomatis (jika sistem aktif)

╰━━〔 👨‍💻 Owner: @${config.OWNER_USERNAME || 'owner'} 〕━━╯
`.trim()

    await ctx.reply(teks, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '📷 QRIS', callback_data: 'payment:qris' }
          ],
          [
            { text: '📤 Kirim Bukti', callback_data: 'payment:kirim_bukti' },
            { text: '📈 Cek Status', callback_data: 'payment:status' }
          ],
          [
            { text: '📞 Hubungi Owner', url: `https://t.me/${config.OWNER_USERNAME || 'owner'}` }
          ]
        ]
      }
    })
  },

  async callbackQuery(ctx) {
    const data = ctx.callbackQuery?.data
    if (!data.startsWith('payment:')) return

    const key = data.split(':')[1]
    await ctx.answerCbQuery()

    switch (key) {
      case 'qris':
        try {
          const buffer = await readFile('./image/payment/qris.jpg')
          await ctx.replyWithPhoto({ source: buffer }, {
            caption: '*Scan QRIS ini untuk melakukan pembayaran!*',
            parse_mode: 'Markdown'
          })
        } catch {
          await ctx.reply('❌ QRIS belum tersedia. Silakan hubungi owner.')
        }
        break

      case 'kirim_bukti':
        await ctx.reply(`
📤 *Cara Kirim Bukti Pembayaran:*
1. Transfer sesuai metode yang kamu pilih.
2. Kirim foto bukti ke @${config.OWNER_USERNAME || 'owner'}.
3. Tunggu verifikasi atau sistem membaca otomatis.

✅ *Jika otomatis aktif*, donatur langsung mendapat badge.
        `.trim(), { parse_mode: 'Markdown' })
        break

      case 'status':
        await ctx.reply(`
📈 *Cek Status Donasi:*

🔍 Sistem ini sedang dalam pengembangan.

📌 Nantinya kamu bisa:
• Cek status donasi
• Lihat histori pembayaran
• Lacak otomatis via OCR

🚧 Mohon tunggu update!
        `.trim(), { parse_mode: 'Markdown' })
        break

      default:
        await ctx.reply('⚠️ Callback tidak dikenali.')
        break
    }
  }
}