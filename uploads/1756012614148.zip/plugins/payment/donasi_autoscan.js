import fs from 'fs'
import path from 'path'
import tesseract from 'tesseract.js'
const { recognize } = tesseract

export default {
  command: ['donasi_autoscan'],
  tags: ['payment'],
  owner: true,
  async handler(m, { conn, args }) {
    if (!m.reply_message || !m.reply_message.photo) {
      return m.reply('📷 *Balas gambar bukti donasi dengan perintah ini!*')
    }

    const file = await conn.download(m.reply_message.photo)
    const tempPath = './tmp/donasi.jpg'
    fs.writeFileSync(tempPath, file)

    await m.reply('🔍 *Memindai bukti donasi...*')
    const result = await recognize(tempPath, 'ind')
    const teks = result.data.text.toLowerCase()

    const valid = /(bca|bri|dana|gopay|ovo|trakteer|transfer|donasi|rp[\s\S]{0,20}\d+)/.test(teks)
    fs.unlinkSync(tempPath)

    if (valid) {
      const username = m.from?.username || m.sender?.username || m.sender?.id || 'pengguna'
      const donorData = {
        id: m.sender?.id,
        username: username,
        date: new Date().toISOString(),
        source: teks.slice(0, 500)
      }

      const filePath = './json/donatur.json'
      const db = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : []
      db.push(donorData)
      fs.writeFileSync(filePath, JSON.stringify(db, null, 2))

      await m.reply(`🎉 *Terima kasih atas donasinya, @${username}!*\nKamu sekarang menjadi *Donatur Official ✨*`)
      await conn.sendMessage(global.config.GROUP_LOG, {
        text: `📥 *Donasi terdeteksi dari @${username}*\nBadge Donatur ✅ aktif.`,
        parse_mode: 'Markdown'
      })
    } else {
      await m.reply('❌ *Bukti tidak valid atau tidak terbaca dengan baik.*')
    }
  }
}