import { Markup } from "telegraf";
import { config } from "../../config.js"; // Pastikan ini berisi OWNER info, dsb.

export default {
  command: ["qris"],
  tags: ["payment"],
  desc: "💸 Menampilkan QRIS untuk donasi",

  async handler(ctx) {
    const qrisImageUrl = "https://files.catbox.moe/uidusn.jpg"; // Ganti sesuai URL QRIS kamu
    const ownerUsername = config.OWNER_USERNAME || "admin";

    const caption = `
╭━━[ *DONASI DUKUNG BOT* ]
┃💸 Silakan scan QRIS di atas
┃📌 Metode: Dana, OVO, Gopay, dll
┃🧑‍💻 Developer: @${ownerUsername}
┃🙏 Terima kasih atas dukungannya!
╰━━━━━━━━━━━━━╯
`;

    try {
      await ctx.replyWithPhoto(
        { url: qrisImageUrl },
        {
          caption,
          parse_mode: "Markdown",
          ...Markup.inlineKeyboard([
            [Markup.button.url("📞 Hubungi Admin", `https://t.me/${ownerUsername}`)],
          ]),
        }
      );
    } catch (err) {
      console.error("Gagal mengirim QRIS:", err);
      await ctx.reply("❌ Gagal mengirim QRIS. Coba lagi nanti.");
    }
  },
};