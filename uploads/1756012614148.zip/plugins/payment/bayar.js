import axios from 'axios'
import crypto from 'crypto'
import { config } from '../../config.js'

const BASE_URL = 'https://tripay.co.id/api'

function signature(ref) {
  return crypto
    .createHmac('sha256', config.TRIPAY_PRIVATE_KEY)
    .update(ref + config.TRIPAY_MERCHANT_CODE + config.TRIPAY_API_KEY)
    .digest('hex')
}

export default {
  command: ['bayar'],
  tags: ['payment'],
  desc: '🧾 Buat invoice donasi Tripay',
  async handler(ctx) {
    const [channel, jumlah] = ctx.text.split(' ').slice(1)
    if (!channel || !jumlah || isNaN(jumlah)) {
      return ctx.reply('❗ Format salah!\nGunakan: `/bayar QRIS 5000`', { parse_mode: 'Markdown' })
    }

    const reference = 'TX-' + Date.now()
    const payload = {
      method: channel,
      merchant_ref: reference,
      amount: parseInt(jumlah),
      customer_name: ctx.from.first_name,
      customer_email: `${ctx.from.username || 'telegram'}@dummy.com`,
      order_items: [
        {
          sku: 'DONASI-TELEGRAM',
          name: 'Donasi Telegram Bot',
          price: parseInt(jumlah),
          quantity: 1
        }
      ],
      callback_url: config.TRIPAY_CALLBACK_URL,
      return_url: config.TRIPAY_RETURN_URL,
      signature: signature(reference)
    }

    try {
      const { data } = await axios.post(`${BASE_URL}/transaction/create`, payload, {
        headers: {
          Authorization: `Bearer ${config.TRIPAY_API_KEY}`
        }
      })

      const invoice = data.data
      await ctx.reply(`
🧾 *Invoice berhasil dibuat!*
• Metode: ${invoice.payment_name}
• Jumlah: Rp${invoice.amount.toLocaleString()}
• Ref: ${invoice.merchant_ref}

💳 Silakan bayar ke:
${invoice.pay_code}

📲 Link pembayaran:
${invoice.checkout_url}
      `.trim(), {
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })
    } catch (e) {
      console.error(e.response?.data || e.message)
      ctx.reply('❌ Gagal membuat invoice. Cek kode channel dan API key Tripay kamu.')
    }
  }
}