import fs from 'fs'
import path from 'path'

export default {
  command: ['paymentmenu', 'menupayment', 'donasimenu'],
  tags: ['payment', 'info'],
  desc: '💳 Menampilkan semua metode pembayaran yang tersedia',

  async handler(ctx) {
    const folderPath = path.join(process.cwd(), 'plugins', 'payment')
    const files = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'))

    if (files.length === 0) {
      return ctx.reply('❌ Tidak ada metode pembayaran yang tersedia saat ini.')
    }

    let teks = `╭━━━〔 *💸 MENU PEMBAYARAN* 〕━━━⬣\n`
    teks += `┃ Berikut adalah daftar metode\n┃ pembayaran yang tersedia:\n┃\n`

    for (let i = 0; i < files.length; i++) {
      const fileName = files[i].replace('.js', '')
      const nomor = (i + 1).toString().padStart(2, '0')
      const nama = fileName.charAt(0).toUpperCase() + fileName.slice(1)
      teks += `┃ ${nomor}. ⤑ ${nama}\n`
    }

    teks += `┃\n┃ Ketik: */nama_metode* untuk akses.\n┃ Contoh: */qris*, */gopay*\n`
    teks += `╰━━━━━━━━━━━━━━━━━━━━━━⬣`

    await ctx.reply(teks, {
      parse_mode: "Markdown"
    })
  }
}