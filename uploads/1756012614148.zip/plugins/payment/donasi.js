import { config } from '../../config.js'
import { Markup } from 'telegraf'

export default {
  command: ['donasi', 'donate', 'support'],
  tags: ['payment'],
  desc: '☕ Menampilkan informasi dukungan dan donasi untuk bot',

  async handler(ctx) {
    await ctx.replyWithPhoto(
      { url: 'https://files.catbox.moe/uidusn.jpg' },
      {
        caption: `
╭━━━━━━━━━━━━━━━━━━━╮
┃     🎁 *Dukung Bot Ini*     ┃
╰━━━━━━━━━━━━━━━━━━━╯

Terima kasih telah menggunakan bot ini!  
Agar bot tetap online dan berkembang, kamu bisa bantu dengan berdonasi 🙏💖

Pilih metode dukungan di tombol berikut:
        `.trim(),
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [
            Markup.button.callback('🍵 Trakteer', 'donasi:trakteer'),
            Markup.button.callback('📱 E-wallet', 'donasi:ewallet')
          ],
          [
            Markup.button.callback('⭐ Keuntungan Donatur', 'donasi:keuntungan'),
            Markup.button.callback('📞 Hubungi Owner', 'donasi:owner')
          ]
        ])
      }
    )
  },

  async onCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data
    if (!data.startsWith('donasi:')) return

    const action = data.split(':')[1]
    await ctx.answerCbQuery()

    switch (action) {
      case 'trakteer':
        return ctx.reply(`
🍰 *Donasi via Trakteer*
━━━━━━━━━━━━━━━━━━━━━━
Dukung bot ini dengan traktiran kecilmu 💕

🔗 [Klik di sini untuk Trakteer](https://trakteer.id/${config.TRAKTEER || 'namatrakteer'})

Setiap donasi sangat berarti 💝
        `.trim(), { parse_mode: 'Markdown', disable_web_page_preview: true })

      case 'ewallet':
        return ctx.reply(`
💸 *Metode Donasi via E-Wallet*
━━━━━━━━━━━━━━━━━━━━━━
📱 *Nomor E-wallet:*
• 🟢 Dana: \`${config.DANA || '081234567890'}\`
• 🟣 OVO: \`${config.OVO || '081234567890'}\`
• 🟠 ShopeePay: \`${config.SHOPEEPAY || '081234567890'}\`
• 🔴 LinkAja: \`${config.LINKAJA || '081234567890'}\`

📷 *Gunakan QRIS pada gambar sebelumnya untuk donasi instan!*
        `.trim(), { parse_mode: 'Markdown' })

      case 'keuntungan':
        return ctx.reply(`
🎉 *Keuntungan Menjadi Donatur*
━━━━━━━━━━━━━━━━━━━━━━
✨ Akses *fitur premium*
🌟 Badge *donatur eksklusif*
⚡ *Bantuan prioritas* saat butuh
🤝 Membantu *perkembangan proyek open-source*

Donasimu bukan cuma bantu bot ini, tapi juga komunitas 🙌
        `.trim(), { parse_mode: 'Markdown' })

      case 'owner':
        return ctx.reply(`
📞 *Hubungi Owner*
━━━━━━━━━━━━━━━━━━━━━━
Ada pertanyaan atau butuh bantuan langsung?

🔗 [Klik untuk chat Owner](https://t.me/${config.OWNER_USERNAME || 'owner'})

Kami senang mendengar dari kamu 💬
        `.trim(), { parse_mode: 'Markdown', disable_web_page_preview: true })

      default:
        return ctx.reply('❌ Perintah tidak dikenali.')
    }
  }
}