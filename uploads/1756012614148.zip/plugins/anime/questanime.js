import axios from 'axios'
import * as cheerio from 'cheerio'

export default {
  command: ['quoteanime'],
  tags: ['anime'],
  desc: '🎭 Cari quote anime berdasarkan kata kunci',

  async handler(ctx) {
    const text = ctx.message.text.split(' ').slice(1).join(' ')
    if (!text) return ctx.reply('🎯 Masukkan kata kunci untuk mencari quote anime.\n\n*Contoh:* `/quoteanime naruto`')

    try {
      const res = await axios.get(`https://otakotaku.com/quote/search?q=${encodeURIComponent(text)}&q_filter=quote`)
      const $ = cheerio.load(res.data)
      const quotes = []

      $('.kotodama-list').each((_, el) => {
        const link = $(el).find('a.kuroi').attr('href')
        const gambar = $(el).find('.char-img img').attr('data-src')
        const karakter = $(el).find('.char-name').text().trim()
        const anime = $(el).find('.anime-title').text().trim()
        const episode = $(el).find('.meta').text().trim()
        const quote = $(el).find('.quote').text().trim()

        quotes.push({ link, gambar, karakter, anime, episode, quote })
      })

      if (!quotes.length) return ctx.reply('❌ Tidak ada hasil ditemukan.')

      const random = quotes[Math.floor(Math.random() * quotes.length)]
      const caption = `
╭━━━〔 🎭 *Quote Anime* 〕━━⬣
│👤 *Karakter:* ${random.karakter}
│📺 *Anime:* ${random.anime}
│🎬 *Episode:* ${random.episode}
╰━━━━━━━━━━━━━━━━━━⬣

💬 *Quote:*
_"${random.quote}"_

🔗 [Lihat di OtakOtaku](https://otakotaku.com${random.link})
`

      await ctx.replyWithPhoto({ url: random.gambar }, { caption, parse_mode: 'Markdown' })
    } catch (e) {
      console.error(e)
      return ctx.reply('⚠️ Terjadi kesalahan saat mencari quote.')
    }
  }
}