import fs from 'fs'
import axios from 'axios'
import FormData from 'form-data'
import { downloadMedia } from '../../lib/download.js' // pastikan file ini ada

export default {
  command: ['traceanime'],
  tags: ['anime'],
  description: 'Cari episode anime dari gambar',
  category: 'Fun',

  async handler(ctx) {
    const msg = ctx.message
    const reply = msg?.reply_to_message
    const photo = reply?.photo?.slice(-1)[0] // ambil resolusi tertinggi

    if (!photo) {
      return await ctx.reply('❌ Kirim atau reply gambar dengan caption `.traceanime` untuk mencari episode.')
    }

    await ctx.reply('🔍 Sabar Wibu Lagi Gw Cariin...')

    try {
      const filePath = await downloadMedia(ctx.telegram, photo.file_id, './temp')
      const form = new FormData()
      form.append('file', fs.createReadStream(filePath))

      const uploadRes = await axios.post('https://cloudgood.xyz/upload.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
      })

      const imageUrl = uploadRes.data?.url
      if (!imageUrl) {
        fs.unlinkSync(filePath)
        return await ctx.reply('❌ Gagal upload gambar ke CloudGood.')
      }

      // Cek apakah URL gambar bisa diakses
      let retry = 0
      let isReady = false
      while (retry < 5) {
        try {
          const check = await axios.head(imageUrl)
          if (check.status === 200) {
            isReady = true
            break
          }
        } catch {}
        await new Promise(r => setTimeout(r, 1000))
        retry++
      }

      if (!isReady) {
        fs.unlinkSync(filePath)
        return await ctx.reply('❌ Gagal akses file yang di-upload. Coba lagi.')
      }

      const res = await axios.get(`https://apii.baguss.web.id/search/epanime?apikey=bagus&url=${encodeURIComponent(imageUrl)}`)
      fs.unlinkSync(filePath)

      const data = res.data
      if (!data.success) return await ctx.reply('❌ Gagal mencari episode dari gambar.')

      const { filename, episode, video } = data
      const shortRes = await axios.get(`https://shogood.zone.id/short?url=${encodeURIComponent(video)}`)
      const videoLink = shortRes.data?.short || video

      const caption = `🎬 *Episode Search Result*\n\n📁 *Filename:* ${filename}\n📺 *Episode:* ${episode}\n🎞️ *Video:* ${videoLink}`
      await ctx.reply(caption, { parse_mode: 'Markdown' })

    } catch (e) {
      console.error(e)
      await ctx.reply('❌ Terjadi kesalahan saat memproses gambar.')
    }
  }
}