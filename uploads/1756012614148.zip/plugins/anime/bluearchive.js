import fetch from 'node-fetch'

export default {
  command: ['bluearchive', 'ba'],
  tags: ['anime'],
  desc: '📸 Kirim waifu random dari Blue Archive',

  async handler(ctx) {
    try {
      const imageUrl = 'https://api.siputzx.my.id/api/r/blue-archive'

      await ctx.replyWithPhoto({ url: imageUrl }, {
        caption: `
┏━━━〔 🌸 *Blue Archive Waifu* 🌸 〕━━━┓
┃ 📷 *Satu waifu pilihan semesta untukmu!*
┃ 💖 Siap menemani harimu~
┗━━━━━━━━━━━━━━━━━━━━━━┛

✨ *Powered by Lin-Qiye Bot*
        `.trim(),
      })
    } catch (err) {
      console.error(err)
      await ctx.reply(`
┏━━━〔 ❌ *Gagal Mengambil Waifu* ❌ 〕━━━┓
┃ 😢 Maaf, sepertinya sedang ada masalah...
┃ 🔁 Silakan coba beberapa saat lagi.
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
      `.trim())
    }
  }
}