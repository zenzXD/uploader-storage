import axios from 'axios'
import { config } from '../../config.js' // Pastikan OWNER_ID diatur

export default {
  command: ['otakusearch', 'otakudesusearch'],
  tags: ['anime'],
  desc: '🔍 Cari anime dari Otakudesu',
  usage: '.otakusearch <judul anime>',

  async handler(ctx) {
    const query = ctx.args.join(' ')
    if (!query) {
      return ctx.reply(`📚 *Masukkan judul anime yang ingin dicari!*\n\nContoh:\n.otakusearch kimetsu no yaiba`)
    }

    try {
      const res = await axios.get(`https://zenzxz.dpdns.org/anime/otakudesu/search?query=${encodeURIComponent(query)}`)
      const results = res.data.result

      if (!results || results.length === 0) {
        return ctx.reply('❌ Anime tidak ditemukan di Otakudesu.')
      }

      const teks = `
🍥 *──〔 OTAKUDESU SEARCH 〕──*

🔎 *Query*: _${query}_

${results.slice(0, 10).map((anime, i) => `*${i + 1}. ${anime.title}*\n🔗 [Tonton di Otakudesu](${anime.link})`).join('\n\n')}

📌 Menampilkan maksimal *10* hasil pencarian.

🧠 Powered by *zenzxz API*
      `.trim()

      // Kirim ke DM user (jika bukan bot & bisa DM)
      const userId = ctx.from.id
      if (ctx.chat.type !== 'private') {
        try {
          await ctx.telegram.sendMessage(userId, teks, {
            parse_mode: 'Markdown',
            disable_web_page_preview: true
          })
          await ctx.reply('📩 Hasil pencarian sudah dikirim via *DM*!')
        } catch (e) {
          await ctx.reply('⚠️ Tidak bisa mengirim DM. Pastikan kamu sudah memulai bot di private chat.')
        }
      } else {
        await ctx.reply(teks, {
          parse_mode: 'Markdown',
          disable_web_page_preview: true
        })
      }

      // Kirim notifikasi ke Owner
      const mention = ctx.from.username ? `@${ctx.from.username}` : `[${ctx.from.first_name}](tg://user?id=${userId})`
      const notif = `
📥 *Notifikasi Pencarian Otakudesu*
👤 Pengguna: ${mention}
📝 Kata Kunci: _${query}_
📆 Waktu: ${new Date().toLocaleString('id-ID')}
      `.trim()

      if (config.OWNER_ID) {
        await ctx.telegram.sendMessage(config.OWNER_ID, notif, {
          parse_mode: 'Markdown',
          disable_web_page_preview: true
        })
      }

    } catch (e) {
      console.error(e)
      return ctx.reply('🚫 Gagal mencari anime di Otakudesu.')
    }
  }
}