// plugins/anime/otakudesu.js
import fetch from 'node-fetch'
import { config } from '../../config.js'

export default {
  command: ['otakudesu'],
  tags: ['anime'],
  desc: '🔎 Cari anime dari Otakudesu',

  async handler(ctx) {
    const text = ctx.args.join(' ')
    const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name

    if (!text) return ctx.reply('📚 Masukkan judul anime!\n\nContoh: `/otakudesu naruto`', { parse_mode: 'Markdown' })

    try {
      const res = await fetch(`https://zenzxz.dpdns.org/anime/otakudesu?q=${encodeURIComponent(text)}`)
      const json = await res.json()

      if (!json.status || !json.result || json.result.length === 0) {
        return ctx.reply('❌ Anime tidak ditemukan. Coba dengan kata kunci lain.')
      }

      const result = json.result[0] // Ambil hasil pertama
      const caption = `
╭─❏ *📺 Hasil Otakudesu*
│ 🏷️ *Judul:* ${result.title}
│ 📁 *Status:* ${result.status}
│ 📅 *Rilis:* ${result.upload}
│ 🎞️ *Episode:* ${result.total_episode}
│ 🔗 *Link:* [Kunjungi](${result.link})
╰─────────────

📌 Ketik: /otakudesu judul_lain untuk cari lagi.
`.trim()

      // Coba kirim ke DM
      try {
        await ctx.telegram.sendPhoto(ctx.from.id, result.image, {
          caption,
          parse_mode: 'Markdown',
          disable_web_page_preview: false
        })

        await ctx.reply('✅ Anime dikirim ke DM kamu!')

        // Kirim notifikasi ke Owner
        await ctx.telegram.sendMessage(config.OWNER_ID, `
🎉 *Pencarian Otakudesu*
👤 *User:* ${username}
🔍 *Kata Kunci:* ${text}
📬 *Hasil:* ${result.title}
📎 *Link:* ${result.link}
📨 *Status:* Dikirim ke DM

_bot mendeteksi permintaan pencarian anime._
        `.trim(), { parse_mode: 'Markdown' })

      } catch (e) {
        await ctx.reply('⚠️ Tidak bisa kirim ke DM! Pastikan kamu sudah mulai chat bot ini.')
      }

    } catch (e) {
      console.error(e)
      await ctx.reply('❌ Gagal mengambil data. Server mungkin sedang down.')
    }
  }
}