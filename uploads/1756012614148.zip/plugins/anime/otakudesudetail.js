import axios from 'axios'

export default {
  command: ['otakudesudetail'],
  tags: ['anime'],
  desc: '📖 Lihat detail anime dari Otakudesu berdasarkan URL',
  usage: 'otakudesudetail <url otakudesu>',

  async handler(ctx) {
    const url = ctx.args[0]
    if (!url || !url.includes('otakudesu')) {
      return ctx.reply(`❗ *Masukkan URL anime Otakudesu yang valid!*

📌 Contoh:
.otakudesudetail https://otakudesu.cloud/anime/jjk-season-2-sub-indo/`)
    }

    try {
      const res = await axios.get(`https://zenzxz.dpdns.org/anime/otakudesu/detail?url=${encodeURIComponent(url)}`)
      const data = res.data.result

      if (!data) return ctx.reply('⚠️ Data tidak ditemukan.')

      const info = `
╭━━━〔 *📖 Detail Anime Otakudesu* 〕━━━⬣
┃ 🎞️ *Judul*: ${data.title}
┃ 🧪 *Skor*: ${data.score}
┃ 📡 *Produser*: ${data.produser}
┃ 📅 *Tayang*: ${data.rilis}
┃ 🎬 *Durasi*: ${data.duration}
┃ 🈷️ *Season*: ${data.season}
┃ 🧭 *Studio*: ${data.studio}
┃ 🌐 *Tipe*: ${data.type}
┃ 📚 *Total Episode*: ${data.total_eps}
┃ 🗂️ *Genre*: ${data.genre.join(', ')}
╰━━━━━━━━━━━━━━━━━━━━⬣

📖 *Sinopsis*:
_${data.synopsis.slice(0, 500)}..._

📥 *Daftar Episode (10 Pertama)*:
${data.episode_list.map((ep, i) => `*${i + 1}. [${ep.title}](${ep.link})*`).slice(0, 10).join('\n')}

🔗 Dan masih banyak episode lainnya...
`.trim()

      await ctx.replyWithPhoto({ url: data.thumb }, {
        caption: info,
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })

    } catch (e) {
      console.error(e)
      ctx.reply('🚫 *Gagal mengambil detail Otakudesu.*')
    }
  }
}