import axios from 'axios'
import { config } from '../../config.js' // pastikan OWNER_ID ada di config

export default {
  command: ['komikusearch'],
  tags: ['anime'],
  desc: '📚 Cari komik di Komiku',
  usage: '.komikusearch <judul komik>',

  async handler(ctx) {
    const query = ctx.args.join(' ')
    const userName = ctx.from.first_name || ctx.from.username || ctx.from.id
    const ownerId = config.OWNER_ID

    if (!query) {
      return ctx.reply(`❗ *Masukkan judul komik yang ingin dicari!*\n\nContoh:\n.komikusearch one piece`)
    }

    try {
      const res = await axios.get(`https://zenzxz.dpdns.org/anime/komikusearch?query=${encodeURIComponent(query)}`)
      const hasil = res.data.result

      if (!hasil || hasil.length === 0) {
        return ctx.reply('🚫 Komik tidak ditemukan.')
      }

      const teks = `
📚 *Hasil Pencarian Komiku*
🔍 *Query*: _${query}_

${hasil.slice(0, 10).map((k, i) => `🔹 *${i + 1}. ${k.title}*\n🔗 [Link](${k.link})`).join('\n\n')}

📝 Menampilkan maksimal 10 hasil...
      `.trim()

      // Kirim ke DM user
      await ctx.telegram.sendMessage(ctx.from.id, teks, {
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })

      // Notifikasi ke owner
      await ctx.telegram.sendMessage(ownerId, `📨 *Permintaan Komiku!*\n👤 Dari: [${userName}](tg://user?id=${ctx.from.id})\n🔍 Query: _${query}_`, {
        parse_mode: 'Markdown'
      })

      // Balasan di grup (atau chat awal)
      await ctx.reply('✅ Hasil pencarian komik telah dikirim via DM!')

    } catch (err) {
      console.error(err)
      ctx.reply('🚫 Terjadi kesalahan saat mencari komik.')
    }
  }
}