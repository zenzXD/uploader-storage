import axios from 'axios'
import { config } from '../../config.js' // pastikan ada OWNER_ID

export default {
  command: ['komikudetail'],
  tags: ['anime'],
  desc: '📖 Lihat detail komik dari Komiku',
  usage: '.komikudetail <link komiku>',

  async handler(ctx) {
    const link = ctx.args[0]
    const userName = ctx.from.first_name || ctx.from.username || ctx.from.id
    const ownerId = config.OWNER_ID

    if (!link || !link.includes('komiku.id')) {
      return ctx.reply(`❗ *Link tidak valid!*\nGunakan link dari komiku.id\n\nContoh:\n.komikudetail https://komiku.id/manga/one-piece/`)
    }

    try {
      const res = await axios.get(`https://zenzxz.dpdns.org/anime/komikudetail?link=${encodeURIComponent(link)}`)
      const data = res.data.result

      if (!data || !data.title) {
        return ctx.reply('🚫 Detail komik tidak ditemukan.')
      }

      const teks = `
📖 *Detail Komik Komiku*
╭─────────────⭓
├ 📚 *Judul:* ${data.title}
├ ✍️ *Penulis:* ${data.author}
├ 🎨 *Ilustrator:* ${data.ilustrator}
├ 📅 *Rilis:* ${data.release}
├ 🧩 *Genre:* ${data.genre}
├ 🔖 *Status:* ${data.status}
╰─────────────⭓

📌 *Deskripsi:*
_${data.synopsis.slice(0, 300)}..._

📚 *Daftar Chapter (10 terbaru):*
${data.chapter.slice(0, 10).map((c, i) => `🔹 [${c.title}](${c.link})`).join('\n')}

🔗 *Link Asli:* [Klik di sini](${link})
      `.trim()

      // DM ke user
      await ctx.telegram.sendMessage(ctx.from.id, teks, {
        parse_mode: 'Markdown',
        disable_web_page_preview: false
      })

      // Notifikasi ke owner
      await ctx.telegram.sendMessage(ownerId, `📨 *Permintaan Komiku Detail!*\n👤 Dari: [${userName}](tg://user?id=${ctx.from.id})\n🔗 Link: ${link}`, {
        parse_mode: 'Markdown'
      })

      // Balas di grup/chat
      await ctx.reply('✅ Detail komik telah dikirim ke DM kamu!')

    } catch (err) {
      console.error(err)
      ctx.reply('🚫 Gagal mengambil detail komik.')
    }
  }
}