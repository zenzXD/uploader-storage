import fs from 'fs'
import path from 'path'

export default {
  command: ['animemenu', 'animecmd'],
  tags: ['anime'],
  desc: '🌸 Daftar semua fitur bertema Anime',

  async handler(ctx) {
    const animeFolder = path.join(process.cwd(), 'plugins', 'anime')
    let files

    try {
      files = fs.readdirSync(animeFolder).filter(file => file.endsWith('.js'))
    } catch (err) {
      console.error(err)
      return ctx.reply('⚠️ Gagal membaca folder anime.')
    }

    if (!files.length) {
      return ctx.reply('🔍 Tidak ada fitur ditemukan di folder *anime*.')
    }

    let teks = `┏━━━━━━━━━━━━━🌸 *ANIME MENU* 🌸━━━━━━━━━━━━━┓\n`
    teks += `┃ ✦ Daftar fitur bertema anime untuk para wibu sejati! ✦\n`
    teks += `┃\n`

    for (const file of files) {
      try {
        const { default: plugin } = await import(`../anime/${file}`)
        const cmd = Array.isArray(plugin.command) ? plugin.command[0] : plugin.command
        const desc = plugin.desc || '✨ Tanpa deskripsi'
        teks += `┃ 🍙 *${cmd}* → ${desc}\n`
      } catch (e) {
        teks += `┃ ⚠️ Gagal memuat: ${file}\n`
      }
    }

    teks += `┃\n┃ 🐾 Gunakan command dengan mengetik: /animemenu\n`
    teks += `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`

    await ctx.reply(teks, { parse_mode: 'Markdown' })
  }
}