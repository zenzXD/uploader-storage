// plugins/fun/waifu.js
import fetch from "node-fetch";
import { config } from "../../config.js";

export default {
    command: ["waifu", "randomwaifu"],
    tags: ["anime"],
    desc: "🧸 Kirim gambar Waifu random ke DM",

    async handler(ctx) {
        try {
            const res = await fetch(
                "https://www.apis-anomaki.zone.id/random/randomwaifu"
            );
            const json = await res.json();
            const imageUrl = json?.url || json?.result;

            const username = ctx.from.username
                ? `@${ctx.from.username}`
                : ctx.from.first_name;

            // Coba kirim ke DM user
            try {
                await ctx.telegram.sendPhoto(
                    ctx.from.id,
                    {
                        url: imageUrl
                    },
                    {
                        caption: `
╭───〔 🧸 *Random Waifu* 〕───
│ 📷 *Source:* Anomaki API
│ 💖 *Request by:* ${username}
╰───────────────
        
Ketik lagi *waifu* untuk dapat waifu selanjutnya!
        `.trim()
                    }
                );

                // Notifikasi ke owner
                await ctx.telegram.sendMessage(
                    config.OWNER_ID,
                    `
📬 *Permintaan Random Waifu!*
👤 *User:* ${username}
🆔 *User ID:* \`${ctx.from.id}\`
🔗 *Link Foto:* [Klik untuk lihat](${imageUrl})

_bot mengirim Waifu via DM ke user._
        `.trim(),
                    { parse_mode: "Markdown", disable_web_page_preview: false }
                );

                await ctx.reply(
                    "✅ Waifu dikirim ke DM kamu, cek sekarang ya~ ✨"
                );
            } catch (e) {
                await ctx.reply(
                    "⚠️ Tidak bisa kirim ke DM kamu! Pastikan kamu sudah mulai chat dengan bot ini."
                );
            }
        } catch (err) {
            console.error(err);
            await ctx.reply("❌ Gagal mengambil waifu. Coba lagi nanti ya~");
        }
    }
};
