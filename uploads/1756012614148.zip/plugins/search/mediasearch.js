import axios from 'axios'

import * as cheerio from 'cheerio'

function shuffle(arr) {

  for (let i = arr.length - 1; i > 0; i--) {

    const j = Math.floor(Math.random() * (i + 1))

    ;[arr[i], arr[j]] = [arr[j], arr[i]]

  }

  return arr

}

async function mfsearch(query) {

  if (!query) throw new Error('Query is required')

  const { data: html } = await axios.get(`https://mediafiretrend.com/?q=${encodeURIComponent(query)}&search=Search`)

  const $ = cheerio.load(html)

  const links = shuffle(

    $('tbody tr a[href*="/f/"]').map((_, el) => $(el).attr('href')).get()

  ).slice(0, 5)

  const result = await Promise.all(links.map(async link => {

    const { data } = await axios.get(`https://mediafiretrend.com${link}`)

    const $ = cheerio.load(data)

    const raw = $('div.info tbody tr:nth-child(4) td:nth-child(2) script').text()

    const match = raw.match(/unescape\(['"`]([^'"`]+)['"`]\)/)

    const decoded = cheerio.load(decodeURIComponent(match[1]))

    return {

      filename: $('tr:nth-child(2) td:nth-child(2) b').text().trim(),

      filesize: $('tr:nth-child(3) td:nth-child(2)').text().trim(),

      url: decoded('a').attr('href'),

      source_url: $('tr:nth-child(5) td:nth-child(2)').text().trim(),

      source_title: $('tr:nth-child(6) td:nth-child(2)').text().trim()

    }

  }))

  return result

}

export default {

  command: ['mfsearch', 'mediafiresearch'],

  tags: ['search'],

  desc: '🔍 Cari file Mediafire berdasarkan keyword',

  async handler(ctx) {

    const query = ctx.text?.split(' ').slice(1).join(' ')

    const reply = (msg, opt) => ctx.reply(msg, opt)

    if (!query) {

      return reply(`❗ *Masukkan kata kunci pencarian!*

📌 *Contoh penggunaan:*

\`\`\`

/mfsearch config ff

/mfsearch data epep

\`\`\``, { parse_mode: 'Markdown' })

    }

    await reply('🛰️ *Sedang menghubungkan ke server Mediafire...*', { parse_mode: 'Markdown' })

    try {

      const results = await mfsearch(query)

      if (!results.length) {

        return reply('😔 *Tidak ada hasil ditemukan.*\nSilakan coba kata kunci lain.', {

          parse_mode: 'Markdown'

        })

      }

      const textResult = results.map((v, i) =>

        `📦 *${i + 1}. ${v.filename}*\n` +

        `🗂️ Size: *${v.filesize}*\n` +

        `🔗 [Download Link](${v.url})\n` +

        `📎 Source: [${v.source_title}](${v.source_url})`

      ).join('\n\n')

      await reply(`✨ *Hasil pencarian Mediafire untuk:* \`${query}\`\n\n${textResult}`, {

        parse_mode: 'Markdown',

        disable_web_page_preview: false

      })

    } catch (e) {

      console.error('mfsearch error:', e)

      await reply(`🚫 *Terjadi kesalahan saat mencari file:*\n\`\`\`${e.message}\`\`\``, {

        parse_mode: 'Markdown'

      })

    }

  }

}