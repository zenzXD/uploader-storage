
import axios from 'axios'
import * as cheerio from 'cheerio'

async function scrapeCodeShare(query) {
  const url = `https://codeshare.cloudku.click/?q=${encodeURIComponent(query)}`
  const res = await axios.get(url)
  const $ = cheerio.load(res.data)
  const results = []

  const cards = $('.snippet-card').toArray()

  for (const el of cards) {
    const card = $(el)
    const title = card.find('.card-title a').text().trim()
    const path = card.find('.card-title a').attr('href')
    const link = 'https://codeshare.cloudku.click' + path
    const author = card.find('.card-user .user-info').text().trim()
    const avatar = card.find('.card-user img').attr('src')
    const views = parseInt(card.find('.meta-item').first().text().replace(/\\D/g, '')) || 0
    const languageIcon = card.find('.meta-item i').attr('class') || ''
    const language = languageIcon.split('-').pop().replace('plain', '') || 'unknown'

    const rawUrl = link + '&raw=true'
    const raw = await axios.get(rawUrl)
    const fullCode = raw.data

    results.push({
      title,
      link,
      author,
      avatar: avatar ? 'https://codeshare.cloudku.click' + avatar : null,
      views,
      language,
      code: fullCode
    })
  }

  return {
    status: 200,
    total: results.length,
    data: results
  }
}

//═════════════════════════════════════════════//
//             📦 Telegram Handler              //
//═════════════════════════════════════════════//

export default {
  command: ['cscsearch'],
  tags: ['search'],
  help: ['cscsearch <query>'],
  desc: '🔎 Cari kode dari CodeShare',

  async handler(ctx) {
    const text = ctx.message?.text?.split(' ')?.slice(1)?.join(' ')?.trim()
    if (!text) return ctx.reply('✏️ *Contoh:* /cscsearch Hello World')

    try {
      const res = await scrapeCodeShare(text)
      if (res.total === 0) return ctx.reply('🚫 Tidak ada hasil ditemukan.')

      let teks = res.data.slice(0, 3).map((x, i) => {
        return `╭━━━〔 🔍 *Hasil ${i + 1}* 〕━━━⬣
┣ 📌 *Judul:* ${x.title}
┣ 👤 *Author:* ${x.author}
┣ 🌐 *Bahasa:* ${x.language}
┣ 👁️ *Views:* ${x.views}
┣ 🔗 *Link:* ${x.link}
┣ 💾 *Code:*
${x.code.slice(0, 500)}${x.code.length > 500 ? '...' : ''}
╰━━━━━━━━━━━━━━━━━━━━⬣`
      }).join('\\n\\n')

      ctx.reply(teks)
    } catch (e) {
      ctx.reply(`❌ *Eror:* ${e.message}`)
    }
  }
}
