import ytSearch from 'yt-search';

import  format from "telegraf/format";
const { bold, escapeMarkdown } = format;

export default {

  command: ['yts', 'ytsearch'],

  tags: ['search'],

  desc: '🔍 Cari video YouTube berdasarkan judul',

  async handler(ctx) {

    const text = ctx.message.text?.split(' ').slice(1).join(' ');

    if (!text) {

      return ctx.reply(

        '📌 Ketik judul YouTube yang ingin dicari.\n\nContoh:\n`/yts lathi weird genius`',

        { parse_mode: 'Markdown' }

      );

    }

    const results = await ytSearch(text);

    const videos = results.videos.slice(0, 10);

    if (!videos.length) {

      return ctx.reply('❌ Tidak ada hasil ditemukan.');

    }

    const first = videos[0];

    const caption = [

      `🔍 ${bold('Hasil YouTube untuk:')} _${escapeMarkdown(text)}_`,

      '',

      `🎬 ${bold('Judul:')} ${escapeMarkdown(first.title)}`,

      `📺 ${bold('Channel:')} ${escapeMarkdown(first.author.name)}`,

      `⏳ ${bold('Durasi:')} ${escapeMarkdown(first.timestamp)}`,

      `👁️ ${bold('Views:')} ${escapeMarkdown(first.views.toLocaleString())}`,

      `📅 ${bold('Upload:')} ${escapeMarkdown(first.ago)}`,

      `🔗 ${bold('Link:')} ${escapeMarkdown(first.url)}`

    ].join('\n');

    const buttons = videos.map(v => [{

      text: v.title.length > 40 ? v.title.slice(0, 37) + '...' : v.title,

      url: v.url

    }]);

    await ctx.replyWithPhoto(first.thumbnail, {

      caption,

      parse_mode: 'MarkdownV2',

      reply_markup: {

        inline_keyboard: buttons

      }

    });

  }

};