import fetch from "node-fetch";

import  format from "telegraf/format";
const { bold, escapeMarkdown } = format;
export default {

  command: ["bstationsearch", "bssearch"],

  tags: ["search"],

  desc: "🔍 Cari video Bilibili berdasarkan kata kunci (BStation)",

  async handler(ctx) {

    const query = ctx.text?.split(" ").slice(1).join(" ");

    const reply = (msg, opt) => ctx.reply(msg, opt);

    if (!query) {

      return reply(

        "❗️ *Kata kunci kosong!*\n\nGunakan contoh:\n```\n/bssearch spy family\n```",

        { parse_mode: "Markdown" }

      );

    }

    const apiKey = "planaai";

    const apiUrl = `https://www.sankavollerei.com/search/bstation-search?apikey=${apiKey}&q=${encodeURIComponent(query)}`;

    try {

      const res = await fetch(apiUrl);

      const data = await res.json();

      if (!data.status || !data.result || data.result.length === 0) {

        return reply("🚫 Tidak ada hasil ditemukan untuk query tersebut.");

      }

      const list = data.result.slice(0, 5).map((v, i) => {

        return `*${i + 1}.* [${escapeMarkdown(v.title)}](${v.url})\n● 🆔 ID: \`${v.id}\`\n● 👤 UP: ${escapeMarkdown(v.author)}\n● ❤️ ${v.likes.toLocaleString("id-ID")} • 👁️ ${v.views.toLocaleString("id-ID")}`;

      }).join("\n\n──────────────\n\n");

      return ctx.replyWithMarkdownV2(

        `✨ ${bold("Hasil BStation untuk:")} \`${escapeMarkdown(query)}\`\n\n${list}`,

        { disable_web_page_preview: false }

      );

    } catch (e) {

      console.error("Error BStationSearch:", e);

      return reply(`⚠️ Terjadi kesalahan saat mengambil data:\n\`${escapeMarkdown(e.message)}\``, { parse_mode: "MarkdownV2" });

    }

  }

};