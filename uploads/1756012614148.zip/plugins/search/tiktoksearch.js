import fetch from "node-fetch";

import  format from "telegraf/format";
const { bold, escapeMarkdown } = format;
export default {

  command: ["tiktoksearch", "ttsearch"],

  tags: ["search"],

  desc: "🔍 Cari video TikTok berdasarkan kata kunci",

  async handler(ctx) {

    const query = ctx.text?.split(" ").slice(1).join(" ");

    if (!query) {

      return ctx.reply(

        `❌ Masukkan kata kunci pencarian TikTok.\n\n📌 *Contoh:*\n\`\`\`\n/tiktoksearch honor of kings\n\`\`\``,

        { parse_mode: "Markdown" }

      );

    }

    const apiKey = "planaai";

    const apiUrl = `https://www.sankavollerei.com/search/tiktok?apikey=${apiKey}&q=${encodeURIComponent(query)}`;

    try {

      const response = await fetch(apiUrl);

      const data = await response.json();

      if (!data.status || !data.result || data.result.length === 0) {

        return ctx.reply("🚫 Tidak ditemukan hasil TikTok untuk kata kunci tersebut.");

      }

      const list = data.result.slice(0, 5).map((v, i) => {

        return `*${i + 1}. [${escapeMarkdown(v.title)}](${v.url})*\n👤 *${escapeMarkdown(v.author)}*\n❤️ ${v.likes?.toLocaleString("id-ID")} • 👁️ ${v.views?.toLocaleString("id-ID")}`;

      }).join("\n\n──────────────\n\n");

      return ctx.replyWithMarkdownV2(

        `✨ ${bold("Hasil TikTok untuk:")} \`${escapeMarkdown(query)}\`\n\n${list}`,

        { disable_web_page_preview: false }

      );

    } catch (e) {

      console.error("Error TikTokSearch:", e);

      return ctx.reply(`⚠️ Terjadi kesalahan:\n\`${escapeMarkdown(e.message)}\``, { parse_mode: "MarkdownV2" });

    }

  }

};