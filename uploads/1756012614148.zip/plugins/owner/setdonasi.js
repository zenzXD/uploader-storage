import fs from 'fs'

const filePath = './json/donasi.json'

export default {
  command: ['setdonasi'],
  tags: ['owner'],
  owner: true,
  desc: '🧾 Edit link donasi bot',

  async handler(ctx) {
    const text = ctx.message.text.split(' ').slice(1).join(' ')
    const [key, ...linkArr] = text.split('=')
    const link = linkArr.join('=').trim()

    if (!key || !link) {
      return ctx.reply('⚠️ Format:\n/setdonasi trakteer=https://trakteer.id/kamu\n/setdonasi dana=https://link.dana.id/xxxx')
    }

    const file = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : {}
    file[key.trim()] = link
    fs.writeFileSync(filePath, JSON.stringify(file, null, 2))

    return ctx.reply(`✅ Link *${key.trim()}* berhasil diperbarui!`)
  }
}