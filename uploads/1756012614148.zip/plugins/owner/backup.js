import fs from 'fs'
import path from 'path'
import archiver from 'archiver'
import { config } from '../../config.js'

const BACKUP_DIR = './'
const EXCLUDE = ['node_modules', '.git', '.DS_Store']

function getTimestamp() {
  const now = new Date()
  const pad = (n) => n.toString().padStart(2, '0')
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`
}

async function createBackupZip(onProgress) {
  return new Promise((resolve, reject) => {
    const timestamp = getTimestamp()
    const zipName = `backup-DonghuaBot-${timestamp}.zip`
    const output = fs.createWriteStream(zipName)
    const archive = archiver('zip', { zlib: { level: 9 } })

    output.on('close', () => resolve(zipName))
    archive.on('error', (err) => reject(err))
    archive.pipe(output)

    // Untuk menghitung total ukuran dan update progres real
    let totalBytes = 0
    let processedBytes = 0

    archive.on('progress', (data) => {
      totalBytes = data.fs.totalBytes || totalBytes
      processedBytes = data.fs.processedBytes || processedBytes
      if (totalBytes > 0) {
        const percent = Math.floor((processedBytes / totalBytes) * 100)
        onProgress(Math.min(percent, 100))
      }
    })

    function addDir(dirPath, base = '') {
      fs.readdirSync(dirPath).forEach((file) => {
        const fullPath = path.join(dirPath, file)
        const relPath = path.join(base, file)
        const stat = fs.statSync(fullPath)

        if (EXCLUDE.includes(file)) return
        if (stat.isDirectory()) {
          addDir(fullPath, relPath)
        } else {
          archive.file(fullPath, { name: relPath })
        }
      })
    }

    addDir(BACKUP_DIR)
    archive.finalize()
  })
}

export default {
  command: ['backupnow', 'backup'],
  tags: ['owner'],
  owner: true,
  desc: '📦 Backup data bot (khusus Owner)',

  async handler(ctx) {
    const senderId = String(ctx.from.id)
    const ownerId = String(config.OWNER_ID)

    if (senderId !== ownerId) {
      return ctx.reply('❌ *Perintah ini hanya dapat digunakan oleh Owner.*', { parse_mode: 'Markdown' })
    }

    let loadingMsg
    let lastProgress = -1

    try {
      loadingMsg = await ctx.reply('📦 Membuat backup...\n[░░░░░░░░░░] 0%\n📝 Status: *Menyiapkan file...*', {
        parse_mode: 'Markdown',
      })

      const updateProgress = async (val) => {
        if (val === lastProgress) return
        lastProgress = val
        const filled = '▓'.repeat(Math.floor(val / 10))
        const empty = '░'.repeat(10 - Math.floor(val / 10))

        const status = val < 100 ? 'Mengarsip file...' : 'Mengirim file...'

        const text = `📦 Membuat backup...\n[${filled}${empty}] ${val}%\n📝 Status: *${status}*`
        try {
          await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, undefined, text, {
            parse_mode: 'Markdown',
          })
        } catch (_) {}
      }

      const zipPath = await createBackupZip(updateProgress)

      const caption = `
╭━━〔 *✅ BACKUP SELESAI* 〕━━╮
├ 📦 *File:* \`${zipPath}\`
├ 📆 *Tanggal:* ${new Date().toLocaleString('id-ID', { timeZone: config.timezone })}
├ 📬 *Dikirim ke:* ${ctx.chat.type === 'private' ? 'Sini' : 'Private Chat'}
╰━━━━━━━━━━━━━━━━━━━━━━╯
      `.trim()

      if (ctx.chat.type !== 'private') {
        await ctx.reply('📬 Backup akan dikirim melalui chat pribadi...')
        await ctx.telegram.sendDocument(
          ownerId,
          { source: zipPath },
          { caption, parse_mode: 'Markdown' }
        )
      } else {
        await ctx.replyWithDocument(
          { source: zipPath },
          { caption, parse_mode: 'Markdown' }
        )
      }

      await fs.promises.unlink(zipPath)
    } catch (e) {
      console.error(e)
      await ctx.replyWithMarkdown(`
╭━━〔 *❌ BACKUP GAGAL* 〕━━╮
├ 📄 Alasan: \`${e.message || e}\`
╰━━━━━━━━━━━━━━━━━━━━━━╯
      `)
    } finally {
      if (loadingMsg) {
        ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {})
      }
    }
  }
}