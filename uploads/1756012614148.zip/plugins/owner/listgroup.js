import fs from "fs";

const whitelistPath = "./json/group_whitelist.json";
const groupsPath = "./json/groups.json";

export default {
    command: ["listgroup", "addwhitelist", "delwhitelist"],
    tags: ["owner"],
    owner: true,
    desc: "🛡️ Manajemen grup dan whitelist",

    async handler(ctx) {
        const cmd = ctx.message.text.split(" ")[0].toLowerCase();
        const args = ctx.message.text.split(" ").slice(1);
        const whitelist = JSON.parse(fs.readFileSync(whitelistPath));
        const groups = JSON.parse(fs.readFileSync(groupsPath));

        if (cmd === "/listgroup") {
            let text = `📊 *Daftar Grup Terdeteksi:*\n\n`;
            for (let g of groups) {
                const status = whitelist.includes(g.id)
                    ? "✅ Whitelist"
                    : "❌ Bukan";
                text += `🏷️ *${g.name}*\n🆔 \`${g.id}\`\n📆 Ditambahkan: ${g.date}\n🔐 Status: ${status}\n\n`;
            }
            return ctx.replyWithMarkdown(text);
        }

        if (cmd === "/addwhitelist") {
            if (!args[0])
                return ctx.reply(
                    "⚠️ Masukkan ID grup.\nContoh: /addwhitelist -1001234567890"
                );
            const gid = Number(args[0]);
            if (!whitelist.includes(gid)) {
                whitelist.push(gid);
                fs.writeFileSync(
                    whitelistPath,
                    JSON.stringify(whitelist, null, 2)
                );
                return ctx.reply(
                    `✅ Grup \`${gid}\` berhasil ditambahkan ke whitelist.`
                );
            } else return ctx.reply("⚠️ Grup sudah ada di whitelist.");
        }

        if (cmd === "/delwhitelist") {
            if (!args[0]) return ctx.reply("⚠️ Masukkan ID grup.");
            const gid = Number(args[0]);
            const idx = whitelist.indexOf(gid);
            if (idx >= 0) {
                whitelist.splice(idx, 1);
                fs.writeFileSync(
                    whitelistPath,
                    JSON.stringify(whitelist, null, 2)
                );
                return ctx.reply(`❌ Grup \`${gid}\` dihapus dari whitelist.`);
            } else return ctx.reply("⚠️ Grup tidak ada di whitelist.");
        }
    }
};
