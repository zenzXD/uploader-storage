export default {
  command: ['broadcast', 'adduser', 'addgroup', 'addchannel', 'deluser', 'delgroup', 'delchannel', 'listuser', 'listgroup', 'listchannel','broadcastupcoming'],
  tags: ['owner'],
  desc: 'Command internal untuk mengelola target dan broadcast',
  async handler(ctx) {
    const cmd = ctx.command.name;
    const args = ctx.message.text.split(' ').slice(1);
    switch (cmd) {
      case 'broadcast':
        if (!args.length) return ctx.reply('⚠️ Masukkan teks broadcast!');
        return ctx.reply(`🛰️ Broadcast ke target:\n${args.join(' ')}`);
      case 'adduser':
        return ctx.reply('✅ User ditambahkan (dummy)');
      default:
        return ctx.reply(`⚠️ Command ${cmd} belum dihandle.`);
    }
  }
};