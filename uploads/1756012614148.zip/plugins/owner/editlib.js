import path from 'path'
import fs from 'fs'
import { config } from '../../config.js'

export default {
  command: ['editlib'],
  tags: ['owner'],
  desc: '✏️ Edit isi file JavaScript di folder lib',

  async handler(ctx) {
    const userId = String(ctx.from?.id)
    const ownerId = config.OWNER_ID
    const isOwner = Array.isArray(ownerId)
      ? ownerId.map(String).includes(userId)
      : String(ownerId) === userId

    if (!isOwner) {
      return ctx.reply('🚫 *Perintah ini hanya dapat dijalankan oleh OWNER!*', { parse_mode: 'Markdown' })
    }

    const teks = ctx.text.trim().split(' ').slice(1).join(' ')
    const spasiPertama = teks.indexOf(' ')
    if (spasiPertama === -1) {
      return ctx.reply(
`╭─❍「 ⚠️ *Format Salah* 」
├ 🖊️ Gunakan: /editlib <namaFile> <kodeBaru>
│
├ 💡 Contoh:
│   /editlib helper export function hi() { return 'Hai!' }
╰─❍`, { parse_mode: 'Markdown' })
    }

    const namaFile = teks.slice(0, spasiPertama).trim()
    const kodeIsi = teks.slice(spasiPertama + 1).trim()

    if (!namaFile || !kodeIsi) {
      return ctx.reply('⚠️ *Nama file dan isi kode tidak boleh kosong!*', { parse_mode: 'Markdown' })
    }

    if (/[^a-z0-9_-]/i.test(namaFile)) {
      return ctx.reply('🚫 *Nama file tidak valid.* Hanya boleh huruf, angka, garis bawah (_), atau strip (-)', { parse_mode: 'Markdown' })
    }

    if (!kodeIsi.startsWith('export') && !kodeIsi.startsWith('import')) {
      return ctx.reply('⚠️ *Kode harus diawali dengan* `export` *atau* `import`.', { parse_mode: 'Markdown' })
    }

    const filePath = path.join(process.cwd(), 'lib', `${namaFile}.js`)

    if (!fs.existsSync(filePath)) {
      return ctx.reply(`❌ *File tidak ditemukan:* \`lib/${namaFile}.js\``, { parse_mode: 'Markdown' })
    }

    try {
      fs.writeFileSync(filePath, kodeIsi, 'utf-8')

      return ctx.reply(
`╭─❍「 ✅ *Berhasil Diedit* 」
├ 📁 File: \`lib/${namaFile}.js\`
├ ✏️ Status: Diperbarui
╰─❍`, { parse_mode: 'Markdown' })
    } catch (e) {
      return ctx.reply(`❌ *Gagal mengedit file:*\n\`\`\`${e.message}\`\`\``, {
        parse_mode: 'Markdown'
      })
    }
  }
}