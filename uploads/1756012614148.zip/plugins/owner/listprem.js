// plugins/owner/listprem.js
import { config } from "../../config.js";
import { listPremium } from '../../lib/premium.js';

export default {
  command: ["listprem"],
  tags: ["owner"],
  owner: true,
  desc: "📋 Lihat daftar user premium dari Google Sheet",
  async handler(ctx) {
    if (ctx.from?.id?.toString() !== config.OWNER_ID?.toString()) {
      return ctx.reply("🚫 Kamu bukan owner!");
    }

    const users = await listPremium(); // rename sesuai isi dari lib/premium.js
    if (!users.length) {
      return ctx.reply("📭 Tidak ada user premium di Sheet.");
    }

    const now = Date.now();
    const result = users.map((u, i) => {
      const sisa = Math.max(0, Math.floor((Number(u.expired) - now) / (1000 * 60 * 60 * 24)));
      return `*${i + 1}. User Premium*\n┏ 👤 ID: \`${u.id}\`\n┣ 🏷️ Nama: *${u.name}*\n┣ 🗓️ Mulai: \`${new Date(Number(u.started)).toLocaleDateString("id-ID")}\`\n┣ 📆 Exp: \`${new Date(Number(u.expired)).toLocaleDateString("id-ID")}\`\n┗ ⏳ Sisa: *${sisa} hari*`;
    }).join("\n━━━━━━━━━━━━━━\n");

    return ctx.reply(
      `┏━━━📋 *DAFTAR USER PREMIUM* ━━━\n┃ Total: *${users.length}*\n┗━━━━━━━━━━━━━━━━━━━━━━━━\n\n${result}`,
      { parse_mode: "Markdown" }
    );
  }
};