import { getLatestRequests } from '../../lib/googleSheet.js'
import { config } from '../../config.js'

export default {
  command: ['listreq'],
  tags: ['owner'],
  desc: '📄 Lihat 5 permintaan terbaru dari pengguna',

  async handler(ctx) {
    const senderId = String(ctx.from.id)
    const ownerId = String(config.OWNER_ID)

    if (senderId !== ownerId) {
      return await ctx.reply('🚫 *Fitur ini hanya bisa digunakan oleh Owner!*', { parse_mode: 'Markdown' })
    }

    try {
      const data = await getLatestRequests(5)

      if (!data.length) {
        return await ctx.reply('📭 Belum ada permintaan yang tercatat.')
      }

      let teks = `╭━━━❖ *📬 PERMINTAAN TERBARU* ❖━━━⬣\n┃`
      for (let i = 0; i < data.length; i++) {
        const d = data[i]
        teks += `
┃ ✦ *${i + 1}. Permintaan dari ${d.nama}*
┃ ┣ 🆔 ID: \`${d.id}\`
┃ ┣ 🔗 Username: ${d.username}
┃ ┣ 🌐 Asal: ${d.asal}
┃ ┣ 🕒 Waktu: ${d.waktu}
┃ ┗ 💬 Pesan:\n┃ \`\`\`
┃ ${(d.permintaan || '').slice(0, 200)}${(d.permintaan?.length > 200 ? '...' : '')}
┃ \`\`\`\n┃`
      }

      teks += `\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━⬣`

      await ctx.reply(teks.trim(), {
        parse_mode: 'Markdown',
      })
    } catch (e) {
      console.error('❌ Gagal ambil data:', e)
      await ctx.reply('⚠️ Gagal mengambil permintaan dari Google Sheet.')
    }
  },
}