import fs from 'fs'
import path from 'path'
import { loadPlugins } from '../../lib/loader.js'
import { config } from '../../config.js'

export default {
  command: ['addplugins'],
  tags: ['owner'],
  desc: '📦 Tambahkan plugin baru via command',
  owner: true,
  example: '/addplugins tools | hello.js | export default { command: ["hello"], handler(ctx) { ctx.reply("Hi!") } }',

  async handler(ctx) {
    const OWNER_ID = String(config.OWNER_ID)
    const senderId = String(ctx.from.id)

    if (senderId !== OWNER_ID) {
      return ctx.reply(
        `🚫 *Akses Ditolak!*\nPerintah ini hanya dapat digunakan oleh *Owner*.`,
        { parse_mode: 'Markdown' }
      )
    }

    const teks = ctx.body || ctx.message?.text || ''
    const input = teks.split('|').map(x => x.trim())

    if (input.length < 3) {
      return ctx.reply(
        `❗ *Format Salah!*\n\n` +
        `📌 Gunakan format:\n` +
        '```bash\n' +
        `/addplugins <folder> | <nama_file.js> | <kode_js>\n` +
        '```\n' +
        `✏️ Contoh:\n` +
        '```bash\n' +
        `/addplugins tools | hello.js | export default { command: ["hello"], handler(ctx) { ctx.reply("Hi!") } }\n` +
        '```',
        { parse_mode: 'Markdown' }
      )
    }

    const [folder, file, ...kodeArr] = input
    const kode = kodeArr.join('|')
    const folderPath = path.join('plugins', folder)
    const filePath = path.join(folderPath, file)

    try {
      if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true })

      if (fs.existsSync(filePath)) {
        return ctx.reply(`⚠️ Plugin \`${folder}/${file}\` sudah ada!`, { parse_mode: 'Markdown' })
      }

      fs.writeFileSync(filePath, kode)
      await loadPlugins()

      return ctx.reply(
        `✅ *Plugin Berhasil Ditambahkan!*\n\n` +
        `📁 *Folder:* \`${folder}\`\n` +
        `📄 *File:* \`${file}\`\n` +
        `🔁 Plugin berhasil dimuat ulang otomatis.`,
        { parse_mode: 'Markdown' }
      )
    } catch (e) {
      console.error('AddPlugin Error:', e)
      return ctx.reply(
        `❌ *Terjadi Kesalahan Saat Menulis Plugin:*\n\`\`\`\n${e.message}\n\`\`\``,
        { parse_mode: 'Markdown' }
      )
    }
  }
}