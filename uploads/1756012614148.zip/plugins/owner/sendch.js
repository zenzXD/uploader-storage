import fs from "fs";
import { config } from "../../config.js";

async function kirimAnimasiBoting(ctx) {
  const loadingMessages = [
    "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▒▒▒▒▒▒▒▒▒▒ 0%\n⏳ Memulai sistem...",
    "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▒▒▒▒▒▒▒▒▒ 25%\n🔍 Mengecek dependensi...",
    "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▒▒▒▒▒▒▒ 50%\n⚙️ Memproses metadata...",
    "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▓▓▒▒▒▒▒ 75%\n🔄 Menyusun modul...",
    "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▓▓▓▓▓▓▓ 100%\n✅ Sistem Siap Digunakan!"
  ];

  const first = await ctx.reply(loadingMessages[0], { parse_mode: "Markdown" });

  for (let i = 1; i < loadingMessages.length; i++) {
    await new Promise(res => setTimeout(res, 700)); // jeda 700ms tiap tahap
    await ctx.telegram.editMessageText(ctx.chat.id, first.message_id, null, loadingMessages[i], {
      parse_mode: "Markdown"
    });
  }

  return first;
}

export default {
  command: ["sendch"],
  tags: ["owner"],
  owner: true,
  desc: "📢 Kirim pesan ke channel owner (support reply)",

  async handler(ctx) {
    const ownerId = String(config.OWNER_ID || "");
    const senderId = String(ctx.from.id);

    if (ownerId !== senderId) {
      return await ctx.reply("🚫 *Khusus untuk owner bot!*", { parse_mode: "Markdown" });
    }

    try {
      const chatId = config.NOTIF_CHANNEL || "-1001234567890";
      const reply = ctx.message.reply_to_message;
      const textInput = ctx.text?.split(" ").slice(1).join(" ") || "";

      if (!reply && !textInput) {
        return await ctx.reply(
          "❌ *Gagal mengirim!*\nBalas pesan atau sertakan teks untuk dikirim.",
          { parse_mode: "Markdown" }
        );
      }

      // ⏳ Tampilkan animasi Boting...
      await kirimAnimasiBoting(ctx);

      const header = `╭━━━[ *📡 BROADCAST CHANNEL* ]━━━╮\n┃`;
      const footer = `\n╰━━━━━━━━━━━━━━━━━━━━━━╯`;
      const caption = `${header}\n┃ ${textInput || ""}${footer}`.trim().slice(0, 5000);

      if (reply) {
        const file =
          reply.document ||
          reply.photo?.slice(-1)[0] ||
          reply.video ||
          reply.audio ||
          reply.voice ||
          reply.sticker;

        const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;

        if (file) {
          const fileId = file.file_id;
          const type = reply.document
            ? "document"
            : reply.photo
            ? "photo"
            : reply.video
            ? "video"
            : reply.audio
            ? "audio"
            : reply.voice
            ? "voice"
            : reply.sticker
            ? "sticker"
            : null;

          if (!type) {
            return await ctx.reply("⚠️ *Tipe media tidak didukung.*", {
              parse_mode: "Markdown"
            });
          }

          await ctx.telegram.sendMessage(
            chatId,
            `🔄 *Mengirim ${type} ke channel...*\n👤 Dari: ${username}\n📝 Caption:\n${caption}`,
            { parse_mode: "Markdown" }
          );

          await ctx.telegram.sendMediaGroup(chatId, [
            {
              type,
              media: fileId,
              caption: type !== "sticker" ? caption : undefined,
              parse_mode: "Markdown"
            }
          ]);
        } else if (reply.text) {
          await ctx.telegram.sendMessage(chatId, caption, {
            parse_mode: "Markdown"
          });
        } else {
          return await ctx.reply("⚠️ *Balasan tidak dikenali.*", {
            parse_mode: "Markdown"
          });
        }
      } else {
        await ctx.telegram.sendMessage(chatId, caption, {
          parse_mode: "Markdown"
        });
      }

      await ctx.reply("✅ *Berhasil dikirim ke channel!*", {
        parse_mode: "Markdown"
      });
    } catch (err) {
      console.error("❌ Error sendch:", err);
      await ctx.reply(
        "🚫 *Gagal mengirim ke channel!*\nPeriksa ID channel di `config.js` atau error lainnya.",
        { parse_mode: "Markdown" }
      );
    }
  }
};