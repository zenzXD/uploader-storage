import fs from 'fs'
import path from 'path'
import { config } from '../../config.js'

export default {
  command: ['listlib'],
  tags: ['owner'],
  desc: '📂 Menampilkan daftar file di folder lib',

  async handler(ctx) {
    const userId = String(ctx.from?.id)
    const ownerId = config.OWNER_ID

    const isOwner = Array.isArray(ownerId)
      ? ownerId.map(String).includes(userId)
      : String(ownerId) === userId

    if (!isOwner) {
      return ctx.reply('🚫 *Perintah ini hanya dapat dijalankan oleh OWNER!*', { parse_mode: 'Markdown' })
    }

    const libDir = path.join(process.cwd(), 'lib')

    try {
      const files = fs.readdirSync(libDir)
        .filter(file => file.endsWith('.js'))

      if (!files.length) {
        return ctx.reply('📭 *Folder lib kosong atau tidak ada file .js*', { parse_mode: 'Markdown' })
      }

      const list = files
        .map((file, i) => `│ ${i + 1}. 📄 \`${file}\``)
        .join('\n')

      return ctx.reply(
`╭─❍「 *📚 Daftar File di Folder lib* 」
│
${list}
│
╰─❍ Total: *${files.length} file*`, {
        parse_mode: 'Markdown'
      })

    } catch (e) {
      return ctx.reply(`❌ *Gagal membaca folder lib:*\n\`\`\`${e.message}\`\`\``, {
        parse_mode: 'Markdown'
      })
    }
  }
}