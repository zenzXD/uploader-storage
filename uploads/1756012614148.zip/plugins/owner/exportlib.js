import fs from 'fs';
import path from 'path';
import { config } from '../../config.js';

export default {
  command: ['exportlib'],
  tags: ['owner'],
  desc: '📤 Kirim isi file lib/ sebagai kode ke owner',

  async handler(ctx) {
    const userId = ctx.from?.id?.toString();
    if (!config.OWNER_ID.includes(userId)) {
      return ctx.reply('🚫 Hanya owner yang bisa menggunakan perintah ini.');
    }

    const text = ctx.body?.split(' ')?.slice(1)?.join(' ')?.trim();
    if (!text) {
      return ctx.reply('✍️ Masukkan nama file, contoh: `/exportlib premium.js`');
    }

    const libDir = path.join(process.cwd(), 'lib');
    const filePath = path.join(libDir, text);

    if (!fs.existsSync(filePath)) {
      return ctx.reply(`❌ File \`${text}\` tidak ditemukan di \`lib/\``);
    }

    try {
      const content = fs.readFileSync(filePath, 'utf-8');

      await ctx.reply(
`╭─❍「 📄 Isi File: ${text} 」
│ 📁 Folder: lib/
│ 🔒 Akses: Owner
╰─❍\`\`\`js
${content.length > 3800 ? content.slice(0, 3800) + '\n// ...dipotong karena panjang.' : content}
\`\`\``
      );
    } catch (e) {
      return ctx.reply(`❌ Gagal membaca file:\n\`\`\`${e.message}\`\`\``);
    }
  }
};