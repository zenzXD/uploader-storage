import fs from 'fs';
import path from 'path';

const dbPath = path.join('json', 'premium.json');

export default {
  command: ['delprem', 'hapusprem'],
  tags: ['owner'],
  desc: '🗑️ Hapus user dari daftar premium',

  async handler(ctx) {
    if (!ctx.isOwner) return ctx.reply('🚫 *Khusus Owner!*', { parse_mode: 'Markdown' });

    const args = ctx.text.trim().split(/\s+/);
    const targetId = args[1] || ctx.message?.reply_to_message?.from?.id;

    if (!targetId) {
      return ctx.reply(
        `╭─❗ *Format Salah!*
│ Gunakan:
│ ➤ \`/delprem [id]\`
│ ➤ atau balas user: \`/delprem\`
╰───────────────`, { parse_mode: 'Markdown' });
    }

    const id = String(targetId);

    if (!fs.existsSync(dbPath)) {
      return ctx.reply('📂 *Data premium belum dibuat.*', { parse_mode: 'Markdown' });
    }

    const data = JSON.parse(fs.readFileSync(dbPath));

    if (!(id in data)) {
      return ctx.reply(`⚠️ *User dengan ID* \`${id}\` *bukan premium!*`, { parse_mode: 'Markdown' });
    }

    const name = ctx.message?.reply_to_message?.from?.first_name || 'User';
    delete data[id];
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

    const teks = `╭── 🎟️ *PREMIUM DIBATALKAN*
│ 👤 [${name}](tg://user?id=${id})
│ 🆔 ID: \`${id}\`
│ ❌ Status: *Non-Premium*
╰──────────────────────`;

    await ctx.reply(teks, { parse_mode: 'Markdown' });

    // Notifikasi ke user
    try {
      await ctx.telegram.sendMessage(id, `⚠️ *PREMIUM kamu telah dicabut oleh Owner.*\n\nJika ini kesalahan, silakan hubungi Admin.`, {
        parse_mode: 'Markdown'
      });
    } catch (e) {
      console.log(`[delprem] Gagal kirim DM ke ${id}`);
    }
  }
};