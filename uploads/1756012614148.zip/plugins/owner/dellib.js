import path from 'path'
import fs from 'fs'
import { config } from '../../config.js'

export default {
  command: ['delib'],
  tags: ['owner'],
  desc: '🗑️ Hapus file JavaScript dari folder lib',

  async handler(ctx) {
    const userId = String(ctx.from?.id)
    const ownerId = config.OWNER_ID

    const isOwner = Array.isArray(ownerId)
      ? ownerId.map(String).includes(userId)
      : String(ownerId) === userId

    if (!isOwner) {
      return ctx.reply('🚫 *Perintah ini hanya dapat dijalankan oleh OWNER!*', { parse_mode: 'Markdown' })
    }

    const namaFile = ctx.text.split(' ')[1]?.trim()

    if (!namaFile) {
      return ctx.reply(
`╭─❍「 ⚠️ *Format Salah* 」
├ 📥 Cara pakai:
│   /delib <namaFile>
│
├ 💡 Contoh:
│   /delib helper
╰─❍`, { parse_mode: 'Markdown' })
    }

    if (/[^a-zA-Z0-9_-]/.test(namaFile)) {
      return ctx.reply('🚫 *Nama file tidak valid.* Hanya huruf, angka, garis bawah (_) dan strip (-) yang diizinkan.', { parse_mode: 'Markdown' })
    }

    const libDir = path.join(process.cwd(), 'lib')
    const filePath = path.join(libDir, `${namaFile}.js`)

    try {
      if (!fs.existsSync(filePath)) {
        return ctx.reply(`❌ *File tidak ditemukan:* \`lib/${namaFile}.js\``, { parse_mode: 'Markdown' })
      }

      fs.unlinkSync(filePath)

      return ctx.reply(
`╭─❍「 ✅ *File Dihapus* 」
├ 🗑️ File: \`lib/${namaFile}.js\`
├ 📌 Status: *Terhapus*
╰─❍`, { parse_mode: 'Markdown' })
    } catch (e) {
      return ctx.reply(`❌ *Gagal menghapus file:*\n\`\`\`${e.message}\`\`\``, { parse_mode: 'Markdown' })
    }
  }
}