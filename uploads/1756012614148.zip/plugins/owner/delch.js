import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { bold, code } from 'telegraf/format'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

export default {
  command: ['delidch', 'delch'],
  tags: ['owner'],
  owner: true,
  desc: '🗑️ Hapus ID Channel dari database',

  async handler(ctx) {
    const text = ctx.message.text?.split(' ')?.slice(1)?.join(' ')
    if (!text) return ctx.reply(`✏️ Contoh penggunaan:\n/delch ${code('@channelusername')}`)

    const dbPath = path.join(__dirname, '../../json/listidch.json')
    let listidch = []

    try {
      listidch = JSON.parse(fs.readFileSync(dbPath))
    } catch {
      return ctx.reply(`⚠️ ${bold('Database tidak ditemukan.')}`)
    }

    if (!listidch.includes(text)) {
      return ctx.reply(`❌ ID ${code(text)} tidak ditemukan dalam database.`)
    }

    listidch = listidch.filter(id => id !== text)
    fs.writeFileSync(dbPath, JSON.stringify(listidch, null, 2))

    ctx.reply(`✅ ${bold('Berhasil menghapus')} ID ${code(text)} dari database.`)
  }
}