import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { bold, italic, code } from 'telegraf/format'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

export default {
  command: ['listidch', 'listch'],
  tags: ['owner'],
  owner: true,
  desc: '📋 Lihat semua ID Channel yang tersimpan',

  async handler(ctx) {
    const dbPath = path.join(__dirname, '../../json/listidch.json')
    let listidch = []

    try {
      listidch = JSON.parse(fs.readFileSync(dbPath))
    } catch {
      return ctx.reply(`📂 ${bold('Database kosong!')}\nBelum ada ID channel yang tersimpan.`)
    }

    if (listidch.length === 0) {
      return ctx.reply(`📂 ${bold('Database kosong!')}\nBelum ada ID channel yang tersimpan.`)
    }

    const list = listidch.map((id, i) => `${i + 1}. ${code(id)}`).join('\n')
    const message = `📋 ${bold('Daftar ID Channel Tersimpan:')}\n\n${list}\n\n🧮 ${bold('Total:')} ${listidch.length} channel`
    
    ctx.reply(message, { parse_mode: 'Markdown' })
  }
}