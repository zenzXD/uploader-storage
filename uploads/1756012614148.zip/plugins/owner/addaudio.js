import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import { config } from '../../config.js';

export default {
  command: ['addaudio'],
  tags: ['owner'],
  desc: '🎵 Tambahkan file audio ke kategori menu atau notif (khusus owner)',

  async handler(ctx) {
    const userId = String(ctx.from.id);
    if (userId !== config.OWNER_ID) {
      return ctx.reply(
        '🚫 *Akses Ditolak\\!*\n\n' +
        'Hanya *OWNER* yang dapat menggunakan perintah ini\\.\n' +
        '_Hubungi admin jika menurutmu ini kesalahan\\._',
        { parse_mode: 'MarkdownV2' }
      );
    }

    const args = ctx.text.trim().split(/\s+/);
    const kategori = args[1]?.toLowerCase();
    const nama = args[2];

    if (!kategori || !['menu', 'notif'].includes(kategori)) {
      return ctx.reply(
        '❗ *Format Salah\\!*\n\n' +
        '📌 Gunakan:\n' +
        '`/addaudio [menu|notif] [namafile]`\n\n' +
        '🔉 Contoh:\n' +
        '`/addaudio menu opening`\n\n' +
        '📝 *Catatan:* Balas pesan audio/mp3/voice yang ingin disimpan\\.',
        { parse_mode: 'MarkdownV2' }
      );
    }

    if (!nama || /[^a-zA-Z0-9_\-]/.test(nama)) {
      return ctx.reply(
        '⚠️ *Nama File Tidak Valid\\!*\n\n' +
        'Nama hanya boleh mengandung huruf, angka, `_` atau `-`\.\n' +
        '✅ Contoh valid:\n' +
        '`/addaudio notif startup_sound`',
        { parse_mode: 'MarkdownV2' }
      );
    }

    const audioMsg = ctx.message?.audio || ctx.message?.document || ctx.message?.voice;
    if (!audioMsg) {
      return ctx.reply(
        '🎧 *Tidak ada audio ditemukan\\!*\n\n' +
        'Balas pesan yang berisi file audio, mp3, atau voice untuk disimpan\\.',
        { parse_mode: 'MarkdownV2' }
      );
    }

    // BOTING effect
    const botingSteps = [
      '*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▒▒▒▒▒▒▒▒▒▒ 0%\n⏳ Memulai sistem...',
      '*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▒▒▒▒▒▒▒▒▒ 25%\n🔍 Mengecek dependensi...',
      '*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▒▒▒▒▒▒▒ 50%\n⚙️ Memproses metadata...',
      '*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▓▓▒▒▒▒▒ 75%\n🔄 Menyusun modul...',
      '*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▓▓▓▓▓▓▓ 100%\n✅ Sistem Siap Digunakan!'
    ];

    let msg = await ctx.reply(botingSteps[0], { parse_mode: 'MarkdownV2' });

    for (let i = 1; i < botingSteps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 700));
      await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, botingSteps[i], {
        parse_mode: 'MarkdownV2'
      });
    }

    const folderPath = path.join('audio', kategori);
    const filePath = path.join(folderPath, `${nama}.mp3`);

    try {
      if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath, { recursive: true });
      }

      const fileLink = await ctx.telegram.getFileLink(audioMsg.file_id);
      const res = await fetch(fileLink.href);
      const buffer = await res.arrayBuffer();

      fs.writeFileSync(filePath, Buffer.from(buffer));

      return ctx.reply(
        '✅ *Berhasil Menyimpan Audio\\!*\n\n' +
        `🗂 *Kategori:* \`${kategori}\`\n` +
        `🎵 *Nama:* \`${nama}.mp3\`\n` +
        `📁 *Lokasi:* \`audio/${kategori}/${nama}.mp3\`\n\n` +
        '🔔 Sekarang audio ini bisa digunakan untuk keperluan *' + kategori + '* kamu\\!',
        { parse_mode: 'MarkdownV2' }
      );
    } catch (e) {
      console.error('[addaudio error]', e);
      return ctx.reply(
        '❌ *Terjadi Kesalahan Saat Menyimpan\\!*\n\n' +
        '🚫 Error:\n' +
        '```' + e.message.replace(/`/g, '') + '```',
        { parse_mode: 'MarkdownV2' }
      );
    }
  }
};