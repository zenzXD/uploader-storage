import fs from 'fs'
import path from 'path'
import { spawn } from 'child_process'
import { config } from '../../config.js'

export default {
  command: ['updatebot', 'updateversi'],
  tags: ['owner'],
  owner: true,
  desc: '🔄 Update versi & informasi bot di package.json + restart',

  async handler(ctx) {
    const userId = String(ctx.from.id)
    const ownerId = String(config.OWNER_ID)

    if (userId !== ownerId) {
      return ctx.reply('🚫 *Perintah ini hanya dapat dijalankan oleh OWNER!*', { parse_mode: 'Markdown' })
    }

    const args = ctx.text?.trim().split(/\s+/) || []
    const versiBaru = args[1]
    const changelog = args.slice(2).join(' ') || 'Tidak ada catatan perubahan.'

    if (!versiBaru || !/^\d+\.\d+\.\d+$/.test(versiBaru)) {
      return ctx.reply(
        `🚫 *Format versi tidak valid!*\n\n` +
        `📌 Penggunaan:\n` +
        `\`/updatebot [versi] [changelog opsional]\`\n\n` +
        `📎 Contoh:\n\`/updatebot 3.1.0 Perbaikan error & penambahan fitur\``,
        { parse_mode: 'Markdown' }
      )
    }

    try {
      const filePath = path.join(process.cwd(), 'package.json')
      const pkg = JSON.parse(fs.readFileSync(filePath, 'utf-8'))

      const nowISO = new Date().toISOString()
      const nowLocale = new Date().toLocaleString('id-ID')

      pkg.version = versiBaru
      pkg.updatedAt = nowISO
      pkg.lastupdate = nowLocale
      pkg.changelog = changelog

      fs.writeFileSync(filePath, JSON.stringify(pkg, null, 2))

      const infoMessage = `
╭━━━〔 🛠️ *UPDATE BOT BERHASIL* 〕━━⬣
┃ 🔖 *Versi Baru:* v${versiBaru}
┃ 🗓️ *Tanggal:* ${nowLocale}
┃ 👤 *Updater:* @${ctx.from.username || ctx.from.first_name || 'Unknown'}
┃
┃ 📋 *Changelog:*
${changelog.split('\n').map(line => `┃ ${line}`).join('\n')}
┃
┃ ♻️ *Bot akan segera di-*__*RESTART*__
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

      await ctx.reply(infoMessage, { parse_mode: 'Markdown' })

      const logChannelId = '-1002778325483'
      await ctx.telegram.sendMessage(logChannelId, infoMessage, { parse_mode: 'Markdown' })

      setTimeout(() => {
        const child = spawn('node', ['LinQiye.js'], {
          cwd: process.cwd(),
          detached: true,
          stdio: 'ignore'
        })
        child.unref()
        process.exit()
      }, 3000)

    } catch (error) {
      console.error('[UpdateBot Error]', error)
      return ctx.reply('❌ *Terjadi kesalahan saat memperbarui versi bot.*', { parse_mode: 'Markdown' })
    }
  }
}