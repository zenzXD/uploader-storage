import { google } from "googleapis";
import path from "path";
import { config } from "../../config.js"; // pastikan path sesuai dengan file config-mu

const SHEET_ID = "1dyK_66DxSMQv1e-fng_bew8U2_oL898YwY3dHOKZdqg";
const SHEET_RANGE = "Users!A2:E"; // Ubah ke sheet "Users"

async function authorize() {
    const auth = new google.auth.GoogleAuth({
        keyFile: path.resolve("./credentials.json"),
        scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"]
    });
    return await auth.getClient();
}

async function readUsersFromSheet() {
    const authClient = await authorize();
    const sheets = google.sheets({ version: "v4", auth: authClient });

    const res = await sheets.spreadsheets.values.get({
        spreadsheetId: SHEET_ID,
        range: SHEET_RANGE
    });

    return res.data.values || [];
}

export default {
    command: ["listuser"],
    tags: ["owner"],
    owner: true,
    desc: "📄 Menampilkan semua user dari Google Sheet",

    async handler(ctx) {
        try {
            const senderId = String(ctx.from.id);
            const OWNER_ID = String(config.OWNER_ID); // hanya satu ID (bukan array)

            if (senderId !== OWNER_ID) {
                return ctx.reply(
                    "❌ Akses ditolak. Fitur ini hanya untuk Owner."
                );
            }

            const rows = await readUsersFromSheet();

            if (!rows.length) {
                return ctx.reply("📭 Tidak ada data pengguna di Google Sheet.");
            }

            let teks = `📄 *Daftar Pengguna Bot dari Google Sheet*\n\n`;

            for (let i = 0; i < rows.length; i++) {
                const [id, nama, username, bahasa, role] = rows[i];

                teks += `╭───⟪ 👤 Pengguna #${i + 1} ⟫───\n`;
                teks += `├ 🆔 *ID Telegram:* \`${id || "Tidak ada"}\`\n`;
                teks += `├ 📝 *Nama:* ${nama || "Tidak ada"}\n`;
                teks += `├ 🧷 *Username:* @${username || "Tidak ada"}\n`;
                teks += `├ 🌐 *Bahasa:* ${bahasa || "Tidak ada"}\n`;
                teks += `├ 🎖️ *Role:* ${role || "Free"}\n`;
                teks += `╰────────────────────\n\n`;
            }

            teks += `📊 Total Pengguna: *${rows.length}*`;

            return ctx.reply(teks, { parse_mode: "Markdown" });
        } catch (err) {
            console.error("[ListUser Error]", err);
            return ctx.reply("❌ Gagal mengambil data dari Google Sheet.");
        }
    }
};
