import util from 'util'

import { config } from '../../config.js'

const OWNER_ID = config.OWNER_ID // harus string atau number, bukan array

export default {

  command: ['eval', 'ev'],

  tags: ['owner'],

  desc: '📟 Menjalankan kode JavaScript (hanya untuk Owner)',

  owner: true,

  async handler(ctx) {

    const userId = ctx.from?.id?.toString()

    const isOwner = userId === OWNER_ID.toString()

    if (!isOwner) return ctx.reply('🚫 *Akses ditolak!*\nPerintah ini hanya bisa digunakan oleh Owner.', {

      parse_mode: 'Markdown'

    })

    const code = ctx.message?.text?.split(' ').slice(1).join(' ')

    if (!code) return ctx.reply('💡 *Contoh penggunaan:*\n`/eval 2 + 2`', {

      parse_mode: 'Markdown'

    })

    try {

      const start = performance.now()

      let result = await eval(`(async () => { ${code} })()`)

      const end = performance.now()

      if (typeof result !== 'string') result = util.inspect(result)

      if (result.length > 4000) result = result.slice(0, 4000) + '... 🔻 [terpotong]'

      await ctx.reply(

`🎯 *Eval Result*

╭───────────────╮

│ 🧠 *Input:* \`${code}\`

╰───────────────╯

\`\`\`js

${result}

\`\`\`

⏱️ *Waktu Eksekusi:* \`${(end - start).toFixed(2)}ms\`

`, {

        parse_mode: 'Markdown'

      })

    } catch (e) {

      await ctx.reply(

`❌ *Terjadi Error*

\`\`\`js

${e.message}

\`\`\`

`, {

        parse_mode: 'Markdown'

      })

    }

  }

}