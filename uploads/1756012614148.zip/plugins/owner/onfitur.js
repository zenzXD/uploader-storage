import fs from 'fs'
import path from 'path'

const fiturPath = './json/fitur_disabled.json'
const userPath = './json/broadcast_user.json'
const groupPath = './json/broadcast_group.json'
const channelPath = './json/broadcast_channel.json'

export default {
  command: ['onfitur'],
  tags: ['owner'],
  owner: true,
  desc: '🔧 Mengaktifkan fitur tertentu',

  async handler(ctx) {
    const args = ctx.message.text.split(' ').slice(1)
    const target = args[0]

    if (!target) {
      return ctx.reply(
        `╭───〔 ❌ *FORMAT SALAH* 〕
│ 
├ 💡 *Contoh Penggunaan:*
│    /onfitur [nama_command]
│ 
├ 🧩 *Contoh Nyata:*
│    /onfitur helpjson
╰─────────────────────`,
        { parse_mode: 'Markdown' }
      )
    }

    const fiturOff = fs.existsSync(fiturPath)
      ? JSON.parse(fs.readFileSync(fiturPath))
      : {}

    if (!fiturOff[target]) {
      return ctx.reply(
        `╭───〔 ⚠️ *FITUR AKTIF* 〕
│ 
├ 📌 *Fitur:* \`${target}\`
├ 🔓 Status: *Sudah Aktif*
│ 
╰ ✅ Tidak perlu diaktifkan ulang.`,
        { parse_mode: 'Markdown' }
      )
    }

    // Aktifkan kembali fiturnya
    delete fiturOff[target]
    fs.writeFileSync(fiturPath, JSON.stringify(fiturOff, null, 2))

    // Notifikasi ke admin (yang menjalankan perintah)
    await ctx.reply(
      `╭───〔 ✅ *FITUR DIAKTIFKAN* 〕
│ 
├ 📌 *Fitur:* \`${target}\`
├ 🔓 Status: *Telah Diaktifkan*
├ 🛠️ *Siap digunakan kembali!*
│ 
╰ 🎉 Terima kasih telah mengelola fitur dengan bijak.`,
      { parse_mode: 'Markdown' }
    )

    // ===== Broadcast ke semua user, grup, dan channel ===== //
    const notif = `📢 *Pemberitahuan Otomatis!*\n\n✅ Fitur \`${target}\` telah diaktifkan kembali oleh Developer.\n\nSilakan gunakan kembali fitur ini di menu yang tersedia.\n\nTerima kasih 🙏`

    const parseOptions = { parse_mode: 'Markdown' }

    const sendNotif = async (id) => {
      try {
        await ctx.telegram.sendMessage(id, notif, parseOptions)
      } catch (e) {
        console.log(`Gagal kirim ke ${id}:`, e.message)
      }
    }

    // Kirim ke user
    if (fs.existsSync(userPath)) {
      const users = JSON.parse(fs.readFileSync(userPath))
      for (const id of users) await sendNotif(id)
    }

    // Kirim ke grup
    if (fs.existsSync(groupPath)) {
      const groups = JSON.parse(fs.readFileSync(groupPath))
      for (const id of groups) await sendNotif(id)
    }

    // Kirim ke channel
    if (fs.existsSync(channelPath)) {
      const channels = JSON.parse(fs.readFileSync(channelPath))
      for (const id of channels) await sendNotif(id)
    }
  }
}