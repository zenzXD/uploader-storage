export default {

  command: ['leavegroup', 'leavegc'],

  owner: true,

  desc: '👋 Perintah untuk bot keluar dari grup',

  async handler(ctx) {

    const reply = ctx.message?.reply_to_message

    const text = ctx.message.text.split(' ')[1]

    const targetId = reply?.chat?.id || text

    if (!targetId) {

      return ctx.reply(

        `🚪 *Keluar Grup*\n` +

        `╭─────────────\n` +

        `│ Kirim ID grup:\n` +

        `│ • /leavegroup -100xxxx\n` +

        `│ atau reply pesan dari grup\n` +

        `╰─────────────`, {

          parse_mode: 'Markdown'

        }

      )

    }

    try {

      const info = await ctx.telegram.getChat(targetId)

      await ctx.telegram.leaveChat(targetId)

      return ctx.reply(

        `✅ *Bot telah keluar dari grup!*\n` +

        `╭─────────────\n` +

        `│ 📛 Nama: *${info.title || 'Tidak diketahui'}*\n` +

        `│ 🆔 ID: \`${info.id}\`\n` +

        `╰─────────────`, {

          parse_mode: 'Markdown'

        }

      )

    } catch (e) {

      console.error('❌ Gagal keluar:', e)

      return ctx.reply(

        `❌ *Gagal keluar dari grup!*\n` +

        `📄 *Error:* \`${e.message || e}\``, {

          parse_mode: 'Markdown'

        }

      )

    }

  }

}