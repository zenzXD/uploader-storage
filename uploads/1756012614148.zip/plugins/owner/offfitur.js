import fs from 'fs'
import path from 'path'
import { config } from '../../config.js'

const fiturPath = './json/fitur_disabled.json'

function loadDisabledFitur() {
  if (!fs.existsSync(fiturPath)) fs.writeFileSync(fiturPath, '{}')
  return JSON.parse(fs.readFileSync(fiturPath))
}

function saveDisabledFitur(data) {
  fs.writeFileSync(fiturPath, JSON.stringify(data, null, 2))
}

export default {
  command: ['offfitur', 'disablefitur'],
  tags: ['owner'],
  owner: true,
  desc: '🚫 Menonaktifkan fitur tertentu di bot',

  async handler(ctx) {
    const fitur = ctx.args[0]?.toLowerCase()
    const alasan = ctx.args.slice(1).join(' ') || 'Tanpa alasan spesifik'

    if (!fitur) {
      return ctx.reply(`
╭━━〔 🚫 *MENONAKTIFKAN FITUR* 〕━━⬣
┃
┃ 📌 *Perintah:* \`/offfitur [nama_command] [alasan]\`
┃ 🧩 *Contoh:* \`/offfitur helpjson Maintenance\`
┃
┃ 💡 Balas dengan nama command yang ingin dimatikan,
┃ disertai alasan yang jelas.
╰━━━━━━━━━━━━━━━━━━━━⬣
`.trim(), { parse_mode: 'Markdown' })
    }

    const fiturData = loadDisabledFitur()

    if (fiturData[fitur]?.status) {
      return ctx.reply(`
╭━━〔 ⚠️ *FITUR SUDAH NONAKTIF* 〕━━⬣
┃
┃ 📌 *Fitur:* \`${fitur}\`
┃ 🚫 Tidak perlu dinonaktifkan ulang.
╰━━━━━━━━━━━━━━━━━━━━⬣
`.trim(), { parse_mode: 'Markdown' })
    }

    fiturData[fitur] = {
      status: true,
      reason: alasan,
      disabledAt: new Date().toISOString(),
      disabledBy: ctx.from?.username || ctx.from?.first_name || 'Unknown'
    }
    saveDisabledFitur(fiturData)

    const log = `
╭━━〔 🔒 *NOTIFIKASI PENONAKTIFAN FITUR* 〕━━⬣
┃
┃ 🛠️ *Fitur:* \`${fitur}\`
┃ ❗ *Alasan:* ${alasan}
┃ 👤 *Oleh:* ${ctx.from?.first_name} (${ctx.from?.id})
┃ 🕒 *Waktu:* ${new Date().toLocaleString('id-ID')}
╰🚨 *Fitur dinonaktifkan sementara hingga diaktifkan ulang.*
`.trim()

    await ctx.reply(`
╭━━〔 ✅ *FITUR DIMATIKAN* 〕━━⬣
┃
┃ 📌 *Fitur:* \`${fitur}\`
┃ 🔒 *Status:* Nonaktif
┃ 📝 *Alasan:* ${alasan}
╰📡 *Notifikasi dikirim ke grup admin.*
`.trim(), { parse_mode: 'Markdown' })

    if (config.NOTIF_CHANNEL) {
      await ctx.telegram.sendMessage(config.NOTIF_CHANNEL, log, { parse_mode: 'Markdown' }).catch(() => {})
    }
  }
}