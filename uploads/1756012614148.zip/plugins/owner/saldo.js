import fs from 'fs'
import { config } from '../../config.js'

const userPath = './json/users.json'
const logPath = './json/saldo-log.json'

function loadUsers() {
  return fs.existsSync(userPath) ? JSON.parse(fs.readFileSync(userPath)) : []
}

function saveUsers(data) {
  fs.writeFileSync(userPath, JSON.stringify(data, null, 2))
}

function logSaldo({ userId, amount, by, type }) {
  const logs = fs.existsSync(logPath) ? JSON.parse(fs.readFileSync(logPath)) : []
  logs.push({
    userId,
    amount,
    type,
    by,
    time: new Date().toLocaleString('id-ID')
  })
  fs.writeFileSync(logPath, JSON.stringify(logs, null, 2))
}

export const tags = ['owner', 'saldo']
export const command = ['setsaldo', 'addsaldo', 'kurangsaldo', 'riwayatsaldo']
export const desc = '💼 Kelola saldo user (hanya untuk owner)'

export default function (bot) {
  bot.command(['setsaldo', 'addsaldo', 'kurangsaldo'], async (ctx) => {
    const senderId = String(ctx.from.id)
    const ownerId = String(config.OWNER_ID)

    if (senderId !== ownerId) return ctx.reply('❌ Hanya owner yang dapat menggunakan perintah ini.')

    const [cmd, targetId, nominalStr] = ctx.message.text.trim().split(' ')
    const amount = parseInt(nominalStr)

    if (!targetId || isNaN(amount) || amount < 0)
      return ctx.reply(`⚠️ Format salah!\nGunakan:\n/${cmd} <id> <jumlah>`)

    const users = loadUsers()
    const user = users.find(u => String(u.id) === targetId)

    if (!user) return ctx.reply('🚫 User tidak ditemukan.')

    if (cmd === 'setsaldo') {
      user.saldo = amount
    } else if (cmd === 'addsaldo') {
      user.saldo = (user.saldo || 0) + amount
    } else if (cmd === 'kurangsaldo') {
      if ((user.saldo || 0) < amount) return ctx.reply('❌ Saldo user tidak mencukupi.')
      user.saldo -= amount
    }

    saveUsers(users)
    logSaldo({
      userId: targetId,
      amount,
      type: cmd,
      by: ctx.from.username || ctx.from.first_name || senderId
    })

    return ctx.reply(
      `✅ Saldo berhasil di-*${cmd.replace('saldo', '')}*.\n` +
      `👤 ID: ${targetId}\n` +
      `💰 Sisa Saldo: Rp ${user.saldo.toLocaleString('id-ID')}`,
      { parse_mode: 'Markdown' }
    )
  })

  bot.command('riwayatsaldo', async (ctx) => {
    const senderId = String(ctx.from.id)
    const ownerId = String(config.OWNER_ID)
    if (senderId !== ownerId) return ctx.reply('❌ Khusus owner.')

    const logs = fs.existsSync(logPath) ? JSON.parse(fs.readFileSync(logPath)) : []
    if (!logs.length) return ctx.reply('📭 Belum ada riwayat transaksi.')

    const last10 = logs.slice(-10).reverse()
    const teks = last10.map(log =>
      `🧾 *ID:* ${log.userId}\n` +
      `💸 *Rp ${log.amount.toLocaleString('id-ID')}*\n` +
      `📌 *Aksi:* ${log.type}\n` +
      `✏️ *Oleh:* ${log.by}\n` +
      `🕒 ${log.time}`
    ).join('\n\n')

    return ctx.reply(`📊 *Riwayat Saldo Terakhir:*\n\n${teks}`, { parse_mode: 'Markdown' })
  })
}