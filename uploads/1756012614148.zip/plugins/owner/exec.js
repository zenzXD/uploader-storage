// plugins/owner/exec.js

import { exec } from 'child_process'

import util from 'util'

import { config } from '../../config.js'

const execPromise = util.promisify(exec)

export default {

  command: ['exec', '$'],

  tags: ['owner'],

  desc: '🖥️ Jalankan perintah shell (khusus Owner)',

  async handler(ctx) {

    const senderId = ctx.from.id

    if (senderId !== config.OWNER_ID) {

      return ctx.reply('❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.')

    }

    const input = ctx.message.text.split(' ').slice(1).join(' ')

    if (!input) {

      return ctx.reply(`

*📦 EXECUTOR TERMINAL*

Kirimkan perintah shell untuk dieksekusi.

💡 *Contoh:* \`/exec ls -la\`

`, { parse_mode: 'Markdown' })

    }

    try {

      const { stdout, stderr } = await execPromise(input)

      const output = (stdout || stderr || '✅ Perintah berhasil dijalankan tanpa output.').slice(0, 4000)

      await ctx.reply(`

╭───[ *EXECUTOR* ]

│ 🧾 *Perintah:* \`${input}\`

│ 📤 *Output:*

╰────

\`\`\`\n${output}\n\`\`\`

`, { parse_mode: 'Markdown' })

    } catch (err) {

      await ctx.reply(`

❌ *Terjadi Kesalahan!*

\`\`\`

${err.message}

\`\`\`

`, { parse_mode: 'Markdown' })

    }

  }

}