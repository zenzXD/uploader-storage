// plugins/tools/listsheet.js

import { listSheets } from '../../lib/gsheet.js'
import { config } from '../../config.js'

export default {
  command: ['listsheet'],
  tags: ['tools'],
  desc: '📄 Menampilkan daftar nama sheet/tab di Google Spreadsheet (Owner only)',
  usage: '/listsheet <spreadsheetId>',
  owner: true,

  async handler(ctx) {
    const userId = String(ctx.from.id)
    const ownerId = String(config.OWNER_ID) // pastikan keduanya string

    // Validasi akses Owner
    if (userId !== ownerId) {
      return ctx.reply(
        `🚫 Akses ditolak.\n\n👤 ID Kamu: \`${userId}\`\n👑 Hanya untuk: \`${ownerId}\``,
        { parse_mode: 'Markdown' }
      )
    }

    const args = ctx.message.text.trim().split(' ')
    const spreadsheetId = args[1]

    if (!spreadsheetId) {
      return ctx.reply(
        '❌ Masukkan *ID Spreadsheet*!\n\n💡 Contoh:\n`/listsheet 1A2B3C...XYZ`',
        { parse_mode: 'Markdown' }
      )
    }

    try {
      const sheets = await listSheets(spreadsheetId)

      if (!sheets.length) {
        return ctx.reply('⚠️ Spreadsheet ditemukan, tapi tidak ada sheet/tab di dalamnya.')
      }

      const list = sheets.map((name, i) => `*${i + 1}.* ${name}`).join('\n')
      const text = `📄 *Daftar Sheet:*\n\n${list}`

      await ctx.reply(text, { parse_mode: 'Markdown' })
    } catch (e) {
      console.error('[ListSheet Error]', e)
      await ctx.reply(
        '❌ Gagal mengambil daftar sheet.\n\nPeriksa:\n• ID Spreadsheet benar\n• Spreadsheet dapat diakses publik atau dibagikan ke *service account*.',
        { parse_mode: 'Markdown' }
      )
    }
  }
} 