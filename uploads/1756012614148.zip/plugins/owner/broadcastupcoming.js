// plugins/owner/broadcastupcoming.js

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

export const command = ['broadcastupcoming', 'bcup'];
export const tags = ['owner'];
export const owner = true;
export const desc = 'Broadcast fitur akan datang ke user/group/channel';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const previews = new Map();

export default function (bot) {
  bot.command(command, async (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 3) {
      return ctx.reply('❌ Format: /broadcastupcoming [kategori] [pesan] [no-button]');
    }

    const kategori = args[1];
    const pesan = args.slice(2).join(' ');
    const useButton = !pesan.toLowerCase().includes('no-button');

    const cleanPesan = pesan.replace(/no-button/i, '').trim();
    const previewKey = `${ctx.from.id}_${Date.now()}`;

    if (!useButton) {
      // Langsung kirim tanpa tombol
      const types = ['user', 'group', 'channel'];
      let total = 0, failed = 0;

      for (const type of types) {
        const file = path.join(__dirname, '../../json/broadcast', type, `${kategori}.json`);
        if (!fs.existsSync(file)) continue;

        const targets = JSON.parse(fs.readFileSync(file));
        for (const id of targets) {
          try {
            await ctx.telegram.sendMessage(id,
              `╭─❖ 「 *📢 COMING SOON* 」 ❖─╮
│
├ 🔧 *Kategori:* _${kategori}_
│
├ ✨ *Detail Fitur:*
│ ${cleanPesan}
│
╰───────────────✦`,
              { parse_mode: 'Markdown' });
            total++;
          } catch {
            failed++;
          }
        }
      }

      return ctx.reply(`✅ Broadcast Terkirim!\n📬 Total: ${total}\n❌ Gagal: ${failed}`);
    }

    // Simpan preview jika pakai tombol
    previews.set(previewKey, { kategori, pesan: cleanPesan, creator: ctx.from.id });

    await ctx.reply(
      `╭───⟪ 🔮 *PREVIEW BROADCAST* ⟫───╮
│
├ 📂 *Kategori:* _${kategori}_
│
├ 💌 *Pesan Preview:*
│ ${cleanPesan}
│
╰───────────────✦`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '✅ Kirim ke semua', callback_data: `bcup_send:${previewKey}` }],
            [{ text: '❌ Batal', callback_data: `bcup_cancel:${previewKey}` }]
          ]
        }
      }
    );
  });

  bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery?.data;
    if (!data) return;

    const matchSend = data.match(/^bcup_send:(.+)$/);
    const matchCancel = data.match(/^bcup_cancel:(.+)$/);

    if (matchSend) {
      const key = matchSend[1];
      const preview = previews.get(key);
      if (!preview || preview.creator !== ctx.from.id) {
        return ctx.answerCbQuery('⛔ Akses tidak valid.');
      }

      const { kategori, pesan } = preview;
      let total = 0, failed = 0;
      const types = ['user', 'group', 'channel'];

      for (const type of types) {
        const file = path.join(__dirname, '../../json/broadcast', type, `${kategori}.json`);
        if (!fs.existsSync(file)) continue;

        const targets = JSON.parse(fs.readFileSync(file));
        for (const id of targets) {
          try {
            await ctx.telegram.sendMessage(id,
              `╭─❖ 「 *📢 COMING SOON* 」 ❖─╮
│
├ 🔧 *Kategori:* _${kategori}_
│
├ ✨ *Detail Fitur:*
│ ${pesan}
│
╰───────────────✦`,
              { parse_mode: 'Markdown' });
            total++;
          } catch {
            failed++;
          }
        }
      }

      previews.delete(key);
      await ctx.editMessageText(`✅ *Broadcast Terkirim!*\n\n📬 Total: *${total}*\n❌ Gagal: *${failed}*`, { parse_mode: 'Markdown' });
      return ctx.answerCbQuery('✅ Terkirim!');
    }

    if (matchCancel) {
      const key = matchCancel[1];
      const preview = previews.get(key);
      if (!preview || preview.creator !== ctx.from.id) {
        return ctx.answerCbQuery('⛔ Tidak valid.');
      }

      previews.delete(key);
      await ctx.editMessageText('❌ Broadcast dibatalkan.');
      return ctx.answerCbQuery('🚫 Dibatalkan');
    }
  });
}