import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { bold, italic, code } from 'telegraf/format'
import { config } from '../../config.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

export default {
  command: ['addidch', 'addch'],
  tags: ['owner'],
  owner: true,
  desc: '🏦 Tambah ID Channel ke Database Premium',

  async handler(ctx) {
    const { text } = ctx
    const sender = ctx.from.id
    const reply = m => ctx.reply(m, { parse_mode: 'Markdown' })

    // ✅ Cek hanya untuk creator tunggal (tanpa array)
    if (String(sender) !== String(config.OWNER_ID)) {
      return reply(`🚫 ${bold('AKSES DITOLAK')}\nHanya ${italic('Creator')} Premium yang berhak menambahkan ID channel.`)
    }

    if (!text) {
      return reply(`💳 ${bold('Contoh Penggunaan:')}\n${code('/addch -1001234567890')}`)
    }

    if (!/^(-100)\d{10,}$/.test(text)) {
      return reply(`❌ ${bold('Format ID Channel Tidak Valid!')}\nGunakan ID yang dimulai dengan ${code('-100')}`)
    }

    const dbPath = path.join(__dirname, '../../json/listidch.json')

    if (!fs.existsSync(dbPath)) {
      fs.writeFileSync(dbPath, '[]')
    }

    let listidch = []

    try {
      listidch = JSON.parse(fs.readFileSync(dbPath))
    } catch (e) {
      return reply(`📛 Gagal membaca database!\n${e.message}`)
    }

    if (listidch.includes(text)) {
      return reply(`⚠️ ${italic('ID Channel sudah ada di database.')}\n\n🆔 ${code(text)}`)
    }

    listidch.push(text)
    fs.writeFileSync(dbPath, JSON.stringify(listidch, null, 2))

    return reply(`💠 ${bold('ID Channel Berhasil Ditambahkan!')}\n\n📡 ${bold('ID:')} ${code(text)}\n📂 ${bold('Total Tersimpan:')} ${listidch.length} channel\n\n🏦 ${italic('Data berhasil diamankan ke database premium.')}`)
  }
}