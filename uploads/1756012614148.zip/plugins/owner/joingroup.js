export default {

  command: ['joingroup', 'joingc'],

  desc: '🔗 Join grup via link atau ID (khusus owner)',

  tags: ['owner'],

  owner: true,

  async handler(ctx) {

    const ownerId = 7375830866 // Ganti sesuai ID Telegram kamu

    if (ctx.from.id !== ownerId) {

      return ctx.reply(

        `🚫 *Akses Ditolak!*\n` +

        `Perintah ini hanya dapat digunakan oleh *Owner Bot*.`,

        { parse_mode: 'Markdown' }

      )

    }

    const input = ctx.message.text.split(" ").slice(1).join(" ").trim()

    if (!input) {

      return ctx.reply(

        `📥 *Join Grup Bot*\n` +

        `╭─❏ *Panduan Penggunaan*\n` +

        `│ ➤ Kirim *link undangan grup*:\n` +

        `│     https://t.me/+xxxxxx\n` +

        `│ ➤ Atau kirim *ID grup*:\n` +

        `│     -100xxxxxxxxxx\n` +

        `╰────────────────────`,

        { parse_mode: 'Markdown' }

      )

    }

    try {

      if (input.startsWith("https://t.me/+")) {

        await ctx.telegram.joinChat(input)

        return ctx.reply(

          `✅ *Berhasil Join Grup!*\n` +

          `🤖 Bot telah masuk melalui link berikut:\n${input}`,

          { parse_mode: 'Markdown' }

        )

      }

      if (/^-100\d+$/g.test(input)) {

        const info = await ctx.telegram.getChat(input)

        await ctx.telegram.sendMessage(input, `👋 Halo semuanya! Aku baru saja join grup ini.`)

        return ctx.reply(

          `✅ *Bot Telah Bergabung!*\n` +

          `╭─❏ *Info Grup*\n` +

          `│ 📛 *Nama:* ${info.title}\n` +

          `│ 🆔 *ID:* \`${info.id}\`\n` +

          `╰────────────────────`,

          { parse_mode: 'Markdown' }

        )

      }

      return ctx.reply(

        `❌ *Format Tidak Dikenali!*\n` +

        `Silakan kirim link undangan grup (*https://t.me/+...*) atau ID grup (*-100xxxxxxxxxx*).`,

        { parse_mode: 'Markdown' }

      )

    } catch (e) {

      console.error("❌ Gagal join grup:", e)

      return ctx.reply(

        `❌ *Gagal Join Grup!*\n` +

        `Pesan error:\n\`${e.message}\``,

        {

          parse_mode: 'Markdown',

          disable_web_page_preview: true

        }

      )

    }

  }

}