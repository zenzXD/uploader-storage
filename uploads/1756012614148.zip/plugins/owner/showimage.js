import fs from 'fs';
import path from 'path';

export default {
  command: ['showimage'],
  tags: ['owner'],
  desc: '📷 Tampilkan gambar dari folder image/menu atau notif',

  async handler(ctx) {
    const args = ctx.text.trim().split(/\s+/);
    const kategori = args[1];
    const nama = args[2];

    if (!kategori || !nama) {
      return ctx.reply(
        `🧾 Format: /showimage [menu|notif] [nama]\n` +
        `Contoh: /showimage menu opening`
      );
    }

    const filePath = path.join('image', kategori, `${nama}.jpg`);
    if (!fs.existsSync(filePath)) return ctx.reply('❌ Gambar tidak ditemukan.');

    try {
      await ctx.replyWithPhoto({ source: filePath }, { caption: `🖼️ Gambar: ${kategori}/${nama}` });
    } catch (e) {
      ctx.reply('❌ Gagal mengirim gambar:\n' + e.message);
    }
  }
};