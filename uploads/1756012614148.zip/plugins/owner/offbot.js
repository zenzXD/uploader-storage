import fs from 'fs'
const statusPath = './json/bot_status.json'

export const command = ['offbot', 'onbot']
export const tags = ['owner']
export const owner = true
export const desc = '🔌 Matikan atau hidupkan bot sementara'

export default function (bot) {
  // Pastikan file status ada
  if (!fs.existsSync(statusPath)) {
    fs.writeFileSync(statusPath, JSON.stringify({ status: 'on' }, null, 2))
  }

  bot.command(['offbot'], async (ctx) => {
    const status = JSON.parse(fs.readFileSync(statusPath))
    if (status.status === 'off') return ctx.reply('⚠️ Bot sudah dimatikan.')

    status.status = 'off'
    fs.writeFileSync(statusPath, JSON.stringify(status, null, 2))
    await ctx.reply('🛑 *Bot telah dimatikan sementara oleh Owner.*\nGunakan /onbot untuk menyalakan kembali.', {
      parse_mode: 'Markdown'
    })
  })

  bot.command(['onbot'], async (ctx) => {
    const status = JSON.parse(fs.readFileSync(statusPath))
    if (status.status === 'on') return ctx.reply('✅ Bot sudah aktif.')

    status.status = 'on'
    fs.writeFileSync(statusPath, JSON.stringify(status, null, 2))
    await ctx.reply('🔌 *Bot berhasil diaktifkan kembali!*', {
      parse_mode: 'Markdown'
    })
  })
}