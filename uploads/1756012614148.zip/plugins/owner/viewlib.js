import fs from 'fs';
import path from 'path';
import { config } from '../../config.js';

export default {
  command: ['viewlib'],
  tags: ['owner'],
  desc: '📖 Lihat isi file di folder lib/',

  async handler(ctx) {
    const userId = ctx.from?.id?.toString();
    if (!config.OWNER_ID.includes(userId)) {
      return ctx.reply(`🚫 *Akses Ditolak*\nPerintah ini hanya untuk *Owner Bot*.`);
    }

    const fileName = ctx.body?.split(' ')?.slice(1)?.join(' ')?.trim();
    if (!fileName) {
      return ctx.reply(
`📖 *View File dari /lib*
╭───────────────⬣
│ 📥 *Contoh:* /viewlib utils.js
│ 📁 *Folder:* lib/
╰───────────────⬣`
      );
    }

    const libDir = path.join(process.cwd(), 'lib');
    const filePath = path.join(libDir, fileName);

    if (!fs.existsSync(filePath)) {
      return ctx.reply(`❌ *File tidak ditemukan!*\nPastikan nama file yang kamu masukkan benar ada di folder *lib/*`);
    }

    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const maxLength = 3800;
      const display = content.length > maxLength 
        ? content.slice(0, maxLength) + '\n// 🔻 Konten terpotong karena terlalu panjang.'
        : content;

      return ctx.reply(
`╭───〔 📄 *VIEW LIB FILE* 〕────⬣
│ 🧩 *Nama File:* ${fileName}
│ 📂 *Lokasi:* lib/
│ 🔒 *Akses:* Owner
│ 📏 *Panjang:* ${content.length} karakter
╰───────────────⬣
\`\`\`js
${display}
\`\`\`
📌 Gunakan dengan bijak.
`
      );
    } catch (err) {
      return ctx.reply(`❌ *Terjadi kesalahan saat membaca file:*\n\`\`\`${err.message}\`\`\``);
    }
  }
};