import fs from 'fs'
import path from 'path'

export default {
  command: ['ownermenu'],
  tags: ['owner'],
  desc: '👑 Tampilkan daftar fitur eksklusif Owner',

  async handler(ctx) {
    try {
      const folderPath = path.join(process.cwd(), 'plugins', 'owner')
      if (!fs.existsSync(folderPath)) {
        await ctx.reply('❌ *Folder Owner tidak ditemukan!*\nPastikan folder `plugins/owner/` tersedia.')
        return
      }

      const files = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'))

      if (files.length === 0) {
        await ctx.reply('⚠️ *Tidak ada fitur Owner ditemukan.*\nCek kembali folder `plugins/owner/`.')
        return
      }

      const list = files
        .map((file, i) => `┃ 💠 *${i + 1}.* \`${file.replace('.js', '')}\``)
        .join('\n')

      const teks = `
╔═══❖「 👑 *OWNER MENU* 」❖═══╗
║📁 Folder: \`plugins/owner/\`
║🔐 Hak Akses: *Owner Only*
║⚙️ Total Fitur: *${files.length}*
╠════════════════════════════╣
${list}
╠════════════════════════════╣
║📌 Hanya Owner yang bisa mengakses
║💼 Panel ini bersifat *privat & penting*
╚════════════════════════════╝
`.trim()

      await ctx.reply(teks, { parse_mode: 'Markdown' })

    } catch (err) {
      console.error(err)
      await ctx.reply('❌ *Gagal memuat Owner Menu.*\nCek log error atau periksa folder.')
    }
  }
}