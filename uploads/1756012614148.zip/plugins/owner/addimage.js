import fs from 'fs';
import path from 'path';
import mime from 'mime-types';

export default {
  command: ['addimage'],
  tags: ['owner'],
  desc: '🖼️ Tambahkan gambar ke folder image/menu atau image/notif',

  async handler(ctx) {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya Owner yang bisa pakai perintah ini.');

    const args = ctx.text?.split(' ').slice(1);
    const kategori = args?.[0];

    if (!kategori || !['menu', 'notif'].includes(kategori)) {
      return ctx.reply(`📸 *Format Salah!*\n\nGunakan: /addimage [menu|notif]\nContoh: /addimage menu\n\n📝 *Catatan:* Reply atau kirim gambar dengan caption perintah ini.`, {
        parse_mode: 'Markdown'
      });
    }

    const media = ctx.message?.photo?.pop() || ctx.message?.document;
    if (!media) {
      return ctx.reply('📎 Harap *reply atau kirim gambar* bersamaan dengan perintah.', {
        parse_mode: 'Markdown'
      });
    }

    const fileLink = await ctx.telegram.getFileLink(media.file_id);
    const res = await fetch(fileLink.href);
    const buffer = await res.arrayBuffer();

    const mimeType = mime.lookup(fileLink.pathname) || 'image/jpeg';
    const ext = mime.extension(mimeType);
    const time = Date.now();
    const filename = `img_${time}.${ext}`;

    const folderPath = path.join('image', kategori);
    const filePath = path.join(folderPath, filename);

    try {
      if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });
      fs.writeFileSync(filePath, Buffer.from(buffer));

      await ctx.replyWithPhoto({ source: filePath }, {
        caption: `✅ *Gambar disimpan sebagai:* \`${kategori}/${filename}\``,
        parse_mode: 'Markdown'
      });
    } catch (e) {
      console.error(e);
      return ctx.reply(`❌ Gagal menyimpan gambar:\n\`${e.message}\``, { parse_mode: 'Markdown' });
    }
  }
};