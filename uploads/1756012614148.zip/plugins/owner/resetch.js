import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { bold } from 'telegraf/format'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

export default {
  command: ['resetch', 'resetidch'],
  tags: ['owner'],
  owner: true,
  desc: '♻️ Reset semua ID Channel yang tersimpan',

  async handler(ctx) {
    const dbPath = path.join(__dirname, '../../json/listidch.json')

    if (!fs.existsSync(dbPath)) {
      return ctx.reply(`⚠️ ${bold('Database belum ada atau sudah kosong.')}`)
    }

    fs.writeFileSync(dbPath, JSON.stringify([], null, 2))
    ctx.reply(`🧹 ${bold('Semua ID Channel berhasil direset!')}\n📂 File: listidch.json`)
  }
}