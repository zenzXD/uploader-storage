import fs from 'fs'
import path from 'path'
import { config } from '../../config.js'

export default {
  command: ['addlib'],
  tags: ['owner'],
  desc: '📦 Tambahkan file JavaScript ke folder lib',

  async handler(ctx) {
    const userId = String(ctx.from?.id)
    const ownerId = config.OWNER_ID

    const isOwner = Array.isArray(ownerId)
      ? ownerId.map(String).includes(userId)
      : String(ownerId) === userId

    if (!isOwner) {
      return ctx.reply('🚫 *Perintah ini hanya dapat dijalankan oleh OWNER!*', { parse_mode: 'Markdown' })
    }

    const args = ctx.text?.trim().split(' ').slice(1).join(' ').trim()
    const firstSpace = args.indexOf(' ')

    if (firstSpace === -1) {
      return ctx.reply(
        `╭─❍「 ❌ *Format Salah* 」
├ 📥 Cara pakai:
│   /addlib <namaFile> <kode JavaScript>
│
├ 💡 Contoh:
│   /addlib helper export function hi() { return 'Hai!'; }
╰─❍`, { parse_mode: 'Markdown' }
      )
    }

    const namaFile = args.slice(0, firstSpace).trim()
    const kodeIsi = args.slice(firstSpace + 1).trim()

    if (!namaFile || !kodeIsi) {
      return ctx.reply('⚠️ *Nama file dan isi kode harus diisi dengan benar!*', { parse_mode: 'Markdown' })
    }

    if (/[^a-zA-Z0-9_-]/.test(namaFile)) {
      return ctx.reply('🚫 *Nama file tidak valid.* Hanya huruf, angka, garis bawah (_) dan strip (-) yang diperbolehkan.', { parse_mode: 'Markdown' })
    }

    if (!kodeIsi.startsWith('export') && !kodeIsi.startsWith('import')) {
      return ctx.reply('⚠️ *Kode harus diawali dengan "export" atau "import".*', { parse_mode: 'Markdown' })
    }

    const libDir = path.join(process.cwd(), 'lib')
    const filePath = path.join(libDir, `${namaFile}.js`)

    try {
      if (!fs.existsSync(libDir)) fs.mkdirSync(libDir, { recursive: true })

      if (fs.existsSync(filePath)) {
        return ctx.reply(`⚠️ *File sudah ada:* \`lib/${namaFile}.js\``, { parse_mode: 'Markdown' })
      }

      fs.writeFileSync(filePath, kodeIsi, 'utf-8')

      return ctx.reply(
        `╭─❍「 ✅ *LIB BERHASIL DITAMBAHKAN* 」
├ 📁 File: \`lib/${namaFile}.js\`
├ 📌 Status: *Tersimpan*
├ 🔁 Gunakan /reloadlib jika perlu
╰─❍`, { parse_mode: 'Markdown' }
      )
    } catch (e) {
      return ctx.reply(`❌ *Gagal menyimpan file:*\n\`\`\`${e.message}\`\`\``, { parse_mode: 'Markdown' })
    }
  }
}