import fs from "fs";

import path from "path";

import archiver from "archiver";

import { config } from "../../config.js";

const botingMessages = [

  "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▒▒▒▒▒▒▒▒▒▒ 0%\n⏳ Memulai sistem...",

  "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▒▒▒▒▒▒▒▒▒ 25%\n🔍 Mengecek dependensi...",

  "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▒▒▒▒▒▒▒ 50%\n⚙️ Memproses metadata...",

  "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▓▓▒▒▒▒▒ 75%\n🔄 Menyusun modul...",

  "*🔧 LIN QIYE PROJECT SYSTEM BOTING...*\n\n▓▓▓▓▓▓▓▓▓▓ 100%\n✅ Sistem Siap Digunakan!"

];

export default {

  command: ["zip"],

  tags: ["owner"],

  owner: true,

  desc: "🗜️ ZIP file/folder dengan animasi boting dan kirim ke target",

  async handler(ctx) {

    const ownerId = String(config.OWNER_ID || "");

    if (String(ctx.from.id) !== ownerId) {

      return ctx.reply("🚫 *Fitur ini khusus Owner bot!*", { parse_mode: "Markdown" });

    }

    const args = ctx.message.text?.split(" ")?.slice(1);

    const input = args?.[0]?.trim();

    const target = args?.[1] || ownerId; // 🔧 Jika kosong, kirim ke Owner

    if (!input) {

      return ctx.reply(

        `╭──❖「 *🗜️ ZIP FILE BOT LIN-QIYE* 」\n` +

        `│ 📦 Fungsi: ZIP file/folder dari \`plugins/\`\n` +

        `│ 📂 Format: \`/zip [path] [target_id(optional)]\`\n` +

        `│ 📌 Contoh:\n` +

        `│ ├ \`/zip owner/broadcast.js\`\n` +

        `│ └ \`/zip info/all -1001234567890\`\n` +

        `│ 🔁 Default: Kirim ke Owner (private)\n` +

        `╰───⏳ Menunggu input...`,

        { parse_mode: "Markdown" }

      );

    }

    const fullPath = path.join("plugins", input);

    const isAllInFolder = input.endsWith("/all");

    const targetDir = isAllInFolder ? fullPath.replace(/\/all$/, "") : fullPath;

    if (!fs.existsSync(targetDir)) {

      return ctx.reply(`❌ *Path tidak ditemukan:*\n\`${input}\``, { parse_mode: "Markdown" });

    }

    const name = path.basename(targetDir).replace(/\.[^/.]+$/, "");

    const filename = `${name}-${Date.now()}.zip`;

    const zipPath = path.join(".", filename);

    const output = fs.createWriteStream(zipPath);

    const archive = archiver("zip", { zlib: { level: 9 } });

    archive.pipe(output);

    // 🗃️ Tambahkan file/folder ke arsip

    if (isAllInFolder) {

      const items = fs.readdirSync(targetDir);

      for (const item of items) {

        const itemPath = path.join(targetDir, item);

        const stat = fs.statSync(itemPath);

        if (stat.isFile()) {

          archive.file(itemPath, { name: item });

        } else if (stat.isDirectory()) {

          archive.directory(itemPath, item);

        }

      }

    } else if (fs.lstatSync(targetDir).isDirectory()) {

      archive.directory(targetDir, false);

    } else {

      archive.file(targetDir, { name: path.basename(targetDir) });

    }

    // ⏳ Animasi booting

    let msgAnimasi = await ctx.reply(botingMessages[0], { parse_mode: "Markdown" });

    for (let i = 1; i < botingMessages.length; i++) {

      await new Promise(r => setTimeout(r, 900));

      await ctx.telegram.editMessageText(

        ctx.chat.id,

        msgAnimasi.message_id,

        undefined,

        botingMessages[i],

        { parse_mode: "Markdown" }

      );

    }

    try {

      await archive.finalize();

      output.on("close", async () => {

        const size = (archive.pointer() / 1024).toFixed(2);

        await ctx.telegram.editMessageText(

          ctx.chat.id,

          msgAnimasi.message_id,

          undefined,

          `✅ *ZIP selesai! Mengirim ke target...*`,

          { parse_mode: "Markdown" }

        );

        try {

          await ctx.telegram.sendDocument(

            target,

            { source: zipPath, filename: `${name}.zip` },

            {

              caption:

                `╭──🎉 *ZIP BERHASIL!*\n` +

                `├ 📂 Path: \`${input}\`\n` +

                `├ 📦 Ukuran: \`${size} KB\`\n` +

                `├ 🕒 Tanggal: \`${new Date().toLocaleString("id-ID")}\`\n` +

                `╰─🤖 Bot: *Lin-Qiye*`,

              parse_mode: "Markdown"

            }

          );

        } catch (sendErr) {

          await ctx.reply(

            `⚠️ *Gagal mengirim ke target:*\n\`${sendErr.message}\`\n\n📎 File dikirim ke sini sebagai cadangan.`,

            { parse_mode: "Markdown" }

          );

          await ctx.replyWithDocument(

            { source: zipPath, filename: `${name}.zip` },

            {

              caption: "📦 ZIP berhasil, tapi gagal kirim ke target.",

              parse_mode: "Markdown"

            }

          );

        }

        fs.unlinkSync(zipPath); // Hapus file setelah dikirim

      });

    } catch (err) {

      console.error("ZIP Error:", err);

      await ctx.reply(`💥 *Gagal ZIP:*\n\`${err.message}\``, { parse_mode: "Markdown" });

    }

  }

};