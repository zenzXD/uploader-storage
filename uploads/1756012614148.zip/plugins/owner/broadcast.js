export default {
    command: ["broadcast"],
    owner: true,
    async handler(ctx) {
        const args = ctx.message.text.split(" ").slice(1);
        const messageText = args.join(" ");
        const reply = ctx.message.reply_to_message;

        const files = {
            user: "../../json/notified.json",
            group: "../../json/whitelist_groups.json",
            channel: "../../json/channel.json"
        };

        const sender = ctx.from?.username
            ? `@${ctx.from.username}`
            : ctx.from?.first_name || "Unknown";
        const senderId = ctx.from?.id;
        const role = isOwner(senderId)
            ? "👑 Owner"
            : isPremium(senderId)
            ? "⭐ Premium"
            : "👤 Free";
        const waktu = new Date().toLocaleString("id-ID");
        const teksFinal = messageText || reply?.text || "(media)";

        let totalTarget = 0;
        let sukses = 0;
        let gagal = 0;

        const allTargets = [];

        // Gabungkan semua target user, group, dan channel
        for (const type in files) {
            const filePath = path.join(__dirname, files[type]);
            if (fs.existsSync(filePath)) {
                const list = JSON.parse(fs.readFileSync(filePath));
                if (Array.isArray(list)) {
                    allTargets.push(...list.map(id => ({ id, type })));
                }
            }
        }

        for (const { id, type } of allTargets) {
            totalTarget++;
            try {
                if (reply) {
                    const options = {};
                    if (messageText) options.caption = messageText;
                    await ctx.telegram.copyMessage(
                        id,
                        ctx.chat.id,
                        reply.message_id,
                        options
                    );
                } else {
                    await ctx.telegram.sendMessage(id, messageText);
                }

                logReceiver({
                    user: id,
                    type,
                    role: isOwner(id)
                        ? "Owner"
                        : isPremium(id)
                        ? "Premium"
                        : "Free",
                    teks: teksFinal,
                    time: new Date().toLocaleString("id-ID")
                });

                sukses++;
            } catch (err) {
                gagal++;
                console.warn(
                    `[Broadcast Error] Gagal kirim ke ${id}:`,
                    err.message
                );
            }

            await delay(700);
        }

        const logData = {
            user: sender,
            role,
            type: "ALL",
            teks: teksFinal,
            time: waktu,
            sukses,
            gagal,
            total_target: totalTarget
        };

        logResult(logData);

        const preview = `╭─⬣ 📣 *Broadcast ke SEMUA*
│ 👤 *User:* ${sender}
│ 🎖️ *Role:* ${role}
│ 🧾 *Isi:* ${teksFinal}
│ 🎯 *Total Target:* ${totalTarget}
│ ✅ *Sukses:* ${sukses}
│ ❌ *Gagal:* ${gagal}
│ 🕒 *Waktu:* ${waktu}
╰─⬣
📥 Log: \`broadcast_log.json\` & \`broadcast_received_log.json\``;

        sendToDiscord(
            `📢 **BROADCAST SEMUA**\n\n${preview.replace(/[*_`]/g, "")}`
        );
        return ctx.reply(preview, { parse_mode: "Markdown" });
    }
};
