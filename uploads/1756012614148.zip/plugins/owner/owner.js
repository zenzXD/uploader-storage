export default {
  command: ['owner', 'dev', 'creator'],
  tags: ['owner'],
  desc: 'Menampilkan informasi pemilik bot',

  async handler(ctx) {
    const config = ctx.config || {}
    const OWNER_NAME = config.OWNER_NAME || 'Unknown'
    const OWNER_ID = config.OWNER_ID || 0
    const OWNER_USERNAME = config.OWNER_USERNAME || 'username_owner'
    const OWNER_LINK = config.infoButtons?.OWNER || `https://t.me/${OWNER_USERNAME}`

    const text = `
👑 *Informasi Pemilik Bot*
╭───────────────╮
│ 📛 Nama: *${OWNER_NAME}*
│ 🆔 ID: \`${OWNER_ID}\`
│ 🔗 Username: [@${OWNER_USERNAME}](https://t.me/${OWNER_USERNAME})
╰───────────────╯
`.trim()

    const btn = config.infoButtons || {}
    const buttons = [
      [
        { text: '👤 Chat Owner', url: OWNER_LINK },
        { text: '📢 Channel', url: btn.CHANNEL || 'https://t.me/example_channel' }
      ],
      [
        { text: '💬 Group Support', url: btn.SUPPORT || 'https://t.me/example_group' },
        { text: '💻 Source Code', url: btn.SOURCE || 'https://github.com/example_repo' }
      ]
    ]

    return ctx.reply(text, {
      parse_mode: 'Markdown',
      disable_web_page_preview: true,
      reply_markup: { inline_keyboard: buttons }
    })
  }
}