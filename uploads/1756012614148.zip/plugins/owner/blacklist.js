import { getBlacklist, addBlacklist, removeBlacklist } from "../../lib/blacklist.js"

export default {

  command: ["blacklist", "unblacklist", "listblacklist"],

  tags: ["owner"],

  desc: "🚫 Atur blacklist user (Google Sheets)",

  async handler(ctx) {

    const ownerId = [7375830866] // Ganti ID owner

    if (!ownerId.includes(ctx.from.id)) return ctx.reply("❌ Hanya owner yang bisa.")

    const args = ctx.text.split(" ").slice(1)

    const cmd = ctx.command

    const userId = Number(args[0])

    if (cmd === "blacklist") {

      if (!userId) return ctx.reply("⚠️ Masukkan ID user.")

      await addBlacklist(userId, args.slice(1).join(" "))

      return ctx.reply(`✅ User ${userId} ditambahkan ke blacklist.`)

    }

    if (cmd === "unblacklist") {

      if (!userId) return ctx.reply("⚠️ Masukkan ID user.")

      await removeBlacklist(userId)

      return ctx.reply(`✅ User ${userId} dihapus dari blacklist.`)

    }

    if (cmd === "listblacklist") {

      const list = await getBlacklist()

      if (!list.length) return ctx.reply("📂 Blacklist kosong.")

      return ctx.reply(

        "📂 *Daftar Blacklist:*\n" + list.map(id => `- ${id}`).join("\n"),

        { parse_mode: "Markdown" }

      )

    }

  }

}