import { addPremium, isPremium } from "../../lib/premium.js";
import { config } from "../../config.js"; // OWNER_ID dari config

const CHANNEL_ID = -1002778325483;

export default {
  command: ["addprem"],
  tags: ["owner"],
  owner: true,
  description: "💢 Tambahkan user ke daftar Premium secara brutal",
  async handler(ctx) {
    const isReply = ctx.message?.reply_to_message;
    const text = ctx.message?.text?.split(" ");
    const userId = isReply?.from?.id || text[1];
    const days = parseInt(text[2]) || 30;

    if (ctx.from.id !== config.OWNER_ID) {
      return ctx.reply(`🚫 Lo bukan owner. Mundur.`);
    }

    if (!userId || isNaN(userId)) {
      return ctx.reply(
        `┏━━━😡 FORMAT GAGAL ━━━┓
┃ Balas pesan target atau
┃ /addprem <id> <hari>
┃ Contoh: /addprem 123456 30
┗━━━━━━━━━━━━━━━━━━━━━━━━┛`
      );
    }

    const id = Number(userId);
    const now = Date.now();
    const expired = now + days * 24 * 60 * 60 * 1000;

    if (await isPremium(id)) {
      return ctx.reply(
        `┏━━━⚠️ SUDAH SULTAN ━━━┓
┃ 👤 ID: \`${id}\`
┃ 💎 Status: Premium Aktif
┃ 🤡 Mau ditambahin lagi?
┗━━━━━━━━━━━━━━━━━━━━━━┛`,
        { parse_mode: "Markdown" }
      );
    }

    const success = await addPremium(id, expired, now);
    if (!success) return ctx.reply(`❌ Gagal total. Coba ulang.`);

    await ctx.reply(
      `┏━━━🔥 PREMIUM DITANCAP ━━━┓
┃ 👤 Target: \`${id}\`
┃ ⏳ Durasi: *${days} hari*
┃ 🕰 Mulai: \`${new Date(now).toLocaleString("id-ID")}\`
┃ 📅 Tamat: \`${new Date(expired).toLocaleString("id-ID")}\`
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`,
      { parse_mode: "Markdown" }
    );

    try {
      await ctx.telegram.sendMessage(
        CHANNEL_ID,
        `📢 *PREMIUM DIPAKSA MASUK!*
👤 ID: \`${id}\`
⏳ Durasi: *${days} hari*
🕰 Mulai: \`${new Date(now).toLocaleString("id-ID")}\`
📅 Tamat: \`${new Date(expired).toLocaleString("id-ID")}\`
🚨 Ditambahkan oleh: \`${ctx.from.username || ctx.from.first_name}\``,
        { parse_mode: "Markdown" }
      );
    } catch (e) {
      console.error("Gagal kirim ke channel:", e.message);
    }
  },
};