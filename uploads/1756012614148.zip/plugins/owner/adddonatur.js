import { google } from 'googleapis'
import { config } from '../../config.js'

const SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
const auth = new google.auth.GoogleAuth({
  keyFile: './credentials.json',
  scopes: SCOPES,
})
const sheets = google.sheets({ version: 'v4', auth })

const spreadsheetId = '1H0QHBtYRfTmMx3I_hPxaf2go-vo8GGqc0xASdvg-Cxw'
const OWNER_ID = String(config.OWNER_ID)
const SHEET_NAME = 'DonasiMasuk'

export default {
  command: ['donatur', 'adddonatur'],
  tags: ['owner'],
  owner: true,
  desc: '💰 Tambah donatur dan simpan ke Google Sheet + notif ke grup dan owner',

  async handler(ctx) {
    const senderId = String(ctx.from.id)
    if (senderId !== OWNER_ID) {
      return ctx.reply(
        `🚫 *Akses Ditolak!*\n` +
        `Fitur ini hanya bisa digunakan oleh *Owner Bot*.\n\n` +
        `🆔 ID Kamu: \`${senderId}\``,
        { parse_mode: 'Markdown' }
      )
    }

    const args = ctx.message.text.split(' ').slice(1)
    const [nama, jumlah] = [args[0], args[1]]

    if (!nama || !jumlah || isNaN(jumlah)) {
      return ctx.reply(
        `📛 *Format Salah!*\n\n` +
        `📌 Gunakan format:\n` +
        `\`/donatur [nama] [jumlah]\`\n\n` +
        `✅ Contoh:\n` +
        `\`/donatur Rian 15000\`\n\n` +
        `📎 Jumlah harus berupa angka!`,
        { parse_mode: 'Markdown' }
      )
    }

    const waktu = new Date().toLocaleString('id-ID')
    const row = [nama, jumlah, waktu, senderId]

    try {
      await sheets.spreadsheets.values.append({
        spreadsheetId,
        range: `${SHEET_NAME}!A:D`,
        valueInputOption: 'USER_ENTERED',
        requestBody: {
          values: [row],
        },
      })

      const formatted = Number(jumlah).toLocaleString('id-ID')
      const notif = `
╭━━━━━━━━━━━━━━━━━━━━━━╮
┃     🎉 *DONASI MASUK!* 🎉
╰━━━━━━━━━━━━━━━━━━━━━━╯

👤 *Nama Donatur* : *${nama}*
💵 *Jumlah Donasi* : *Rp ${formatted}*
🕰️ *Waktu*        : ${waktu}
🆔 *User ID*      : \`${senderId}\`

🙏 *Terima kasih banyak atas dukungannya!* 🙌
`.trim()

      const LOG_CHAT_ID = config.LOG_DONASI || ctx.chat.id
      await ctx.telegram.sendMessage(LOG_CHAT_ID, notif, { parse_mode: 'Markdown' })

      if (senderId !== OWNER_ID) {
        await ctx.telegram.sendMessage(OWNER_ID, notif, { parse_mode: 'Markdown' })
      }

      return ctx.reply(
        `✅ *Donasi berhasil dicatat!*\n\n` +
        `🎁 Terima kasih *${nama}* atas donasi sebesar *Rp ${formatted}*\n` +
        `📤 Info sudah dikirim ke grup log dan owner.`,
        { parse_mode: 'Markdown' }
      )
    } catch (err) {
      console.error('❌ Gagal menyimpan ke Google Sheet:', err)
      return ctx.reply('⚠️ Terjadi kesalahan saat menyimpan donasi ke Google Sheet.')
    }
  }
}