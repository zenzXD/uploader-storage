import os from 'os'

import { performance } from 'perf_hooks'

import { bold, italic, code } from 'telegraf/format'

const startTime = performance.now()

const startedAt = new Date()

// Fungsi untuk escape karakter spesial MarkdownV2

function escapeMarkdownV2(text) {

  return text.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&')

}

export default {

  command: ['runtime', 'uptime'],

  tags: ['main'],

  desc: 'Cek lama bot berjalan & info server',

  async handler(ctx) {

    const now = performance.now()

    const runtimeMs = now - startTime

    const seconds = Math.floor(runtimeMs / 1000) % 60

    const minutes = Math.floor(runtimeMs / (1000 * 60)) % 60

    const hours = Math.floor(runtimeMs / (1000 * 60 * 60)) % 24

    const days = Math.floor(runtimeMs / (1000 * 60 * 60 * 24))

    const waktuBot = [

      days ? `${days} 🗓️ hari` : '',

      hours ? `${hours} ⏰ jam` : '',

      minutes ? `${minutes} ⏱️ menit` : '',

      seconds ? `${seconds} 🔁 detik` : ''

    ].filter(Boolean).join(', ')

    const uptimeSec = os.uptime()

    const uptimeDays = Math.floor(uptimeSec / (60 * 60 * 24))

    const uptimeHours = Math.floor((uptimeSec / (60 * 60)) % 24)

    const uptimeMinutes = Math.floor((uptimeSec / 60) % 60)

    const uptimeSeconds = Math.floor(uptimeSec % 60)

    const waktuServer = [

      uptimeDays ? `${uptimeDays} 🗓️ hari` : '',

      uptimeHours ? `${uptimeHours} ⏰ jam` : '',

      uptimeMinutes ? `${uptimeMinutes} ⏱️ menit` : '',

      uptimeSeconds ? `${uptimeSeconds} 🔁 detik` : ''

    ].filter(Boolean).join(', ')

    const mem = process.memoryUsage()

    const formatMB = (val) => (val / 1024 / 1024).toFixed(2) + ' MB'

    const cpu = process.cpuUsage()

    const cpuUserMs = cpu.user / 1000

    const cpuSystemMs = cpu.system / 1000

    const nowTime = new Date()

    const teks = [

      '┏━━━━━━━━━━━━━━━━━━━━━━━┓',

      '┃  ⏳  *BOT RUNTIME STATUS*  ⏳  ┃',

      '┗━━━━━━━━━━━━━━━━━━━━━━━┛',

      '┃',

      `┣ 📅 Lama berjalan: ${bold(escapeMarkdownV2(waktuBot))}`,

      `┣ 💾 Memory:`,

      `┃   • RSS: ${code(escapeMarkdownV2(formatMB(mem.rss)))}`,

      `┃   • Heap: ${code(escapeMarkdownV2(formatMB(mem.heapUsed)))} / ${code(escapeMarkdownV2(formatMB(mem.heapTotal)))}`,

      `┣ ⚙️ CPU Usage:`,

      `┃   • User: ${code(cpuUserMs.toFixed(1))} ms`,

      `┃   • System: ${code(cpuSystemMs.toFixed(1))} ms`,

      `┣ 🌐 Server uptime: ${bold(escapeMarkdownV2(waktuServer))}`,

      `┣ 🕒 Mulai: ${italic(escapeMarkdownV2(startedAt.toLocaleString('id-ID')))}`,

      `┣ 🕐 Sekarang: ${italic(escapeMarkdownV2(nowTime.toLocaleString('id-ID')))}`,

      `┣ ⏱️ Runtime (ms): ${code(runtimeMs.toFixed(0))}`,

      '┃',

      '┗━━━━━━━━━━━━━━━━━━━━━━━┛'

    ].join('\n')

    await ctx.reply(teks, { parse_mode: 'MarkdownV2' })

  }

}