export default {
  command: ["totalfitur", "totalplugin"],
  tags: ["main"],
  desc: "📊 Menampilkan jumlah total fitur aktif",

  async handler(ctx) {
    const { pluginMeta } = ctx.bot.context;

    if (!pluginMeta || Object.keys(pluginMeta).length === 0) {
      return ctx.reply("❌ Tidak ada plugin yang dimuat.");
    }

    const emojiKategori = {
      admin: '🛡️',
      ai: '🧠',
      anime: '🍥',
      bot: '🤖',
      bugs: '🐞',
      downloader: '⬇️',
      donghua: '🐉',
      elphoto: '🖼️',
      enc: '🔒',
      fix: '🧩',
      fun: '🎮',
      game: '🎲',
      group: '👥',
      info: '📘',
      internal: '🔧',
      islam: '🕌',
      main: '🎯',
      maker: '🧪',
      news: '📰',
      nsfw: '🔞',
      other: '📦',
      owner: '👑',
      panel: '📟',
      payment: '💰',
      primbon: '🔮',
      rpg: '🗡️',
      search: '🔍',
      sertifikat: '📄',
      stalker: '🕵️',
      store: '🏪',
      tools: '🛠️',
      default: '📦'
    };

    const totalFitur = Object.keys(pluginMeta).length;
    const kategori = {};

    for (const key in pluginMeta) {
      const tags = pluginMeta[key].tags || ["other"];
      for (const tag of tags) {
        kategori[tag] = (kategori[tag] || 0) + 1;
      }
    }

    const garis = "═".repeat(35);
    const header = `┏━━━「 *📦 Total Fitur Bot* 」━━━\n┣ 📁 *Total Plugin:* ${totalFitur}\n┣ 📚 *Kategori Plugin:*\n`;
    const body = Object.entries(kategori)
      .map(([k, v]) => {
        const emoji = emojiKategori[k] || emojiKategori.default;
        return `┃ ├─ ${emoji} ${k} : ${v} fitur`;
      })
      .join("\n");
    const footer = `┗${garis}`;

    ctx.reply(`${header}${body}\n${footer}`);
  }
}