export default {

  command: ['rules'],

  tags: ['main'],

  desc: 'Tampilkan aturan atau rules grup/bot',

  async handler(ctx) {

    // Kirim rules seperti biasa

    const rulesText = `

┌───〔 *📜 RULES & REGULATIONS* 〕───┐

│

│ 🙏 Hormati sesama anggota grup.

│ 🚫 Dilarang spam, flood, atau promosi tanpa izin.

│ ⚖️ Tidak membagikan konten yang melanggar hukum.

│ 🗣️ Gunakan bahasa yang sopan dan santun.

│ 👮 Ikuti arahan admin dan owner grup.

│ ❌ Jangan menyebar hoaks atau informasi palsu.

│ 🔞 Dilarang konten pornografi dan kekerasan.

│ 🗯️ Jangan menggunakan bahasa kasar atau menghina.

│ 🔒 Jangan bagikan data pribadi anggota tanpa izin.

│ 🤝 Hindari diskusi yang menimbulkan konflik.

│ ↩️ Gunakan fitur reply saat merespon pesan.

│ 🔗 Tidak share link grup lain tanpa izin.

│ 🚷 Dilarang bullying atau pelecehan.

│ 🙌 Hormati keputusan admin & moderator.

│ ⚠️ Jangan memancing atau memprovokasi anggota.

│ 🛑 Tidak melakukan penipuan.

│ 📚 Gunakan grup sesuai topik berlaku.

│ ⛔ Jangan spam konten berulang-ulang.

│ 📨 Jika ada masalah, laporkan ke admin dengan sopan.

│ 🔨 Admin berhak tindakan tanpa pemberitahuan.

│

│ *⚠️ Pelanggaran berakibat peringatan, mute, atau banned.*

│

└───────────────────────────────┘

    `.trim()

    await ctx.reply(rulesText, { parse_mode: 'Markdown' })

  },

  

  // Event handler tambahan untuk member baru join

  async onNewChatMembers(ctx) {

    const newMembers = ctx.message.new_chat_members

    for (const member of newMembers) {

      const name = member.first_name || member.username || "teman baru"

      await ctx.reply(`👋 Halo, ${name}! Selamat datang di grup. Jangan lupa baca rules ya.`)

      // Opsional: kirim rules otomatis juga

       await ctx.reply(rulesText, { parse_mode: 'Markdown' })

    }

  }

}