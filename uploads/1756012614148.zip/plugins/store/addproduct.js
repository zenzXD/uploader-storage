import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { Markup } from 'telegraf'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const dbFile = path.join(__dirname, '../../json/products.json')

function loadProducts() {
  if (!fs.existsSync(dbFile)) return []
  return JSON.parse(fs.readFileSync(dbFile))
}

function saveProducts(data) {
  fs.writeFileSync(dbFile, JSON.stringify(data, null, 2))
}

export default {
  command: ['addproduct'],
  tags: ['store'],
  desc: '➕ Tambah produk ke database',
  async handler(ctx) {
    const text = ctx.message.text?.split(' ').slice(1).join(' ')
    const reply = ctx.message?.reply_to_message
    const [name, price] = text?.split('|').map(t => t.trim()) || []

    if (!name || !price || isNaN(price)) {
      return ctx.reply('❗ *Format salah!*\nContoh: `/addproduct Es Teh | 5000`\nBalas dengan foto/audio/video jika perlu.', {
        parse_mode: 'Markdown'
      })
    }

    let fileUrl = null
    let fileType = null

    if (reply) {
      const file = reply.photo?.pop() || reply.audio || reply.document || reply.video || null
      if (file) {
        fileUrl = await ctx.telegram.getFileLink(file.file_id)
        fileType = reply.photo ? 'photo' : reply.audio ? 'audio' : reply.video ? 'video' : 'document'
      }
    }

    const products = loadProducts()
    products.push({
      id: 'PRD-' + Date.now(),
      name,
      price: parseInt(price),
      type: fileType,
      media: fileUrl?.href || null
    })
    saveProducts(products)

    await ctx.reply(`✅ *Produk berhasil ditambahkan!*
📦 Nama: *${name}*
💸 Harga: Rp${parseInt(price).toLocaleString()}
${fileUrl ? `📎 File: ${fileType}` : ''}
🛒 ID: PRD-${Date.now()}
`, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.url('📂 Lihat Produk', 'http://localhost:3030/store')]
      ])
    })
  }
}