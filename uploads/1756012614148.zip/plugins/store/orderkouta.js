import axios from 'axios'
import { config } from '../../config.js'

export default {
  command: ['orderkuota'],
  tags: ['store'],
  desc: '📶 Order kuota dari OkeConnet via API',
  private: true, // hanya bisa di PM
  premium: false,
  owner: false,

  async handler(ctx) {
    const { text, sender, reply } = ctx
    const args = text.split(' ')
    const nomor = args[1]
    const produk = args[2] // misalnya: 'DATA5GB'
    
    if (!nomor || !produk) {
      return await reply(`❗ *Contoh penggunaan:*\n/orderkuota 081234567890 DATA5GB`)
    }

    const apiKey = config.okekey // simpan apikey di config.js
    const url = `https://api.okeconnet.my.id/order?apikey=${apiKey}&nomor=${nomor}&produk=${produk}`

    try {
      const res = await axios.get(url)
      const data = res.data

      if (data.status && data.status.toLowerCase() === 'sukses') {
        return await reply(`
╭───「 📶 *ORDER KUOTA BERHASIL* 」
│ 👤 Nama: *${data.data.nama || '-'}*
│ 📱 Nomor: *${nomor}*
│ 📦 Produk: *${produk}*
│ 🆔 ID Transaksi: *${data.data.trxid || '-'}*
│ 💰 Harga: *Rp${data.data.harga || '-'}*
│ ⏰ Waktu: *${data.data.waktu || '-'}*
╰───────────────────────
✅ Terima kasih telah menggunakan layanan kami!
        `.trim())
      } else {
        return await reply(`
❌ *Gagal order kuota!*
📄 Pesan: ${data.pesan || 'Tidak diketahui'}
💡 Silakan periksa kembali nomor & produk.`)
      }
    } catch (err) {
      console.error(err)
      return await reply(`🚫 *Terjadi kesalahan saat memproses permintaan.*\nSilakan coba beberapa saat lagi.`)
    }
  }
}