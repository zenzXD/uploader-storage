import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { config } from "../../config.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default {
    command: ["storemenu","menustore"],
    tags: ["store"],
    desc: "🛍️ Menampilkan daftar fitur toko / store",

    async handler(ctx) {
        const storeDir = path.join(__dirname);
        const files = fs
            .readdirSync(storeDir)
            .filter(file => file.endsWith(".js") && file !== "storemenu.js");

        let teks = "";
        teks += `╭━━━〔 🛍️ *${config.BOTNAME} STORE MENU* 〕━━⬣\n`;
        teks += `┃ 📦 *Total Produk:* ${files.length}\n`;
        teks += `┃ 🗂️ *Kategori:* \`store/*\`\n`;
        teks += `┣━━━━━━━━━━━━━━━━━━━━━━\n`;

        for (const file of files) {
            try {
                const plugin = (await import(`./${file}`)).default;
                const commands = Array.isArray(plugin.command)
                    ? plugin.command
                    : [plugin.command];
                const desc = plugin.desc || "📁 Tidak ada deskripsi.";
                const namaCmd = commands
                    .map(cmd => `💸 \`/${cmd}\``)
                    .join("\n┃ ");

                teks += `┃ ${namaCmd}\n`;
                teks += `┃ 📝 *${desc}*\n`;
                teks += `┣━━━━━━━━━━━━━━━━━━━━━━\n`;
            } catch (e) {
                teks += `┃ ⚠️ Gagal memuat: \`${file}\`\n`;
                teks += `┣━━━━━━━━━━━━━━━━━━━━━━\n`;
            }
        }

        teks += `┃ 🧾 Ketik \`/help\` untuk bantuan lainnya.\n`;
        teks += `╰━━━━━━━━━━━━━━━━━━━━━━⬣`;

        await ctx.reply(teks, { parse_mode: "Markdown" });
    }
};
