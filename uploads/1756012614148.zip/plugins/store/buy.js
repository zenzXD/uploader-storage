import fs from 'fs'
import path from 'path'

const dbPath = './json/products.json'
const userPath = './json/users.json'

function loadProduk() {
  if (!fs.existsSync(dbPath)) return []
  return JSON.parse(fs.readFileSync(dbPath))
}

function loadUsers() {
  if (!fs.existsSync(userPath)) return []
  return JSON.parse(fs.readFileSync(userPath))
}

export default {
  command: ['buy'],
  tags: ['store'],
  desc: '🛒 Beli produk via QRIS kamu',
  async handler(ctx) {
    const body = ctx.body?.trim() || ''
    const args = body.split(/\s+/)

    // Validasi ID produk
    let produkId = args[1]

    // Jika reply ke pesan produk
    if (!produkId && ctx.message?.reply_to_message?.text) {
      const match = ctx.message.reply_to_message.text.match(/ID[:：]?\s*(\w+)/i)
      if (match) produkId = match[1]
    }

    if (!produkId) {
      return ctx.reply(
        '❗ *Format salah!*\n' +
        '📌 Contoh: `buy 001`\n' +
        '💬 Atau reply ke pesan produk.',
        { parse_mode: 'Markdown' }
      )
    }

    const produk = loadProduk().find(p => p.id === produkId)
    if (!produk) return ctx.reply('🚫 *Produk tidak ditemukan!*', { parse_mode: 'Markdown' })

    // Cek stok
    if (produk.stok <= 0) {
      return ctx.reply(`🚫 *Stok produk "${produk.nama}" sedang habis!*`, { parse_mode: 'Markdown' })
    }

    // Cek user
    const userId = String(ctx.from?.id || ctx.sender?.id)
    const users = loadUsers()
    const user = users.find(u => u.id == userId)

    if (!user) {
      return ctx.reply('⚠️ *Kamu belum terdaftar!*\nSilakan daftar terlebih dahulu.', { parse_mode: 'Markdown' })
    }

    // Tampilkan detail produk dan QRIS
    await ctx.reply(
      `🛒 *Pembelian Produk*\n\n` +
      `🆔 *ID:* \`${produk.id}\`\n` +
      `📦 *Nama:* ${produk.nama}\n` +
      `💰 *Harga:* Rp${produk.harga?.toLocaleString('id-ID') || '???'}\n` +
      `📦 *Stok Tersisa:* ${produk.stok}\n\n` +
      `📲 *Silakan bayar via QRIS:*\n` +
      `🔗 ${produk.qris}\n\n` +
      `✅ Setelah bayar, kirim bukti atau ketik *done ${produk.id}* untuk konfirmasi pembelian.`,
      { parse_mode: 'Markdown' }
    )
  }
}