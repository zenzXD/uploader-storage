import axios from 'axios'
import { v4 as uuidv4 } from 'uuid'

const configPanel = {
  url: 'https://panel.domainmu.com',
  apiKey: 'PTUq...APIKEY...GvZ',
  nestId: 1,
  eggId: 5,
  nodeId: 1,
  allocationId: 14,
  memory: 512, // dalam MB
  disk: 1024,  // dalam MB
  cpu: 100     // dalam %
}

export default {
  command: ['buyadp'],
  tags: ['store'],
  owner: false,
  desc: '🛒 Beli 1 server panel Pterodactyl',

  async handler(ctx) {
    const { url, apiKey, nestId, eggId, nodeId, allocationId, memory, disk, cpu } = configPanel

    try {
      const username = ctx.from.username || `user${ctx.from.id}`
      const password = uuidv4().slice(0, 10)
      const serverName = `srv-${username}-${Date.now()}`

      const response = await axios.post(`${url}/api/application/servers`, {
        name: serverName,
        user: 1, // ID user di panel, perlu disesuaikan!
        egg: eggId,
        docker_image: 'ghcr.io/pterodactyl/yolks:nodejs_18',
        startup: 'npm start',
        environment: {
          NODE_VERSION: "18"
        },
        limits: {
          memory,
          swap: 0,
          disk,
          io: 500,
          cpu
        },
        feature_limits: {
          databases: 1,
          backups: 1,
          allocations: 1
        },
        allocation: {
          default: allocationId
        },
        deploy: {
          locations: [nodeId],
          dedicated_ip: false,
          port_range: []
        },
        start_on_completion: true
      }, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      })

      const serverData = response.data

      await ctx.replyWithMarkdown(`
🎉 *Server berhasil dibuat!*

🖥️ *Nama:* ${serverData.attributes.name}
🌐 *Panel:* ${url}
🔑 *User:* ${username}
🔒 *Password:* ${password}
🧠 *RAM:* ${memory} MB
💽 *Disk:* ${disk} MB
⚙️ *CPU:* ${cpu}%
`)

    } catch (e) {
      console.error(e.response?.data || e)
      await ctx.reply(`❌ Gagal membuat server: ${e.response?.data?.errors?.[0]?.detail || e.message}`)
    }
  }
}