import fs from 'fs'
const dbPath = './json/products.json'

function loadProduk() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, '[]')
  return JSON.parse(fs.readFileSync(dbPath))
}

function simpanProduk(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2))
}

export default {
  command: ['delproduct', 'deleteproduct'],
  tags: ['store'],
  desc: '🗑️ Hapus produk dari daftar',
  example: '.hapusproduk 2 / .hapusproduk Nama Produk',
  async handler(ctx) {
    const arg = ctx.args.join(' ')
    if (!arg) return ctx.reply('❌ Masukkan nomor atau nama produk.\nContoh: `.hapusproduk 2` atau `.hapusproduk TikTok Premium`')

    let data = loadProduk()
    let index = -1

    if (!isNaN(arg)) {
      index = parseInt(arg) - 1
    } else {
      index = data.findIndex(p => p.nama.toLowerCase() === arg.toLowerCase())
    }

    if (index < 0 || index >= data.length) return ctx.reply('🚫 Produk tidak ditemukan.')

    const removed = data.splice(index, 1)[0]
    simpanProduk(data)

    ctx.reply(`✅ Produk *${removed.nama}* telah dihapus.`)
  }
}