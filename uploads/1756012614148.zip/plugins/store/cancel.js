import fetch from 'node-fetch'
import { config } from '../../config.js'

const API_KEY = config.VIRTUALSIM_API_KEY
const BASE_URL = 'https://5sim.net/v1/user' // base URL resmi

export default {
  command: ['cancel'],
  tags: ['store'],
  desc: '❌ Batalkan nomor virtual (jika belum dipakai)',
  async handler(ctx) {
    const args = ctx.body.trim().split(/\s+/)
    const id = args[1]
    if (!id) return ctx.reply('❌ Gunakan format: *.cancel <id>*')

    try {
      const res = await fetch(`${BASE_URL}/cancel/${id}`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          Accept: 'application/json'
        }
      })

      const data = await res.json()
      if (!res.ok) {
        console.error('[CANCEL ERROR]', data)
        return ctx.reply(`🚫 Gagal membatalkan nomor: ${data.message || res.statusText}`)
      }

      if (data.status === 'CANCELED') {
        ctx.reply(`✅ Nomor dengan ID \`${id}\` berhasil dibatalkan.`)
      } else {
        ctx.reply(`⚠️ Gagal membatalkan nomor. Status saat ini: ${data.status}`)
      }
    } catch (err) {
      console.error('[CANCEL ERROR]', err)
      ctx.reply('🚫 Terjadi kesalahan saat membatalkan nomor.')
    }
  }
}