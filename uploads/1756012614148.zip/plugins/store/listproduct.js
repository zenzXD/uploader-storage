import axios from "axios";
import { config } from "../../config.js";

export default {
    command: ["listproduk", "produkkuota"],
    tags: ["store"],
    desc: "📦 Menampilkan daftar produk kuota dari OkeConnet",
    async handler(ctx) {
        const { reply } = ctx;
        const apiKey = config.okekey;
        const url = `https://api.okeconnet.my.id/produk?apikey=${apiKey}`;

        try {
            const res = await axios.get(url);
            const data = res.data;

            if (!data.status || data.status.toLowerCase() !== "sukses") {
                return await reply(
                    `❌ *Gagal mengambil data produk!*\n📛 *Pesan:* ${
                        data.pesan || "Tidak diketahui"
                    }`
                );
            }

            const produkList = data.data || [];
            if (!produkList.length)
                return await reply(`📦 *Tidak ada produk ditemukan!*`);

            const listTampil = produkList
                .slice(0, 30)
                .map((item, i) =>
                    `
${i + 1}. 📦 *${item.kode}*
   ┣ 📛 *${item.nama}*
   ┗ 💰 *Rp${item.harga}*
      `.trim()
                )
                .join("\n");

            await reply(
                `
╭━━━━━━━〔 🛒 *LIST PRODUK KUOTA* 〕━━━━━━━╮
┣ 👥 Total Produk: *${produkList.length}*
┣ 📌 Tampilkan kode untuk pemesanan!
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
${listTampil}

╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
📥 *Cara Order:*
Ketik: /orderkuota [nomor] [kode]
Contoh: /orderkuota 081234567890 DATA5GB

🔍 Gunakan /listprodukfull untuk melihat semua produk!
      `.trim()
            );
        } catch (err) {
            console.error(err);
            return await reply(
                `🚫 *Gagal memuat daftar produk!*\n🔁 Silakan coba lagi nanti.`
            );
        }
    }
};
