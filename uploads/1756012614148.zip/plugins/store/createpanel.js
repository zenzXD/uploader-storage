

import fs from 'fs/promises'

import fetch from 'node-fetch'

import crypto from 'crypto'

import { writeDatabase } from '../../lib/database.js'

import { config } from '../../config.js'

const saldoPath = config.saldoPath

// Konfigurasi internal

const domain = 'https://dinzxzan.biz.id' // jangan kasih / di akhir

const apikey = 'ptla_J5nnSqbvI8e0fTlhA9wQwv8izekOSQS8q3MgVQXP53d'

const capikey = 'ptlc_CP3OYrh3iGSW3sKugzfnvmNWqCVClp8NdCSNlb4vh6y'

const loc = 1 // sesuaikan jika kamu punya location ID berbeda

const egg = 5 // ID egg yang digunakan, sesuaikan

// Harga RAM (dalam Rupiah)

const hargaList = {

  "1gb": 3000,

  "2gb": 5000,

  "3gb": 7000,

  "4gb": 9000,

  "5gb": 11000,

  "6gb": 13000,

  "7gb": 15000,

  "8gb": 17000,

  "9gb": 19000,

  "10gb": 21000,

  "unlimited": 30000,

  "unli": 30000

}

// Spesifikasi masing-masing paket

const specs = {

  "1gb": { disk: 1000, cpu: 50 },

  "2gb": { disk: 3000, cpu: 100 },

  "3gb": { disk: 6000, cpu: 150 },

  "4gb": { disk: 8000, cpu: 200 },

  "5gb": { disk: 10000, cpu: 250 },

  "6gb": { disk: 12000, cpu: 300 },

  "7gb": { disk: 14000, cpu: 350 },

  "8gb": { disk: 16000, cpu: 400 },

  "9gb": { disk: 18000, cpu: 450 },

  "10gb": { disk: 20000, cpu: 500 }

}

const buypanelHandler = async (ctx) => {

  if (ctx.chat.type !== 'private')

    return ctx.reply("🛑 Beli panel hanya bisa dilakukan di *private chat*", { parse_mode: "Markdown" })

  const sender = ctx.from.id.toString()

  if (!db.users[sender]?.status_deposit) {

    return ctx.reply("🌸 Kamu belum memulai pembelian panel.\n\nKetik: /belipanel namamu", { parse_mode: "Markdown" });

  }

  const text = ctx.message.text.split(' ').slice(1).join(' ')

  if (!text.includes('|')) {

    return ctx.reply("❌ *Format salah!*\nGunakan: /buypanel username|ram\nContoh: /buypanel Tradz|4gb", { parse_mode: 'Markdown' })

  }

  let [usernameRaw, ramInputRaw] = text.split("|")

  const username = usernameRaw.trim()

  const ramInput = ramInputRaw.toLowerCase().replace(/ram|\s+/g, '').replace(/[^a-z0-9]/gi, '')

  if (!hargaList[ramInput])

    return ctx.reply("⚠️ *RAM tidak valid!*\nGunakan: 1gb–10gb atau unlimited", { parse_mode: 'Markdown' })

  const saldoData = JSON.parse(await fs.readFile(saldoPath))

  const userSaldo = saldoData[sender] || 0

  const harga = hargaList[ramInput]

  if (userSaldo < harga) {

    return ctx.reply(💰 *Saldo tidak cukup!*\n\n💸 Harga: Rp${harga.toLocaleString()}\n💼 Saldo kamu: Rp${userSaldo.toLocaleString()}, { parse_mode: 'Markdown' })

  }

  saldoData[sender] -= harga

  await fs.writeFile(saldoPath, JSON.stringify(saldoData, null, 2))

  const isUnli = ramInput === "unlimited" || ramInput === "unli"

  const ramValue = isUnli ? 0 : parseInt(ramInput) * 1000

  const diskValue = isUnli ? 0 : specs[ramInput].disk

  const cpuValue = isUnli ? 0 : specs[ramInput].cpu

  const email = ${username}@gmail.com

  const name = username.charAt(0).toUpperCase() + username.slice(1) + " Server"

  const password = username + crypto.randomBytes(2).toString("hex")

  const userRes = await fetch(${domain}/api/application/users, {

    method: "POST",

    headers: {

      "Authorization": Bearer ${apikey},

      "Accept": "application/json",

      "Content-Type": "application/json"

    },

    body: JSON.stringify({

      email,

      username,

      first_name: name,

      last_name: "Server",

      language: "en",

      password

    })

  })

  const userData = await userRes.json()

  if (userData.errors) return ctx.reply(❌ *Gagal membuat user:*\n${userData.errors[0].detail}, { parse_mode: "Markdown" })

  const user = userData.attributes

  const serverRes = await fetch(${domain}/api/application/servers, {

    method: "POST",

    headers: {

      "Authorization": Bearer ${apikey},

      "Accept": "application/json",

      "Content-Type": "application/json"

},

    body: JSON.stringify({

      name,

      user: user.id,

      egg,

      docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",

      startup: "npm start",

      environment: {

        INST: "npm",

        USER_UPLOAD: "0",

        AUTO_UPDATE: "0",

        CMD_RUN: "npm start"

      },

      limits: {

        memory: ramValue,

        swap: 0,

        disk: diskValue,

        io: 500,

        cpu: cpuValue

      },

      feature_limits: {

        databases: 5,

        backups: 5,

        allocations: 2

      },

      deploy: {

        locations: [loc],

        dedicated_ip: false,

        port_range: []

      }

    })

  })

  const serverData = await serverRes.json()

  if (serverData.errors) return ctx.reply(❌ *Gagal membuat server:*\n${serverData.errors[0].detail}, { parse_mode: "Markdown" })

  const server = serverData.attributes

  const teksPanel = 

╭──〔 🌐 *PANEL SERVER* 〕──╮

│ 🆔 *Server ID*: ${server.id}

│ 👤 *Username*: ${user.username}

│ 🔐 *Password*: ${password}

│

│ 💾 *Spesifikasi*

│ ├─ RAM: ${ramValue === 0 ? "Unlimited" : ${ramValue / 1000}GB}

│ ├─ Disk: ${diskValue === 0 ? "Unlimited" : ${diskValue / 1000}GB}

│ └─ CPU: ${cpuValue === 0 ? "Unlimited" : ${cpuValue}%}

│

│ 🔗 *Panel:* ${domain}

│

│ 📌 *Keterangan:*

│ ├─ Expired: 1 bulan

│ └─ Garansi: 15 hari

╰──⛩️ Jangan disebar ya!

.trim()

  await ctx.reply(teksPanel, { parse_mode: "Markdown" })

  db.users[sender].status_deposit = false

  db.users[sender].pending_panel = null

  db.saveDB()

}

export default {

  command: ['buypanel'],

  tags: ['store'],

  desc: '🛒 Beli panel Pterodactyl',

  private: true,

  handler: buypanelHandler

}