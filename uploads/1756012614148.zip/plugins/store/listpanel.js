// store/listpanel.js
export default {
  command: ['listpanel', 'paketpanel'],
  tags: ['store'],
  desc: 'Menampilkan daftar paket panel sebelum pembelian',
  async handler(m, { conn }) {
    const daftarPanel = [
      { size: '1 GB', harga: '5k', status: '✅ Ready', spek: '1 Core • 10GB Disk' },
      { size: '2 GB', harga: '8k', status: '✅ Ready', spek: '1 Core • 15GB Disk' },
      { size: '3 GB', harga: '10k', status: '✅ Ready', spek: '2 Core • 20GB Disk' },
      { size: '4 GB', harga: '13k', status: '✅ Ready', spek: '2 Core • 25GB Disk' },
      { size: '5 GB', harga: '15k', status: '✅ Ready', spek: '2 Core • 30GB Disk' },
      { size: '6 GB', harga: '18k', status: '✅ Ready', spek: '3 Core • 35GB Disk' },
      { size: '8 GB', harga: '22k', status: '✅ Ready', spek: '4 Core • 40GB Disk' },
      { size: '10 GB', harga: '27k', status: '✅ Ready', spek: '4 Core • 50GB Disk' },
      { size: '♾️ Unlimited', harga: '50k', status: '✅ Ready', spek: '∞ Core • ∞ Storage' }
    ]

    let teks = `╭─〔  *📦 DAFTAR PAKET PANEL* 〕\n`
    teks += `│\n`
    teks += `│ 🌐 *Lokasi*: 🇮🇩 ID & 🇸🇬 SG\n`
    teks += `│ 💳 *Pembayaran*: Dana / Qris / Pulsa\n`
    teks += `│ ⚙️ *Auto Setup • 100% Online 24/7*\n`
    teks += `│\n`
    teks += `├────────────────────────────\n`

    for (let panel of daftarPanel) {
      teks += `│ 🧩 *Paket:* ${panel.size}\n`
      teks += `│ 💰 Harga : ${panel.harga}\n`
      teks += `│ 📦 Status: ${panel.status}\n`
      teks += `│ ⚙️ Spek  : _${panel.spek}_\n`
      teks += `├────────────────────────────\n`
    }

    teks += `│ 🛍️ *Cara Order:*\n`
    teks += `│ ➤ Ketik: *cpanel 2gb* (contoh)\n`
    teks += `╰────────────────────────────╯`

    await conn.reply(m.chat, teks, m)
  }
}