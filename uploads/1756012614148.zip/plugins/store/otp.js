import fetch from 'node-fetch'
import { config } from '../../config.js'

const API_KEY = config.VIRTUALSIM_API_KEY
const BASE_URL = 'https://api.5sim.net/v1/user'

export default {
  command: ['otp'],
  tags: ['store'],
  desc: '📩 Cek kode OTP dari nomor virtual',
  async handler(ctx) {
    const id = ctx.body.trim().split(/\s+/)[1]
    if (!id) return ctx.reply('❌ Gunakan format: *.otp <id>*')

    try {
      const res = await fetch(`${BASE_URL}/check/${id}`, {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          Accept: 'application/json'
        }
      })

      if (!res.ok) throw new Error(`Gagal cek OTP (${res.status})`)
      const data = await res.json()

      if (data.sms && data.sms.length > 0) {
        const pesan = data.sms.map(s => `📨 Dari: ${s.sender}\n📬 Pesan: ${s.text}`).join('\n\n')
        return ctx.reply(`✅ *OTP Diterima!*\n\n${pesan}`)
      } else {
        return ctx.reply('⏳ Belum ada OTP masuk. Tunggu beberapa saat lalu coba lagi.')
      }
    } catch (err) {
      console.error('[OTP ERROR]', err)
      ctx.reply('🚫 Gagal cek OTP. Periksa ID atau coba lagi nanti.')
    }
  }
}