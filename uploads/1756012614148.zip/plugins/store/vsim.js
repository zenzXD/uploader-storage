import fetch from 'node-fetch'
import { config } from '../../config.js'
import { getUser, kurangiSaldo, tambahRiwayat } from '../../lib/users.js'

const API_KEY = config.VIRTUALSIM_API_KEY
const BASE_URL = 'https://api.5sim.net/v1'

export default {
  command: ['sim', 'virtualsim', 'simlayanan'],
  tags: ['store'],
  desc: '📱 Beli nomor virtual OTP & lihat layanan tersedia (via 5sim)',
  async handler(ctx) {
    const args = ctx.body?.trim().split(/\s+/) || []
    const cmd = ctx.command.toLowerCase()

    // ==============================
    // 📄 FITUR LIHAT LAYANAN
    // ==============================
    if (cmd === 'simlayanan') {
      const negara = args[1]?.toLowerCase() || 'indonesia'
      await ctx.reply(`📦 Mengambil daftar layanan untuk *${negara.toUpperCase()}*...`)

      try {
        const res = await fetch(`${BASE_URL}/guest/prices?country=${negara}&product=any`, {
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            Accept: 'application/json'
          }
        })

        if (!res.ok) throw new Error(`API gagal (${res.status})`)
        const data = await res.json()

        const daftar = Object.entries(data[negara] || {})
          .map(([layanan, info]) => `• *${layanan}* - $${info.cost} (${info.count} tersedia)`)
          .slice(0, 50)
          .join('\n')

        if (!daftar) return ctx.reply(`🚫 Tidak ada layanan ditemukan untuk negara *${negara}*.`)

        return ctx.reply(
          `📄 *Layanan Tersedia - ${negara.toUpperCase()}*\n\n${daftar}\n\n` +
          `📲 Gunakan: *.sim ${negara} layanan* untuk beli nomor.`
        )
      } catch (e) {
        console.error('[SIMLAYANAN ERROR]', e)
        return ctx.reply('⚠️ Gagal mengambil daftar layanan. Periksa API Key dan coba lagi.')
      }
    }

    // ==============================
    // 📲 FITUR BELI NOMOR VIRTUAL
    // ==============================
    const negara = args[1]?.toLowerCase() || 'indonesia'
    const layanan = args[2]?.toLowerCase() || 'telegram'

    await ctx.reply(`🛰️ *Sedang mencari nomor...*\n\n🔍 *Layanan:* ${layanan}\n🌍 *Negara:* ${negara}`)

    try {
      const user = await getUser(ctx.sender)
      if (!user) return ctx.reply('❌ Kamu belum terdaftar!\n📌 Ketik `.daftar` untuk mendaftar.')

      const res = await fetch(`${BASE_URL}/user/buy/activation/${negara}/${layanan}`, {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          Accept: 'application/json'
        }
      })

      if (!res.ok) throw new Error(`❌ Gagal ambil nomor (${res.status})`)
      const data = await res.json()

      if (!data?.phone || !data.price) {
        return ctx.reply('🚫 Nomor tidak tersedia untuk layanan tersebut.\nSilakan coba layanan atau negara lain.')
      }

      if (user.saldo < data.price) {
        return ctx.reply(
          `💰 *Saldo tidak cukup!*\n\n` +
          `🧾 Harga: *$${data.price}*\n💳 Saldo kamu: *$${user.saldo}*\n\n` +
          `🛒 Silakan isi ulang saldo untuk melanjutkan.`
        )
      }

      await kurangiSaldo(ctx.sender, data.price, `Beli nomor ${layanan} (${data.phone})`)
      await tambahRiwayat(ctx.sender, {
        jenis: 'virtualsim',
        harga: data.price,
        detail: {
          negara,
          layanan,
          nomor: data.phone,
          id: data.id
        },
        waktu: Date.now()
      })

      await ctx.reply(
        `🎉 *Nomor Virtual Berhasil Dibeli!*\n\n` +
        `🌍 *Negara:* ${negara}\n` +
        `🔧 *Layanan:* ${layanan}\n` +
        `📞 *Nomor:* \`${data.phone}\`\n` +
        `🆔 *ID:* \`${data.id}\`\n` +
        `💵 *Harga:* $${data.price}\n\n` +
        `📩 Tunggu OTP dari layanan.\n` +
        `📲 Ketik: *.otp ${data.id}* untuk melihat kode.`
      )
    } catch (err) {
      console.error('[VIRTUALSIM ERROR]', err)
      return ctx.reply(
        `🚫 *Terjadi kesalahan saat memproses!*\n\n` +
        `🔒 Pastikan API key valid & layanan tersedia.\n` +
        `🧰 Jika terus gagal, coba lagi nanti atau hubungi admin.`
      )
    }
  }
}