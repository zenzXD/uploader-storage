import fs from 'fs'
import path from 'path'
const dbPath = './json/products.json'

function loadProduk() {
  if (!fs.existsSync(dbPath)) return []
  return JSON.parse(fs.readFileSync(dbPath))
}

export default {
  command: ['done'],
  tags: ['store'],
  desc: '✅ Konfirmasi setelah bayar',
  async handler(ctx) {
    const args = ctx.body.trim().split(' ')
    if (args.length < 2) return ctx.reply('Contoh: done 001')

    const produkId = args[1]
    const produk = loadProduk().find(p => p.id === produkId)
    if (!produk) return ctx.reply('Produk tidak ditemukan.')

    const filePath = path.resolve(produk.file)
    if (!fs.existsSync(filePath)) return ctx.reply('❌ File tidak ditemukan.')

    await ctx.reply('✅ Pembayaran diterima. Mengirim file...')
    ctx.replyWithDocument({ source: filePath, filename: path.basename(filePath) })
  }
}