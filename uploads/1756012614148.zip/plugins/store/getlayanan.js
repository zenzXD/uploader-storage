import fetch from 'node-fetch'
import { config } from '../../config.js'
import { getUser, kurangiSaldo, tambahRiwayat } from '../../lib/users.js'

const API_KEY = config.VIRTUALSIM_API_KEY
const BASE_GUEST = 'https://5sim.net/v1/guest'
const BASE_USER = 'https://5sim.net/v1/user'

export default {
  command: ['sim', 'virtualsim', 'getlayanan', 'listlayanan'],
  tags: ['store'],
  desc: '📱 Beli nomor virtual OTP (via 5sim) & lihat layanan tersedia',
  async handler(ctx) {
    const args = ctx.body?.trim().split(/\s+/) || []
    const cmd = ctx.command.toLowerCase()
    const negara = args[1] || 'indonesia'
    const layanan = args[2] || 'telegram'

    // ========================
    // 📦 TAMPILKAN LAYANAN NEGARA
    // ========================
    if (cmd === 'getlayanan' || cmd === 'listlayanan') {
      await ctx.reply(`📡 Mengambil layanan dari *${negara}*...`)

      try {
        const res = await fetch(`${BASE_GUEST}/prices?country=${negara}&product=any`, {
          headers: {
            Authorization: `Bearer ${API_KEY}`,
            Accept: 'application/json'
          }
        })

        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const data = await res.json()

        const layananList = Object.entries(data[negara] || {})
          .map(([layanan, info]) => `• *${layanan}* — $${info.cost} (${info.count} tersedia)`)
          .slice(0, 50)
          .join('\n')

        if (!layananList) return ctx.reply('❌ Tidak ada layanan ditemukan untuk negara tersebut.')

        return ctx.reply(
          `🗂️ *Daftar Layanan 5SIM - ${negara.toUpperCase()}*\n\n` +
          `${layananList}\n\n` +
          `🛒 Ketik: *.sim ${negara} <layanan>* untuk beli.`
        )
      } catch (e) {
        console.error('[GETLAYANAN ERROR]', e)
        return ctx.reply('🚫 Gagal memuat layanan. Coba negara lain atau periksa API Key.')
      }
    }

    // ========================
    // 📲 BELI NOMOR VIRTUAL
    // ========================
    await ctx.reply(`🔍 Mencari nomor untuk *${layanan}* di *${negara}*...`)

    try {
      const user = await getUser(ctx.sender)
      if (!user) return ctx.reply('❌ Kamu belum terdaftar. Ketik: `.daftar` dulu.')

      const res = await fetch(`${BASE_USER}/buy/activation/${negara}/${layanan}`, {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          Accept: 'application/json'
        }
      })

      if (!res.ok) throw new Error(`Gagal ambil nomor (${res.status})`)
      const data = await res.json()

      if (!data?.phone || !data.price) {
        return ctx.reply('🚫 Nomor tidak tersedia. Coba negara/layanan lain.')
      }

      if (user.saldo < data.price) {
        return ctx.reply(
          `💰 *Saldo tidak cukup!*\n\n` +
          `📦 Harga: *$${data.price}*\n` +
          `💼 Saldo kamu: *$${user.saldo}*\n\n` +
          `🔁 Silakan isi ulang untuk lanjut beli.`
        )
      }

      await kurangiSaldo(ctx.sender, data.price, `Beli nomor ${layanan} (${data.phone})`)
      await tambahRiwayat(ctx.sender, {
        jenis: 'virtualsim',
        harga: data.price,
        detail: {
          negara,
          layanan,
          nomor: data.phone,
          id: data.id
        },
        waktu: Date.now()
      })

      return ctx.reply(
        `✅ *Nomor Virtual Siap!*\n\n` +
        `🌍 Negara: *${negara}*\n` +
        `🔧 Layanan: *${layanan}*\n` +
        `📞 Nomor: \`${data.phone}\`\n` +
        `🆔 ID: \`${data.id}\`\n` +
        `💵 Harga: $${data.price}\n\n` +
        `📩 Tunggu OTP dari layanan.\n` +
        `🔐 Gunakan perintah: *.otp ${data.id}* untuk cek kode.`
      )
    } catch (err) {
      console.error('[BUY SIM ERROR]', err)
      return ctx.reply('🚫 Terjadi kesalahan saat pembelian. Coba beberapa saat lagi.')
    }
  }
}