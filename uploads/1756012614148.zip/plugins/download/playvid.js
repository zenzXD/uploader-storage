// plugins/tools/playvid.js
import ytdl from 'ytdl-core';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

try {
  const ffmpegPath = execSync('which ffmpeg').toString().trim();
  ffmpeg.setFfmpegPath(ffmpegPath);
  console.log(`✅ [LinQiye] FFMPEG OK: ${ffmpegPath}`);
} catch {
  console.log('❌ [LinQiye] ffmpeg gak ketemu bro!');
}

export default {
  command: ['playvid'],
  tags: ['downloader'],
  desc: '🎥 Kirim video dari YouTube (ala Lin Qiye style)',
  async handler(ctx) {
    const query = ctx.args.join(' ');
    if (!query) return ctx.reply('⚠️ Ketik judul atau keyword videonya, boss!');

    await ctx.reply('🔎 Sedang mencari video YouTube... ⏳');

    const res = await fetch(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
    const html = await res.text();
    const videoId = html.match(/"videoId":"(.*?)"/)?.[1];
    if (!videoId) return ctx.reply('😵‍💫 Gagal nemuin video! Coba lagi.');

    const url = `https://www.youtube.com/watch?v=${videoId}`;
    const filePath = path.join(__dirname, `../../tmp/${videoId}.mp4`);

    await ctx.reply('🎬 Lagi render video pakai chakra Lin Qiye... 🔥');

    await new Promise((resolve, reject) => {
      ffmpeg(ytdl(url, { quality: 'highestvideo' }))
        .videoCodec('libx264')
        .save(filePath)
        .on('end', resolve)
        .on('error', reject);
    });

    await ctx.replyWithVideo({ source: fs.createReadStream(filePath) }, {
      caption: `✅ *Selesai!* Berikut video dari YouTube: ${query}`,
      parse_mode: 'Markdown'
    });
    fs.unlinkSync(filePath);
  },
};