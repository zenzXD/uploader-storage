export default {
  command: ['tiktok', 'playvidt', ],
  tags: ['downloader'],
  desc: 'Perintah untuk mengelola status dan kontrol bot',
  async handler(ctx) {
    const cmd = ctx.command.name;
    const args = ctx.message.text?.split(' ').slice(1) ?? [];

    switch (cmd) {
      case 'tiktok':
        await ctx.reply('♻️ Restarting bot...');
        process.exit(0); // akan di-restart oleh PM2 / nodemon
        break;

      case 'playvid':
        return ctx.reply(`✅ Bot aktif!\n🕒 ${new Date().toLocaleString()}`);

      case 'play':
        return ctx.reply(`🤖 Info Bot:
• Nama: Lin Qiye Bot
• Platform: Telegram
• Status: Aktif
• Library: Telegraf
• Source: ESM + Modular`);

      default:
        return ctx.reply(`⚠️ Command *${cmd}* belum tersedia.`);
    }
  }
}