// plugins/tools/playlist.js
import ytpl from 'ytpl';
import ytdl from 'ytdl-core';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

try {
  const ffmpegPath = execSync('which ffmpeg').toString().trim();
  ffmpeg.setFfmpegPath(ffmpegPath);
} catch {
  console.log('❌ [LinQiye] ffmpeg gak ketemu!');
}

export default {
  command: ['playlist'],
  tags: ['downloader'],
  desc: '🎶 Convert playlist YouTube jadi audio savage',
  async handler(ctx) {
    const url = ctx.args[0];
    if (!url || !url.includes('list=')) return ctx.reply('❗ Kirim URL playlist YouTube dong!');

    const playlist = await ytpl(url, { limit: 5 });

    await ctx.reply(`📦 Playlist terdeteksi: *${playlist.title}*\n🎵 Lagu ditemukan: ${playlist.items.length}\n\n🧪 Proses dimulai... tungguin ya!`, { parse_mode: 'Markdown' });

    for (const video of playlist.items) {
      const out = path.join(__dirname, `../../tmp/${video.id}.mp3`);
      await ctx.reply(`🎧 Sedang proses: *${video.title}*`, { parse_mode: 'Markdown' });

      await new Promise((resolve, reject) => {
        ffmpeg(ytdl(video.url, { quality: 'highestaudio' }))
          .audioBitrate(128)
          .save(out)
          .on('end', resolve)
          .on('error', reject);
      });

      await ctx.replyWithAudio({ source: fs.createReadStream(out) }, {
        title: video.title,
        performer: 'YouTube Savage',
        caption: `✅ Berhasil convert lagu: *${video.title}*`,
        parse_mode: 'Markdown'
      });

      fs.unlinkSync(out);
    }

    await ctx.reply('✨ Semua lagu dari playlist udah dikirim! Lin Qiye pamit! ⚡');
  },
};