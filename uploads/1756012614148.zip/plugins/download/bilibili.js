import axios from 'axios'

import qs from 'qs'

async function bilibiliDown(urls) {

  function getBilibiliId(url) {

    const match = url.match(/\/video\/(\d+)/)

    return match ? match[1] : null

  }

  const videoId = getBilibiliId(urls)

  const headers = {

    'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',

    'Accept': '*/*',

    'Referer': 'https://bilibili-video-downloader.com/id/',

    'Content-Type': 'application/x-www-form-urlencoded',

    'Cookie': 'night=0; pll_language=id'

  }

  const data = qs.stringify({

    nonce: 'e5a666b33e', // ⚠️ nonce bisa kadaluarsa

    action: 'get_bilibili_tv_video',

    aid: videoId

  })

  try {

    const response = await axios.post(

      'https://bilibili-video-downloader.com/wp-admin/admin-ajax.php',

      data,

      { headers }

    )

    return response.data

  } catch (error) {

    return { error: error.message }

  }

}

export default {

  command: ['bilibili'],

  tags: ['downloader'],

  desc: '📥 Download video dari Bilibili (via bilibili-video-downloader.com)',

  async handler(ctx) {

    const input = ctx.text?.split(' ')[1]

    const reply = (msg, opt) => ctx.reply(msg, opt)

    if (!input || !input.includes('bilibili.com')) {

      return reply(`🚫 *Link tidak valid!*

📌 *Contoh penggunaan:*

\`\`\`

/bilibili https://www.bilibili.com/video/123456789

\`\`\`

Pastikan URL mengandung */video/*`, {

        parse_mode: 'Markdown'

      })

    }

    await reply('🔍 *Sedang mengambil data dari Bilibili...*\nMohon tunggu sebentar ya kak! ⏳', {

      parse_mode: 'Markdown'

    })

    try {

      const result = await bilibiliDown(input)

      if (result?.error || !result?.data?.video_url) {

        return reply(`⚠️ *Gagal mengambil video!*

        

🔎 *Pesan:*

\`${result?.error || 'Tidak ditemukan URL video.'}\``, {

          parse_mode: 'Markdown'

        })

      }

      const videoUrl = result.data.video_url

      const videoId = input.match(/\/video\/(\d+)/)?.[1] || 'bilibili_video'

      await ctx.replyWithDocument(

        { url: videoUrl },

        {

          caption: `✅ *Berhasil mengunduh dari Bilibili!*\n\n🎬 *ID Video:* \`${videoId}\`\n📥 *Sedang mengirim file...*`,

          parse_mode: 'Markdown',

          filename: `bilibili_${videoId}.mp4`,

          contentType: 'video/mp4'

        }

      )

    } catch (e) {

      console.error('Bilibili Error:', e)

      reply(`🚫 *Terjadi kesalahan saat memproses permintaan:*\n\`${e.message}\``, {

        parse_mode: 'Markdown'

      })

    }

  }

}