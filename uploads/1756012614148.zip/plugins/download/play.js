import ytSearch from 'yt-search'
import fetch from 'node-fetch'
import { config } from '../../config.js'

export default {
  command: ['play', 'song', 'ds'],
  tags: ['downloader'],
  desc: '🎵 Download lagu dari YouTube',
  limit: true,
  premium: false,

  async handler(ctx) {
    const text = ctx.text?.split(' ').slice(1).join(' ')
    if (!text) return ctx.reply('❌ *Masukkan judul atau link YouTube!*')

    await ctx.reply('⏳ *Sedang mencari dan mengunduh audio...*')

    try {
      const result = await ytSearch(text)
      const video = result.videos[0]
      if (!video) return ctx.reply('❌ Video/Audio tidak ditemukan!')

      if (video.seconds >= 3600)
        return ctx.reply('⚠️ Video terlalu panjang (maksimal 1 jam)')

      const apiUrl = `https://api.botcahx.eu.org/api/dowloader/yt?url=${video.url}&apikey=${config.BOTCAHX_API_KEY}`

      const res = await fetch(apiUrl)
      const data = await res.json()
      const audioUrl = data.result?.mp3

      if (!audioUrl) return ctx.reply('❌ Gagal mendapatkan audio.')

      // Caption dengan hiasan
      const caption = `
🎵 *YOUTUBE AUDIO*
────────────────────
📌 *Judul:* ${video.title}
🕒 *Durasi:* ${video.timestamp}
👁️ *Views:* ${video.views.toLocaleString()}
📤 *Upload:* ${video.ago}
👤 *Channel:* ${video.author.name}
🔗 *Link:* [Klik di sini](${video.url})
📝 *Deskripsi:* ${video.description?.split('\n')[0] || '-'}
────────────────────
💡 *Bot by ${config.BOTNAME || 'Donghua Bot'}*
`.trim()

      // Kirim thumbnail & caption
      await ctx.replyWithPhoto(
        { url: video.image },
        {
          caption,
          parse_mode: 'Markdown',
          disable_web_page_preview: true,
        }
      )

      // Kirim audio
      await ctx.replyWithAudio(
        { url: audioUrl },
        {
          title: video.title,
          performer: video.author.name,
          thumbnail: { url: video.image },
        }
      )
    } catch (err) {
      console.error(err)
      ctx.reply('⚠️ Terjadi kesalahan saat mengunduh audio.')
    }
  }
}