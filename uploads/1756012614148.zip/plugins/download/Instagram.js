import fetch from 'node-fetch'

export default {

  command: ['igdl','ig','instagram'],

  tags: ['downloader'],

  desc: '📥 Download media Instagram via link (foto/video)',

  async handler(ctx) {

    const url = ctx.text?.split(' ')[1]

    const reply = (msg) => ctx.reply(msg)

    const userId = ctx.from?.id

    const isPrivate = ctx.chat.type === 'private'

    if (!url) {

      return reply(`❗ *Tautan Tidak Ditemukan!*

Kirimkan tautan postingan Instagram yang ingin diunduh.

📌 Contoh:

\`\`\`

/igdl https://www.instagram.com/p/Cx123xyz/

\`\`\``)

    }

    try {

      const apiUrl = `https://www.sankavollerei.com/download/instagram?apikey=planaai&url=${encodeURIComponent(url)}`

      const res = await fetch(apiUrl)

      const data = await res.json()

      if (!data || !data.url) {

        return reply(`❌ *Gagal mengambil media!*

Pastikan link Instagram valid atau coba beberapa saat lagi.`)

      }

      const isImage = data.url.match(/\.(jpg|png|jpeg|gif)$/i)

      const caption = `╭───[ *📥 INSTAGRAM MEDIA* ]───⬣\n` +

                      `│✨ *Berhasil Diunduh!*\n` +

                      `│📎 Link: ${url}\n` +

                      `╰──────────────⬣`

      const sendToPrivate = async () => {

        try {

          if (isImage) {

            await ctx.telegram.sendPhoto(userId, data.url, {

              caption,

              parse_mode: 'Markdown'

            })

          } else {

            await ctx.telegram.sendVideo(userId, data.url, {

              caption,

              parse_mode: 'Markdown'

            })

          }

        } catch (error) {

          if (error.code === 403) {

            return reply(`🚫 *Gagal mengirim ke chat pribadi!*\n\nKamu belum pernah memulai bot di private.\n\n➡️ Silakan kirim /start ke bot terlebih dahulu.`)

          } else {

            console.error('Gagal kirim ke private:', error)

            return reply(`❌ *Terjadi kesalahan saat mengirim media ke DM.*`)

          }

        }

      }

      if (isPrivate) {

        await sendToPrivate()

      } else {

        await reply(`📬 *Permintaan diterima!*\nMedia sedang dikirim ke chat pribadi kamu.`)

        await sendToPrivate()

      }

    } catch (err) {

      console.error('IG Download Error:', err)

      return reply(`🚫 *Terjadi kesalahan saat menghubungi server!*

Silakan coba lagi nanti.`)

    }

  }

}