import axios from 'axios'
import { Markup } from 'telegraf'

export default {
  command: ['aio'],
  tags: ['downloader'],
  help: ['aio <url>'],
  desc: '📥 Downloader semua platform dari URL',

  async handler(ctx) {
    const text = ctx.message.text.split(' ').slice(1).join(' ')
    if (!text) {
      return ctx.reply(`
╭───〔 *❗ PERINTAH SALAH* 〕───⬣
│ Kirim URL yang ingin didownload!
│
│ Contoh: 
│ /aio https://youtu.be/example
╰────────────⬣
`, { parse_mode: 'Markdown' })
    }

    const url = text.trim()
    const userId = ctx.from.id

    await ctx.reply('⏳ *Tunggu sebentar...* Sedang memproses link kamu 🔍', { parse_mode: 'Markdown' })

    try {
      const res = await axios.get(`https://zenzxz.dpdns.org/downloader/aio?url=${encodeURIComponent(url)}`)
      const data = res.data

      if (!data.status || !data.result) {
        return ctx.reply(`
╭───〔 *⚠️ GAGAL* 〕───⬣
│ Link tidak valid atau tidak didukung.
╰────────────⬣
`, { parse_mode: 'Markdown' })
      }

      const { title, thumbnail, source, audio, video } = data.result

      const caption = `
╭───〔 *📥 HASIL DOWNLOAD* 〕───⬣
│📌 *Judul:* ${title}
│🌐 *Sumber:* ${source}
│🔗 *Link:* [Klik di sini](${url})
╰────────────⬣
`.trim()

      const thumb = thumbnail || 'https://telegra.ph/file/8b8b8b8b8b.jpg'

      const sendToPrivate = async () => {
        await ctx.telegram.sendPhoto(userId, { url: thumb }, {
          caption,
          parse_mode: 'Markdown'
        })

        if (video?.url) {
          await ctx.telegram.sendVideo(userId, { url: video.url }, {
            caption: `🎞️ *Video MP4:*\n📌 ${title}`,
            parse_mode: 'Markdown'
          })
        }

        if (audio?.url) {
          await ctx.telegram.sendAudio(userId, { url: audio.url }, {
            caption: `🎵 *Audio MP3:*\n📌 ${title}`,
            parse_mode: 'Markdown'
          })
        }

        if (ctx.chat.type !== 'private') {
          await ctx.reply('📬 *Hasil sudah dikirim ke DM kamu!*\nSilakan cek *Private Chat!* ✉️', { parse_mode: 'Markdown' })
        }
      }

      try {
        await sendToPrivate()
      } catch (err) {
        await ctx.reply(`
╭───〔 *🚫 GAGAL MENGIRIM DM* 〕───⬣
│ Bot tidak bisa mengirim pesan ke kamu.
│
│ 💡 Solusi:
│ Kirim *pesan apa saja* ke bot ini dulu.
╰────────────⬣
`, {
          parse_mode: 'Markdown',
          reply_markup: Markup.inlineKeyboard([
            [Markup.button.url('💬 Chat Bot', `https://t.me/${ctx.me}`)]
          ])
        })
      }

    } catch (e) {
      console.error(e)
      return ctx.reply(`
╭───〔 *❌ ERROR SERVER* 〕───⬣
│ Gagal memproses link.
│ Coba beberapa saat lagi.
╰────────────⬣
`, { parse_mode: 'Markdown' })
    }
  }
}