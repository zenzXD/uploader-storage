// plugins/downloader/tiktok.js
import fetch from "node-fetch";

export default {
    command: ["tiktok", "tt", "tiktokdl"],
    tags: ["downloader"],
    desc: "🎥 Downloader video TikTok tanpa watermark",
    limit: true,

    async handler(ctx) {
        const args = ctx.message.text.split(" ").slice(1);
        const link = args[0];

        if (!link) {
            return ctx.reply(
                `🚫 *Format salah!*\n\n` +
                `📌 *Contoh penggunaan:*\n` +
                `/${this.command[0]} https://vt.tiktok.com/ZSkpqLD9U/`
            );
        }

        try {
            const api = `https://zenzxz.dpdns.org/downloader/tiktok?url=${encodeURIComponent(link)}`;
            const res = await fetch(api);
            const json = await res.json();

            if (!json.status || !json.result?.data) {
                return ctx.reply("❌ Gagal mengambil data dari TikTok. Mungkin URL-nya salah atau video telah dihapus.");
            }

            const result = json.result.data;
            const caption = `
╭━━━[ *🎬 TikTok Downloader* ]━━━⬣
┃
┃ 📛 *Judul:* ${result.title}
┃ 👤 *Author:* ${result.author.nickname} (@${result.author.unique_id})
┃ 🎵 *Lagu:* ${result.music_info.title} - ${result.music_info.author}
┃ ⏳ *Durasi:* ${result.duration} detik
┃ 👍 *Suka:* ${result.digg_count.toLocaleString()}
┃ 💬 *Komentar:* ${result.comment_count.toLocaleString()}
┃ 🔁 *Dibagikan:* ${result.share_count.toLocaleString()}
┃
╰🔗 *Link:* ${link}
`;

            if (ctx.chat.type.endsWith("group")) {
                await ctx.reply(
                    "📬 Video sedang dikirim ke *DM kamu*.\nPastikan kamu sudah *start bot* ini di chat pribadi."
                );
                await ctx.telegram.sendVideo(
                    ctx.from.id,
                    { url: result.play },
                    { caption, parse_mode: "Markdown" }
                );
            } else {
                await ctx.replyWithVideo(
                    { url: result.play },
                    { caption, parse_mode: "Markdown" }
                );
            }
        } catch (e) {
            console.error(e);
            ctx.reply("⚠️ Terjadi kesalahan saat memproses permintaan.\nSilakan coba lagi nanti atau kirim link lain.");
        }
    }
};