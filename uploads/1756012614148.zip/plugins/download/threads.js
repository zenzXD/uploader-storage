import axios from 'axios'

export default {

  command: ['threads', 'tredl'],

  tags: ['downloader'],

  desc: '📥 Unduh post Threads dari URL',

  async handler(ctx) {

    const input = ctx.text?.split(' ')[1]

    const reply = (msg, opt) => ctx.reply(msg, opt)

    let url = input || ctx?.message?.reply_to_message?.text

    if (!url || !url.includes('/post/')) {

      return reply(`❗️ *Masukkan URL Threads yang valid!*

📌 Contoh:

\`\`\`

/threads https://www.threads.net/@infopop.id/post/DMk2wrVzIoP

\`\`\``, { parse_mode: 'Markdown' })

    }

    const threadId = url.match(/\/post\/([a-zA-Z0-9]+)/)?.[1]

    if (!threadId) return reply('⚠️ Gagal mengambil ID post.')

    try {

      await reply('⏳ *Mengambil data dari Threads...*', { parse_mode: 'Markdown' })

      const res = await axios.get(`https://www.dolphinradar.com/api/threads/post_detail/${threadId}`, {

        headers: {

          'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',

          'Accept': 'application/json'

        }

      })

      const data = res.data?.data

      if (!data || !data.post_detail || !data.user) {

        return reply('❌ Data tidak ditemukan atau post sudah dihapus.')

      }

      const { post_detail: post, user } = data

      const media = post.media_list || []

      const mediaUrls = media.map(m => m.url)

      let caption = `╭━━━〔 *📌 THREADS POST* 〕━━━╮\n`

      caption += `┃ 👤 *${user.full_name}* \`(@${user.username})\`\n`

      caption += `┃ ☑️ *Verified:* ${user.verified ? 'Ya' : 'Tidak'}\n`

      caption += `┃ 👥 *Followers:* ${user.follower_count.toLocaleString()}\n`

      caption += `╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n`

      caption += `📝 *Caption:*\n${post.caption_text || '_Tidak ada caption_'}\n\n`

      caption += `❤️ *Likes:* ${post.like_count.toLocaleString()}\n`

      caption += `🔗 [Buka di Threads](${url})`

      if (mediaUrls.length) {

        // Kirim sebagai grup media (photo/video)

        const mediaGroup = mediaUrls.map((mediaUrl, i) => {

          const isVideo = /\.(mp4|webm|mov)$/i.test(mediaUrl)

          return {

            type: isVideo ? 'video' : 'photo',

            media: { url: mediaUrl },

            ...(i === 0 && { caption, parse_mode: 'Markdown' })

          }

        })

        await ctx.replyWithMediaGroup(mediaGroup)

      } else {

        // Jika tidak ada media, kirim teks saja

        await reply(caption, {

          parse_mode: 'Markdown',

          disable_web_page_preview: false

        })

      }

    } catch (err) {

      console.error('THREADS Error:', err)

      reply(`🚫 *Terjadi kesalahan saat mengambil data:*\n\`${err.message}\``, {

        parse_mode: 'Markdown'

      })

    }

  }

}