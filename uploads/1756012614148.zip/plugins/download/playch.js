import search from "yt-search";
import fetch from "node-fetch";
import { config } from "../../config.js";

export default {
  command: ["playch"],
  tags: ["downloader"],
  desc: "🎶 Cari lagu YouTube dan kirim ke channel",
  owner: true,
  channel: true,

  async handler(ctx) {
    // Cek ID Owner
    if (ctx.from.id.toString() !== config.OWNER_ID.toString()) {
      return ctx.reply("🚫 *Khusus Owner!*", { parse_mode: "Markdown" });
    }

    const text = ctx.message.text?.split(" ").slice(1).join(" ");
    if (!text) {
      return ctx.reply(
        "❌ *Masukkan judul atau link YouTube!*\n\n" +
        "📌 Contoh:\n`/playch Alan Walker`",
        { parse_mode: "Markdown" }
      );
    }

    try {
      await ctx.reply("🔍 *Sedang mencari lagu terbaik di YouTube...*", {
        parse_mode: "Markdown"
      });

      const res = await search(text);
      const video = res.videos[0];
      if (!video) return await ctx.reply("🚫 *Video tidak ditemukan!*", { parse_mode: "Markdown" });

      if (video.seconds >= 3600) {
        return await ctx.reply("⚠️ *Video berdurasi lebih dari 1 jam tidak diperbolehkan.*", {
          parse_mode: "Markdown"
        });
      }

      const api = `https://api.botcahx.eu.org/api/dowloader/yt?url=${video.url}&apikey=${config.BOTCAHX_API_KEY}`;
      const json = await fetch(api).then(res => res.json());

      if (!json.status || !json.result || !json.result.mp3) {
        return await ctx.reply("⚠️ *Gagal mengambil audio dari video!*", {
          parse_mode: "Markdown"
        });
      }

      const caption =
        `🎧 *YouTube Music Search*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🎵 *Judul:* ${video.title}\n` +
        `🆔 *ID:* \`${video.videoId}\`\n` +
        `⏱️ *Durasi:* ${video.timestamp}\n` +
        `👁️ *Penonton:* ${video.views.toLocaleString()}x\n` +
        `🗓️ *Upload:* ${video.ago}\n` +
        `📺 *Channel:* [${video.author.name}](${video.author.url})\n` +
        `🔗 *Link:* [Tonton di YouTube](${video.url})\n` +
        `━━━━━━━━━━━━━━━━━━━━━━`;

      await ctx.telegram.sendMessage(config.NOTIF_CHANNEL, caption, {
        parse_mode: "Markdown",
        disable_web_page_preview: false
      });

      await ctx.telegram.sendAudio(
        config.NOTIF_CHANNEL,
        { url: json.result.mp3 },
        {
          title: video.title,
          performer: video.author.name,
          thumbnail: { url: video.image },
          caption: `🎶 *${video.title}*\n📺 ${video.author.name}`,
          parse_mode: "Markdown"
        }
      );

      await ctx.reply("✅ *Lagu berhasil dikirim ke channel!*", {
        parse_mode: "Markdown"
      });
    } catch (e) {
      console.error(e);
      await ctx.reply("❌ *Terjadi kesalahan saat memproses.*", {
        parse_mode: "Markdown"
      });
    }
  }
};