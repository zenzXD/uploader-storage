import axios from 'axios'
import FormData from 'form-data'
import * as cheerio from 'cheerio'

async function spotifyDownload(url) {
  const form = new FormData()
  form.append('url', url)

  const headers = {
    ...form.getHeaders(),
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://spotifydown.org/',
    'Cookie': 'codehap_domain=spotifydown.org'
  }

  const { data } = await axios.post('https://spotifydown.org/result.php', form, {
    headers,
    timeout: 30000
  })

  const $ = cheerio.load(data)
  const downloadLink = $('a.dlbtnhigh').attr('href')

  if (!downloadLink) {
    const errorMsg = $('.error').text() || '❌ Link download tidak ditemukan.'
    throw new Error(errorMsg)
  }

  return downloadLink
}

export default {
  command: ['spotifydl2', 'spdl2'],
  tags: ['downloader'],
  help: ['spotifydl2 <url>'],
  desc: '🎶 Download lagu dari Spotify (max 5 jam)',
  limit: 2,
  premium: false,

  async handler(ctx) {
    const text = ctx.message?.text?.split(' ').slice(1).join(' ')
    const spotifyRegex = /https?:\/\/open\.spotify\.com\/track\/[a-zA-Z0-9]+/

    if (!text) {
      return ctx.reply(`🎧 *SPOTIFY TRACK DOWNLOADER*\n\n` +
        `📥 Untuk mengunduh lagu, kirimkan link track Spotify!\n\n` +
        `🔗 *Contoh:*\n/spotifydl2 https://open.spotify.com/track/...\n\n` +
        `📌 *COMING SOON:*\n- 🎵 Dukungan Spotify *Playlist*\n- 🧾 Sistem *Antrian Unduhan* (Queue)\n\n` +
        `⚠️ Hanya mendukung link dari *track*, bukan album atau playlist.`)
    }

    if (!spotifyRegex.test(text)) {
      return ctx.reply('⚠️ *Link tidak valid!*\nGunakan link dari Spotify track seperti:\nhttps://open.spotify.com/track/...')
    }

    await ctx.reply('⏳ *Sedang memproses lagu...*')

    try {
      const audioUrl = await spotifyDownload(text)

      await ctx.replyWithAudio({ url: audioUrl }, {
        caption: `✅ *Lagu berhasil diunduh!*\nKlik untuk memutar atau simpan 🎧`,
        parse_mode: 'Markdown',
        title: 'Spotify Track',
        performer: 'Unknown',
        duration: 60 * 60 * 5, // max 5 jam
        thumbnail: { url: 'https://i.scdn.co/image/ab6775700000ee8510b5d5d5a9c03c36e1c9c6b5' }
      })

    } catch (e) {
      console.error(e)
      return ctx.reply(`❌ *Gagal mengunduh lagu!*\n${e.message || 'Silakan coba lagi nanti.'}`)
    }
  }
}