import fetch from 'node-fetch'

const sc = {

  _tools: {

    async hit(hitDescription, url, options, returnType = "text") {

      try {

        const response = await fetch(url, options)

        if (!response.ok)

          throw Error(`${response.status} ${response.statusText} ${(await response.text() || `(respond body kosong)`).substring(0, 100)}...`)

        try {

          if (returnType === "text") return { data: await response.text(), response }

          if (returnType === "json") return { data: await response.json(), response }

          if (returnType === "buffer") return { data: Buffer.from(await response.arrayBuffer()), response }

          throw Error(`invalid param returnType. pilih text/json`)

        } catch (e) {

          throw Error(`Gagal parsing ke ${returnType}\n${e.message}`)

        }

      } catch (e) {

        throw Error(`Gagal request: ${hitDescription}.\n${e.message}`)

      }

    },

    validateString: (desc, val) => {

      if (typeof val !== "string" || val?.trim()?.length === 0)

        throw Error(`${desc} harus berupa string dan tidak boleh kosong!`)

    }

  },

  get baseHeaders() {

    return {

      'accept-encoding': 'gzip, deflate, br, zstd',

      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'

    }

  },

  async getTrackAuthAndStreamUrlAndKey(url) {

    const headers = this.baseHeaders

    const { data: html } = await this._tools.hit('Load homepage', url, { headers })

    const m_json = html?.match(/<script>window.__sc_hydration = (.+?);<\/script>/)?.[1]

    if (!m_json) throw Error(`Gagal parsing JSON`)

    const json = JSON.parse(m_json)

    const ddjsKey = html.match(/window\.ddjskey = '(.+?)';/)?.[1]

    const track_authorization = json?.[7]?.data?.track_authorization

    const stream_url = json?.[7]?.data?.media?.transcodings?.[3]?.url

    const title = json?.[7]?.data?.title || `no title`

    const image = html.match(/og:image" content="(.+?)">/)?.[1]

    const username = json?.[7]?.data?.user?.username

    const playbackCount = json?.[7]?.data?.playback_count || 0

    const likesCount = json?.[7]?.data?.likes_count || 0

    const commentsCount = json?.[7]?.data?.comment_count || 0

    const displayDate = json?.[7]?.data?.display_date

    if (!ddjsKey || !track_authorization || !stream_url) throw Error('Data tidak lengkap')

    return {

      ddjsKey, track_authorization, stream_url,

      soundMetadata: { title, image, username, playbackCount, likesCount, commentsCount, displayDate }

    }

  },

  async getDatadome({ ddjsKey }) {

    const headers = { Referer: "https://soundcloud.com/", ...this.baseHeaders }

    const body = new URLSearchParams({ ddk: ddjsKey })

    const { data: json } = await this._tools.hit('Get datadome', 'https://dwt.soundcloud.com/js/', { headers, body, method: "post" }, 'json')

    const value = json?.cookie?.split("; ")?.[0]?.split('=')?.[1]

    if (!value) throw Error(`Datadome kosong`)

    return { datadome: value }

  },

  async getClientId() {

    const { data: js } = await this._tools.hit('Client ID', 'https://a-v2.sndcdn.com/assets/0-b9979956.js', { headers: this.baseHeaders })

    const client_id = js.match(/"client_id=(.+?)"\)/)?.[1]

    if (!client_id) throw Error('Client ID kosong')

    return { client_id }

  },

  async getHls(obj1, obj2, obj3) {

    const { datadome, stream_url, client_id, track_authorization } = { ...obj1, ...obj2, ...obj3 }

    const headers = { "x-datadome-clientid": datadome, ...this.baseHeaders }

    const url = new URL(stream_url)

    url.search = new URLSearchParams({ client_id, track_authorization })

    const { data: json } = await this._tools.hit('Get HLS URL', url, { headers }, 'json')

    return json

  },

  async download(trackUrl) {

    this._tools.validateString('Track URL', trackUrl)

    const obj1 = await this.getTrackAuthAndStreamUrlAndKey(trackUrl)

    const obj2 = await this.getClientId()

    const obj3 = await this.getDatadome(obj1)

    const hls = await this.getHls(obj1, obj2, obj3)

    const { soundMetadata } = obj1

    const { url } = hls

    return { ...soundMetadata, url }

  }

}

export default {

  command: ['soundcloud'],

  tags: ['downloader'],

  desc: '🎶 Download audio dari SoundCloud',

  async handler(ctx) {

    const input = ctx.text?.split(' ')[1]

    const reply = (msg, opt) => ctx.reply(msg, opt)

    if (!input || !input.includes('soundcloud.com')) {

      return reply(`❗️ *Masukkan URL SoundCloud yang valid!*

📌 *Contoh:*

\`\`\`

/soundcloud https://soundcloud.com/nocopyrightsounds/stars-ncs-release

\`\`\``, { parse_mode: 'Markdown' })

    }

    await reply('🎧 *Mengambil lagu dari SoundCloud...*\n⏳ Mohon tunggu sebentar...', { parse_mode: 'Markdown' })

    try {

      const result = await sc.download(input)

      const audioRes = await fetch(result.url)

      const audioBuffer = await audioRes.buffer()

      await ctx.replyWithAudio({ source: audioBuffer }, {

        filename: `${result.title}.mp3`,

        title: result.title,

        performer: result.username,

        caption: `🎶 *Berhasil didownload!*

🎧 *Judul:* ${result.title}

👤 *User:* ${result.username}

▶️ *Play Count:* ${result.playbackCount?.toLocaleString('id-ID') || '-'}

🗓️ *Tanggal:* ${result.displayDate || '-'}

🔗 [Link Asli](${input})`,

        parse_mode: 'Markdown',

        thumb: { url: result.image }

      })

    } catch (e) {

      console.error('SoundCloud Error:', e)

      reply(`❌ *Terjadi kesalahan saat mendownload:*\n\`${e.message}\``, { parse_mode: 'Markdown' })

    }

  }

}