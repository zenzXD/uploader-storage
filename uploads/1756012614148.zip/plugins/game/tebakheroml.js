import fetch from 'node-fetch'

export default {
  command: ['tebakheroml'],
  tags: ['game'],
  desc: '🎮 Tebak Hero Mobile Legends!',

  async handler(ctx) {
    const res = await fetch(`https://api.betabotz.eu.org/api/game/tebakheroml?apikey=Btz-JeYoW`)
    const data = await res.json()

    if (!data?.status || !data?.result?.gambar) {
      return ctx.reply('❌ *Gagal mengambil soal dari server!*\nSilakan coba lagi nanti.', { parse_mode: 'Markdown' })
    }

    const { gambar, petunjuk, jawaban } = data.result
    const hint = petunjuk || 'Tidak tersedia'
    const answer = jawaban.toLowerCase()
    const userId = ctx.from.id

    await ctx.replyWithPhoto({ url: gambar }, {
      caption: `
🎮 *TEBAK HERO MLBB* 🎮

🧩 Petunjuk: _${hint}_
⏱️ Waktu: 60 detik
💬 Jawab langsung di bawah!

_Tebak siapa nama hero ini!_
`.trim(),
      parse_mode: 'Markdown'
    })

    const onText = async (msg) => {
      if (!msg?.text || msg.chat.id !== ctx.chat.id || msg.from.id !== userId) return

      const userAnswer = msg.text.toLowerCase().trim()
      if (userAnswer === answer) {
        await ctx.reply(`
🎉 *Benar!* 🎉
✅ Jawaban: *${jawaban}*
🧠 Kamu hebat!
`, { parse_mode: 'Markdown' })
      } else {
        await ctx.reply(`
❌ *Salah!*
💬 Jawabanmu: *${msg.text}*
Coba lagi di kesempatan berikutnya!
`, { parse_mode: 'Markdown' })
      }

      ctx.bot.telegram.off('text', onText)
    }

    ctx.bot.telegram.on('text', onText)

    setTimeout(() => {
      ctx.bot.telegram.off('text', onText)
      ctx.reply(`
⌛ *Waktu Habis!*
🕹️ Jawaban yang benar adalah: *${jawaban}*
Coba lagi dengan perintah /tebakheroml
`, { parse_mode: 'Markdown' })
    }, 60000)
  }
}