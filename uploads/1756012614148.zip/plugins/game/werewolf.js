import fs from 'fs'
import path from 'path'

const games = {}
const rolesList = [
  'Werewolf', 'Villager', 'Seer', 'Doctor', 'Hunter'
]

function getRandomRoles(players) {
  const count = players.length
  const roles = []
  if (count < 5) return []
  roles.push('Werewolf')
  roles.push('Seer')
  roles.push('Doctor')
  roles.push('Hunter')
  while (roles.length < count) roles.push('Villager')
  return roles.sort(() => Math.random() - 0.5)
}

function mention(id) {
  return `[${id}](tg://user?id=${id})`
}

function sendDM(bot, userId, text) {
  return bot.telegram.sendMessage(userId, text, { parse_mode: 'Markdown' }).catch(() => null)
}

function startGame(bot, chatId) {
  const game = games[chatId]
  if (!game || game.players.length < 5) return

  game.state = 'night'
  const roles = getRandomRoles(game.players)
  game.players.forEach((userId, i) => {
    const role = roles[i]
    game.roles[userId] = role
    sendDM(bot, userId, `🎭 Kamu adalah *${role}* dalam permainan Werewolf.`)
  })

  bot.telegram.sendMessage(chatId, `🌙 *Malam dimulai!*
Semua pemain tutup mata. Werewolf pilih korbannya...`, { parse_mode: 'Markdown' })
  game.phaseTimeout = setTimeout(() => startDay(bot, chatId), 30000)
}

function startDay(bot, chatId) {
  const game = games[chatId]
  game.state = 'day'
  bot.telegram.sendMessage(chatId, `☀️ *Pagi tiba!*
Diskusikan dan vote siapa yang akan digantung hari ini. Gunakan /vote @user`, { parse_mode: 'Markdown' })
  game.votes = {}
  game.phaseTimeout = setTimeout(() => tallyVotes(bot, chatId), 30000)
}

function tallyVotes(bot, chatId) {
  const game = games[chatId]
  const tally = {}
  Object.values(game.votes).forEach(v => tally[v] = (tally[v] || 0) + 1)
  const sorted = Object.entries(tally).sort((a, b) => b[1] - a[1])
  if (!sorted.length) return bot.telegram.sendMessage(chatId, '⚖️ Tidak ada yang digantung hari ini.')

  const [topUserId, count] = sorted[0]
  game.alive = game.alive.filter(uid => uid !== parseInt(topUserId))
  bot.telegram.sendMessage(chatId, `💀 *${mention(topUserId)}* telah digantung!`, { parse_mode: 'Markdown' })

  checkGameOver(bot, chatId)
  if (game.alive.length >= 3) setTimeout(() => startGame(bot, chatId), 10000)
}

function checkGameOver(bot, chatId) {
  const game = games[chatId]
  const werewolves = game.alive.filter(uid => game.roles[uid] === 'Werewolf')
  const others = game.alive.length - werewolves.length

  if (werewolves.length === 0) {
    bot.telegram.sendMessage(chatId, '🎉 *Villager menang!*', { parse_mode: 'Markdown' })
    delete games[chatId]
  } else if (werewolves.length >= others) {
    bot.telegram.sendMessage(chatId, '🐺 *Werewolf menang!*', { parse_mode: 'Markdown' })
    delete games[chatId]
  }
}

export default {
  command: ['werewolf','ww'],
  tags: ['game'],
  desc: '🐺 Main game werewolf di grup',
  async handler(ctx) {
    const chatId = ctx.chat.id
    const userId = ctx.from.id
    const args = ctx.args
    const isAdmin = ctx.chat.type === 'private' || (await ctx.getChatMember(userId)).status.includes('admin')

    games[chatId] ||= {
      players: [],
      alive: [],
      state: 'waiting',
      roles: {},
      votes: {},
      phaseTimeout: null,
    }

    const game = games[chatId]

    const sub = args[0]
    if (sub === 'join') {
      if (game.players.includes(userId)) return ctx.reply('📌 Kamu sudah ikut.')
      game.players.push(userId)
      game.alive.push(userId)
      ctx.reply(`✅ ${mention(userId)} bergabung! (${game.players.length} pemain)`, { parse_mode: 'Markdown' })
    } else if (sub === 'leave') {
      game.players = game.players.filter(uid => uid !== userId)
      game.alive = game.alive.filter(uid => uid !== userId)
      ctx.reply(`❌ ${mention(userId)} keluar dari permainan.`, { parse_mode: 'Markdown' })
    } else if (sub === 'start') {
      if (!isAdmin) return ctx.reply('⚠️ Hanya admin yang bisa memulai game.')
      if (game.players.length < 5) return ctx.reply('⚠️ Minimal 5 pemain untuk mulai.')
      if (game.state !== 'waiting') return ctx.reply('⚠️ Game sudah berjalan.')
      startGame(ctx.bot, chatId)
    } else if (sub === 'vote') {
      const mentionArg = args[1]
      if (!mentionArg) return ctx.reply('📥 Tag user yang ingin kamu vote.')
      const mentionId = mentionArg.replace(/[^0-9]/g, '')
      if (!game.alive.includes(parseInt(mentionId))) return ctx.reply('⚠️ Pemain tidak valid.')
      game.votes[userId] = parseInt(mentionId)
      ctx.reply(`🗳️ ${mention(userId)} vote ke ${mention(mentionId)}`, { parse_mode: 'Markdown' })
    } else if (sub === 'status') {
      const status = game.players.map(uid => `• ${mention(uid)} [${game.roles[uid] || '?'}]`).join('\n')
      ctx.reply(`📊 *Status Game*
${status}`, { parse_mode: 'Markdown' })
    } else if (sub === 'reset') {
      if (!isAdmin) return ctx.reply('⚠️ Hanya admin yang bisa reset game.')
      clearTimeout(game.phaseTimeout)
      delete games[chatId]
      ctx.reply('🔄 Game direset.')
    } else {
      ctx.reply(`🐺 *Werewolf Game Command*

/join - Gabung
/leave - Keluar
/start - Mulai game
/vote @user - Vote pemain
/status - Lihat status
/reset - Reset game`, { parse_mode: 'Markdown' })
    }
  }
}
