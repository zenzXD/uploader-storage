import fs from 'fs'

const negaraData = [
  { emoji: '🇮🇩', nama: 'indonesia' },
  { emoji: '🇺🇸', nama: 'amerika serikat' },
  { emoji: '🇯🇵', nama: 'jepang' },
  { emoji: '🇧🇷', nama: 'brasil' },
  { emoji: '🇬🇧', nama: 'inggris' },
  { emoji: '🇨🇳', nama: 'tiongkok' },
  { emoji: '🇫🇷', nama: 'prancis' },
  { emoji: '🇩🇪', nama: 'jerman' },
  { emoji: '🇷🇺', nama: 'rusia' },
  { emoji: '🇰🇷', nama: 'korea selatan' },
  { emoji: '🇸🇬', nama: 'singapura' },
  { emoji: '🇲🇾', nama: 'malaysia' },
  { emoji: '🇹🇭', nama: 'thailand' },
  { emoji: '🇵🇭', nama: 'filipina' },
  { emoji: '🇮🇳', nama: 'india' },
  { emoji: '🇦🇺', nama: 'australia' },
  { emoji: '🇪🇸', nama: 'spanyol' },
  { emoji: '🇮🇹', nama: 'italia' },
  { emoji: '🇸🇦', nama: 'arab saudi' },
  { emoji: '🇹🇷', nama: 'turki' },
  { emoji: '🇵🇰', nama: 'pakistan' },
  { emoji: '🇲🇽', nama: 'meksiko' },
  { emoji: '🇨🇦', nama: 'kanada' },
  { emoji: '🇦🇷', nama: 'argentina' },
  { emoji: '🇳🇬', nama: 'nigeria' },
  { emoji: '🇿🇦', nama: 'afrika selatan' },
  { emoji: '🇮🇷', nama: 'iran' },
  { emoji: '🇵🇱', nama: 'polandia' },
  { emoji: '🇳🇱', nama: 'belanda' },
  { emoji: '🇧🇪', nama: 'belgia' },
  { emoji: '🇸🇪', nama: 'swedia' },
  { emoji: '🇳🇴', nama: 'norwegia' },
  { emoji: '🇫🇮', nama: 'finlandia' },
  { emoji: '🇩🇰', nama: 'denmark' },
  { emoji: '🇺🇦', nama: 'ukraina' },
  { emoji: '🇨🇭', nama: 'swiss' },
  { emoji: '🇬🇷', nama: 'yunani' },
  { emoji: '🇵🇹', nama: 'portugal' },
  { emoji: '🇨🇴', nama: 'kolombia' },
  { emoji: '🇨🇱', nama: 'chile' },
  { emoji: '🇵🇪', nama: 'peru' },
  { emoji: '🇻🇳', nama: 'vietnam' },
  { emoji: '🇲🇲', nama: 'myanmar' },
  { emoji: '🇰🇭', nama: 'kamboja' },
  { emoji: '🇱🇦', nama: 'laos' },
  { emoji: '🇧🇩', nama: 'bangladesh' },
  { emoji: '🇳🇿', nama: 'selandia baru' },
  { emoji: '🇮🇶', nama: 'irak' },
  { emoji: '🇦🇪', nama: 'uni emirat arab' }
]

let sesiTebak = {}

export default {
  command: ['tebaknegara'],
  tags: ['game'],
  desc: '🗺️ Tebak nama negara dari emoji bendera',

  async handler(ctx) {
    const id = ctx.chat.id
    if (sesiTebak[id]) {
      return ctx.reply('❗ Kamu masih punya soal yang belum dijawab.\nKetik jawabannya atau ketik *menyerah*.', { parse_mode: 'Markdown' })
    }

    const negara = negaraData[Math.floor(Math.random() * negaraData.length)]
    sesiTebak[id] = negara

    await ctx.reply(`🧠 Tebak negara dari bendera ini:\n${negara.emoji}\n\nBalas dengan nama negaranya (dalam bahasa Indonesia).`)
  },

  on: {
    text: async (ctx) => {
      const id = ctx.chat.id
      if (!sesiTebak[id]) return

      const jawaban = ctx.message.text.trim().toLowerCase()
      if (jawaban === 'menyerah') {
        const jawabBenar = sesiTebak[id].nama
        delete sesiTebak[id]
        return ctx.reply(`🙃 Jawabannya adalah *${jawabBenar}*`, { parse_mode: 'Markdown' })
      }

      if (jawaban === sesiTebak[id].nama.toLowerCase()) {
        delete sesiTebak[id]
        return ctx.reply('🎉 Benar! Kamu hebat!')
      } else {
        return ctx.reply('❌ Salah. Coba lagi atau ketik *menyerah*.', { parse_mode: 'Markdown' })
      }
    }
  }
}