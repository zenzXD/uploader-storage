const tebakan = global.tebakan || new Map()
global.tebakan = tebakan

export default {
  command: ['jawab'],
  tags: ['game'],
  desc: '✅ Menjawab tebak gambar',

  async handler(ctx) {
    const userId = ctx.from.id
    const soal = tebakan.get(userId)

    if (!soal) return ctx.reply('❗ Kamu belum memulai game!\nGunakan perintah /tebakgambar dulu.')

    const userJawab = ctx.args.join(' ').toLowerCase()
    if (!userJawab) return ctx.reply('📝 Ketik jawabanmu!\nContoh: /jawab kucing lucu')

    if (userJawab === soal.jawaban) {
      tebakan.delete(userId)
      return ctx.reply('🎉 *Benar!* Kamu berhasil menjawab!\n\nIngin main lagi? ketik /tebakgambar', { parse_mode: 'Markdown' })
    } else {
      return ctx.reply('❌ Salah! Coba lagi!')
    }
  }
}