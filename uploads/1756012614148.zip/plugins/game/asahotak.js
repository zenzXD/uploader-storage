import axios from 'axios'

export default {

  command: ['asahotak'],

  tags: ['game'],

  desc: 'Game asah otak realtime',

  async handler(ctx) {

    const apikey = 'planaai'

    const userId = ctx.from.id

    const url = `https://www.sankavollerei.com/game/asahotak?apikey=${apikey}&user=${userId}`

    try {

      const res = await axios.get(url)

      const question = res.data.question ?? res.data // sesuaikan struktur JSON API

      await ctx.reply(`🎮 *Pertanyaan untuk semua pemain:*\n${question}`, { parse_mode: 'Markdown' })

      // Simpan state pertanyaan di memory/db biar semua user bisa jawab

      ctx.botState = ctx.botState || {}

      ctx.botState.currentQuestion = question

      // Listener jawaban semua user

      ctx.bot.on('text', async (answerCtx) => {

        if (!ctx.botState?.currentQuestion) return

        const answer = answerCtx.message.text

        const urlAnswer = `https://www.sankavollerei.com/game/asahotak/answer?apikey=${apikey}`

        try {

          const resAns = await axios.post(urlAnswer, { answer })

          const reply = resAns.data.reply ?? resAns.data

          await answerCtx.reply(`📝 ${reply}`)

        } catch (err) {

          console.error(err)

          await answerCtx.reply('⚠️ Ada masalah saat memproses jawaban.')

        }

      })

    } catch (err) {

      console.error(err)

      await ctx.reply('❌ Gagal memulai game, coba lagi nanti.')

    }

  }

}