import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const kataList = [
  { kata: 'komputer', clue: 'Perangkat elektronik pemroses data' },
  { kata: 'pisang', clue: 'Buah berwarna kuning' },
  { kata: 'sungai', clue: 'Aliran air alami' },
  { kata: 'harimau', clue: 'Hewan buas belang' },
  { kata: 'kamera', clue: 'Alat untuk mengambil gambar' },
  { kata: 'buku', clue: 'Tempat membaca ilmu' },
  { kata: 'mobil', clue: 'Kendaraan roda empat' },
  { kata: 'pulpen', clue: 'Alat untuk menulis' },
  { kata: 'teknologi', clue: 'Inovasi modern' },
  { kata: 'radio', clue: 'Media suara zaman dulu' },
  { kata: 'internet', clue: 'Jaringan global' },
  { kata: 'jakarta', clue: 'Ibukota Indonesia' },
  { kata: 'pantai', clue: 'Tempat wisata berpasir' },
  { kata: 'gunung', clue: 'Tinggi menjulang' },
  { kata: 'pesawat', clue: 'Transportasi udara' },
  { kata: 'roti', clue: 'Sarapan orang Barat' },
  { kata: 'api', clue: 'Panas dan membakar' },
  { kata: 'air', clue: 'Tak berwarna dan menyegarkan' },
  { kata: 'matahari', clue: 'Pusat tata surya' },
  { kata: 'bintang', clue: 'Bersinar di malam hari' },
  { kata: 'bulan', clue: 'Satelit alami Bumi' },
  { kata: 'hujan', clue: 'Air jatuh dari langit' },
  { kata: 'pelangi', clue: 'Warna-warni setelah hujan' },
  { kata: 'kapal', clue: 'Berlayar di laut' },
  { kata: 'sepeda', clue: 'Roda dua tanpa mesin' },
  { kata: 'televisi', clue: 'Alat menonton acara' },
  { kata: 'meja', clue: 'Tempat menaruh barang' },
  { kata: 'kursi', clue: 'Tempat duduk' },
  { kata: 'pohon', clue: 'Tumbuh tinggi dan hijau' },
  { kata: 'sapu', clue: 'Untuk membersihkan lantai' },
  { kata: 'kucing', clue: 'Hewan peliharaan lucu' },
  { kata: 'anjing', clue: 'Sahabat manusia yang setia' },
  { kata: 'rumah', clue: 'Tempat tinggal' },
  { kata: 'jalan', clue: 'Tempat kendaraan lewat' },
  { kata: 'jendela', clue: 'Lubang di dinding rumah' },
  { kata: 'pintu', clue: 'Tempat masuk ruangan' },
  { kata: 'jam', clue: 'Penunjuk waktu' },
  { kata: 'kaca', clue: 'Benda bening bisa memantul' },
  { kata: 'uang', clue: 'Alat tukar ekonomi' },
  { kata: 'pasar', clue: 'Tempat jual beli' },
  { kata: 'sekolah', clue: 'Tempat belajar siswa' },
  { kata: 'guru', clue: 'Orang yang mengajar' },
  { kata: 'murid', clue: 'Orang yang belajar' },
  { kata: 'tas', clue: 'Tempat menyimpan barang' },
  { kata: 'sepatu', clue: 'Pelindung kaki' },
  { kata: 'kaos', clue: 'Pakaian atasan kasual' },
  { kata: 'jaket', clue: 'Pakaian luar saat dingin' },
  { kata: 'topi', clue: 'Penutup kepala' },
  { kata: 'ikan', clue: 'Hidup di air' },
  { kata: 'burung', clue: 'Bisa terbang dan berkicau' },
  { kata: 'ular', clue: 'Hewan melata berbisa' },
  { kata: 'kodok', clue: 'Hidup di air dan darat' },
  { kata: 'ayam', clue: 'Berkokok pagi hari' },
  { kata: 'nasi', clue: 'Makanan pokok Indonesia' },
  { kata: 'mie', clue: 'Makanan dari tepung berbentuk panjang' },
  { kata: 'sayur', clue: 'Makanan sehat dari tumbuhan' },
  { kata: 'buah', clue: 'Manis dan segar, dari pohon' },
  { kata: 'eskrim', clue: 'Makanan dingin manis' },
  { kata: 'kopi', clue: 'Minuman pahit pengusir kantuk' },
  { kata: 'teh', clue: 'Minuman dari daun' },
  { kata: 'susu', clue: 'Minuman dari sapi' },
  { kata: 'jeruk', clue: 'Buah kaya vitamin C' },
  { kata: 'apel', clue: 'Buah merah dari barat' },
  { kata: 'semangka', clue: 'Buah besar dan berair' },
  { kata: 'melon', clue: 'Buah bulat berwarna hijau' },
  { kata: 'komik', clue: 'Buku bergambar cerita' },
  { kata: 'film', clue: 'Tontonan di bioskop' },
  { kata: 'musik', clue: 'Suara dengan irama' },
  { kata: 'lagu', clue: 'Lirik dan musik' },
  { kata: 'gitar', clue: 'Alat musik berdawai' },
  { kata: 'piano', clue: 'Alat musik dengan tuts' },
  { kata: 'drum', clue: 'Alat musik dipukul' },
  { kata: 'lukisan', clue: 'Gambar karya seni' },
  { kata: 'patung', clue: 'Karya seni tiga dimensi' },
  { kata: 'teater', clue: 'Pertunjukan seni peran' },
  { kata: 'taman', clue: 'Tempat rekreasi dengan tanaman' },
  { kata: 'perpustakaan', clue: 'Tempat pinjam buku' },
  { kata: 'museum', clue: 'Tempat benda bersejarah' },
  { kata: 'bioskop', clue: 'Tempat menonton film' },
  { kata: 'kantor', clue: 'Tempat kerja' },
  { kata: 'kamar', clue: 'Tempat tidur' },
  { kata: 'dapur', clue: 'Tempat memasak' },
  { kata: 'toilet', clue: 'Tempat buang air' },
  { kata: 'tangga', clue: 'Alat naik turun lantai' },
  { kata: 'lift', clue: 'Naik turun otomatis' },
  { kata: 'obat', clue: 'Penyembuh penyakit' },
  { kata: 'dokter', clue: 'Orang yang menyembuhkan' },
  { kata: 'rumahsakit', clue: 'Tempat berobat' },
  { kata: 'ambulans', clue: 'Mobil darurat kesehatan' },
  { kata: 'polisi', clue: 'Penjaga keamanan' },
  { kata: 'tentara', clue: 'Penjaga negara' },
  { kata: 'presiden', clue: 'Pemimpin negara' },
  { kata: 'menteri', clue: 'Pembantu presiden' },
  { kata: 'pengusaha', clue: 'Orang menjalankan bisnis' },
  { kata: 'artis', clue: 'Orang terkenal di hiburan' },
  { kata: 'atlet', clue: 'Orang yang berolahraga profesional' },
  { kata: 'pelatih', clue: 'Membimbing atlet' },
  { kata: 'wasit', clue: 'Penengah pertandingan' },
  { kata: 'bola', clue: 'Benda bulat untuk olahraga' },
  { kata: 'sepakbola', clue: 'Olahraga tendang bola' },
  { kata: 'basket', clue: 'Olahraga lempar bola ke ring' },
  { kata: 'renang', clue: 'Olahraga di air' }
]

const activeSessions = new Map()
export { activeSessions }

export default {
  command: ['tebakata'],
  tags: ['game'],
  desc: '🧠 Main tebak kata dengan clue',

  async handler(ctx) {
    const chatId = ctx.chat.id
    if (activeSessions.has(chatId)) return ctx.reply('⏳ Masih ada sesi tebak kata yang aktif!')

    const selected = kataList[Math.floor(Math.random() * kataList.length)]
    const clue = selected.clue
    const jawaban = selected.kata.toLowerCase()

    const soalMessage = await ctx.reply(`
╭─〔 🧠 Tebak Kata 〕─⬣
│
│ Tebak kata berdasarkan petunjuk!
│
│ 💡 Clue: *${clue}*
│ 🔤 Huruf: ${'_ '.repeat(jawaban.length)}
│
│ ⏳ Waktu: 60 detik
│ ❌ Ketik /nyerah untuk menyerah
│
╰────────────⬣
`.trim(), {
      parse_mode: 'Markdown'
    })

    // Simpan sesi aktif dan ID pesan soal
    activeSessions.set(chatId, {
      answer: jawaban,
      startTime: Date.now(),
      soalMessageId: soalMessage.message_id,
      timeout: setTimeout(() => {
        ctx.reply(`⏰ Waktu habis!\n🫣 Jawaban yang benar adalah: *${jawaban}*`, { parse_mode: 'Markdown' })
        activeSessions.delete(chatId)
      }, 60000)
    })

    // Kirim permintaan balasan otomatis ke soal
    return ctx.reply('✍️ Balas pesan soal di atas dengan jawaban kamu!', {
      reply_to_message_id: soalMessage.message_id,
      reply_markup: {
        force_reply: true,
        selective: true
      }
    })
  }
}