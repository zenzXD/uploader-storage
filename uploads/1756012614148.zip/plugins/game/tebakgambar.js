import axios from 'axios'

const tebakan = new Map()

export default {
  command: ['tebakgambar'],
  tags: ['game'],
  desc: '🧠 Main game tebak gambar!',

  async handler(ctx) {
    const userId = ctx.from.id
    if (tebakan.has(userId)) {
      return ctx.reply(`
╭──〔 ❗ *SOAL AKTIF* 〕──
│ Kamu masih punya soal yang belum dijawab!
│ 
│ ❌ Menyerah? Gunakan perintah:
│ /nyerah
╰───────────────
      `.trim(), { parse_mode: 'Markdown' })
    }

    try {
      const res = await axios.get('https://api.betabotz.eu.org/api/game/tebakgambar?apikey=Btz-JeYoW')
      const { soal, jawaban, gambar } = res.data.result

      tebakan.set(userId, { soal, jawaban: jawaban.toLowerCase() })

      await ctx.replyWithPhoto(gambar, {
        caption: `
🎮 *GAME TEBAK GAMBAR*

📷 Gambar: (lihat di atas)
🧠 Soal:
> *${soal}*

💬 Jawaban? /jawab <tebakanmu>
😵 Menyerah? /nyerah

🏆 Semangat dan buktikan otakmu masih aktif!
        `.trim(),
        parse_mode: 'Markdown'
      })
    } catch (e) {
      console.error(e)
      ctx.reply(`
⚠️ *Gagal mengambil soal dari server!*
Coba lagi beberapa saat lagi.
      `.trim(), { parse_mode: 'Markdown' })
    }
  }
}

// Export map tebakan agar bisa diakses dari plugin /jawab dan /nyerah
export { tebakan }