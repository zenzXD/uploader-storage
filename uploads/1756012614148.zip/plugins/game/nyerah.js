const tebakan = global.tebakan || new Map()
global.tebakan = tebakan

export default {
  command: ['nyerah'],
  tags: ['game'],
  desc: '🚫 Menyerah dari tebak gambar',

  async handler(ctx) {
    const userId = ctx.from.id
    const soal = tebakan.get(userId)

    if (!soal) return ctx.reply('📭 Tidak ada soal aktif untuk diserahin.')

    tebakan.delete(userId)
    return ctx.reply(`😢 Kamu menyerah...\n✅ Jawaban yang benar adalah: *${soal.jawaban}*`, {
      parse_mode: 'Markdown'
    })
  }
}