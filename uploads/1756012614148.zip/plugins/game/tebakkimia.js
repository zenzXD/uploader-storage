import fetch from 'node-fetch';

export default {
  command: ['tebakkimia'],
  tags: ['game'],
  desc: '🧪 Tebak nama unsur kimia dari simbolnya!',
  limit: true,

  async handler(ctx) {
    try {
      const res = await fetch(`https://api.botcahx.eu.org/api/game/tebakkimia?apikey=${config.BOTCAHX_API_KEY}`);
      const json = await res.json();
      const { question, jawaban } = json.result;
      const waktu = 60; // detik

      const thumb = 'https://i.ibb.co/jw0wR1h/unsur-kimia.jpg';

      await ctx.replyWithPhoto(
        { url: thumb },
        {
          caption: 
`╭━〔 *🧪 Tebak Unsur Kimia!* 〕━⬣
┃
┃ 📍 *Simbol*: _${question}_
┃ ⏳ *Durasi*: *${waktu} detik*
┃ ✨ *Petunjuk*: Ketik nama unsur kimia dari simbol di atas!
┃
╰┬🔍 *Jawab langsung di chat ini!*
  ╰───⬣`,
          parse_mode: 'Markdown'
        }
      );

      const filter = (m) =>
        m.chat.id === ctx.chat.id &&
        typeof m.text === 'string' &&
        m.text.toLowerCase().trim() === jawaban.toLowerCase();

      const listener = async (m) => {
        if (filter(m)) {
          await ctx.telegram.sendMessage(
            ctx.chat.id,
`🎉 *Selamat!* ${m.from.first_name} menjawab dengan tepat!
✅ Jawaban: *${jawaban}*`,
            { parse_mode: 'Markdown' }
          );
          ctx.telegram.off('message', listener);
          clearTimeout(timeout);
        }
      };

      ctx.telegram.on('message', listener);

      const timeout = setTimeout(() => {
        ctx.telegram.off('message', listener);
        ctx.reply(
`⏰ *Waktu Habis!*
❌ Jawaban yang benar adalah: *${jawaban}* 🧪`,
          { parse_mode: 'Markdown' }
        );
      }, waktu * 1000);

    } catch (e) {
      console.error(e);
      ctx.reply('🚫 *Gagal memuat soal*. Silakan coba lagi nanti.', { parse_mode: 'Markdown' });
    }
  }
}
