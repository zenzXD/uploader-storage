// plugins/tools/filterai.js

import fetch from "node-fetch";

export default {

  command: ["filterai", "imgfilter"],

  tags: ["ai"],

  desc: "✨ Terapkan filter AI ke gambar dari URL dengan style pilihan",

  async handler(ctx) {

    try {

      // Ambil input user

      const parts = ctx.message.text.split(" ").slice(1).join(" ").split("|").map(s => s.trim());

      const [promptAndUrl, styleId] = [parts[0], (parts[1] || "1")];

      // Pecah prompt dan URL gambar

      const [prompt, imageUrl] = promptAndUrl ? promptAndUrl.split(" ").map(s => s.trim()) : [];

      // Validasi

      if (!prompt || !imageUrl) {

        return ctx.reply(

          `⚠️ *Format salah!*\n\n` +

          `💡 Contoh penggunaan:\n` +

          `/filterai night https://example.com/image.jpg | 2\n\n` +

          `📌 Keterangan:\n` +

          `- Prompt: kata kunci filter AI\n` +

          `- URL Gambar: link gambar asli\n` +

          `- Style ID (opsional): angka style filter (default = 1)`,

          { parse_mode: "Markdown" }

        );

      }

      // Notif sedang memproses

      await ctx.reply(

        `🎨 *Memproses filter AI...*\n\n` +

        `📜 *Prompt:* \`${prompt}\`\n` +

        `🖼️ *Gambar:* [klik disini](${imageUrl})\n` +

        `🎭 *Style ID:* \`${styleId}\`\n\n` +

        `⏳ Mohon tunggu sebentar...`,

        { parse_mode: "Markdown", disable_web_page_preview: false }

      );

      // API URL

      const apiKey = "planaai";

      const apiURL = `https://www.sankavollerei.com/ai/filter?apikey=${apiKey}&prompt=${encodeURIComponent(prompt)}&imageUrl=${encodeURIComponent(imageUrl)}&id_style=${encodeURIComponent(styleId)}`;

      // Fetch hasil gambar

      const res = await fetch(apiURL);

      if (!res.ok) throw new Error(`Gagal menghubungi API (status ${res.status})`);

      const buffer = await res.buffer();

      // Kirim hasil ke user

      await ctx.replyWithPhoto(

        { source: buffer },

        {

          caption:

            `✅ *Filter AI Selesai!*\n\n` +

            `📜 Prompt: \`${prompt}\`\n` +

            `🎭 Style ID: \`${styleId}\`\n` +

            `🖌️ Dihasilkan oleh *FilterAI* ✨`,

          parse_mode: "Markdown"

        }

      );

    } catch (err) {

      console.error(err);

      ctx.reply(`❌ Terjadi kesalahan: ${err.message}`);

    }

  }

};