import axios from 'axios'

const smith = {
  getToken: async () => {
    const { data } = await axios({
      method: 'POST',
      url: 'https://api.vulcanlabs.co/smith-auth/api/v1/token',
      headers: {
        'User-Agent': 'Chat Smith Android, Version 4.0.1(970)',
        'Content-Type': 'application/json; charset=utf-8',
        'x-vulcan-application-id': 'com.smartwidgetlabs.chatgpt',
        'x-vulcan-request-id': '9149487891752494707093'
      },
      data: JSON.stringify({
        device_id: "A718E10669C7C5F7",
        order_id: "",
        product_id: "",
        purchase_token: "",
        subscription_id: ""
      })
    })
    return data
  },

  chat: async (messages) => {
    const token = await smith.getToken()
    const { data } = await axios({
      method: 'POST',
      url: 'https://api.vulcanlabs.co/smith-v2/api/v7/chat_android',
      headers: {
        'User-Agent': 'Chat Smith Android, Version 4.0.1(970)',
        'Content-Type': 'application/json; charset=utf-8',
        'authorization': `Bearer ${token.AccessToken}`,
        'x-vulcan-application-id': 'com.smartwidgetlabs.chatgpt',
        'x-vulcan-request-id': '9149487891752494721341'
      },
      data: JSON.stringify({
        usage_model: {
          provider: "openai",
          model: "gpt-4o-mini"
        },
        user: "A718E10669C7C5F7",
        messages: messages,
        nsfw_check: true,
        tools: [{
          function: {
            name: "create_ai_art"
          }
        }]
      })
    })
    return data
  }
}

export default {
  command: ['smithai'],
  tags: ['ai'],
  desc: '💬 Tanya jawab dengan AI Smith (GPT-4o-mini)',

  async handler(ctx) {
    const text = ctx.message?.text?.split(' ').slice(1).join(' ')
    if (!text) return await ctx.reply(`Contoh: /smithai Apa itu Node.js`)

    try {
      const res = await smith.chat([
        {
          role: "system",
          content: "You are Ai Smith. You are the cheerful Ai who likes to help. You are friendly. You like to use emojis."
        },
        {
          role: "user",
          content: text
        }
      ])

      const reply = res.choices?.[0]?.Message?.content || '❌ Gagal mendapatkan respons.'
      await ctx.reply(reply)
    } catch (e) {
      await ctx.reply(`⚠️ Error: ${e.message}`)
    }
  }
}