// plugins/ai/zonerai.js
import axios from 'axios'
import FormData from 'form-data'
import https from 'https'

const reso = {
  portrait: { width: 768, height: 1344 },
  landscape: { width: 1344, height: 768 },
  square: { width: 1024, height: 1024 },
  ultra: { width: 1536, height: 1536 },
  tall: { width: 832, height: 1344 },
  wide: { width: 1344, height: 832 }
}

async function Txt2IMG(prompt, resolusi, upscale = 2) {
  const selected = reso[resolusi] || reso.portrait
  const { width, height } = selected

  const promises = Array.from({ length: 3 }, (_, idx) => {
    const form = new FormData()
    form.append('Prompt', prompt)
    form.append('Language', 'eng_Latn')
    form.append('Size', `${width}x${height}`)
    form.append('Upscale', upscale.toString())
    form.append('Batch_Index', idx.toString())

    const agent = new https.Agent({ rejectUnauthorized: false })

    return axios.post(
      'https://api.zonerai.com/zoner-ai/txt2img',
      form,
      {
        httpsAgent: agent,
        headers: {
          ...form.getHeaders(),
          'Origin': 'https://zonerai.com',
          'Referer': 'https://zonerai.com/',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/115 Safari/537.36'
        },
        responseType: 'arraybuffer'
      }
    ).then(res => Buffer.from(res.data))
  })

  return Promise.all(promises)
}

export default {
  command: ['zonerai'],
  tags: ['ai'],
  desc: '🎨 Generate image from prompt using ZonerAI',
  async handler(ctx) {
    const text = ctx.message?.text?.split(' ')?.slice(1)?.join(' ')
    if (!text) {
      return ctx.reply(`╭─〔 ZonerAI Generator 〕─⬣
│ 📌 *Contoh:* /zonerai cewek anime|square
│ 📐 *Resolusi:* portrait, landscape, square, ultra, tall, wide
╰────────────⬣`)
    }

    const [prompt, resolutionRaw] = text.split('|').map(t => t.trim())
    const resKey = resolutionRaw?.toLowerCase()
    const isValidRes = Object.keys(reso).includes(resKey)
    const resType = isValidRes ? resKey : 'portrait'
    const size = reso[resType]

    try {
      await ctx.reply('⏳ *Sedang menggambar, tunggu sebentar ya...*')

      const images = await Txt2IMG(prompt, resType)

      for (let i = 0; i < images.length; i++) {
        const caption = `
╭──〔 🎨 ZonerAI Generator 〕──⬣
│ 🖋️ *Prompt:* ${prompt}
│ 📐 *Resolusi:* ${size.width}x${size.height}
│ 🖼️ *Gambar ${i + 1}/3*
╰────────────⬣
🤖 Powered by *ZonerAI*
        `.trim()

        await ctx.telegram.sendPhoto(ctx.chat.id, { source: images[i] }, {
          caption: i === 0 ? caption : undefined
        })
      }

      await ctx.reply('✅ *Gambar berhasil dikirim!*')

    } catch (e) {
      console.error(e)
      await ctx.reply(`❌ *Gagal menggambar:*\n\`${e.message}\``)
    }
  }
}