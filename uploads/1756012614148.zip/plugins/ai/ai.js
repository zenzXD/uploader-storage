import axios from 'axios'
import fs from 'fs'
import path from 'path'
import { config } from '../../config.js'

const listmodel = [
  'gpt-4.1-nano', 'gpt-4.1-mini', 'gpt-4.1', 'o4-mini', 'deepseek-r1',
  'deepseek-v3', 'claude-3.7', 'gemini-2.0', 'grok-3-mini', 'qwen-qwq-32b',
  'gpt-4o', 'o3', 'gpt-4o-mini', 'llama-3.3'
]

const defaultSettings = {
  model: 'grok-3-mini',
  system_prompt: 'Be a helpful AI assistant.'
}

const dbPath = path.resolve('./json/ai-custom.json')

function loadUserSettings() {
  try {
    if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, '{}')
    return JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
  } catch (e) {
    console.error('❗ Gagal load settings:', e)
    return {}
  }
}

function saveUserSettings(settings) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(settings, null, 2), 'utf-8')
  } catch (e) {
    console.error('❗ Gagal simpan settings:', e)
  }
}

async function chatai(q, model, system_prompt) {
  if (!listmodel.includes(model)) {
    return {
      error: `❌ Model tidak tersedia. Coba salah satu:\n\n${listmodel.map(m => `• ${m}`).join('\n')}`
    }
  }

  const headers = {
    'Content-Type': 'application/json',
    'User-Agent': 'Mozilla/5.0',
    'Referer': 'https://ai-interface.anisaofc.my.id/'
  }

  const data = { question: q, model, system_prompt }

  try {
    const res = await axios.post('https://ai-interface.anisaofc.my.id/api/chat', data, {
      headers,
      timeout: 10000
    })
    return res.data
  } catch (e) {
    throw new Error(e.response?.data?.message || e.message || '❌ Request gagal')
  }
}

export default {
  command: ['ai'],
  tags: ['ai'],
  desc: '💬 AI Multibot: Tanya apa saja dengan model pilihanmu',

  async handler(ctx) {
    const sender = ctx.from.id.toString()
    const text = ctx.message?.text?.split(' ').slice(1).join(' ')?.trim()
    const userSettings = loadUserSettings()

    if (!text) {
      const currentSettings = userSettings[sender] || defaultSettings
      return await ctx.reply(`
╭━━━〔 🤖 *${config.BOTNAME} AI* 〕━━━⬣
┃ 💬 *Tanyakan sesuatu:*  
┃ Contoh: \`/ai Apa itu JavaScript?\`
┃
┃ ⚙️ *Atur Model & Prompt:*  
┃ Contoh: \`/ai set gpt-4o | Kamu asisten ramah\`
┃
┃ 🔧 *Pengaturanmu:*
┃ • Model: *${currentSettings.model}*
┃ • Prompt: _${currentSettings.system_prompt}_
╰━━━━━━━━━━━━━━━━━━━━⬣
      `.trim(), { parse_mode: 'Markdown' })
    }

    if (text.startsWith('set')) {
      const input = text.slice(4).split('|').map(i => i.trim())
      const model = input[0]
      const system_prompt = input[1]

      if (!model || !listmodel.includes(model)) {
        return await ctx.reply(`🚫 *Model tidak valid!*\n\n🧠 *Model tersedia:*\n${listmodel.map(m => `• ${m}`).join('\n')}`, {
          parse_mode: 'Markdown'
        })
      }

      if (!system_prompt) {
        return await ctx.reply(`📝 *Prompt kosong!*\nContoh: \`/ai set gpt-4o | Kamu asisten pemrograman\``, {
          parse_mode: 'Markdown'
        })
      }

      userSettings[sender] = { model, system_prompt }
      saveUserSettings(userSettings)

      return await ctx.reply(`
✅ *Pengaturan Tersimpan!*
📦 Model: *${model}*
🧠 Prompt: _${system_prompt}_
      `.trim(), { parse_mode: 'Markdown' })
    }

    try {
      const { model, system_prompt } = userSettings[sender] || defaultSettings
      await ctx.reply('⌛ *Memproses pertanyaanmu...*', { parse_mode: 'Markdown' })

      const res = await chatai(text, model, system_prompt)

      if (res.error) {
        return await ctx.reply(`❌ *Gagal:* ${res.error}`, { parse_mode: 'Markdown' })
      }

      return await ctx.reply(`╭───〔 💬 *Jawaban dari ${model}* 〕───⬣\n${res.response}\n╰━━━━━━━━━━━━━━━━━━━━⬣`, {
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })
    } catch (e) {
      return await ctx.reply(`⚠️ *Terjadi kesalahan:* ${e.message}`, { parse_mode: 'Markdown' })
    }
  }
}