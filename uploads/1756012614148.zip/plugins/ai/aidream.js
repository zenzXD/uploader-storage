import fetch from "node-fetch"

import { bold, italic } from "telegraf/format"

export default {

  command: ["dream", "aidream"],

  tags: ["ai"],

  desc: "🌙 Tafsir mimpi kamu lewat AI",

  async handler(ctx) {

    const query = ctx.text?.split(" ").slice(1).join(" ")

    if (!query) {

      return ctx.reply(

        `╭── ⌜  *AI Dream*  ⌟ ──⬣\n` +

        `│ 🌙 Ketikkan mimpi kamu untuk ditafsirkan\n` +

        `│ ✏️ Contoh:\n` +

        `│   /dream aku dikejar harimau\n` +

        `╰────────────⬣`

      )

    }

    try {

      const res = await fetch(`https://yeonelleapi.vercel.app/ai/aidream?q=${encodeURIComponent(query)}`)

      const json = await res.json()

      if (!json?.status || !json.result) {

        return ctx.reply("❌ Gagal mendapatkan tafsir mimpi dari AI.")

      }

      const result = json.result.trim()

      await ctx.reply(

        `╭── ❏ *AI Dream Interpretation* ❏ ──⬣\n` +

        `│ 💤 *Prompt:* ${query}\n` +

        `│ 🧠 *Makna Mimpi Kamu:*\n` +

        `╰──────────────────────────⬣\n\n` +

        `${result}\n\n` +

        `🔮 _Ditafsirkan oleh AI dari YeonElle_\n` +

        `🌐 https://yeonelleapi.vercel.app/`,

        { parse_mode: "Markdown" }

      )

    } catch (err) {

      console.error(err)

      ctx.reply("⚠️ Terjadi kesalahan saat mengambil tafsir mimpi.")

    }

  }

}