import fetch from "node-fetch";

export default {

  command: ["askai"],

  tags: ["ai"],

  desc: "💬 Tanya AI Realtime (Claude Model)",

  async handler(ctx) {

    const text = ctx.body?.split(" ").slice(1).join(" ");

    if (!text) {

      return ctx.reply(

        `⚠️ *Masukkan pertanyaan yang mau ditanyakan ke AI!*\n\n` +

        `💡 Contoh:\n\`/askai apa itu telegraf\``,

        { parse_mode: "Markdown" }

      );

    }

    try {

      await ctx.reply(

        `⏳ *Sedang bertanya ke AI Realtime...*\n` +

        `📝 Pertanyaan:\n\`\`\`${text}\`\`\``,

        { parse_mode: "Markdown" }

      );

      const res = await fetch(

        `https://www.sankavollerei.com/ai/realtime?apikey=planaai&model=claude&text=${encodeURIComponent(text)}`

      );

      const json = await res.json();

      if (!json || !json.result) {

        return ctx.reply("⚠️ Gagal mengambil jawaban dari AI.");

      }

      await ctx.reply(

        `🤖 *AI Realtime - Claude Model*\n` +

        `━━━━━━━━━━━━━━━━━━━━━━\n` +

        `❓ *Pertanyaan:*\n\`${text}\`\n\n` +

        `💬 *Jawaban:*\n${json.result}\n` +

        `━━━━━━━━━━━━━━━━━━━━━━\n` +

        `✅ *Selesai!*`,

        { parse_mode: "Markdown" }

      );

    } catch (err) {

      console.error(err);

      ctx.reply("🚫 Terjadi kesalahan saat menghubungi AI.");

    }

  }

};