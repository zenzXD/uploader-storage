import fetch from "node-fetch"

export default {

  command: ["kimi", "askkimi"],

  tags: ["ai"],

  desc: "👩‍💼 Tanya ke AI Kimi (YeonElle)",

  async handler(ctx) {

    const text = ctx.text?.split(" ").slice(1).join(" ")

    if (!text) {

      return ctx.reply(

        `╭── 「 *Kimi AI Chat* 」──⬣\n` +

        `│ 💬 Kirim pertanyaan untuk Kimi\n` +

        `│ ✏️ Contoh:\n` +

        `│   /kimi siapa kamu?\n` +

        `╰────────────⬣`

      )

    }

    try {

      const res = await fetch(`https://yeonelleapi.vercel.app/ai/kimi?text=${encodeURIComponent(text)}`)

      const json = await res.json()

      if (!json?.status || !json.result?.text) {

        return ctx.reply("❌ Gagal mendapatkan jawaban dari Kimi.")

      }

      const reply = json.result.text.trim()

      await ctx.reply(`👩‍💼 *Kimi menjawab:*\n\n${reply}`, {

        parse_mode: "Markdown"

      })

    } catch (e) {

      console.error(e)

      ctx.reply("⚠️ Terjadi kesalahan saat menghubungi Kimi.")

    }

  }

}