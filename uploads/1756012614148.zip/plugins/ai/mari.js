// plugins/tools/mari.js

import fetch from "node-fetch";

export default {

  command: ["mari"],

  tags: ["ai"],

  desc: "✨ Aplikasikan transformasi 'mari' ke teks menggunakan API sankavollerei",

  async handler(ctx) {

    try {

      const text = ctx.message.text.split(" ").slice(1).join(" ");

      if (!text) {

        return ctx.reply(

          `⚠️ *Format Salah!*\n` +

          `Gunakan contoh:\n\`/mari night\`\n\n` +

          `💡 *Tips:* Masukkan teks apapun untuk diubah dengan *Mari Mode* ✨`,

          { parse_mode: "Markdown" }

        );

      }

      await ctx.reply(

        `🪄 *Mari Magic Activated!*\n` +

        `⏳ Sedang memproses teks...\n\n` +

        `📝 *Input:* \`${text}\`\n` +

        `🎯 Mode: \`Mari\``,

        { parse_mode: "Markdown" }

      );

      const apiUrl = `https://www.sankavollerei.com/ai/mari?apikey=planaai&text=${encodeURIComponent(text)}`;

      const res = await fetch(apiUrl);

      if (!res.ok) throw new Error(`API Error: ${res.status}`);

      const data = await res.text(); // Jika output-nya JSON, ganti ke res.json()

      await ctx.reply(

        `✨ *Hasil Transformasi Mari*\n\n` +

        `🌱 *Teks Asli:*\n\`\`\`\n${text}\n\`\`\`\n\n` +

        `🌸 *Teks Mari:*\n\`\`\`\n${data}\n\`\`\`\n` +

        `✅ Diproses dengan kekuatan *Mari AI* ✨`,

        { parse_mode: "Markdown" }

      );

    } catch (err) {

      console.error(err);

      ctx.reply(`❌ Terjadi kesalahan: ${err.message}`);

    }

  }

};