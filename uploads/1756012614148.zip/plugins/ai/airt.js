// plugins/tools/artai.js

import fetch from "node-fetch";

export default {

  command: ["artai", "aigen"],

  tags: [ "ai"],

  desc: "🎨 Generate gambar AI (ArtAI) dengan style pilihan",

  async handler(ctx) {

    try {

      // Ambil input user

      const text = ctx.message.text.split(" ").slice(1).join(" ");

      if (!text) {

        return ctx.reply(

          `┏━🎨 *ArtAI Generator* ━┓\n` +

          `📌 *Contoh penggunaan:*\n` +

          `\`/artai night | anime\`\n` +

          `\`/artai sunset beach | realistic\`\n\n` +

          `💡 Pisahkan *prompt* & *style* dengan tanda *|*`,

          { parse_mode: "Markdown" }

        );

      }

      // Default value

      let prompt = text;

      let style = "anime";

      if (text.includes("|")) {

        const parts = text.split("|").map(s => s.trim());

        prompt = parts[0];

        style = parts[1] || "anime";

      }

      // Pesan loading

      await ctx.reply(

        `🎨 *ArtAI Sedang Bekerja...*\n` +

        `🖌 *Prompt:* \`${prompt}\`\n` +

        `🎭 *Style:* \`${style}\`\n\n` +

        `✨ Mohon tunggu, sedang memoles karya senimu...`,

        { parse_mode: "Markdown" }

      );

      // API URL

      const apiKey = "planaai";

      const apiURL = `https://www.sankavollerei.com/ai/artai?apikey=${apiKey}&text=${encodeURIComponent(prompt)}&style=${encodeURIComponent(style)}`;

      // Ambil gambar

      const res = await fetch(apiURL);

      if (!res.ok) throw new Error(`Gagal menghubungi API (${res.status})`);

      const buffer = await res.buffer();

      // Kirim hasil ke user

      await ctx.replyWithPhoto(

        { source: buffer },

        {

          caption:

            `┏━ 🎨 *ArtAI Result* ━┓\n` +

            `📜 *Prompt:* \`${prompt}\`\n` +

            `🎭 *Style:* \`${style}\`\n` +

            `💎 *Quality:* High\n` +

            `✅ Dibuat dengan penuh cinta oleh *ArtAI* ✨\n` +

            `┗━━━━━━━━━━━━━━━━━━━┛`,

          parse_mode: "Markdown"

        }

      );

    } catch (err) {

      console.error(err);

      ctx.reply(

        `❌ *Terjadi Kesalahan:*\n` +

        `\`${err.message}\`\n\n` +

        `💡 Coba lagi dengan format yang benar.`,

        { parse_mode: "Markdown" }

      );

    }

  }

};