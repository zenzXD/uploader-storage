import fetch from "node-fetch"

export default {

  command: ["gptmini", "gpt4mini", "mini"],

  tags: ["ai"],

  desc: "💬 Tanya jawab dengan GPT4-O Mini (YeonElle API)",

  async handler(ctx) {

    const text = ctx.text?.split(" ").slice(1).join(" ")

    if (!text) {

      return ctx.reply(

        `╭─「 *GPT4-O Mini* 」\n` +

        `│ 💬 Kirim pertanyaan atau pesan\n` +

        `│ ✏️ Contoh:\n` +

        `│   /gptmini siapa presiden indonesia?\n` +

        `╰────────────⬣`

      )

    }

    try {

      const res = await fetch(`https://yeonelleapi.vercel.app/ai/gpt4omini?text=${encodeURIComponent(text)}`)

      const json = await res.json()

      if (!json?.status || !json.result) {

        return ctx.reply("❌ Gagal mengambil jawaban dari GPT4-O Mini.")

      }

      const reply = json.result.trim()

      await ctx.reply(`🤖 *GPT4-O Mini Jawab:*\n\n${reply}`, {

        parse_mode: "Markdown"

      })

    } catch (e) {

      console.error(e)

      ctx.reply("⚠️ Terjadi kesalahan saat menghubungi GPT4-O Mini.")

    }

  }

}