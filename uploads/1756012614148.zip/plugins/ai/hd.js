import axios from 'axios'
import FormData from 'form-data'
import fs from 'fs'
import path from 'path'

let queue = []
let isProcessing = false

export default {
  command: ['hd'],
  tags: ['ai'],
  desc: '🔍 Upscale gambar (HD AI)',
  async handler(ctx) {
    const msg = ctx.message
    const replied = msg?.reply_to_message
    const mime = replied?.photo ? 'image/jpeg' : null

    if (!replied || !mime) {
      return await ctx.reply('⚠️ *Balas gambar* dengan perintah `.hd`\n\n_Contoh: Balas foto lalu ketik `.hd`_', { parse_mode: 'Markdown' })
    }

    const userId = msg.from.id
    queue.push({ ctx, userId })

    if (!isProcessing) processQueue()
    await ctx.reply(`⏳ Permintaan kamu masuk antrian...\n📌 Posisi antrian: *${queue.length}*\nMohon tunggu...`, { parse_mode: 'Markdown' })
  }
}

async function processQueue() {
  isProcessing = true

  while (queue.length > 0) {
    const { ctx, userId } = queue[0]

    try {
      const msg = ctx.message
      const replied = msg.reply_to_message

      await ctx.reply('🎨 *Sedang memperjelas gambar...*\nIni bisa memakan waktu 10-20 detik.', { parse_mode: 'Markdown' })

      const fileId = replied.photo[replied.photo.length - 1].file_id
      const fileLink = await ctx.telegram.getFileLink(fileId)
      const res = await axios.get(fileLink.href, { responseType: 'arraybuffer' })
      const buffer = await upscale(Buffer.from(res.data))

      await ctx.replyWithPhoto({ source: buffer }, { caption: '✅ *Selesai! Ini hasil HD-nya kak* 😊', parse_mode: 'Markdown' })
    } catch (e) {
      await ctx.reply(`❌ *Gagal:* ${e.message || e}`, { parse_mode: 'Markdown' })
    }

    queue.shift()
  }

  isProcessing = false
}

async function upscale(imageBuffer) {
  try {
    const form = new FormData()
    form.append('image', imageBuffer, {
      filename: 'upload.jpg',
      contentType: 'image/jpeg'
    })
    form.append('user_id', 'undefined')
    form.append('is_public', 'true')

    const headers = {
      ...form.getHeaders(),
      'Accept': '*/*',
      'Origin': 'https://picupscaler.com',
      'Referer': 'https://picupscaler.com/',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
    }

    const { data } = await axios.post('https://picupscaler.com/api/generate/handle', form, { headers })
    const resultUrl = data?.image_url || data?.url
    if (!resultUrl) throw new Error('Upscale gagal. Gambar tidak ditemukan.')

    const result = await axios.get(resultUrl, { responseType: 'arraybuffer' })
    return Buffer.from(result.data)
  } catch (err) {
    throw new Error(`Upscale error: ${typeof err === 'string' ? err : err.message}`)
  }
}