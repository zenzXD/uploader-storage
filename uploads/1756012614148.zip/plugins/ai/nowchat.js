import crypto from 'crypto'
import axios from 'axios'

// 🔐 Generate Key untuk NowTech AI
function generateNowKey() {
  const t = Date.now().toString()
  const s = 'dfaugf098ad0g98-idfaugf098ad0g98-iduoafiunoa-f09a8s098a09ea-a0s8g-asd8g0a9d--gasdga8d0g8a0dg80a9sd8g0a9d8gduoafiunoa-f09adfaugf098ad0g98-iduoafiunoa-f09a8s098a09ea-a0s8g-asd8g0a9d--gasdga8d0g8a0dg80a9sd8g0a9d8g8s098a09ea-a0s8g-asd8g0a9d--gasdga8d0g8a0dg80a9sd8g0a9d8g'
  const k = crypto.createHmac('sha512', s).update(t).digest('base64')
  return { key: k, time: t }
}

// 🤖 AI Chat Handler
async function nowchat(question) {
  const { key, time } = generateNowKey()
  const data = JSON.stringify({ content: question })

  const config = {
    method: 'POST',
    url: 'http://aichat.nowtechai.com/now/v1/ai',
    headers: {
      'User-Agent': 'Ktor client',
      'Connection': 'Keep-Alive',
      'Accept': 'application/json',
      'Accept-Encoding': 'gzip',
      'Content-Type': 'application/json',
      'Key': key,
      'TimeStamps': time,
      'Accept-Charset': 'UTF-8'
    },
    data,
    responseType: 'stream'
  }

  return new Promise((resolve, reject) => {
    axios.request(config).then(res => {
      let result = ''
      res.data.on('data', chunk => {
        const lines = chunk.toString().split('\n')
        for (const line of lines) {
          if (line.startsWith('data: ') && line !== 'data: [DONE]') {
            try {
              const json = JSON.parse(line.replace('data: ', ''))
              const c = json?.choices?.[0]?.delta?.content
              if (c) result += c
            } catch {}
          }
        }
      })
      res.data.on('end', () => resolve(result.trim()))
      res.data.on('error', reject)
    }).catch(reject)
  })
}

// 🎨 AI Art Generator
async function nowart(prompt) {
  const res = await axios.get(`http://art.nowtechai.com/art?name=${encodeURIComponent(prompt)}`, {
    headers: {
      'User-Agent': 'okhttp/5.0.0-alpha.9',
      'Connection': 'Keep-Alive',
      'Accept': 'application/json',
      'Accept-Encoding': 'gzip',
      'Content-Type': 'application/json'
    }
  })
  return res.data
}

// 📦 Telegram Plugin Handler
export default {
  command: ['nowchat', 'nowartimg'],
  tags: ['ai'],
  desc: '🧠 AI Chat & 🎨 AI Art via NowTech',

  async handler(ctx) {
    const args = ctx.message.text?.split(' ').slice(1)
    const command = ctx.message.text?.split(' ')[0]?.slice(1)
    const input = args.join(' ').trim()

    if (!input) {
      return ctx.reply(`❌ *Input tidak boleh kosong!*\n\n📌 _Contoh:_\n\`/${command} Apakah AI bisa menggantikan manusia?\``, { parse_mode: 'Markdown' })
    }

    if (command === 'nowchat') {
      await ctx.reply('💬 *Sedang berpikir...*', { parse_mode: 'Markdown' })
      try {
        const reply = await nowchat(input)
        return ctx.reply(`🤖 *Jawaban dari NowAI:*\n\n🗨️ ${reply}`, { parse_mode: 'Markdown' })
      } catch (err) {
        console.error(err)
        return ctx.reply('⚠️ *Gagal mendapatkan respon dari AI.*', { parse_mode: 'Markdown' })
      }
    }

    if (command === 'nowartimg') {
      await ctx.reply('🖌️ *Sedang menggambar...*', { parse_mode: 'Markdown' })
      try {
        const res = await nowart(input)
        if (!res?.data?.length) {
          return ctx.reply('🚫 *Tidak ada gambar yang dihasilkan.*', { parse_mode: 'Markdown' })
        }
        for (const x of res.data) {
          await ctx.replyWithPhoto({ url: x.img_url }, {
            caption: `🎨 *Prompt:* _${input}_`,
            parse_mode: 'Markdown'
          })
        }
      } catch (err) {
        console.error(err)
        return ctx.reply('❌ *Gagal mengambil gambar dari NowArt.*', { parse_mode: 'Markdown' })
      }
    }
  }
}
