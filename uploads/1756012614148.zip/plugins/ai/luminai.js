import fetch from "node-fetch"

export default {

  command: ["luminai", "lumi"],

  tags: ["ai"],

  desc: "✨ Tanya ke LuminAI (YeonElle)",

  async handler(ctx) {

    const text = ctx.text?.split(" ").slice(1).join(" ")

    if (!text) {

      return ctx.reply(

        `╭─「 *LuminAI Chat* 」\n` +

        `│ ✨ Kirim pertanyaan kamu\n` +

        `│ Contoh:\n` +

        `│   /luminai bagaimana cara belajar cepat?\n` +

        `╰────────────⬣`

      )

    }

    try {

      const res = await fetch(`https://yeonelleapi.vercel.app/ai/luminai?text=${encodeURIComponent(text)}`)

      const json = await res.json()

      if (json?.result?.toLowerCase().includes("rate limit")) {

        return ctx.reply("⏳ Kamu sudah mencapai batas pemakaian per jam.\nSilakan coba lagi nanti.")

      }

      if (!json?.status || !json.result) {

        return ctx.reply("❌ Gagal mendapatkan jawaban dari LuminAI.")

      }

      const reply = json.result.trim()

      await ctx.reply(`✨ *LuminAI Menjawab:*\n\n${reply}`, {

        parse_mode: "Markdown"

      })

    } catch (e) {

      console.error(e)

      ctx.reply("⚠️ Terjadi kesalahan saat menghubungi LuminAI.")

    }

  }

}