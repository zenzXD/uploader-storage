import fetch from "node-fetch";

export default {

  command: ["humanize"],

  tags: ["ai"],

  desc: "📝 Ubah teks menjadi lebih natural dan manusiawi",

  async handler(ctx) {

    try {

      const text = ctx.message?.text?.split(" ").slice(1).join(" ");

      if (!text) {

        return ctx.reply(

          `⚠️ *Masukkan teks yang mau di-humanize!*\n\n` +

          `💡 Contoh:\n\`/humanize Males keluar rumah\`\n\n` +

          `Teks akan diubah menjadi lebih natural.`,

          { parse_mode: "Markdown" }

        );

      }

      await ctx.reply(

        `⏳ *Memproses teks...*\n\n` +

        `📝 *Teks Asli:* \`${text}\`\n` +

        `🎯 Level: \`standard\``,

        { parse_mode: "Markdown" }

      );

      const apiUrl = `https://www.sankavollerei.com/ai/humanize?apikey=planaai&text=${encodeURIComponent(text)}&level=standard`;

      const res = await fetch(apiUrl);

      if (!res.ok) throw new Error(`API Error: ${res.status}`);

      const data = await res.json();

      if (!data.result) {

        return ctx.reply("❌ Gagal mengubah teks.");

      }

      await ctx.reply(

        `✨ *Hasil Humanize*\n` +

        `━━━━━━━━━━━━━━\n` +

        `📜 *Teks Asli:*\n${text}\n\n` +

        `💬 *Humanized:*\n${data.result}\n` +

        `━━━━━━━━━━━━━━\n` +

        `✅ Dibuat dengan *AI Humanizer*`,

        { parse_mode: "Markdown" }

      );

    } catch (err) {

      console.error(err);

      ctx.reply(`❌ Terjadi kesalahan: ${err.message}`);

    }

  }

};