// plugins/tools/ai4chat.js

import fetch from "node-fetch";

export default {

  command: ["ai4chat", "aiimage"],

  tags: ["ai"],

  desc: "🎨 Generate gambar AI dari prompt menggunakan API sankavollerei.com",

  async handler(ctx) {

    try {

      // Ambil input prompt user

      const text = ctx.message.text.split(" ").slice(1).join(" ");

      if (!text) {

        return ctx.reply(

          `⚠️ *Contoh Penggunaan:*\n` +

          `\`/ai4chat sunset beach | 2:3\`\n\n` +

          `💡 *Tips:* Pisahkan prompt & ratio dengan tanda *|*`,

          { parse_mode: "Markdown" }

        );

      }

      // Pisahkan prompt dan ratio jika ada

      let prompt = text;

      let ratio = "2:3";

      if (text.includes("|")) {

        const parts = text.split("|").map(s => s.trim());

        prompt = parts[0];

        ratio = parts[1] || "2:3";

      }

      // Pesan loading

      await ctx.reply(

        `⏳ *Sedang membuat gambar AI...*\n\n` +

        `📜 *Prompt:* \`${prompt}\`\n` +

        `📐 *Ratio:* \`${ratio}\`\n\n` +

        `✨ Mohon tunggu, ini mungkin memakan waktu beberapa detik...`,

        { parse_mode: "Markdown" }

      );

      // API Key & Endpoint

      const apiKey = "planaai";

      const apiURL = `https://www.sankavollerei.com/ai/ai4chat?apikey=${apiKey}&prompt=${encodeURIComponent(prompt)}&ratio=${encodeURIComponent(ratio)}`;

      // Fetch data (asumsi API mengembalikan gambar langsung)

      const res = await fetch(apiURL);

      if (!res.ok) throw new Error(`Gagal ambil data API: ${res.status}`);

      const buffer = await res.buffer();

      // Kirim gambar ke user

      await ctx.replyWithPhoto(

        { source: buffer },

        {

          caption:

            `🎨 *AI Generated Image*\n\n` +

            `📜 *Prompt:* \`${prompt}\`\n` +

            `📐 *Ratio:* \`${ratio}\`\n\n` +

            `✅ Selesai dibuat oleh *AI4Chat* ✨`,

          parse_mode: "Markdown"

        }

      );

    } catch (err) {

      console.error(err);

      ctx.reply(

        `❌ *Terjadi Kesalahan:*\n\`${err.message}\`\n\n` +

        `💡 Pastikan format sudah benar dan API bisa diakses.`,

        { parse_mode: "Markdown" }

      );

    }

  }

};