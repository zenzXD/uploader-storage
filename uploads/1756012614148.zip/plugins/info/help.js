import { config } from '../../config.js'

export default {
  command: ['help'],
  tags: ['info'],
  desc: '📖 Menampilkan bantuan dan daftar perintah bot',

  async handler(ctx) {
    const helpText = `
╭───〔 🤖 *PANDUAN PENGGUNAAN BOT* 〕───╮

📌 *Cara Penggunaan:*
• Gunakan perintah dengan awalan: \`/\`
• Bisa tag @user, reply pesan, atau pakai ID
• Contoh: \`/ban @user 2d\`, \`/mute 12345 5m\`

👮 *Perintah Admin Grup:*
• /ban @user [durasi] – 🚫 Banned
• /kick @user – 👢 Kick dari grup
• /mute @user [durasi] – 🔇 Mute user
• /unmute @user – 🔊 Unmute user
• /warn @user – ⚠️ Peringatan
• /unwarn @user – ✅ Hapus peringatan

🛡 *Fitur Anti-Toxic Otomatis:*
• Pesan toxic langsung dihapus
• User diberi peringatan otomatis
• 3x toxic = auto-banned 😵

📋 *Fitur Lainnya:*
• /cekid – 🆔 Lihat ID user / grup
• /adduser [kategori] – 📥 Tambah target broadcast
• /donasi – ☕ Dukung pengembangan bot
• /tos – 📜 Syarat & Ketentuan Penggunaan

🔧 *Contoh Perintah:*
• /ban @user 2d
• /mute 123456789 5m
• /warn (sambil reply)

🚫 *Hal yang Dilarang:*
• Menggunakan bot untuk spam/fitnah/penipuan
• Merusak reputasi developer atau user lain
• Mengkloning/menjual ulang tanpa izin
• Menggunakan bot untuk aktivitas ilegal

╰────〔 👨‍💻 Dev: @${config.OWNER_USERNAME} 〕────╯
    `.trim()

    await ctx.reply(helpText, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '📬 Hubungi Owner', url: `https://t.me/${config.OWNER_USERNAME}` },
            { text: '📦 Sewa Bot', callback_data: 'sewa_bot' }
          ],
          [
            { text: '☕ Donasi', url: 'https://trakteer.id/${config.TRAKTEER' },
            { text: '📜 Terms of Service', callback_data: 'tos' }
          ]
        ]
      }
    })
  }
}