import os from 'os';
import fs from 'fs';
import path from 'path';
import { performance } from 'perf_hooks';
import { formatUptime } from '../../lib/format.js';
import pkg from '../../package.json' with { type: 'json' };

export const command = ['info', 'status'];
export const tags = ['info'];
export const desc = 'Menampilkan status & informasi bot';

const startedAt = performance.now();

export default (bot) => {
  bot.command(command, async (ctx) => {
    const uptime = formatUptime(process.uptime());
    const ramUsage = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);
    const totalCommand = Object.keys(bot.context.pluginList || {}).length;
    const pluginCount = Object.keys(bot.context.pluginMeta || {}).length;

    // Ambil waktu terakhir update
    const pluginDir = path.join(process.cwd(), 'plugins');
    const stats = fs.statSync(pluginDir);
    const lastUpdate = new Intl.DateTimeFormat('id-ID', {
      dateStyle: 'full',
      timeStyle: 'short',
      timeZone: 'Asia/Jakarta'
    }).format(stats.mtime);

    // Baca info_config.json
    const configPath = path.join('json', 'info_config.json');
    let config = {
      nextUpdate: '-',
      upcomingFeatures: [],
      fixedFeatures: []
    };

    if (fs.existsSync(configPath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(configPath));
        config = { ...config, ...parsed };
      } catch (e) {
        console.error('❌ Gagal membaca info_config.json:', e);
      }
    }

    const upcoming = (config.upcomingFeatures || [])
      .map(f => `│  • ${f}`).join('\n') || '│  • -';

    const fixed = (config.fixedFeatures || [])
      .map(f => `│  • ${f}`).join('\n') || '│  • -';

    const teks = [
      `╭━━━〔 🤖 *STATUS BOT* 〕━━⬣`,
      `│ 👤 Pengguna: ${ctx.from?.first_name || 'Tidak diketahui'}`,
      `│ ⏱️ Uptime: ${uptime}`,
      `│ 💾 RAM Digunakan: ${ramUsage} MB`,
      `│ 🧩 Plugin Aktif: ${pluginCount}`,
      `│ 📘 Jumlah Command: ${totalCommand}`,
      `│ 🖥️ Sistem: ${os.type()} (${os.platform()})`,
      `│`,
      `│ 🔄 Terakhir Update: ${lastUpdate}`,
      `│ 🗂️ Versi Sekarang: ${pkg.version}`,
      `│ 📅 Update Selanjutnya: ${config.nextUpdate || '-'}`,
      `│`,
      `│ 🆕 *Fitur Akan Datang:*`,
      upcoming,
      `│`,
      `│ ✅ *Fitur Telah Diperbaiki:*`,
      fixed,
      `│`,
      `│ 🔗 *Channel:* [Klik di sini](https://t.me/LinQiyeLiMuwan)`,
      `│ 💬 *Grup Support:* [Gabung Grup](https://t.me/+GbfCloZtxRtkNTQ1)`,
      `╰━━━━━━━━━━━━━━━━━━━━⬣`
    ].join('\n');

    const imagePath = path.join('image', 'info', 'status.jpg');
    if (fs.existsSync(imagePath)) {
      await ctx.replyWithPhoto({ source: imagePath }, {
        caption: teks,
        parse_mode: 'Markdown'
      });
    } else {
      await ctx.reply(teks, { parse_mode: 'Markdown' });
    }
  });
};