// ==========================
// Import dan Konfigurasi
// ==========================
import fs from "fs";
import path from "path";
import process from "process";
import { google } from "googleapis";
import { config } from "../../config.js";

const logChannel = "-1002706696440";
const pluginsPath = path.join(process.cwd(), "./plugins");

const SHEET_USERS = "Users";
const SHEET_GROUPS = "Groups";

const spreadsheetUsersId = "1dyK_66DxSMQv1e-fng_bew8U2_oL898YwY3dHOKZdqg";
const spreadsheetGroupsId = "1RZtzVNbTjxoXSxI5KjSW2ol08aIIAZIyonJY7t0WRPM";

// ==========================
// Handler Start Command
// ==========================
export default {
  command: ["start"],
  tags: ["main"],
  desc: "🟢 Mulai bot dan lihat info utama",

  async handler(ctx) {
    const userId = ctx.from.id;
    const name = ctx.from.first_name || "Pengguna";
    const username = ctx.from.username ? "@" + ctx.from.username : "-";
    const botName = escapeMarkdown(config.BOTNAME || "Donghua Bot");
    const isPremium = checkPremium(userId);
    const uptime = escapeMarkdown(formatUptime(process.uptime()));
    const language = escapeMarkdown(ctx.from.language_code || "Tidak diketahui");

    const already = await checkUserInSheet(spreadsheetUsersId, SHEET_USERS, userId);

    let userCount = "?", groupCount = "?", version = "?", pluginStats = {
      first: "-",
      least: { name: "-", count: 0 },
      most: { name: "-", count: 0 }
    };

    if (!already) {
      userCount = escapeMarkdown(await countRowsInSheet(spreadsheetUsersId, SHEET_USERS));
      groupCount = escapeMarkdown(await countRowsInSheet(spreadsheetGroupsId, SHEET_GROUPS));
      version = escapeMarkdown(getBotVersion());
      pluginStats = getCommandStats();

      const header = escapeMarkdown("🖥️ *LIN QIYE PROJECT SYSTEM BOTING...*\n╭────────────────────────");
      const bootSteps = [0, 15, 30, 35, 50, 60, 70, 85, 100];
      const bootTexts = [
        "📦 Menyiapkan konfigurasi...",
        "🔌 Memuat plugin...",
        "📂 Memeriksa database pengguna...",
        "🌍 Mengambil data lokasi pengguna...",
        "⚙️ Memproses metadata...",
        "🔒 Menyiapkan keamanan...",
        "📡 Sinkronisasi server...",
        "💾 Menyimpan cache sistem...",
        "✅ Sistem Siap Digunakan!"
      ];

      const progressBar = val => {
        const filled = "▓".repeat(Math.floor(val / 10));
        const empty = "░".repeat(10 - Math.floor(val / 10));
        return `▣ ${escapeMarkdown(filled + empty)} ${val}\\%`;
      };

      let sent = await ctx.reply(`${header}\n${progressBar(0)}\n\n${escapeMarkdown(bootTexts[0])}`, {
        parse_mode: "MarkdownV2"
      });

      for (let i = 1; i < bootSteps.length; i++) {
        await new Promise(res => setTimeout(res, 400));
        await ctx.telegram.editMessageText(
          ctx.chat.id,
          sent.message_id,
          null,
          `${header}\n${progressBar(bootSteps[i])}\n\n${escapeMarkdown(bootTexts[i])}`,
          { parse_mode: "MarkdownV2" }
        );
      }

      await new Promise(res => setTimeout(res, 500));
    }

    const statsText = escapeMarkdown(`
✨ *${botName} Siap Membantu!*
────────────────────
👤 Pengguna: ${name}
🆔 ID: ${userId}
🌐 Bahasa: ${language}
💎 Status: ${isPremium ? "✅ Premium" : "❌ Gratisan"}
────────────────────
⚙️ Versi Bot: ${version}
⏱️ Uptime: ${uptime}
👥 Total Pengguna: ${userCount}
🏘️ Total Grup: ${groupCount}
────────────────────
🔌 Plugin Awal: ${pluginStats.first}
📉 Fitur Tersedikit: ${pluginStats.least.name} (${pluginStats.least.count})
📈 Fitur Terbanyak: ${pluginStats.most.name} (${pluginStats.most.count})
────────────────────
📜 Ketik /menu untuk mulai!
💸 /donasi – Dukung bot ini
❓ /help – Bantuan lengkap
`);

    await ctx.reply(statsText, { parse_mode: "MarkdownV2" });

    if (!already) {
      try {
        const photos = await ctx.telegram.getUserProfilePhotos(userId);
        const photo = photos.total_count > 0 ? photos.photos[0][0].file_id : null;

        const notifText = escapeMarkdown(`
🎉 Pengguna Baru Mendaftar!

👤 Nama: ${name}
🔤 Username: ${username}
🆔 ID: ${userId}
🌐 Bahasa: ${language}
💎 Status: ${isPremium ? "Premium" : "Gratisan"}
`);

        if (photo) {
          await ctx.telegram.sendPhoto(logChannel, photo, {
            caption: notifText,
            parse_mode: "MarkdownV2"
          });
        } else {
          await ctx.telegram.sendMessage(logChannel, notifText, {
            parse_mode: "MarkdownV2"
          });
        }

        await appendUserToSheet(spreadsheetUsersId, SHEET_USERS, [
          userId,
          name,
          username,
          ctx.from.language_code || "-",
          isPremium ? "Premium" : "Gratisan"
        ]);
      } catch (err) {
        console.error("[LOG CHANNEL ERROR]", err.message);
      }
    }
  }
};

// ==========================
// Fungsi Bantu
// ==========================
function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}j ${m}m ${s}d`;
}

function getBotVersion() {
  try {
    const pkg = JSON.parse(fs.readFileSync("./package.json"));
    return pkg.version || "1.0.0";
  } catch {
    return "1.0.0";
  }
}

function checkPremium(userId) {
  try {
    const data = JSON.parse(fs.readFileSync("./lib/premium.json"));
    if (Array.isArray(data)) return data.includes(userId);
    const info = data[userId];
    return info?.expireAt ? Date.now() < info.expireAt : true;
  } catch {
    return false;
  }
}

function getCommandStats() {
  const stats = [];
  const files = fs.readdirSync(pluginsPath).filter(f => f.endsWith(".js"));
  for (const file of files) {
    try {
      const plugin = require(path.join(pluginsPath, file));
      const count = Array.isArray(plugin.command) ? plugin.command.length : 0;
      stats.push({ name: file.replace(/.js$/, ""), count });
    } catch {
      continue;
    }
  }

  stats.sort((a, b) => a.count - b.count);
  return {
    first: stats[0]?.name || "-",
    least: stats[0] || { name: "-", count: 0 },
    most: stats[stats.length - 1] || { name: "-", count: 0 }
  };
}

function escapeMarkdown(text) {
  return String(text).replace(/([_*\[\]()~`>#+=|{}.!\\-])/g, "\\$1");
}

// ==========================
// Google Sheet Integration
// ==========================
async function getAuth() {
  const auth = new google.auth.GoogleAuth({
    keyFile: "credentials.json",
    scopes: ["https://www.googleapis.com/auth/spreadsheets"]
  });
  return await auth.getClient();
}

async function appendUserToSheet(spreadsheetId, sheetName, values) {
  const auth = await getAuth();
  const sheets = google.sheets({ version: "v4", auth });
  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: `${sheetName}!A:E`,
    valueInputOption: "USER_ENTERED",
    requestBody: { values: [values] }
  });
}

async function checkUserInSheet(spreadsheetId, sheetName, id) {
  try {
    const auth = await getAuth();
    const sheets = google.sheets({ version: "v4", auth });
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A:A`
    });
    const rows = res.data.values || [];
    return rows.flat().includes(String(id));
  } catch (e) {
    console.error("Google Sheet check error:", e.message);
    return false;
  }
}

async function countRowsInSheet(spreadsheetId, sheetName) {
  try {
    const auth = await getAuth();
    const sheets = google.sheets({ version: "v4", auth });
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A:A`
    });
    return (res.data.values || []).length.toString();
  } catch (e) {
    console.error("Google Sheet count error:", e.message);
    return "0";
  }
}