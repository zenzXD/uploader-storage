import axios from 'axios'

export default {
  command: ['infoapi', 'apistatus'],
  tags: [ 'info'],
  help: ['infoapi'],
  desc: '🌐 Menampilkan status API ZenZXZ secara lengkap dan informatif',

  async handler(ctx) {
    await ctx.reply('🔍 Sedang mengambil data status API...')

    try {
      const res = await axios.get('https://zenzxz.dpdns.org/api/status')
      const data = res.data

      if (!data.status) return ctx.reply('🚫 Gagal mendapatkan data dari server API.')

      const {
        uptime,
        cpu,
        memory,
        os,
        hostname,
        platform,
        totalEndpoints,
        totalVisitors,
        apiVersion,
        lastRestart,
        usageToday
      } = data.result

      const teks = `
╭━━━〔 🛰️ *STATUS API ZENZXZ* 〕━━━⬣
┃ 🖥️ *Hostname:* \`${hostname}\`
┃ 💽 *Platform:* \`${platform}\`
┃ 🧠 *OS:* \`${os}\`
┃ 
┃ ⏳ *Uptime:* \`${uptime}\`
┃ ⚙️ *CPU Usage:* \`${cpu}\`
┃ 📈 *Memory:* \`${memory}\`
┃ 🔁 *Last Restart:* \`${lastRestart}\`
┃ 
┃ 📡 *Endpoint Aktif:* \`${totalEndpoints}\`
┃ 👤 *Visitor Hari Ini:* \`${totalVisitors}\`
┃ 📊 *Request Hari Ini:* \`${usageToday}\`
┃ 🧩 *Versi API:* \`${apiVersion}\`
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

      return ctx.reply(teks, {
        parse_mode: 'Markdown',
      })

    } catch (err) {
      console.error(err)
      return ctx.reply('❌ Terjadi kesalahan saat mengambil status API.\nSilakan coba lagi nanti.')
    }
  }
}