import fs from 'fs'
import crypto from 'crypto'
import { config } from '../../config.js'

const usersPath = './json/users.json'
const notifChannel = config.NOTIF_CHANNEL || '-1001234567890'
const minAge = 13

export default {
  command: ['daftar'],
  tags: ['info'],
  desc: '📝 Daftar untuk mulai menggunakan bot',

  async handler(ctx) {
    const text = ctx.message.text?.trim().split(' ').slice(1).join(' ')
    if (!text || !text.includes('.')) {
      return await ctx.reply(`❌ *Format salah!*\n\nGunakan:\n*/daftar Nama.Umur*\nContoh:\n*/daftar Andi.17*`, { parse_mode: 'Markdown' })
    }

    const [nama, umurStr] = text.split('.')
    const umur = parseInt(umurStr)
    const userId = ctx.from.id

    if (!nama || isNaN(umur)) {
      return await ctx.reply(`❌ *Format tidak valid!*\n\nGunakan format:\n*/daftar Nama.Umur*`, { parse_mode: 'Markdown' })
    }

    if (umur < minAge) {
      return await ctx.reply(`🚫 *Umur minimal untuk mendaftar adalah ${minAge} tahun!*`, { parse_mode: 'Markdown' })
    }

    const users = loadUsers()
    if (users[userId]) {
      return await ctx.reply(`✅ *Kamu sudah terdaftar sebelumnya!*\n\n👤 Nama: *${users[userId].nama}*\n🎂 Umur: *${users[userId].umur} tahun*`, { parse_mode: 'Markdown' })
    }

    const serial = crypto.randomBytes(6).toString('hex').toUpperCase()

    users[userId] = {
      nama,
      umur,
      waktu: Date.now(),
      serial
    }

    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2))

    await ctx.reply(`🎉 *Pendaftaran Berhasil!*\n\n👤 Nama: *${nama}*\n🎂 Umur: *${umur} tahun*\n🆔 ID: \`${userId}\`\n🔐 Serial: \`${serial}\`\n\nKetik */start* untuk mulai menggunakan bot.`, {
      parse_mode: 'Markdown'
    })

    // Notifikasi ke channel
    await ctx.telegram.sendMessage(notifChannel, `
╭───❖ 「 *PENDAFTARAN BARU* 」 ❖───╮
│
│ 👤 *Nama:* ${nama}
│ 🎂 *Umur:* ${umur} tahun
│ 🆔 *ID:* \`${userId}\`
│ 🔐 *Serial:* \`${serial}\`
│ ⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}
│
╰──────────────────────────╯`, {
      parse_mode: 'Markdown'
    })
  }
}

function loadUsers() {
  if (!fs.existsSync(usersPath)) fs.writeFileSync(usersPath, JSON.stringify({}))
  return JSON.parse(fs.readFileSync(usersPath))
}