import fetch from 'node-fetch'

export default {
  command: ['jadwalfilm', 'film'],
  tags: ['info'],
  desc: '🍿 Jadwal film bioskop terbaru lengkap dengan gambar dan trailer',

  async handler(ctx) {
    try {
      const res = await fetch('https://zenzxz.dpdns.org/info/jadwalfilm')
      const json = await res.json()

      if (!json.status || !Array.isArray(json.data)) {
        throw '🚫 Gagal mengambil data film dari server.'
      }

      const listFilm = json.data.slice(0, 5) // Maksimal 5 film ditampilkan

      for (const film of listFilm) {
        const teks = `
╭━━🎬 *FILM BIOSKOP TERBARU* ━━╮
┃
┃ 🎞️ *Judul:* _${film.title}_
┃ 🕒 *Durasi:* _${film.duration}_
┃ 🎭 *Genre:* _${film.genre}_
┃ 📅 *Tayang:* _${film.date_show}_
┃
┃ 📖 *Sinopsis:*
┃ _${film.synopsis.slice(0, 300)}_${film.synopsis.length > 300 ? '... (lanjut di trailer)' : ''}
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯
        `.trim()

        await ctx.replyWithPhoto({ url: film.image }, {
          caption: teks,
          parse_mode: 'Markdown'
        })

        await ctx.replyWithVideo({ url: film.trailer }, {
          caption: `▶️ *Trailer:* _${film.title}_`,
          parse_mode: 'Markdown'
        })
      }

      return ctx.reply(`✨ Menampilkan *${listFilm.length}* dari total *${json.total}* film.\n📡 Sumber: _@ZenzzXD_`, {
        parse_mode: 'Markdown'
      })

    } catch (err) {
      console.error('[Jadwal Film Error]', err)
      return ctx.reply('🚫 Terjadi kesalahan saat memuat data. Silakan coba lagi nanti.')
    }
  }
}