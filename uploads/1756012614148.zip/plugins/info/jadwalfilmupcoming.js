import fetch from 'node-fetch'

export default {
  command: ['filmupcoming', 'jadwalfilmupcoming'],
  tags: ['info'],
  desc: '🎬 Menampilkan daftar film yang akan tayang',

  async handler(ctx) {
    try {
      const res = await fetch('https://zenzxz.dpdns.org/info/jadwalfilmupcoming')
      const json = await res.json()

      if (!json.status || !Array.isArray(json.data) || json.data.length === 0) {
        return ctx.reply('❌ Tidak ada data film upcoming tersedia untuk saat ini.')
      }

      const data = json.data.slice(0, 5) // tampilkan 5 film saja

      for (const film of data) {
        const caption = `🎬 *${film.title}*\n` +
                        `📅 Tayang: *${film.date_show}*\n` +
                        `🕒 Durasi: *${film.duration}*\n` +
                        `🎭 Genre: *${film.genre}*\n\n` +
                        `📝 *Sinopsis:*\n_${film.synopsis}_\n\n` +
                        `📽️ *Trailer:* ${film.trailer}`

        // Kirim gambar + caption
        await ctx.telegram.sendPhoto(ctx.chat.id, film.image, {
          caption,
          parse_mode: 'Markdown'
        })

        // Kirim trailer (jika format MP4 valid)
        if (film.trailer.endsWith('.mp4')) {
          await ctx.telegram.sendVideo(ctx.chat.id, film.trailer, {
            caption: `🎬 *Trailer ${film.title}*`,
            parse_mode: 'Markdown'
          })
        }
      }

    } catch (err) {
      console.error('[ERROR JADWALFILM]', err)
      return ctx.reply('🚫 Gagal mengambil data film upcoming.')
    }
  }
}