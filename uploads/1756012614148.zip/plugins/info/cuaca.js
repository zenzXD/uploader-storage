import fetch from 'node-fetch'
import { bold } from 'telegraf/format'

const cuaca = {
  get url() {
    return {
      api_search_geo: `https://cuaca.bmkg.go.id/api/df/v1/adm/search`,
      api_search_geo_2: `https://www.gps-coordinates.net/geoproxy`,
      api_cuaca: `https://weather.bmkg.go.id/api/presentwx/coord`,
      api_cuaca_warning: `https://cuaca.bmkg.go.id/api/v1/public/weather/warning`,
    }
  },

  get string() {
    return {
      gps: '9416bf2c8b1d4751be6a9a9e94ea85ca',
      bmkg: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjFjNWFkZWUxYzY5MzM0NjY2N2EzZWM0MWRlMjBmZWZhNDcxOTNjYzcyZDgwMGRiN2ZmZmFlMWVhYjcxZGYyYjQiLCJpYXQiOjE3MDE1ODMzNzl9.D1VNpMoTUVFOUuQW0y2vSjttZwj0sKBX33KyrkaRMcQ'
    }
  },

  get baseHeaders() {
    return {
      'accept-encoding': 'gzip, deflate, br, zstd',
    }
  },

  validateCoordinate: function (what, input, startLimit, endLimit) {
    let lat = parseFloat(input)
    if (isNaN(lat) || !(lat >= startLimit && lat <= endLimit)) throw Error(`${what}`)
  },

  validasiString: function (deskripsi, variabel) {
    if (typeof variabel !== "string" || !variabel.trim().length) throw Error(`Parameter ${deskripsi} harus berupa teks yang tidak kosong.`)
  },

  mintaJson: async function (desc, url, fetchOptions) {
    try {
      const res = await fetch(url, fetchOptions)
      if (!res.ok) throw new Error(`${res.status} ${res.statusText}\n${await res.text()}`)
      return await res.json()
    } catch (e) {
      throw Error(`Gagal mengambil data: ${desc}\nError: ${e.message}`)
    }
  },

  cariKoordinat: async function (lokasi) {
    this.validasiString('lokasi', lokasi)
    const searchUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(lokasi)}`
    const res = await fetch(searchUrl)
    const data = await res.json()
    if (!data.length) throw Error('❌ Lokasi tidak ditemukan.')
    const { lat, lon, display_name } = data[0]
    return {
      latitude: parseFloat(lat),
      longitude: parseFloat(lon),
      placeName: display_name.split(',')[0]
    }
  },

  getkWeatherByCoordinateBMKG: async function (latitude, longitude, placeName = "") {
    this.validateCoordinate(`latitude`, latitude, -12, 7)
    this.validateCoordinate(`longitude`, longitude, 93, 142)

    const namaTempat = placeName ? `📍 *Lokasi:* ${placeName}\n` : ''
    const cuacaApi = new URL(this.url.api_cuaca)
    cuacaApi.search = new URLSearchParams({ lon: longitude, lat: latitude })

    const cuacaWarningApi = new URL(this.url.api_cuaca_warning)
    cuacaWarningApi.search = new URLSearchParams({ lat: latitude, long: longitude })

    const headersWarning = { 'X-api-key': this.string.bmkg, ...this.baseHeaders }

    const [cuacaJson, cuacaWarningJson] = await Promise.all([
      this.mintaJson('cuaca', cuacaApi, { headers: this.baseHeaders }),
      this.mintaJson('peringatan cuaca', cuacaWarningApi, { headers: headersWarning })
    ])

    const { provinsi, kotkab, kecamatan, desa, adm4 } = cuacaJson.data.lokasi
    const lokasi = `${desa}, ${kecamatan}, ${kotkab}, ${provinsi}`

    const {
      weather_desc, weather_desc_en, t, tcc, wd_deg, wd, wd_to, ws, hu, vs, vs_text, local_datetime
    } = cuacaJson.data.cuaca

    const arahAngin = { N: 'Utara', NE: "Timur Laut", E: 'Timur', SE: 'Tenggara', S: 'Selatan', SW: 'Barat Daya', W: 'Barat', NW: 'Barat Laut' }
    const angin = `💨 *Angin:* Dari ${arahAngin[wd]} ke ${arahAngin[wd_to]} ${ws} km/jam (${wd_deg}°)`
    const cuaca = 
`${namaTempat}🕓 *Waktu:* ${local_datetime.split(" ")[1]}
🌦️ *Cuaca:* ${weather_desc} / ${weather_desc_en}
🌡️ *Suhu:* ${t}°C
💧 *Kelembaban:* ${hu}%
☁️ *Awan:* ${tcc}%
👁️ *Jarak Pandang:* ${vs_text} (${vs} m)
${angin}`

    let dampak = cuacaWarningJson.data?.today?.kategoridampak
    dampak = dampak ? JSON.parse(dampak.replaceAll("'", '"')).join(", ") : 'Tidak ada'
    const peringatan = cuacaWarningJson.data?.today?.description?.description?.trim() || 'Tidak ada'
    const cuacaWarning = `⚠️ *Dampak:* ${dampak}\n🚨 *Peringatan:* ${peringatan}`

    const bmkgUrl = `🌐 *BMKG:* https://www.bmkg.go.id/cuaca/prakiraan-cuaca/${adm4}`
    const gmapUrl = `🗺️ *Peta:* https://www.google.com/maps?q=${latitude},${longitude}`

    return `${cuaca}\n\n${cuacaWarning}\n\n${bmkgUrl}\n${gmapUrl}`
  },

  run: async function (lokasi) {
    const { latitude, longitude, placeName } = await this.cariKoordinat(lokasi)
    return await this.getkWeatherByCoordinateBMKG(latitude, longitude, placeName)
  }
}

export default {
  command: ['cuaca', 'weather'],
  tags: ['info'],
  desc: '🔍 Cek prakiraan cuaca dari BMKG berdasarkan lokasi',

  async handler(ctx) {
    const args = ctx.message.text.split(' ').slice(1)
    const lokasi = args.join(' ')
    if (!lokasi) {
      return ctx.reply('❗ Masukkan nama lokasi!\n\nContoh:\n`/cuaca Jakarta`', { parse_mode: 'Markdown' })
    }

    try {
      await ctx.reply('🌦️ Sedang mengambil data cuaca...')
      const hasil = await cuaca.run(lokasi)
      await ctx.reply(hasil, { parse_mode: 'Markdown' })
    } catch (e) {
      console.error(e)
      await ctx.reply(`❌ Gagal mendapatkan data.\n${e.message}`)
    }
  }
}
