import { config } from '../../config.js'

export default {
  command: ['tos', 'termsofservice'],
  tags: ['info'],
  desc: '📜 Terms of Service bot',

  async handler(ctx) {
    const tosText = `
╭─❏ *「 TERMS OF SERVICE 」* ❏─╮

🔰 *PENGGUNAAN UMUM*
╰───────────────⧸⧹──────────────╯
🤖 Bot disediakan apa adanya tanpa garansi.  
✅ Gunakan dengan bijak dan tanggung jawab.  
🚫 Dilarang gunakan untuk spam & abuse.  
📦 Fitur bisa berubah sewaktu-waktu.  
⚠️ Risiko ditanggung pengguna.  
📊 Aktivitas terekam untuk keamanan.  
🔄 Update dilakukan secara berkala.  
📴 Akses bisa dicabut kapan saja.  
🧾 Gunakan username/nama asli.  
📉 Developer tidak bertanggung jawab atas kerugian.

🔐 *DATA & PRIVASI*
╰───────────────⧸⧹──────────────╯
🗂️ Data tersimpan lokal (ID, username, dsb).  
🚫 Tidak menyimpan isi pesan pribadi.  
🔐 Data digunakan untuk keperluan fitur bot.  
❌ Tidak menjual/menyebar data.  
🕵️‍♂️ Privasi pengguna dijaga ketat.  
🔒 Chat dibaca hanya jika diminta user.  
🧬 Permintaan dienkripsi otomatis.  
🧹 Data bisa dihapus kapan saja oleh dev.  
💾 Backup dilakukan otomatis.  
🧾 Bisa minta hapus data lewat owner.

🚫 *LARANGAN KERAS*
╰───────────────⧸⧹──────────────╯
❌ Menyebar SARA, hoaks, atau provokasi.  
🚷 Gunakan bot untuk judi atau penipuan.  
🐞 Sebar script berbahaya atau virus.  
💣 Manipulasi sistem tanpa izin.  
👿 Bajak fitur premium.  
🔓 Coba bongkar sistem internal bot.  
🪧 Promosi ilegal atau phishing.  
⚔️ Gunakan bot untuk kepentingan politik.  
📤 Spam forward/link massal.  
🧟 Pelanggaran = banned permanen.

👨‍💻 *HAK & KETENTUAN DEVELOPER*
╰───────────────⧸⧹──────────────╯
👑 Developer bisa nonaktifkan user kapan pun.  
🧾 Pelanggaran berat bisa ke ranah hukum.  
♻️ Fitur dapat diubah tanpa pemberitahuan.  
🌟 Premium diberikan manual oleh owner.  
💸 Tidak ada refund donasi.  
⌛ Sewa berlaku sesuai kesepakatan.  
🛠️ Developer tak wajib terima permintaan khusus.  
🧰 Source code tidak diberikan publik.  
📡 Dukungan hanya di channel resmi.  
🌍 Akses bisa dibatasi per wilayah.

📌 *LAINNYA*
╰───────────────⧸⧹──────────────╯
❓ Tanyakan ke owner jika ragu.  
🙏 Sopan = Prioritas.  
💬 Kritik & saran diterima baik.  
🏢 Disarankan premium di grup besar.  
📛 Jangan ganggu sistem bot.  
🐞 Laporkan bug dengan jelas.  
🗨️ Hindari command ganda.  
🚫 Hindari grup spam.  
⚙️ Dev tidak bantu masalah di luar bot.  
🤝 Hormati sesama user.

📜 *PENUTUP*
╰───────────────⧸⧹──────────────╯
📑 ToS bisa berubah kapan saja.  
🔔 Gunakan versi terbaru.  
🔍 Pelanggar akan ditindak.  
🧪 Bot bukan untuk proyek custom publik.  
🕹️ Tujuan bot: edukasi & hiburan.  
📚 Gunakan fitur sesuai kategori.  
🌀 Jangan spam command.  
🕒 Laporan diproses 1x24 jam.  
🧾 Owner tak bertanggung jawab atas konten pihak ketiga.  
🔥 Dengan memakai bot, Anda *setuju* semua aturan di atas. Jika melanggar, Anda akan *diban secara permanen tanpa peringatan.*

╰───〔 👤 Owner: @${config.OWNER_USERNAME} 〕───╯
`.trim()

    await ctx.reply(tosText, {
      parse_mode: 'Markdown'
    })
  }
}