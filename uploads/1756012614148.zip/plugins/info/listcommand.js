export default {
  command: ['listcommand'],
  tags: ['info'],
  desc: 'Daftar semua command aktif per kategori. Contoh: /listcommand owner',
  async handler(ctx) {
    const bot = ctx.telegram.botInstance;
    const pluginList = bot?.context?.pluginList || [];
    const meta = bot?.context?.pluginMeta || {};

    const kategori = {};

    for (const file of pluginList) {
      const folder = file.split('/')[0] || 'other';
      const commands = meta[file]?.command || [file.replace('.js', '')];
      if (!kategori[folder]) kategori[folder] = [];
      kategori[folder].push(...commands);
    }

    // Ambil argumen kategori (misalnya 'owner', 'fun', dst)
    const args = ctx.message.text?.split(' ').slice(1);
    const targetKategori = args?.[0]?.toLowerCase();

    let teks = '';
    if (targetKategori && kategori[targetKategori]) {
      // Hanya tampilkan satu kategori
      const cmds = [...new Set(kategori[targetKategori])].sort();
      teks += `╭─〔 📁 *Kategori: ${targetKategori.toUpperCase()}* 〕\n`;
      for (const cmd of cmds) {
        teks += `│   ├─ ⦿ \`/${cmd}\`\n`;
      }
      teks += `│\n╰─ 📦 *Total:* ${cmds.length} command\n`;
    } else if (targetKategori && !kategori[targetKategori]) {
      teks = `🚫 Kategori *${targetKategori}* tidak ditemukan.\nGunakan */listcommand* untuk lihat semua.`;
    } else {
      // Tampilkan semua kategori
      teks += '╭─〔 📜 *List Semua Command* 〕\n';
      const sortedKategori = Object.keys(kategori).sort();
      for (const folder of sortedKategori) {
        const cmds = [...new Set(kategori[folder])].sort();
        teks += `│\n├─ 📂 *${folder.toUpperCase()}*\n`;
        for (const cmd of cmds) {
          teks += `│   ├─ ⦿ \`/${cmd}\`\n`;
        }
      }
      teks += `│\n╰─ 📦 *Total Plugin:* ${pluginList.length}\n`;
    }

    await ctx.reply(teks, { parse_mode: 'Markdown' });
  }
};