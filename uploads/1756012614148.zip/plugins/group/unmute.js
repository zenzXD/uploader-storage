import moment from 'moment';

export default {
  command: ['unmute'],
  tags: ['group'],
  desc: '🔈 Unmute user (aktifkan bicara kembali)',

  async handler(ctx) {
    const chat = ctx.chat;
    const from = ctx.from;
    const msg = ctx.message;

    if (!chat || chat.type === 'private') return ctx.reply('❌ Gunakan perintah ini di grup!');
    if (!msg.reply_to_message) return ctx.reply('📍 *Reply* ke user yang ingin di-unmute!', { parse_mode: 'Markdown' });

    const target = msg.reply_to_message.from;
    const userId = target.id;
    const botId = ctx.botInfo.id;

    // Proteksi owner & bot
    if (userId === botId || (ctx.config?.owner && ctx.config.owner.includes(userId))) {
      return ctx.reply('🛡️ Tidak bisa unmute bot atau owner!');
    }

    const groupName = chat.title || 'Grup';
    const groupLink = chat.username ? `https://t.me/${chat.username}` : '🔒 Privat';
    const userLink = `[${target.first_name}](tg://user?id=${userId})`;
    const fromLink = `[${from.first_name}](tg://user?id=${from.id})`;
    const now = moment().format('dddd, DD MMMM YYYY HH:mm:ss');
    const garis = '━━━━━━━━━━━━━━━━━━━━━━';

    try {
      await ctx.restrictChatMember(userId, {
        permissions: {
          can_send_messages: true,
          can_send_media_messages: true,
          can_send_other_messages: true,
          can_add_web_page_previews: true,
        }
      });

      await ctx.reply(
        `🔈 *UNMUTE USER*\n${garis}\n\n` +
        `👤 *Target:* ${userLink}\n` +
        `📣 *Diaktifkan oleh:* ${fromLink}\n` +
        `🏷️ *Grup:* ${groupName}\n🔗 *Link:* ${groupLink}\n🕒 *Waktu:* ${now}\n\n` +
        `${garis}\n🧩 *Command:* /unmute\n🆔 UserID: ${userId}\n💬 ChatID: ${chat.id}`,
        { parse_mode: 'Markdown' }
      );
    } catch (e) {
      ctx.reply(`❌ Gagal unmute: ${e.message}`);
    }
  }
};