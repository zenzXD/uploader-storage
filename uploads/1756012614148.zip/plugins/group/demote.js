import moment from 'moment-timezone'

export default {
  command: ['demote', 'unadmin'],
  tags: ['group'],
  desc: '⬇️ Turunkan pengguna dari admin grup',
  group: true,
  admin: true,
  botAdmin: true,

  handler: async (ctx) => {
    const sender = ctx.from
    const groupName = ctx.chat.title
    const alasan = ctx.args.slice(1).join(' ') || '— Tanpa alasan —'
    let target

    // Deteksi target: reply / ID / username
    const quoted = ctx.message.reply_to_message
    if (quoted) {
      target = quoted.from
    } else if (ctx.args[0]) {
      const arg = ctx.args[0].replace('@', '')
      try {
        const member = await ctx.telegram.getChatMember(ctx.chat.id, arg)
        target = member.user
      } catch {
        return ctx.reply('❌ *Tidak dapat menemukan pengguna tersebut.*')
      }
    } else {
      return ctx.reply('📌 *Balas pesan atau berikan username/ID yang ingin diturunkan dari admin.*')
    }

    if (target.is_bot) {
      return ctx.reply('🤖 Tidak bisa menurunkan bot.')
    }

    try {
      await ctx.telegram.promoteChatMember(ctx.chat.id, target.id, {
        can_change_info: false,
        can_post_messages: false,
        can_edit_messages: false,
        can_delete_messages: false,
        can_invite_users: false,
        can_restrict_members: false,
        can_pin_messages: false,
        can_promote_members: false,
        is_anonymous: false
      })

      const waktu = moment().tz('Asia/Jakarta').format('dddd, DD MMMM YYYY • HH:mm:ss')
      const namaTarget = `[${target.first_name}](tg://user?id=${target.id})`
      const namaAdmin = `[${sender.first_name}](tg://user?id=${sender.id})`

      return ctx.replyWithMarkdownV2(`
╭━━━〔 *⚠️ DEMOSI ADMIN* 〕━━━⬣
┃
┣ 👤 *User:* ${namaTarget}
┣ 👮‍♂️ *Diturunkan oleh:* ${namaAdmin}
┣ ⏰ *Waktu:* ${waktu}
┣ 📝 *Alasan:* _${alasan}_
┃
╰───〔 *📍 Grup:* ${groupName} 〕───⬣
`.trim())
    } catch (err) {
      console.error(err)
      return ctx.reply('❌ *Gagal menurunkan admin.* Pastikan bot memiliki izin.')
    }
  }
}