import moment from 'moment-timezone'

export default {
  command: ['promote', 'angkatadmin'],
  tags: ['admin'],
  group: true,
  admin: true,
  botAdmin: true,
  desc: '⬆️ Mengangkat user menjadi admin grup',

  async handler(ctx) {
    const m = ctx.message
    const target = m.reply_to_message?.from
    const user = m.from

    if (!target) return ctx.reply('❗ Balas pesan user yang ingin diangkat jadi admin.')

    const alasan = ctx.message.text.split(' ').slice(1).join(' ') || 'Tidak ada alasan diberikan.'
    const waktu = moment().tz('Asia/Jakarta').format('HH:mm:ss - DD MMMM YYYY')

    try {
      // Angkat jadi admin
      await ctx.telegram.promoteChatMember(ctx.chat.id, target.id, {
        can_change_info: true,
        can_delete_messages: true,
        can_invite_users: true,
        can_restrict_members: true,
        can_pin_messages: true,
        can_promote_members: false,
        can_manage_chat: true,
        can_manage_video_chats: true,
      })

      // Ambil daftar admin untuk hitungan posisi
      const admins = await ctx.telegram.getChatAdministrators(ctx.chat.id)
      const urutanAdmin = admins.findIndex(a => a.user.id === target.id) + 1 || 'Tidak diketahui'

      // Kirim hasil
      await ctx.replyWithMarkdownV2(`
╭───❖ *「 👑 PROMOTE BERHASIL 」*
│ 🏷️ *Grup:* ${ctx.chat.title}
│ 👤 *User:* [${target.first_name}](tg://user?id=${target.id})
│ 👑 *Dinaikkan oleh:* [${user.first_name}](tg://user?id=${user.id})
│ 📌 *Posisi Admin:* Admin ke\-*${urutanAdmin}*
│ 💬 *Alasan:* ${alasan}
│ ⏰ *Waktu:* ${waktu}
╰───────────────
      `.trim(), { disable_web_page_preview: true })
    } catch (e) {
      console.error(e)
      return ctx.reply('❌ Gagal mempromosikan user. Pastikan bot punya izin cukup.')
    }
  }
}