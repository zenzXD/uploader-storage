import fs from 'fs'
const warnDBPath = './json/group_warn.json'

if (!fs.existsSync(warnDBPath)) fs.writeFileSync(warnDBPath, '{}')

export default {
  command: ['hidetag', 'add', 'kick', 'ban', 'promote', 'demote', 'mute', 'unmute', 'warn', 'resetwarn','linkgc','linkgroup'],
  tags: ['group'],
  desc: 'Fitur-fitur lengkap untuk manajemen grup.',

  async handler(ctx) {
    const command = ctx.command?.[0]
    const reply = ctx.message?.reply_to_message
    const targetUser = reply?.from
    const sender = ctx.from
    const groupName = ctx.chat?.title || 'Private/Unknown'
    const linkGroup = ctx.chat?.username ? `https://t.me/${ctx.chat.username}` : 'Tidak tersedia'
    const admins = await ctx.getChatAdministrators()
    const me = await ctx.telegram.getMe()
    const isAdmin = admins.some(a => a.user.id === sender.id)
    const botAdmin = admins.some(a => a.user.id === me.id)
    const warnData = JSON.parse(fs.readFileSync(warnDBPath))

    if (ctx.chat?.type === 'private') return ctx.reply('❌ Khusus grup.')

    if (!isAdmin) return ctx.reply('🚫 Cuma admin yang boleh make ini.')

    switch (command) {
      case 'hidetag':
        const teks = ctx.args?.join(' ') || reply?.text || '📢 Hidden Tag!'
        const mention = admins.map(a => `[${a.user.first_name}](tg://user?id=${a.user.id})`).join(' ')
        await ctx.replyWithMarkdown(`📢 ${teks}\n\n${mention}`, { disable_notification: true })
        break

      case 'add':
        const nomor = ctx.args?.[0]
        if (!nomor) return ctx.reply('❗ Format: /add +628xxxx')
        try {
          await ctx.telegram.sendMessage(nomor, `📩 Diundang ke grup *${groupName}*`, {
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [[{ text: 'Gabung', url: linkGroup }]]
            }
          })
          ctx.reply('✅ Undangan dikirim.')
        } catch {
          ctx.reply('❌ Gagal kirim undangan. Pastikan user pernah chat bot.')
        }
        break

      case 'kick':
        if (!botAdmin) return ctx.reply('❌ Bot bukan admin!')
        if (!targetUser) return ctx.reply('Balas pesan user yang mau ditendang.')
        await ctx.kickChatMember(targetUser.id)
        ctx.reply(`👢 @${targetUser.username || targetUser.first_name} dikeluarkan.`)
        break

      case 'ban':
        if (!botAdmin) return ctx.reply('❌ Bot bukan admin!')
        if (!targetUser) return ctx.reply('Balas pesan user yang mau diban.')
        await ctx.banChatMember(targetUser.id)
        ctx.reply(`⛔️ ${targetUser.first_name} dibanned.`)
        break

      case 'promote':
        if (!botAdmin) return ctx.reply('❌ Bot bukan admin!')
        if (!targetUser) return ctx.reply('Balas pesan user yang mau dipromote.')
        await ctx.promoteChatMember(targetUser.id, {
          can_change_info: true,
          can_delete_messages: true,
          can_invite_users: true,
          can_restrict_members: true,
          can_pin_messages: true,
          can_promote_members: false
        })
        ctx.reply(`⬆️ ${targetUser.first_name} sekarang admin.`)
        break

      case 'demote':
        if (!botAdmin) return ctx.reply('❌ Bot bukan admin!')
        if (!targetUser) return ctx.reply('Balas pesan user yang mau didemote.')
        await ctx.promoteChatMember(targetUser.id, {
          can_change_info: false,
          can_delete_messages: false,
          can_invite_users: false,
          can_restrict_members: false,
          can_pin_messages: false,
          can_promote_members: false
        })
        ctx.reply(`⬇️ ${targetUser.first_name} bukan admin lagi.`)
        break

      case 'mute':
        if (!botAdmin) return ctx.reply('❌ Bot bukan admin!')
        if (!targetUser) return ctx.reply('Balas pesan user yang mau dimute.')
        const until = Math.floor(Date.now() / 1000) + 3600
        await ctx.restrictChatMember(targetUser.id, {
          permissions: { can_send_messages: false },
          until_date: until
        })
        ctx.reply(`🔇 ${targetUser.first_name} dimute 1 jam.`)
        break

      case 'unmute':
        if (!botAdmin) return ctx.reply('❌ Bot bukan admin!')
        if (!targetUser) return ctx.reply('Balas pesan user yang mau diunmute.')
        await ctx.restrictChatMember(targetUser.id, {
          permissions: {
            can_send_messages: true,
            can_send_media_messages: true,
            can_send_polls: true,
            can_send_other_messages: true,
            can_add_web_page_previews: true,
            can_change_info: false,
            can_invite_users: true,
            can_pin_messages: false
          },
          until_date: 0
        })
        ctx.reply(`🔊 ${targetUser.first_name} sudah bisa bicara.`)
        break

      case 'warn':
        if (!targetUser) return ctx.reply('Balas pesan user yang mau diperingatkan.')
        const chatId = ctx.chat.id.toString()
        const userId = targetUser.id.toString()
        warnData[chatId] = warnData[chatId] || {}
        warnData[chatId][userId] = (warnData[chatId][userId] || 0) + 1
        fs.writeFileSync(warnDBPath, JSON.stringify(warnData, null, 2))

        if (warnData[chatId][userId] >= 3) {
          await ctx.kickChatMember(targetUser.id)
          delete warnData[chatId][userId]
          ctx.reply(`🚫 ${targetUser.first_name} sudah 3x diperingatkan dan ditendang.`)
        } else {
          ctx.reply(`⚠️ ${targetUser.first_name} diberi peringatan (${warnData[chatId][userId]}/3)`)
        }
        break

      case 'resetwarn':
        if (!targetUser) return ctx.reply('Balas pesan user yang mau direset peringatannya.')
        if (warnData[ctx.chat.id]?.[targetUser.id]) {
          delete warnData[ctx.chat.id][targetUser.id]
          fs.writeFileSync(warnDBPath, JSON.stringify(warnData, null, 2))
          ctx.reply(`✅ Peringatan untuk ${targetUser.first_name} sudah direset.`)
        } else {
          ctx.reply('🚫 User ini belum pernah diperingatkan.')
        }
        break
    }

    // Log
    console.log(`
┏━━━━━━━━━ 📢 GROUP ACTION ━━━━━━━━━
┃ 🧑 From  : @${sender.username || sender.first_name}
┃ 👥 Group : ${groupName}
┃ 🌐 Link  : ${linkGroup}
┃ 💬 CMD   : /${command}
┃ 🕒 Time  : ${new Date().toLocaleString()}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
  }
}