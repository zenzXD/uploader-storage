import moment from 'moment-timezone'
import ms from 'ms'

export default {
  command: ['mute'],
  tags: ['group'],
  desc: '🔇 Membisukan anggota grup untuk sementara/permanen',
  group: true,
  admin: true,
  botAdmin: true,

  handler: async (ctx) => {
    const sender = ctx.from
    const chatId = ctx.chat.id
    const groupName = ctx.chat.title

    const quoted = ctx.message.reply_to_message
    let target, duration, reason

    // Ambil target dari reply / arg
    if (quoted) {
      target = quoted.from
      duration = ctx.args[0]
      reason = ctx.args.slice(1).join(' ') || '— Tanpa alasan —'
    } else if (ctx.args[0]) {
      try {
        const arg = ctx.args[0]
        const userId = arg.replace('@', '')
        const member = await ctx.telegram.getChatMember(chatId, userId)
        target = member.user
        duration = ctx.args[1]
        reason = ctx.args.slice(2).join(' ') || '— Tanpa alasan —'
      } catch {
        return ctx.reply('❌ Tidak dapat menemukan pengguna tersebut.')
      }
    } else {
      return ctx.reply('📌 *Balas pesan atau beri username/ID + durasi* untuk mute.\n\nContoh:\n`/mute @user 1h Spammer`\n`/mute 123456 30m Ujaran kebencian`\n`(balas pesan) /mute 10m`', { parse_mode: 'Markdown' })
    }

    // Hitung waktu mute
    let untilDate
    if (duration) {
      const msDur = ms(duration)
      if (!msDur || msDur < 10000) return ctx.reply('⏳ Durasi tidak valid. Gunakan format seperti `10m`, `1h`, `2d`.')
      untilDate = Math.floor((Date.now() + msDur) / 1000)
    } else {
      untilDate = Math.floor((Date.now() + 365 * 24 * 60 * 60 * 1000) / 1000) // 1 tahun default
    }

    try {
      await ctx.telegram.restrictChatMember(chatId, target.id, {
        permissions: {
          can_send_messages: false,
          can_send_media_messages: false,
          can_send_polls: false,
          can_send_other_messages: false,
          can_add_web_page_previews: false,
          can_change_info: false,
          can_invite_users: false,
          can_pin_messages: false
        },
        until_date: untilDate
      })

      const waktu = moment().tz('Asia/Jakarta').format('dddd, DD MMMM YYYY • HH:mm:ss')
      const durasiText = duration ? ms(ms(duration), { long: true }) : '⏳ *Tanpa batas waktu*'
      const targetName = `[${target.first_name}](tg://user?id=${target.id})`
      const adminName = `[${sender.first_name}](tg://user?id=${sender.id})`

      return ctx.replyWithMarkdownV2(`
╭━━〔 🔇 *MUTE PENGGUNA* 〕━━⬣
┃
┣ 👤 *User:* ${targetName}
┣ 👮 *Dibisukan oleh:* ${adminName}
┣ ⏰ *Waktu:* ${waktu}
┣ 🕒 *Durasi:* ${durasiText}
┣ 📝 *Alasan:* _${reason}_
┃
╰──〔 📍 *Grup:* ${groupName} 〕──⬣
`.trim())
    } catch (e) {
      console.error(e)
      return ctx.reply('❌ Gagal membisukan pengguna. Cek apakah bot punya izin.')
    }
  }
}