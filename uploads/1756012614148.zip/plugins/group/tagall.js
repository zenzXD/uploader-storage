export default {
  command: ['tagall'],
  tags: ['group'],
  desc: '👥 Mention semua anggota grup',
  group: true,

  handler: async (ctx) => {
    const chat = ctx.chat;
    const sender = ctx.from;

    if (chat.type === 'private') {
      return ctx.reply('❌ Fitur ini hanya bisa digunakan di grup.');
    }

    try {
      const member = await ctx.getChatMember(sender.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('🚫 Hanya admin grup yang bisa menggunakan perintah ini.');
      }
    } catch {
      return ctx.reply('⚠️ Gagal memverifikasi status kamu.');
    }

    let admins;
    try {
      admins = await ctx.telegram.getChatAdministrators(chat.id);
      const botAdmin = admins.find(a => a.user.id === ctx.botInfo.id);

      if (!botAdmin || !botAdmin.can_invite_users) {
        return ctx.reply('❌ Bot tidak memiliki izin untuk mention anggota.');
      }
    } catch {
      return ctx.reply('❌ Bot bukan admin atau gagal mengambil daftar admin.');
    }

    // Gunakan mention dari daftar admin saja (karena Telegram tidak izinkan ambil semua member)
    const mentions = admins.map(a => {
      if (a.user.is_bot) return null;
      const name = (a.user.first_name || 'User').replace(/[\[\]\*\_\~\`]/g, '');
      return `[👤 ${name}](tg://user?id=${a.user.id})`;
    }).filter(Boolean);

    const pesan = `
🔊 *TAG SEMUA ANGGOTA*
─────────────────────
📌 Diminta oleh: [${sender.first_name}](tg://user?id=${sender.id})
👥 Grup: *${chat.title}*
🕒 Waktu: ${new Date().toLocaleString('id-ID')}

${mentions.join('\n')}
    `.trim();

    await ctx.replyWithMarkdown(pesan, { disable_web_page_preview: true });
  }
}