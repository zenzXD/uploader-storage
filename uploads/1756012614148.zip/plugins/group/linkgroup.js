export const command = ['linkgroup', 'linkgc'];
export const tags = ['group'];
export const desc = 'Menampilkan link grup (khusus admin grup & owner)';

import { config } from '../../config.js';

export default (bot) => {
  bot.command(command, async (ctx) => {
    const userId = ctx.from.id;
    const chat = ctx.chat;

    try {
      if (!['group', 'supergroup'].includes(chat.type)) {
        return ctx.reply('❌ Command ini hanya bisa digunakan di *grup*.', {
          parse_mode: 'Markdown'
        });
      }

      const isOwner = userId === config.OWNER_ID;
      let isAdmin = false;

      if (!isOwner) {
        const admins = await ctx.getChatAdministrators();
        isAdmin = admins.some(admin => admin.user.id === userId);
        if (!isAdmin) {
          return ctx.reply('🚫 Hanya *admin grup* atau *owner bot* yang bisa menggunakan command ini.', {
            parse_mode: 'Markdown'
          });
        }
      }

      const fullChat = await ctx.telegram.getChat(chat.id);

      let inviteLink = fullChat.invite_link;

      if (!inviteLink) {
        // Bot harus admin agar ini berhasil
        inviteLink = await ctx.telegram.exportChatInviteLink(chat.id);
      }

      const timeStr = new Date().toLocaleString('id-ID', {
        dateStyle: 'full',
        timeStyle: 'short',
      });

      const message = [
        `╭━━━〔 👥 *LINK GRUP* 〕━━━╮`,
        `│`,
        `├ 📛 *Nama:* ${fullChat.title}`,
        `├ 🆔 *ID Grup:* \`${chat.id}\``,
        `├ 👮‍♂️ *Akses:* ${isOwner ? 'Owner Bot' : 'Admin Grup'}`,
        `├ 🔗 *Link:*`,
        `│   ${inviteLink}`,
        `│`,
        `╰━━━━━━━━━━━━━━━━━━━━╯`,
        `🕒 *Waktu:* ${timeStr}`,
        `_Gunakan link di atas untuk join atau undang orang lain._`
      ].join('\n');

      await ctx.reply(message, { parse_mode: 'Markdown' });

    } catch (err) {
      console.error('❌ Gagal mengambil link grup:', err);
      return ctx.reply('❌ Gagal mengambil link grup. Pastikan bot adalah admin dan punya izin "Invite via link".');
    }
  });
};