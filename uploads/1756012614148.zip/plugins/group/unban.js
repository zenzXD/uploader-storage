export default {
  command: ['unban'],
  tags: ['group'],
  desc: 'Unban user dari grup',

  async handler(ctx) {
    if (!ctx.chat || ctx.chat.type === 'private') return ctx.reply('❌ Hanya bisa di grup!');
    if (!ctx.message.reply_to_message) return ctx.reply('🚫 Reply user yang ingin di-unban!');

    const target = ctx.message.reply_to_message.from;
    try {
      await ctx.unbanChatMember(target.id);
      ctx.reply(`✅ @${target.username || target.first_name} telah di-unban.`);
    } catch (e) {
      ctx.reply(`❌ Gagal unban: ${e.message}`);
    }
  }
};