import fs from 'fs'
const filePath = './json/antispam.json'

// Buat file JSON kalau belum ada
if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '{}', 'utf-8')

let antispamDB = JSON.parse(fs.readFileSync(filePath))

// Helper untuk save file
function saveDB() {
  fs.writeFileSync(filePath, JSON.stringify(antispamDB, null, 2))
}

const userSpamMap = new Map()
const SPAM_INTERVAL_MS = 5000
const SPAM_LIMIT = 4

export default {
  command: ['antispam'],
  tags: ['group'],
  desc: '🛡️ Aktif/nonaktifkan fitur anti-spam di grup',

  async handler(ctx, next) {
    const chatId = ctx.chat?.id
    const isGroup = ctx.chat?.type?.endsWith('group')
    const isAdmin = ctx.from?.id && await ctx.getChatMember(ctx.from.id).then(r => ['administrator', 'creator'].includes(r.status))

    if (!isGroup) return ctx.reply('⚠️ Hanya untuk grup!')
    if (!isAdmin) return ctx.reply('⛔ Hanya admin yang bisa mengatur proteksi!')

    const status = antispamDB[chatId] ?? false
    antispamDB[chatId] = !status
    saveDB()

    return ctx.reply(`🛡️ *Proteksi Anti-Spam* sekarang: *${!status ? 'AKTIF ✅' : 'NONAKTIF ❌'}*`, {
      parse_mode: 'Markdown'
    })
  },

  async onMessage(ctx, next) {
    const chatId = ctx.chat?.id
    if (!ctx.chat || ctx.chat.type === 'private') return next()
    if (!antispamDB[chatId]) return next()
    if (ctx.from?.is_bot) return next()

    const userId = ctx.from?.id
    const now = Date.now()
    const spamData = userSpamMap.get(userId) || { lastTime: 0, count: 0 }
    const timeDiff = now - spamData.lastTime

    if (timeDiff < SPAM_INTERVAL_MS) {
      spamData.count++
    } else {
      spamData.count = 1
    }

    spamData.lastTime = now
    userSpamMap.set(userId, spamData)

    if (spamData.count > SPAM_LIMIT) {
      try {
        await ctx.replyWithMarkdownV2(`
🚫 *ANTI-SPAM TRIGGERED*
👤 User: [${ctx.from.first_name}](tg://user?id=${userId})
⚠️ Status: *SPAM TERDETEKSI*
🧹 Aksi: *Auto Kick* 🚪
`, { parse_mode: 'MarkdownV2' })

        await ctx.kickChatMember(userId)
        await ctx.unbanChatMember(userId) // agar bisa join ulang
        userSpamMap.delete(userId)
      } catch (err) {
        console.error('❌ Gagal kick spammer:', err.message)
      }
    }

    return next()
  }
}