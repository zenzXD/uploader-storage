import fs from 'fs';
import moment from 'moment';

const warnFile = './json/warns.json';
if (!fs.existsSync(warnFile)) fs.writeFileSync(warnFile, '{}');

export default {
  command: ['warn', 'unwarn'],
  tags: ['group'],
  desc: '⚠️ Beri atau cabut peringatan user (3x = auto ban)',

  async handler(ctx) {
    const chat = ctx.chat;
    const from = ctx.from;
    const msg = ctx.message;

    if (!chat || chat.type === 'private') return ctx.reply('❌ Hanya bisa digunakan di grup!');
    if (!msg.reply_to_message) return ctx.reply('📍 *Reply* ke user yang ingin diperingatkan/dicabut!', { parse_mode: 'Markdown' });

    const target = msg.reply_to_message.from;
    const userId = target.id.toString();
    const chatId = chat.id.toString();
    const warns = JSON.parse(fs.readFileSync(warnFile));

    const now = moment().format('dddd, DD MMM YYYY HH:mm:ss');
    const groupName = chat.title || 'Grup';
    const groupLink = chat.username ? `https://t.me/${chat.username}` : '🔒 Privat';
    const command = ctx.command;
    const totalWarns = (warns[chatId]?.[userId] || 0);

    // Proteksi bot dan owner
    if (target.id === ctx.botInfo.id || (ctx.config?.owner && ctx.config.owner.includes(target.id))) {
      return ctx.reply('🛡️ Tidak bisa memberi/cabut warning pada bot atau owner!');
    }

    warns[chatId] = warns[chatId] || {};
    warns[chatId][userId] = warns[chatId][userId] || 0;

    const userLink = `[${target.first_name}](tg://user?id=${target.id})`;
    const fromLink = `[${from.first_name}](tg://user?id=${from.id})`;

    const garis = '━━━━━━━━━━━━━━━━━━━━━━';

    if (command === 'warn') {
      warns[chatId][userId]++;
      fs.writeFileSync(warnFile, JSON.stringify(warns, null, 2));

      const newTotal = warns[chatId][userId];

      await ctx.reply(
        `⚠️ *PERINGATAN USER*\n${garis}\n\n` +
        `👤 *Target:* ${userLink}\n` +
        `📣 *Diberi oleh:* ${fromLink}\n` +
        `📌 *Warning ke:* ${newTotal}/3\n\n` +
        `🏷️ *Grup:* ${groupName}\n🔗 *Link:* ${groupLink}\n🕒 *Waktu:* ${now}\n\n` +
        `${garis}\n🧩 *Command:* /warn\n🆔 UserID: ${userId}\n💬 ChatID: ${chatId}`,
        { parse_mode: 'Markdown' }
      );

      if (newTotal >= 3) {
        try {
          await ctx.banChatMember(target.id);
          await ctx.reply(
            `🚫 ${userLink} telah *dibanned* karena mencapai batas warning!\n${garis}`, {
            parse_mode: 'Markdown'
          });
        } catch (err) {
          await ctx.reply(`❌ Gagal ban: ${err.message}`);
        }
      }
    }

    if (command === 'unwarn') {
      if (warns[chatId][userId] <= 0) return ctx.reply('ℹ️ User ini belum memiliki warning.');

      warns[chatId][userId]--;
      fs.writeFileSync(warnFile, JSON.stringify(warns, null, 2));

      await ctx.reply(
        `🔄 *CABUT WARNING*\n${garis}\n\n` +
        `👤 *Target:* ${userLink}\n` +
        `📣 *Dicabut oleh:* ${fromLink}\n` +
        `📉 *Sisa Warning:* ${warns[chatId][userId]}/3\n\n` +
        `🏷️ *Grup:* ${groupName}\n🔗 *Link:* ${groupLink}\n🕒 *Waktu:* ${now}\n\n` +
        `${garis}\n🧩 *Command:* /unwarn\n🆔 UserID: ${userId}\n💬 ChatID: ${chatId}`,
        { parse_mode: 'Markdown' }
      );
    }
  }
};