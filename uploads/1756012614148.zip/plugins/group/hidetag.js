export const command = ['hidetag',];
export const tags = ['group'];
export const desc = '🔒 Sebut semua anggota tanpa terlihat (hidetag)';

export default (bot) => {
  bot.command('hidetag', async (ctx) => {
    if (!ctx.chat?.id || ctx.chat?.type === 'private')
      return ctx.reply('🚫 *Perintah ini hanya bisa digunakan di grup!*', { parse_mode: 'Markdown' });

    const memberStatus = await ctx.getChatMember(ctx.from.id);
    const isAdmin = ['administrator', 'creator'].includes(memberStatus.status);

    if (!ctx.isOwner && !isAdmin)
      return ctx.reply('❌ *Hanya admin atau owner yang bisa menggunakan perintah ini!*', { parse_mode: 'Markdown' });

    const text = ctx.message?.text?.split(' ').slice(1).join(' ') || '📢 *Perhatian semuanya!*';

    // Ambil daftar member
    try {
      const members = await ctx.telegram.getChatAdministrators(ctx.chat.id);
      const mentionList = [];

      for (const member of members) {
        if (member.user?.is_bot) continue;
        mentionList.push({
          type: 'text_mention',
          offset: 0,
          length: 0,
          user: member.user
        });
      }

      await ctx.reply(`🔔 *[Hidetag Mode ON]*\n\n${text}`, {
        parse_mode: 'Markdown',
        entities: mentionList
      });
    } catch (err) {
      console.error('[HIDETAG ERROR]', err);
      return ctx.reply('⚠️ *Gagal mengirim mention tersembunyi. Coba lagi nanti.*', { parse_mode: 'Markdown' });
    }
  });
};