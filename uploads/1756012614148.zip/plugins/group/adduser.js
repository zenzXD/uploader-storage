export const command = ['add'];
export const tags = ['admin'];
export const desc = '➕ Invite user ke grup via link undangan';

export default (bot) => {
  bot.command('add', async (ctx) => {
    if (!ctx.chat || ctx.chat.type === 'private') {
      return ctx.reply('🚫 Perintah hanya bisa digunakan di grup!');
    }

    const memberStatus = await ctx.getChatMember(ctx.from.id);
    const isAdmin = ['administrator', 'creator'].includes(memberStatus.status);
    if (!ctx.isOwner && !isAdmin) {
      return ctx.reply('❌ Hanya admin atau owner yang bisa menggunakan perintah ini!');
    }

    const args = ctx.message?.text?.split(' ').slice(1);
    if (!args || args.length === 0) {
      return ctx.reply('❗ Contoh: /add @username atau user_id');
    }

    const target = args[0].replace('@', '');

    try {
      const inviteLink = await ctx.telegram.exportChatInviteLink(ctx.chat.id);
      const sent = await ctx.telegram.sendMessage(target, `🔗 Anda diundang ke grup: ${ctx.chat.title}\nGabung di sini:\n${inviteLink}`);
      return ctx.reply(`✅ Undangan dikirim ke @${target}`);
    } catch (err) {
      console.error('[ADD ERROR]', err);
      return ctx.reply('⚠️ Gagal mengirim undangan. Pastikan username atau ID benar & bot bisa DM user tersebut.');
    }
  });
};