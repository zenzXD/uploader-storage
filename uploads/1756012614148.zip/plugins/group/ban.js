import { config } from '../../config.js'
import { sendToTelegram } from '../../lib/telegram.js'
import { getTargetUser } from '../../lib/utils.js';
export default {
  command: ['ban', 'kick'],
  tags: ['group'],
  desc: 'Ban atau kick member dari grup, support reply, tag, ID, dan durasi.',

  async handler(ctx) {
    const { chat, from, message } = ctx
    const chatId = chat.id

    // ─── Validasi Grup ─────────────────────────────
    if (!['group', 'supergroup'].includes(chat.type))
      return ctx.reply('❌ Perintah ini hanya bisa digunakan di grup/supergroup.')

    const args = ctx.message.text?.split(' ').slice(1) || []
    const reply = message.reply_to_message
    let target

    // ─── Ambil Target ─────────────────────────────
    if (reply) {
      target = reply.from
    } else if (args[0]?.startsWith('@') || /^\d+$/.test(args[0])) {
      try {
        const user = await ctx.telegram.getChatMember(chatId, args[0])
        target = user.user
      } catch {
        return ctx.reply('⚠️ Tidak bisa menemukan pengguna tersebut.')
      }
    } else {
      return ctx.reply('⚠️ Balas pesan user atau tag/ID user.\n\nContoh:\n/ban @user\n/ban 123456789\n(Bisa ditambah durasi: 1d, 2h, 10m...)')
    }

    // ─── Cek Bot & Admin ───────────────────────────
    const botId = (await ctx.getMe()).id
    const botStatus = await ctx.getChatMember(chatId, botId)
    if (!['administrator', 'creator'].includes(botStatus.status))
      return ctx.reply('🤖 Bot bukan admin, tidak bisa ban/kick member.')

    const admins = await ctx.getChatAdministrators(chatId)
    const isSenderAdmin = admins.some(a => a.user.id === from.id)
    if (!isSenderAdmin)
      return ctx.reply('🚫 Perintah ini hanya untuk admin grup.')

    const isTargetAdmin = admins.some(a => a.user.id === target.id)
    if (target.id === botId)
      return ctx.reply('⚠️ Tidak bisa ban/kick bot sendiri.')
    if (isTargetAdmin)
      return ctx.reply('🛡️ Tidak bisa ban sesama admin.')

    // ─── Durasi Opsional ──────────────────────────
    const durationInput = args.find(a => /\d+[smhd]/i.test(a))
    const durationMs = parseDuration(durationInput)
    const untilDate = durationMs ? Math.floor((Date.now() + durationMs) / 1000) : undefined

    // ─── Eksekusi Ban/Kick ────────────────────────
    try {
      if (ctx.command === 'kick') {
        await ctx.unbanChatMember(target.id) // kick = unban tanpa waktu
        await ctx.reply(`┌─[👢 KICK BERHASIL]\n├ 👤: [${target.first_name}](tg://user?id=${target.id})\n└ 🛡️ Oleh: [${from.first_name}](tg://user?id=${from.id})`, { parse_mode: 'Markdown' })
      } else {
        await ctx.kickChatMember(target.id, untilDate)
        await ctx.reply(`┌─[🔨 BAN BERHASIL]\n├ 👤: [${target.first_name}](tg://user?id=${target.id})\n├ ⏳: ${untilDate ? `*${formatDuration(durationMs)}*` : 'Permanen'}\n└ 🛡️ Oleh: [${from.first_name}](tg://user?id=${from.id})`, { parse_mode: 'Markdown' })
      }

      // ─── Kirim ke Log Grup (Opsional) ─────────────
      if (config.logGroupId) {
        const logText = `📣 *LAPORAN ${ctx.command.toUpperCase()}*\n` +
          `👥 Grup: ${chat.title}\n` +
          `👮 Admin: [${from.first_name}](tg://user?id=${from.id})\n` +
          `👤 Target: [${target.first_name}](tg://user?id=${target.id})\n` +
          `⏰ Durasi: ${untilDate ? formatDuration(durationMs) : '-'}\n` +
          `🕒 ${new Date().toLocaleString()}`
        await sendToTelegram(config.logGroupId, logText, { parse_mode: 'Markdown' })
      }

    } catch (err) {
      console.error(err)
      ctx.reply('❌ Gagal melakukan ban/kick. Pastikan bot punya izin.')
    }
  }
}

// ─── Utility Durasi ─────────────────────────────
function parseDuration(text) {
  if (!text) return null
  const m = text.match(/(\d+)([smhd])/)
  if (!m) return null
  const val = parseInt(m[1])
  const unit = { s: 1000, m: 60000, h: 3600000, d: 86400000 }
  return val * (unit[m[2]] || 0)
}

function formatDuration(ms) {
  const s = ms / 1000
  if (s < 60) return `${s}s`
  if (s < 3600) return `${Math.floor(s / 60)}m`
  if (s < 86400) return `${Math.floor(s / 3600)}h`
  return `${Math.floor(s / 86400)}d`
}