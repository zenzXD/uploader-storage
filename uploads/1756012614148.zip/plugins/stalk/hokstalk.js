import fetch from "node-fetch";
import { config } from "../../config.js";

const queue = new Map();

export default {
    command: ["stalkhok", "hokstalk"],
    tags: ["stalker"],
    desc: "🔍 Stalk akun HOK (Heroes of Crown)",
    limit: true,

    async handler(ctx) {
        const id = ctx.message.text.split(" ").slice(1).join(" ");
        const user = ctx.from.id;

        if (!id)
            return ctx.reply(
                `🚫 *Contoh:* /${this.command[0]} 18394462029520398963`
            );

        if (queue.has(user)) {
            return ctx.reply(
                "⏳ Mohon tunggu, permintaan sebelumnya masih diproses..."
            );
        }

        queue.set(user, true);

        try {
            const res = await fetch(
                `https://api.botcahx.eu.org/api/stalk/hok?apikey=${
                    config.BOTCAHX_API_KEY
                }&id=${encodeURIComponent(id)}`
            );
            const json = await res.json();

            if (!json.status) {
                return ctx.reply(
                    `❌ Gagal mengambil data HOK:\n${
                        json.message || "Tidak diketahui."
                    }`
                );
            }

            const r = json.result;
            const teks = `
╭───❏ *🎮 HOK Stalker Result*
│👤 *Nickname:* ${r.nickname}
│🆔 *User ID:* ${r.user_id}
│🧩 *Level:* ${r.level}
│⚔️ *Battle Power:* ${r.battle_power}
│🥇 *Arena Rank:* ${r.arena_rank}
│🏹 *Guild:* ${r.guild_name || "-"}
│🌍 *Server:* ${r.server}
╰──────────────⬣

📌 _Data diambil secara real-time dari database HOK._
`;

            await ctx.reply(teks.trim());
        } catch (e) {
            console.error(e);
            ctx.reply("⚠️ Terjadi kesalahan saat mengambil data.");
        } finally {
            queue.delete(user);
        }
    }
};
