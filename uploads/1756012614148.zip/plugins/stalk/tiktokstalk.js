import fetch from 'node-fetch'
import { Markup } from 'telegraf'
import { config } from '../../config.js'

export default {
  command: ['tiktokstalk', 'ttstalk'],
  tags: ['stalker'],
  desc: '🔍 Stalk profil TikTok berdasarkan username',

  async handler(ctx) {
    const text = ctx.message?.text?.split(' ')?.slice(1)?.join(' ')?.trim()
    if (!text)
      return ctx.reply(
        `📌 *Contoh penggunaan:*\n/tiktokstalk username\n\nContoh:\n/tiktokstalk zenzx`,
        { parse_mode: 'Markdown' }
      )

    try {
      const res = await fetch(`https://zenzxz.dpdns.org/stalker/tiktok?username=${encodeURIComponent(text)}`)
      const json = await res.json()

      if (!json.status || !json.result)
        return ctx.reply('❌ Gagal mendapatkan data dari TikTok.')

      const data = json.result
      const caption = `
╭━━━[ *👤 TIKTOK PROFILE* ]━━━⬣
┃🆔 *Username:* @${data.username}
┃📛 *Nickname:* ${data.nickname}
┃📝 *Bio:* ${data.bio || '-'}
┃🎞️ *Video:* ${data.video}
┃👥 *Followers:* ${data.followers}
┃👤 *Following:* ${data.following}
┃❤️ *Likes:* ${data.likes}
┃🌐 *Region:* ${data.region || '-'}
╰━━━━━━━━━━━━━━━━━━━⬣
🤖 ${config.BOTNAME}
`.trim()

      await ctx.replyWithPhoto(data.avatar, {
        caption,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.urlButton('🔗 Kunjungi Profil', `https://tiktok.com/@${data.username}`)],
        ])
      })
    } catch (e) {
      console.error(e)
      return ctx.reply('⚠️ Terjadi kesalahan saat mengambil data TikTok.')
    }
  }
}