import moment from 'moment-timezone'
import { parsePhoneNumber } from 'libphonenumber-js'
import fetch from 'node-fetch'

const regionNames = new Intl.DisplayNames(['en'], { type: 'region' })

export default {
  command: ['wastalk', 'whatsappstalk'],
  tags: ['stalker'],
  desc: '📲 Stalk akun WhatsApp berdasarkan nomor atau mention (premium banking style)',
  usage: '/wastalk @user atau 628xxxx',

  async handler(ctx) {
    const { message, reply, telegram } = ctx
    let text = ctx.text?.trim().split(/\s+/).slice(1).join(' ')
    let target = ctx.message?.reply_to_message?.text || text

    if (!target) {
      return ctx.reply(`❌ *Format salah!*\n\nContoh:\n/wastalk @username\n/wastalk 628xxxxxx`, { parse_mode: 'Markdown' })
    }

    const phone = target.replace(/\D/g, '')

    let phoneInfo
    try {
      phoneInfo = parsePhoneNumber('+' + phone)
      if (!phoneInfo.isValid()) throw 'Nomor tidak valid'
    } catch (e) {
      return ctx.reply('❌ Nomor tidak valid atau tidak bisa dikenali.')
    }

    const number = phoneInfo.number.replace('+', '')
    const name = `Sample User ${number.slice(-4)}`
    const img = 'https://telegra.ph/file/70e8de9b1879568954f09.jpg'
    const bio = {
      status: '👔 Ready for business inquiries!',
      setAt: new Date()
    }

    const country = regionNames.of(phoneInfo.country) || 'Unknown'

    const business = {
      wid: `+${number}@s.whatsapp.net`,
      website: 'https://premiumbank.id',
      email: 'cs@premiumbank.id',
      category: 'Financial Services',
      address: 'Jl. Sultan Premium No.88, Jakarta',
      business_hours: {
        timezone: 'Asia/Jakarta'
      },
      description: '🏦 Premium Banking & Financial Consulting Services.'
    }

    const caption = `
╭───「 👤 *PREMIUM WHATSAPP PROFILE* 」───⬣
│
├─ 🌍 *Country:* ${country.toUpperCase()}
├─ 🙍‍♂️ *Name:* ${name}
├─ ☎️ *International:* ${phoneInfo.formatInternational()}
├─ 🔗 *API URL:* wa.me/${number}
├─ 🗣️ *Mention:* @${number}
├─ 📝 *Status:* ${bio.status}
├─ 🕰️ *Updated:* ${moment(bio.setAt).locale('id').format('LL')}
│
├───「 🏢 *BUSINESS INFO* 」───⬣
│
├─ 🆔 *Business ID:* ${business.wid}
├─ 🌐 *Website:* ${business.website}
├─ 📧 *Email:* ${business.email}
├─ 🏷️ *Category:* ${business.category}
├─ 📍 *Address:* ${business.address}
├─ 🕑 *Timezone:* ${business.business_hours.timezone}
├─ 🧾 *Description:* ${business.description}
│
╰────────────⬣
`.trim()

    await ctx.replyWithPhoto({ url: img }, {
      caption,
      parse_mode: 'Markdown'
    })
  }
}
