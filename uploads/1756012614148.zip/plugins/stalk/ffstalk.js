import axios from 'axios'

function convertEpochToDate(epoch) {
  return new Date(parseInt(epoch) * 1000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
}

async function cekAkunFreeFire(uid, region = 'id', key = 'FFwlx') {
  try {
    const endpoint = 'https://client-hlgamingofficial.vercel.app/api/ff-hl-gaming-official-api-account-v2-latest/account'
    const headers = {
      'Content-Type': 'application/json',
      'Origin': 'https://www.hlgamingofficial.com',
      'Referer': 'https://www.hlgamingofficial.com/',
      'User-Agent': 'Mozilla/5.0'
    }

    const body = { uid, region, key }
    const { data } = await axios.post(endpoint, body, { headers })

    if (!data?.AccountInfo) throw new Error("ga ada respon, mungkin uid/region salah")

    const {
      AccountInfo,
      AccountProfileInfo,
      GuildInfo,
      captainBasicInfo,
      creditScoreInfo,
      petInfo,
      socialinfo
    } = data

    return {
      status: true,
      nickname: AccountInfo.AccountName,
      level: AccountInfo.AccountLevel,
      region: AccountInfo.AccountRegion,
      likes: AccountInfo.AccountLikes,
      exp: AccountInfo.AccountEXP,
      title: AccountInfo.Title,
      createTime: convertEpochToDate(AccountInfo.AccountCreateTime),
      lastLogin: convertEpochToDate(AccountInfo.AccountLastLogin),
      diamondCost: AccountInfo.DiamondCost,
      brRank: AccountInfo.ShowBrRank,
      csRank: AccountInfo.ShowCsRank,
      guild: GuildInfo?.GuildName,
      signature: socialinfo?.AccountSignature || '-'
    }

  } catch (e) {
    return {
      status: false,
      message: 'Gagal mengambil data akun.',
      error: e?.response?.data || e.message
    }
  }
}

export default {
  command: ['cekff', 'ffcheck'],
  tags: ['stalker'],
  desc: '🎮 Cek informasi akun Free Fire',

  async handler(ctx) {
    const args = ctx.message.text?.split(' ').slice(1)
    const uid = args?.[0]
    const region = args?.[1] || 'id'

    if (!uid) {
      return ctx.reply(`❌ *Masukkan UID Free Fire!*\n\n📌 Contoh:\n\`/cekff 123456789 id\``, {
        parse_mode: 'Markdown'
      })
    }

    const result = await cekAkunFreeFire(uid, region)

    if (!result.status) {
      return ctx.reply(`❌ *Gagal mendapatkan data akun!*\n\n📋 Pesan: ${result.message || 'Unknown error'}`, {
        parse_mode: 'Markdown'
      })
    }

    const text = `
╭───〘 🎮 *Free Fire Account Info* 〙───✧
│ 📛 *Nickname:* ${result.nickname}
│ 🆔 *UID:* ${uid}
│ 🌍 *Region:* ${result.region}
│ 📈 *Level:* ${result.level}
│ 💖 *Like:* ${result.likes}
│ 💬 *Signature:* ${result.signature}
│ 🏅 *Title:* ${result.title || '-'}
│ 💎 *Diamond Dipakai:* ${result.diamondCost}
│ 🎖️ *BR Rank:* ${result.brRank}
│ 🥇 *CS Rank:* ${result.csRank}
│ 🛡️ *Guild:* ${result.guild || '-'}
│ 📅 *Dibuat:* ${result.createTime}
│ ⏰ *Login Terakhir:* ${result.lastLogin}
╰─────────────────────────────⬣
`.trim()

    await ctx.reply(text, { parse_mode: 'Markdown' })
  }
}