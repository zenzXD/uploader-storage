import fetch from 'node-fetch'

export default {
  command: ['stalkroblox'],
  tags: ['stalker'],
  help: '🔍 Stalk akun Roblox seseorang',
  desc: '🔎 Menampilkan detail profil Roblox berdasarkan username',
  limit: 2, // Integrasi limit harian
  premium: false, // Non-premium
  group: false,

  async handler(ctx) {
    const username = ctx.args[0]
    if (!username) return ctx.reply('❗ Contoh: /stalkroblox pinkeu_c4sttle')

    const msg = await ctx.reply(`⏳ *Melacak akun Roblox:* \`${username}\`...\nMohon tunggu sebentar ya...`)

    try {
      const res = await fetch(`https://zenzxz.dpdns.org/stalker/roblox?username=${username}`)
      const json = await res.json()

      if (!json.status || !json.success || !json.data) {
        return ctx.reply(`❌ Akun *${username}* tidak ditemukan.`)
      }

      const {
        account,
        presence,
        stats
      } = json.data

      const teks = `
╭───⭓ 👾 *Roblox Profile*
│ 👤 *Username:* ${account.username}
│ 🏷️ *Display Name:* ${account.displayName}
│ 📅 *Dibuat:* ${new Date(account.created).toLocaleDateString()}
│ ❌ *Banned:* ${account.isBanned ? 'Ya' : 'Tidak'}
│ ✅ *Verified:* ${account.hasVerifiedBadge ? 'Ya' : 'Tidak'}
│ 📄 *Deskripsi:* ${account.description || '-'}
│
├───⭓ 📊 *Statistik*
│ 👥 Teman: ${stats.friendCount}
│ 👣 Pengikut: ${stats.followers}
│ 👤 Mengikuti: ${stats.following}
│
╰───⭓ 🕹️ *Aktivitas*
  • Online: ${presence.isOnline ? 'Ya' : 'Tidak'}
  • Terakhir Online: ${presence.lastOnline || 'Tidak diketahui'}
  • Game Terakhir: ${presence.recentGame || '-'}
      `.trim()

      await ctx.replyWithPhoto(account.profilePicture, {
        caption: teks,
        parse_mode: 'Markdown'
      })

      await ctx.api.deleteMessage(ctx.chat.id, msg.message_id)
    } catch (e) {
      console.error(e)
      return ctx.reply('🚫 Terjadi kesalahan saat mengambil data.')
    }
  }
}
