import axios from 'axios'

import * as cheerio from 'cheerio'

async function cscstalk(username) {

  const url = `https://codeshare.cloudku.click/profile?user=${username}`

  const { data } = await axios.get(url, {

    headers: {

      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'

    }

  })

  const $ = cheerio.load(data)

  const banner = $('#banner-preview').attr('src')

  const avatar = $('#avatar-preview').attr('src')

  const bio = $('.profile-bio').text().trim()

  const followers = $('.profile-stats .stat-item').first().find('strong').text().trim()

  const following = $('.profile-stats .stat-item').last().find('strong').text().trim()

  const snippets = []

  $('.snippets-grid .snippet-card').each((i, el) => {

    const title = $(el).find('h3').text().trim()

    const date = $(el).find('.snippet-meta time').text().trim()

    const lang = $(el).find('.lang-tag').text().trim()

    const views = $(el).find('.card-stats span').text().trim()

    const link = $(el).find('a').attr('href')

    snippets.push({

      title,

      date,

      language: lang,

      views: parseInt(views || '0'),

      url: link ? (link.startsWith('http') ? link : `https://codeshare.cloudku.click/${link}`) : null

    })

  })

  return {

    profile: {

      username,

      banner: banner ? (banner.startsWith('http') ? banner : `https://codeshare.cloudku.click/${banner}`) : null,

      avatar: avatar ? (avatar.startsWith('http') ? avatar : `https://codeshare.cloudku.click/${avatar}`) : null,

      bio,

      followers: parseInt(followers || '0'),

      following: parseInt(following || '0')

    },

    snippets

  }

}

export default {

  command: ['cscstalk'],

  tags: ['stalker'],

  desc: '🔍 Cek profil Codeshare (codeshare.cloudku.click)',

  async handler(ctx) {

    const input = ctx.text?.split(' ')[1]

    const reply = (msg, opt) => ctx.reply(msg, opt)

    if (!input) {

      return reply(`❗️ *Masukkan username Codeshare!*

📌 Contoh:

\`\`\`

/cscstalk ZenzzXD

\`\`\``, { parse_mode: 'Markdown' })

    }

    await reply('🔍 *Sedang mengambil data profile...*', { parse_mode: 'Markdown' })

    try {

      const result = await cscstalk(input.trim())

      if (!result || !result.profile) {

        return reply('❌ *Gagal mengambil data profil!*', { parse_mode: 'Markdown' })

      }

      const { profile, snippets } = result

      let caption = `╭━━━[ *👤 Profile Codeshare* ]━━━╮\n\n`

      caption += `• 🆔 *Username:* \`${profile.username}\`\n`

      caption += `• 📃 *Bio:* ${profile.bio || '_Tidak ada bio_'}\n`

      caption += `• 👥 *Followers:* *${profile.followers}*\n`

      caption += `• 👤 *Following:* *${profile.following}*\n`

      caption += `\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n`

      if (snippets.length) {

        caption += `\n📁 *Total Snippet:* *${snippets.length}*\n📝 *Daftar Snippet:*\n`

        snippets.forEach((snip, i) => {

          caption += `\n*${i + 1}. ${snip.title}* \`(${snip.language})\`\n`

          caption += `   📅 ${snip.date} | 👁️ ${snip.views} views\n`

          caption += `   🔗 [Link](${snip.url})\n`

        })

      } else {

        caption += `\n⚠️ Tidak ada snippet di akun ini.`

      }

      caption += `\n\n✨ _Data diambil langsung dari_ [codeshare.cloudku.click](https://codeshare.cloudku.click/)`

      const thumb = profile.avatar || profile.banner

      if (thumb) {

        await ctx.replyWithPhoto({ url: thumb }, {

          caption,

          parse_mode: 'Markdown',

          disable_web_page_preview: false

        })

      } else {

        await reply(caption, {

          parse_mode: 'Markdown',

          disable_web_page_preview: true

        })

      }

    } catch (err) {

      console.error('cscstalk error:', err)

      return reply(`🚫 *Terjadi kesalahan saat mengambil data:*\n\`${err.message}\``, {

        parse_mode: 'Markdown'

      })

    }

  }

}