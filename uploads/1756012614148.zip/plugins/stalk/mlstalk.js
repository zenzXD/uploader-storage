import fetch from "node-fetch";
export default {
    command: ["mlstalk"],
    tags: ["stalker"],
    desc: "📱 Stalk akun Mobile Legends secara manual",

    async handler(ctx) {
        const input = ctx.args.join(" ");
        if (!input)
            return ctx.reply(
                "⚠️ Contoh: `/mlstalk 214885010 2253`\natau `/mlstalk 214885010|2253`",
                { parse_mode: "Markdown" }
            );

        // Parsing ID dan Server
        let user_id, server_id;
        if (input.includes("|")) {
            [user_id, server_id] = input.split("|").map(v => v.trim());
        } else {
            [user_id, server_id] = input.split(" ").map(v => v.trim());
        }

        if (!user_id || !server_id) {
            return ctx.reply(
                "❌ Format salah. Contoh:\n`/mlstalk 214885010 2253`",
                { parse_mode: "Markdown" }
            );
        }

        // Data dummy statis
        const data = {
            user_id,
            server_id,
            nickname: "₡ɭᴏυƉ",
            country: "ID",
            rank: "Mythic Honor",
            total_hero: 122,
            total_skin: 345,
            total_like: 2943,
            favorite_hero: ["Ling", "Yin", "Fanny"],
            main_role: "Assassin",
            last_login: "3 jam yang lalu",
            skin_collection: [
                "Epic Ling",
                "Collector Yin",
                "KOF Chou",
                "Fanny Skylark",
                "Aldous Saitama"
            ]
        };

        const teks = `
╭━━━〔 🕹️ *MLBB STALKER* 〕━━━✦
┃ ✦ ᴺᵃᵐᵃ: *${data.nickname}*
┃ ✦ ᴬᴷᴬᴺᴴᴱᴿᴼ: ${data.favorite_hero.map(h => `「${h}」`).join(", ")}
┃ ✦ ᴿᴬᴺᴷ: *${data.rank}*
┃ ✦ ᴿᴼᴸᴱ ᴹᴬᴵᴺ: *${data.main_role}*
┃ ✦ ᴸᴼᴳᴵᴺ ᵀᴱᴿᴬᴷᴴᴵᴿ: ${data.last_login}
┃
┃ 🆔 *ID*: ${data.user_id} (${data.server_id})
┃ 🌍 *Negara*: ${data.country}
┃ 🦸 *Total Hero*: ${data.total_hero}
┃ 🎨 *Total Skin*: ${data.total_skin}
┃ ❤️ *Total Like*: ${data.total_like}
╰━━━━━━━━━━━━━━━━━━━━━━━✦

╭─〔 🎭 *KOLEKSI SKIN* 〕
${data.skin_collection.map((s, i) => `│ ${i + 1}. ${s}`).join("\n")}
╰───────────────✦

📌 _Bot ini bukan cuma stalker, tapi juga ngintip masa depanmu di Land of Dawn._ 🔮🔥
    `.trim();

        await ctx.reply(teks, { parse_mode: "Markdown" });
    }
};
