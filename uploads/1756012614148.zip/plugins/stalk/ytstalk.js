import fetch from 'node-fetch'

export default {
  command: ['ytstalk', 'youtube', 'ytstalker'],
  tags: ['stalker'],
  desc: '🔍 Stalk akun YouTube berdasarkan username',

  async handler(bot) {
    bot.command('ytstalk', async (ctx) => {
      const text = ctx.message.text.split(' ').slice(1).join(' ')
      if (!text) {
        return ctx.reply(
          `🚨 *Masukkan username YouTube!*\n\n📌 Contoh:\n/ytstalk Dhot`,
          { parse_mode: 'Markdown' }
        )
      }

      try {
        const res = await fetch(`https://zenzxz.dpdns.org/stalker/youtube?username=${encodeURIComponent(text)}`)
        if (!res.ok) throw await res.text()
        const json = await res.json()
        if (!json.status) throw json

        const r = json.result
        const caption = `
╭─〔 📺 *YouTube Profile* 〕─⬣
│👤 *Nama Channel:* ${r.title}
│🆔 *Channel ID:* ${r.channelId}
│✅ *Terverifikasi:* ${r.verified ? 'Ya' : 'Tidak'}
│📅 *Tanggal Dibuat:* ${r.createdAt}
│📚 *Kategori:* ${r.category}
╰──────────────⬣

╭─〔 📊 *Statistik Akun* 〕─⬣
│👥 *Subscribers:* ${r.subscriberCount}
│🎥 *Jumlah Video:* ${r.videoCount}
│▶️ *Total Views:* ${r.viewCount}
│📈 *Monthly Views:* ${r.monthlyViews}
╰──────────────⬣

╭─〔 💰 *Estimasi Penghasilan* 〕─⬣
│💵 *Total Revenue:* ${r.totalRevenue}
│📆 *Monthly Revenue:* ${r.monthlyRevenue}
│💸 *Default CPM:* ${r.defaultCPM}
╰──────────────⬣
        `.trim()

        await ctx.replyWithPhoto({ url: r.thumbnailUrl }, {
          caption,
          parse_mode: 'Markdown'
        })

      } catch (e) {
        console.error(e)
        return ctx.reply('❌ Gagal mengambil data. Username mungkin salah atau server sedang bermasalah.')
      }
    })
  }
}