import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

import { fileURLToPath } from "url";

const mandarinChars = [

  "龙", "虎", "风", "云", "山", "河", "天", "地", "雷", "电",

  "火", "水", "木", "金", "土", "星", "月", "日", "光", "影",

  "峰", "泉", "林", "海", "雪", "霜", "雾", "冰", "焰", "石"

];

const genMandarin = () =>

  Array.from({ length: Math.floor(Math.random() * 4) + 3 }, () =>

    mandarinChars[Math.floor(Math.random() * mandarinChars.length)]

  ).join("");

const getMandarinObf = () => ({

  target: "node",

  compact: true,

  renameVariables: true,

  renameGlobals: true,

  identifierGenerator: genMandarin,

  stringEncoding: true,

  stringSplitting: true,

  controlFlowFlattening: 0.95,

  shuffle: true,

  duplicateLiteralsRemoval: true,

  deadCode: true,

  calculator: true,

  opaquePredicates: true,

  lock: {

    selfDefending: true,

    antiDebug: true,

    integrity: true,

    tamperProtection: true,

  },

});

const bar = (p) => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```⚡ Lin-Qiye\n🔐 MandarinEncryptor\n⚙️ " + l + " (" + p + "%)\n " + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  );

const ensureExportDefault = (code, originalCode) => {

  // Jika sudah menggunakan ekspor ES6

  if (/\bexport\s+(default|const|function|class)\b/.test(originalCode)) return code;

  // Jika menggunakan CommonJS

  const match = originalCode.match(/module\.exports\s*=\s*([a-zA-Z0-9_$]+)/);

  if (match) {

    const varName = match[1];

    return code + `\n\nexport default ${varName};`;

  }

  // Jika tidak ada ekspor sama sekali

  return code + `\n\nexport default {};`;

};

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default {

  command: ["encchina"],

  tags: ["enc"],

  desc: "Enkripsi file JavaScript dengan karakter Mandarin (obfuscator hardening)",

  handler: async (ctx) => {

    const d = ctx.message?.reply_to_message?.document;

    if (

      !d ||

      !/\.(js|mjs|cjs|ts)$/i.test(d.file_name) ||

      d.file_size > 20 * 1024 * 1024

    ) {

      return ctx.replyWithMarkdown(

        "⚠️ *Balas file dengan ekstensi .js/.ts/.cjs/.mjs dan ukuran ≤ 20MB, lalu kirim perintah `/encchina`*"

      );

    }

    const tmpPath = path.join(__dirname, `linqiye-encrypted-${d.file_name}`);

    try {

      const prog = await ctx.replyWithMarkdown(

        "```⚡ Lin-Qiye\n🔐 MandarinEncryptor\n⚙️ Memulai (1%)\n " + bar(1) + "\n```"

      );

      const fileUrl = await ctx.telegram.getFileLink(d.file_id);

      const raw = await (await fetch(fileUrl.href)).text();

      await upd(ctx, prog, 20, "Unduhan selesai");

      // Cek apakah ini ESM module

      const isESM = /\b(import|export)\b/.test(raw);

      // Validasi awal (hanya jika bukan ESM)

      if (!isESM) new Function(raw);

      await upd(ctx, prog, 30, "Validasi berhasil");

      const obf = await JsConfuser.obfuscate(raw, getMandarinObf());

      let code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Obfuscasi selesai");

      code = ensureExportDefault(code, raw);

      await fs.writeFile(tmpPath, code);

      await upd(ctx, prog, 80, "File ditulis");

      if (!isESM) new Function(code); // Validasi akhir jika bukan ESM

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: tmpPath,

          filename: `linqiye-encrypted-${d.file_name}`,

        },

        {

          caption: "✅ *File terenkripsi dengan Mandarin oleh Lin-Qiye ⚡*",

          parse_mode: "Markdown",

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      console.error(e);

      await ctx.reply(`❌ Error: ${e.message}`);

    } finally {

      if (await fs.pathExists(tmpPath)) {

        await fs.remove(tmpPath);

      }

    }

  },

};