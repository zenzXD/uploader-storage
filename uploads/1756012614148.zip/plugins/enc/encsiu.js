import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

import { fileURLToPath } from "url";

// ⛓️ ESM path fix

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

/* ── PRESET: SIU + CALCRICK ── */

const genSiu = () => {

  const abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  let r = ""; for (let i = 0; i < 6; i++) r += abc[Math.floor(Math.random() * abc.length)];

  return `CalceKarik和SiuSiu${r}`;

};

const getSiuObf = () => ({

  target: "node",

  compact: true,

  renameVariables: true,

  renameGlobals: true,

  identifierGenerator: genSiu,

  stringEncoding: true,

  stringSplitting: true,

  controlFlowFlattening: 0.95,

  flatten: true,

  shuffle: true,

  dispatcher: true,

  duplicateLiteralsRemoval: true,

  deadCode: true,

  calculator: true,

  opaquePredicates: true,

  lock: {

    selfDefending: true,

    antiDebug: true,

    integrity: true,

    tamperProtection: true,
      splitDetections: true,

stack: true,

asyncWrappers: true,

proxy: true,

  }

});

/* ── UTIL ── */

const log = (...a) => console.log(new Date().toISOString(), ...a);

const bar = p => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ " + l + " (" + p + "%)\n " + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  );

const ensureExportDefault = (code, raw) => {

  if (/\bexport\s+(default|const|function|class)\b/.test(raw)) return code;

  const match = raw.match(/module\.exports\s*=\s*([a-zA-Z0-9_$]+)/);

  if (match) return code + `\n\nexport default ${match[1]};`;

  return code + `\n\nexport default {};`;

};

/* ── PLUGIN ── */

export default {

  command: ["encsiu"],

  tags: ["enc"],

  desc: "Enkripsi JavaScript dengan preset Calcrick SiuSiu",

  handler: async (ctx) => {

    const doc = ctx.message?.reply_to_message?.document;

    const allowedExt = [".js", ".ts", ".mjs", ".cjs"];

    if (!doc || !allowedExt.some(ext => doc.file_name.endsWith(ext)) || doc.file_size > 20 * 1024 * 1024) {

      return ctx.replyWithMarkdown("❌ *Balas file .js/.ts/.mjs (maks. 20MB) dengan `/encsiu`*");

    }

    const out = path.join(__dirname, `linqiye-encrypted-${doc.file_name}`);

    try {

      const prog = await ctx.replyWithMarkdown(

        "```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ Memulai (Calcrick Chaos Core) (1%)\n " + bar(1) + "\n```"

      );

      const link = await ctx.telegram.getFileLink(doc.file_id);

      const raw = await (await fetch(link.href)).text();

      await upd(ctx, prog, 20, "Mengunduh selesai");

      const isESM = /\b(import|export)\b/.test(raw);

      if (!isESM) new Function(raw); // Validasi hanya jika bukan ESM

      await upd(ctx, prog, 30, "Validasi selesai");

      const obf = await JsConfuser.obfuscate(raw, getSiuObf());

      let code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Transformasi selesai");

      code = ensureExportDefault(code, raw);

      await fs.writeFile(out, code);

      await upd(ctx, prog, 80, "Finalisasi");

      if (!isESM) new Function(code); // Validasi hasil jika bukan ESM

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: out,

          filename: `linqiye-encrypted-${doc.file_name}`

        },

        {

          caption: "✅ *Calcrick Chaos Core encrypted by Lin Qiye!*",

          parse_mode: "Markdown"

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      log("Siu+Calcrick error:", e.message);

      await ctx.reply(`❌ ${e.message}`);

    } finally {

      if (await fs.pathExists(out)) await fs.remove(out);

    }

  }

};