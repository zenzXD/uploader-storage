import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

const arab = [

  "أ", "ب", "ت", "ث", "ج", "ح", "خ", "د", "ذ", "ر", "ز", "س", "ش", "ص", "ض", "ط",

  "ظ", "ع", "غ", "ف", "ق", "ك", "ل", "م", "ن", "ه", "و", "ي"

];

const genArab = () =>

  Array.from({ length: Math.floor(Math.random() * 4) + 3 }, () =>

    arab[Math.floor(Math.random() * arab.length)]

  ).join("");

const getArabObf = () => ({

  target: "node",

  compact: true,

  renameVariables: true,

  renameGlobals: true,

  identifierGenerator: genArab,

  stringEncoding: true,

  stringSplitting: true,

  controlFlowFlattening: 0.95,

  shuffle: true,

  duplicateLiteralsRemoval: true,

  deadCode: true,

  calculator: true,

  opaquePredicates: true,

  lock: {

    selfDefending: true,

    antiDebug: true,

    integrity: true,

    tamperProtection: true,

  },

});

const bar = (p) => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "`⚡ Lin-Qiye\n🔒 ArabEncryptor\n⚙️ " + l + " (" + p + "%)\n" + bar(p) + "\n`",

    { parse_mode: "Markdown" }

  );

const ensureExportDefault = (code, originalCode) => {

  // Kalau sudah ada ekspor → biarkan

  if (/\bexport\s+(default|const|function|class)\b/.test(originalCode)) return code;

  // Jika pakai module.exports = something

  const matchCommonJS = originalCode.match(/module\.exports\s*=\s*([a-zA-Z0-9_$]+)/);

  if (matchCommonJS) {

    const varName = matchCommonJS[1];

    return code + `\n\nexport default ${varName};`;

  }

  // Kalau tidak ada ekspor sama sekali

  return code + `\n\nexport default {};`;

};

export default {

  command: ["encarab"],

  tags: ["enc"],

  desc: "Enkripsi file JS pakai charset Arab (Hardened)",

  handler: async (ctx) => {

    const d = ctx.message?.reply_to_message?.document;

    if (

      !d ||

      !/\.(js|cjs|mjs|ts)$/i.test(d.file_name) ||

      d.file_size > 20 * 1024 * 1024

    ) {

      return ctx.replyWithMarkdown(

        "⚠️ *Balas file JS/CJS/MJS/TS maksimal 20MB dengan perintah `/encarab`*"

      );

    }

    const tmp = path.join(

      process.cwd(),

      `linqiye-encrypted-${d.file_name}`

    );

    try {

      const prog = await ctx.replyWithMarkdown(

        "```⚡ Lin-Qiye\n🔒 ArabEncryptor\n⚙️ Memulai (1%)\n" + bar(1) + "\n```"

      );

      const link = await ctx.telegram.getFileLink(d.file_id);

      const raw = await (await fetch(link.href)).text();

      await upd(ctx, prog, 20, "Mengunduh Selesai");

      // Jika bukan ESM, validasi via Function

      const isESM = /\b(import|export)\b/.test(raw);

      if (!isESM) new Function(raw);

      await upd(ctx, prog, 30, "Validasi");

      const obf = await JsConfuser.obfuscate(raw, getArabObf());

      let code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Transformasi");

      code = ensureExportDefault(code, raw); // Sisipkan export default

      await fs.writeFile(tmp, code);

      await upd(ctx, prog, 80, "Finalisasi");

      if (!isESM) new Function(code);

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: tmp,

          filename: `linqiye-encrypted-${d.file_name}`,

        },

        {

          caption: "✅ *Berhasil terenkripsi oleh Lin-Qiye ⚡*",

          parse_mode: "Markdown",

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      console.error(e);

      ctx.reply(`❌ ${e.message}`);

    } finally {

      if (await fs.pathExists(tmp)) await fs.remove(tmp);

    }

  },

};