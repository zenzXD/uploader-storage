import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

import { fileURLToPath } from "url";

// ⛓️ Path ESM

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

/* ── PRESET JAPAN × ARAB ── */

const mix = [

  "あ","い","う","え","お","か","き","く","け","こ","さ","し","す","せ","そ",

  "た","ち","つ","て","と","な","に","ぬ","ね","の","は","ひ","ふ","へ","ほ",

  "ま","み","む","め","も","や","ゆ","よ","ら","り","る","れ","ろ","わ","を","ん",

  "أ","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"

];

const genMix = () =>

  Array.from({ length: Math.floor(Math.random() * 4) + 3 }, () =>

    mix[Math.floor(Math.random() * mix.length)]

  ).join("");

const getJpxArabObf = () => ({

  target: "node",

  compact: true,

  renameVariables: true,

  renameGlobals: true,

  identifierGenerator: genMix,

  stringEncoding: true,

  stringSplitting: true,

  controlFlowFlattening: 0.95,

  flatten: true,

  shuffle: true,

  dispatcher: true,

  duplicateLiteralsRemoval: true,

  deadCode: true,

  calculator: true,

  opaquePredicates: true,

  lock: {

    selfDefending: true,

    antiDebug: true,

    integrity: true,

    tamperProtection: true

  }

});

/* ── UTIL ── */

const bar = (p) => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ " + l + " (" + p + "%)\n " + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  );

// Tambahkan export default jika perlu

const ensureExportDefault = (code, raw) => {

  if (/\bexport\s+(default|const|function|class)\b/.test(raw)) return code;

  const match = raw.match(/module\.exports\s*=\s*([a-zA-Z0-9_$]+)/);

  if (match) return code + `\n\nexport default ${match[1]};`;

  return code + `\n\nexport default {};`;

};

/* ── PLUGIN EXPORT ── */

export default {

  command: ["encjapxab"],

  tags: ["enc"],

  desc: "Enkripsi JavaScript dengan preset Japan × Arab",

  handler: async (ctx) => {

    const doc = ctx.message?.reply_to_message?.document;

    const allowedExt = [".js", ".mjs", ".cjs", ".ts", ".typescript"];

    if (!doc || !allowedExt.some(ext => doc.file_name.endsWith(ext)) || doc.file_size > 20 * 1024 * 1024) {

      return ctx.replyWithMarkdown("❌ *Balas file .js/.ts/.mjs (maks. 20MB) dengan `/encjapxab`*");

    }

    const out = path.join(__dirname, `linqiye-encrypted-${doc.file_name}`);

    try {

      const prog = await ctx.replyWithMarkdown(

        "```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ Memulai (Japan × Arab Mode) (1%)\n " + bar(1) + "\n```"

      );

      const link = await ctx.telegram.getFileLink(doc.file_id);

      const raw = await (await fetch(link.href)).text();

      await upd(ctx, prog, 20, "Mengunduh selesai");

      const isESM = /\b(import|export)\b/.test(raw);

      if (!isESM) new Function(raw); // Validasi awal jika bukan ESM

      await upd(ctx, prog, 30, "Validasi selesai");

      const obf = await JsConfuser.obfuscate(raw, getJpxArabObf());

      let code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Transformasi selesai");

      code = ensureExportDefault(code, raw);

      await fs.writeFile(out, code);

      await upd(ctx, prog, 80, "Menyimpan file");

      if (!isESM) new Function(code); // Validasi hasil jika bukan ESM

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: out,

          filename: `linqiye-encrypted-${doc.file_name}`

        },

        {

          caption: "✅ *Japan × Arab encrypted by Lin Qiye!*",

          parse_mode: "Markdown"

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      console.error("JP×AR obfuscation error:", e.message);

      await ctx.reply(`❌ ${e.message}`);

    } finally {

      if (await fs.pathExists(out)) await fs.remove(out);

    }

  }

};