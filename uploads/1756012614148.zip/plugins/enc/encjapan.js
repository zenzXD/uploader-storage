import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

// 🇯🇵 Hiragana Obfuscator Generator

const jp = [

  "あ","い","う","え","お",

  "か","き","く","け","こ",

  "さ","し","す","せ","そ",

  "た","ち","つ","て","と",

  "な","に","ぬ","ね","の",

  "は","ひ","ふ","へ","ほ",

  "ま","み","む","め","も",

  "や","ゆ","よ",

  "ら","り","る","れ","ろ",

  "わ","を","ん"

];

const genJP = () =>

  Array.from({ length: Math.floor(Math.random() * 4) + 3 }, () =>

    jp[Math.floor(Math.random() * jp.length)]

  ).join("");

const getJPObf = () => ({

  target: "node",

  compact: true,

  renameVariables: true,

  renameGlobals: true,

  identifierGenerator: genJP,

  stringEncoding: true,

  stringSplitting: true,

  controlFlowFlattening: 0.9,

  flatten: true,

  shuffle: true,

  duplicateLiteralsRemoval: true,

  deadCode: true,

  calculator: true,

  opaquePredicates: true,

  lock: {

    selfDefending: true,

    antiDebug: true,

    integrity: true,

    tamperProtection: true

  }

});

// Progress bar

const bar = (p) => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ " + l + " (" + p + "%)\n " + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  );

// Menambahkan ekspor default jika tidak ada

const ensureExportDefault = (code, originalCode) => {

  // Jika sudah ada ekspor

  if (/\bexport\s+(default|const|function|class)\b/.test(originalCode)) return code;

  // Jika menggunakan CommonJS

  const match = originalCode.match(/module\.exports\s*=\s*([a-zA-Z0-9_$]+)/);

  if (match) {

    const varName = match[1];

    return code + `\n\nexport default ${varName};`;

  }

  // Jika tidak ada ekspor sama sekali

  return code + `\n\nexport default {};`;

};

export default {

  command: ["encjapan"],

  tags: ["enc"],

  desc: "Enkripsi JavaScript dengan Hiragana Obfuscator",

  handler: async (ctx) => {

    const d = ctx.message?.reply_to_message?.document;

    const allowedExt = [".js", ".mjs", ".cjs", ".ts", ".typescript"];

    if (

      !d ||

      !allowedExt.some(ext => d.file_name.endsWith(ext)) ||

      d.file_size > 20 * 1024 * 1024

    ) {

      return ctx.replyWithMarkdown("❌ *Balas file .js/.ts/.mjs (maks. 20MB) dengan `/encjapan`*");

    }

    const tmp = path.join(__dirname, `linqiye-encrypted-${d.file_name}`);

    try {

      const prog = await ctx.replyWithMarkdown(

        "```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ Memulai (Japan Mode) (1%)\n " + bar(1) + "\n```"

      );

      const link = await ctx.telegram.getFileLink(d.file_id);

      const raw = await (await fetch(link.href)).text();

      await upd(ctx, prog, 20, "Mengunduh selesai");

      const isESM = /\b(import|export)\b/.test(raw);

      if (!isESM) new Function(raw); // Validasi awal jika bukan ESM

      await upd(ctx, prog, 30, "Validasi selesai");

      const obf = await JsConfuser.obfuscate(raw, getJPObf());

      let code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Transformasi selesai");

      code = ensureExportDefault(code, raw); // Tambahkan ekspor jika perlu

      await fs.writeFile(tmp, code);

      await upd(ctx, prog, 80, "Menyimpan file");

      if (!isESM) new Function(code); // Validasi hasil jika bukan ESM

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: tmp,

          filename: `linqiye-encrypted-${d.file_name}`

        },

        {

          caption: "✅ *Japan encrypted by Lin Qiye!*",

          parse_mode: "Markdown"

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      console.error(e);

      await ctx.reply(`❌ ${e.message}`);

    } finally {

      if (await fs.pathExists(tmp)) await fs.remove(tmp);

    }

  }

};