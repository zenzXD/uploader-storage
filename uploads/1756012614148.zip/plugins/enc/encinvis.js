import fs from "fs-extra"

import path from "path"

import fetch from "node-fetch"

import JsConfuser from "js-confuser"

import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)

const __dirname = path.dirname(__filename)

// 🔒 Invisible preset generator

const genInvis = () => "_".repeat(Math.floor(Math.random() * 4) + 3) + Math.random().toString(36).slice(2, 5)

const getInvisObf = () => ({

  target: "node",

  compact: true,

  renameVariables: true,

  renameGlobals: true,

  identifierGenerator: genInvis,

  stringEncoding: true,

  stringSplitting: true,

  controlFlowFlattening: 0.95,

  shuffle: true,

  duplicateLiteralsRemoval: true,

  deadCode: true,

  calculator: true,

  opaquePredicates: true,

  lock: {

    selfDefending: true,

    antiDebug: true,

    integrity: true,

    tamperProtection: true

  }

})

// Progress bar

const bar = (p) => {

  const t = 20, f = Math.round(p / 5)

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`

}

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ " + l + " (" + p + "%)\n " + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  )

export default {

  command: ["encinvis"],

  tags: ["enc"],

  desc: "Enkripsi file dengan preset 'Invisible Hardened'",

  handler: async (ctx) => {

    const doc = ctx.message?.reply_to_message?.document

    const allowedExt = [".js", ".mjs", ".cjs", ".ts", ".typescript"]

    if (!doc || !allowedExt.some(ext => doc.file_name.endsWith(ext)) || doc.file_size > 20 * 1024 * 1024) {

      return ctx.replyWithMarkdown("❌ *Balas file .js/.ts/.mjs/.cjs (maks. 20MB) dengan perintah `/encinvis`*")

    }

    const out = path.join(__dirname, `linqiye-encrypted-${doc.file_name}`)

    try {

      const prog = await ctx.replyWithMarkdown("```Lin Qiye ⚡\n🔒 EncryptBot\n⚙️ Memulai (Invisible Hardened) (1%)\n " + bar(1) + "\n```")

      const link = await ctx.telegram.getFileLink(doc.file_id)

      const raw = await (await fetch(link.href)).text()

      await upd(ctx, prog, 20, "Mengunduh selesai")

      // Deteksi apakah mengandung import/export

      const isESM = /\b(import|export)\b/.test(raw)

      // Cek sintaks hanya jika bukan ESM

      if (!isESM) {

        new Function(raw) // bisa dicek langsung

        await upd(ctx, prog, 30, "Validasi selesai")

      } else {

        await upd(ctx, prog, 30, "Lewat validasi ESM")

      }

      const obf = await JsConfuser.obfuscate(raw, getInvisObf())

      const code = typeof obf === "string" ? obf : obf.code

      await upd(ctx, prog, 60, "Transformasi selesai")

      await fs.writeFile(out, code)

      await upd(ctx, prog, 80, "Menyimpan file")

      if (!isESM) {

        new Function(code) // validasi hasil jika bukan ESM

      }

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: out,

          filename: `linqiye-encrypted-${doc.file_name}`

        },

        {

          caption: "✅ *Invisible encrypted by Lin Qiye!*",

          parse_mode: "Markdown"

        }

      )

      await upd(ctx, prog, 100, "Selesai ✅")

    } catch (e) {

      await ctx.reply(`❌ ${e.message}`)

    } finally {

      if (await fs.pathExists(out)) await fs.remove(out)

    }

  }

}