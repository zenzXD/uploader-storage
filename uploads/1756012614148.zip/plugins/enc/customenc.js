import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

import { fileURLToPath } from "url";

// Path saat ini

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

// Logging & progress bar

const log = (...a) => console.log(new Date().toISOString(), ...a);

const bar = (p) => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```Saturn 🪐\n🔒 EncryptBot\n⚙️ " + l + ` (${p}%)\n ` + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  );

// Obfuscator config

const getCustomObf = (customName) => {

  const idGen = () => {

    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    let suf = "";

    for (let i = 0; i < Math.floor(Math.random() * 3) + 2; i++) {

      suf += chars[Math.floor(Math.random() * chars.length)];

    }

    return `${customName}_${suf}`;

  };

  return {

    target: "node",

    compact: true,

    renameVariables: true,

    renameGlobals: true,

    identifierGenerator: idGen,

    stringEncoding: true,

    stringSplitting: true,

    controlFlowFlattening: 0.75,

    shuffle: true,

    duplicateLiteralsRemoval: true,

    deadCode: true,

    opaquePredicates: true,

    lock: {

      selfDefending: true,

      antiDebug: true,

      integrity: true,

      tamperProtection: true,

    },

  };

};

// Export default handler

export default {

  command: ["customenc"],

  tags: ["enc"],

  desc: "Enkripsi JS dengan nama identifier kustom: /customenc <nama>",

  handler: async (ctx) => {

    const args = ctx.message.text.split(" ");

    if (args.length < 2 || !args[1]) {

      return ctx.replyWithMarkdown("❌ *Format:* `/customenc <nama>`");

    }

    const customName = args[1].replace(/[^a-zA-Z0-9_]/g, "");

    if (!customName) return ctx.reply("❌ Nama kustom tidak valid!");

    const doc = ctx.message?.reply_to_message?.document;

    if (!doc || !doc.file_name.endsWith(".js") || doc.file_size > 20 * 1024 * 1024) {

      return ctx.replyWithMarkdown("❌ *Balas file .js (maks. 20MB) dengan `/customenc <nama>`*");

    }

    const out = path.join(__dirname, `saturn-${customName}-encrypted-${doc.file_name}`);

    try {

      const prog = await ctx.replyWithMarkdown(

        "```Saturn 🪐\n🔒 EncryptBot\n⚙️ Memulai (" + customName + ") (1%)\n " + bar(1) + "\n```"

      );

      const link = await ctx.telegram.getFileLink(doc.file_id);

      const raw = await (await fetch(link.href)).text();

      await upd(ctx, prog, 20, "Mengunduh selesai");

      // Deteksi apakah mengandung import/export

      const isESM = /\b(import|export)\b/.test(raw);

      // Validasi hanya jika bukan ESM

      if (!isESM) {

        new Function(raw); // Validasi sintaks JS biasa

        await upd(ctx, prog, 30, "Validasi selesai");

      } else {

        await upd(ctx, prog, 30, "Lewati validasi (ESM)");

      }

      const obf = await JsConfuser.obfuscate(raw, getCustomObf(customName));

      const code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Obfuscasi selesai");

      await fs.writeFile(out, code);

      await upd(ctx, prog, 80, "Menyimpan file");

      if (!isESM) {

        new Function(code); // Validasi hasil obfuscation jika bukan ESM

      }

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: out,

          filename: `saturn-${customName}-encrypted-${doc.file_name}`,

        },

        {

          caption: `✅ *Custom \`${customName}\` encrypted!*`,

          parse_mode: "Markdown",

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      log("CustomEnc Error:", e.message);

      await ctx.reply(`❌ ${e.message}`);

    } finally {

      if (await fs.pathExists(out)) await fs.remove(out);

    }

  },

};