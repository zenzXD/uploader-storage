import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

import { fileURLToPath } from "url";

// Fix __dirname in ESM

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

/* ── STRONG preset ── */

const getStrongObf = () => ({

  target: "node",

  compact: true,

  renameVariables: true,

  renameGlobals: true,

  identifierGenerator: "randomized",

  stringEncoding: true,

  stringSplitting: true,

  controlFlowFlattening: 0.75,

  shuffle: true,

  duplicateLiteralsRemoval: true,

  calculator: true,

  dispatcher: true,

  deadCode: true,

  opaquePredicates: true,

  lock: {

    selfDefending: true,

    antiDebug: true,

    integrity: true,

    tamperProtection: true,

  },

});

/* ── util ── */

const stamp = (...x) => console.log(new Date().toISOString(), ...x);

const bar = (p) => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```Saturn 🪐\n🔒 EncryptBot\n ⚙️ " + l + " (" + p + "%)\n " + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  );

const ensureExportDefault = (code, raw) => {

  if (/\bexport\s+(default|const|function|class)\b/.test(raw)) return code;

  const match = raw.match(/module\.exports\s*=\s*([a-zA-Z0-9_$]+)/);

  if (match) return code + `\n\nexport default ${match[1]};`;

  return code + `\n\nexport default {};`;

};

/* ── plugin ── */

export default {

  command: ["encstrong"],

  tags: ["enc"],

  desc: "Enkripsi JavaScript dengan preset strong security",

  handler: async (ctx) => {

    const doc = ctx.message?.reply_to_message?.document;

    const allowedExt = [".js", ".ts", ".mjs", ".cjs"];

    if (

      !doc ||

      !allowedExt.some((ext) => doc.file_name.endsWith(ext)) ||

      doc.file_size > 20 * 1024 * 1024

    ) {

      return ctx.replyWithMarkdown(

        "❌ *Balas file .js/.ts/.mjs (maks. 20MB) dengan `/encstrong`*"

      );

    }

    const out = path.join(__dirname, `saturn-strong-encrypted-${doc.file_name}`);

    try {

      const prog = await ctx.replyWithMarkdown(

        "```Saturn 🪐\n🔒 EncryptBot\n ⚙️ Memulai (Hardened Strong) (1%)\n " + bar(1) + "\n```"

      );

      const fileLink = await ctx.telegram.getFileLink(doc.file_id);

      const raw = await (await fetch(fileLink.href)).text();

      await upd(ctx, prog, 20, "Mengunduh selesai");

      const isESM = /\b(import|export)\b/.test(raw);

      if (!isESM) new Function(raw); // Validasi awal (non-ESM)

      await upd(ctx, prog, 30, "Validasi selesai");

      const obf = await JsConfuser.obfuscate(raw, getStrongObf());

      let code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Transformasi selesai");

      code = ensureExportDefault(code, raw);

      await fs.writeFile(out, code);

      await upd(ctx, prog, 80, "Finalisasi");

      if (!isESM) new Function(code); // Validasi hasil (non-ESM)

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: out,

          filename: `saturn-strong-encrypted-${doc.file_name}`,

        },

        {

          caption: "✅ *Hardened Strong encrypted!* — SATURN 🔥",

          parse_mode: "Markdown",

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      stamp("Strong obfuscation error:", e.message);

      await ctx.reply(`❌ ${e.message}`);

    } finally {

      if (await fs.pathExists(out)) await fs.remove(out);

    }

  },

};