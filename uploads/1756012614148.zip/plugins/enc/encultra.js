import fs from "fs-extra";

import path from "path";

import fetch from "node-fetch";

import JsConfuser from "js-confuser";

import { fileURLToPath } from "url";

// __dirname untuk ESM

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);

/* ── ULTRA preset ── */

const getUltraObf = () => {

  const idGen = () => {

    const chars = "abcdefghijklmnopqrstuvwxyz";

    const nums = "0123456789";

    return (

      "z" +

      nums[Math.floor(Math.random() * nums.length)] +

      chars[Math.floor(Math.random() * chars.length)] +

      Math.random().toString(36).slice(2, 6)

    );

  };

  return {

    target: "node",

    compact: true,

    renameVariables: true,

    renameGlobals: true,

    identifierGenerator: idGen,

    stringCompression: true,

    stringEncoding: true,

    stringSplitting: true,

    controlFlowFlattening: 0.9,

    flatten: true,

    shuffle: true,

    rgf: true,

    deadCode: true,

    opaquePredicates: true,

    dispatcher: true,

    lock: {

      selfDefending: true,

      antiDebug: true,

      integrity: true,

      tamperProtection: true,

    },

  };

};

/* ── UTIL ── */

const log = (...a) => console.log(new Date().toISOString(), ...a);

const bar = (p) => {

  const t = 20, f = Math.round(p / 5);

  return "[" + "█".repeat(f) + " ".repeat(t - f) + `] ${p}%`;

};

const upd = (ctx, m, p, l) =>

  ctx.telegram.editMessageText(

    ctx.chat.id,

    m.message_id,

    undefined,

    "```Saturn 🪐\n🔒 EncryptBot\n ⚙️ " + l + " (" + p + "%)\n " + bar(p) + "\n```",

    { parse_mode: "Markdown" }

  );

// Tambah ekspor default jika tidak ada

const ensureExportDefault = (code, raw) => {

  if (/\bexport\s+(default|const|function|class)\b/.test(raw)) return code;

  const match = raw.match(/module\.exports\s*=\s*([a-zA-Z0-9_$]+)/);

  if (match) return code + `\n\nexport default ${match[1]};`;

  return code + `\n\nexport default {};`;

};

/* ── PLUGIN ── */

export default {

  command: ["encultra"],

  tags: ["enc"],

  desc: "Enkripsi JavaScript ultra-hardening SATURN",

  handler: async (ctx) => {

    const doc = ctx.message?.reply_to_message?.document;

    const allowedExt = [".js", ".ts", ".mjs", ".cjs"];

    if (

      !doc ||

      !allowedExt.some((ext) => doc.file_name.endsWith(ext)) ||

      doc.file_size > 20 * 1024 * 1024

    ) {

      return ctx.replyWithMarkdown(

        "❌ *Balas file .js/.ts/.mjs (maks. 20MB) dengan `/encultra`*"

      );

    }

    const out = path.join(__dirname, `saturn-ultra-encrypted-${doc.file_name}`);

    try {

      const prog = await ctx.replyWithMarkdown(

        "```Saturn 🪐\n🔒 EncryptBot\n ⚙️ Memulai (Hardened Ultra) (1%)\n " + bar(1) + "\n```"

      );

      const fileLink = await ctx.telegram.getFileLink(doc.file_id);

      const raw = await (await fetch(fileLink.href)).text();

      await upd(ctx, prog, 20, "Mengunduh selesai");

      const isESM = /\b(import|export)\b/.test(raw);

      if (!isESM) new Function(raw); // Validasi hanya jika bukan ESM

      await upd(ctx, prog, 30, "Memvalidasi");

      const obf = await JsConfuser.obfuscate(raw, getUltraObf());

      let code = typeof obf === "string" ? obf : obf.code;

      await upd(ctx, prog, 60, "Transformasi selesai");

      code = ensureExportDefault(code, raw);

      await fs.writeFile(out, code);

      await upd(ctx, prog, 80, "Finalisasi");

      if (!isESM) new Function(code); // Validasi hanya jika bukan ESM

      await ctx.telegram.sendDocument(

        ctx.from.id,

        {

          source: out,

          filename: `saturn-ultra-encrypted-${doc.file_name}`,

        },

        {

          caption: "✅ *Hardened Ultra encrypted!* — SATURN 🔥",

          parse_mode: "Markdown",

        }

      );

      await upd(ctx, prog, 100, "Selesai ✅");

    } catch (e) {

      log("Ultra obfuscation error:", e.message);

      await ctx.reply(`❌ ${e.message}`);

    } finally {

      if (await fs.pathExists(out)) await fs.remove(out);

    }

  },

};