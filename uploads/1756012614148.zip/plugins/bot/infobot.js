import os from 'os'

import fs from 'fs'

import path from 'path'

import prettyMs from 'pretty-ms'

import { config } from '../../config.js'

import { google } from 'googleapis'

const pkg = JSON.parse(fs.readFileSync('./package.json'))

function escape(str = '') {

  return str.replace(/[_*[\]()~`>#+=|{}.!\\-]/g, '\\$&')

}

function countPlugins(dir = './plugins') {

  let total = 0

  const files = fs.readdirSync(dir)

  for (const file of files) {

    const fullPath = `${dir}/${file}`

    if (fs.lstatSync(fullPath).isDirectory()) {

      total += countPlugins(fullPath)

    } else if (file.endsWith('.js')) {

      total++

    }

  }

  return total

}

function countFilesInDir(dir, ext = '.js') {

  if (!fs.existsSync(dir)) return 0

  return fs.readdirSync(dir).filter(file => file.endsWith(ext)).length

}

function countBroadcastTargets(type) {

  const dirPath = `./json/broadcast/${type}`

  if (!fs.existsSync(dirPath)) return 0

  const files = fs.readdirSync(dirPath)

  let total = 0

  for (const file of files) {

    const fullPath = path.join(dirPath, file)

    if (!file.endsWith('.json')) continue

    try {

      const data = JSON.parse(fs.readFileSync(fullPath))

      total += Array.isArray(data) ? data.length : 0

    } catch (e) {}

  }

  return total

}

function formatBytes(bytes) {

  const sizes = ['B', 'KB', 'MB', 'GB', 'TB']

  if (bytes === 0) return '0 B'

  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)))

  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`

}

// Ambil total user dari Google Sheets

async function getTotalUsersFromSheet() {

  try {

    const auth = new google.auth.GoogleAuth({

      keyFile: './credentials.json',

      scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly']

    })

    const client = await auth.getClient()

    const sheets = google.sheets({ version: 'v4', auth: client })

    const spreadsheetId = '1dyK_66DxSMQv1e-fng_bew8U2_oL898YwY3dHOKZdqg' // Ganti dengan ID Google Sheets

    const range = 'Users!A2:A' // Ambil user dari baris ke-2

    const res = await sheets.spreadsheets.values.get({ spreadsheetId, range })

    const rows = res.data.values

    return rows ? rows.length : 0

  } catch (err) {

    console.error('❌ Gagal ambil data dari Google Sheets:', err)

    return 0

  }

}

export default {

  command: ['infobot', 'aboutbot'],

  tags: ['bot'],

  desc: '🤖 Menampilkan informasi lengkap tentang bot',

  async handler(ctx) {

    const uptime = escape(prettyMs(process.uptime() * 1000, { verbose: true }))

    const pluginCount = countPlugins()

    const platform = escape(process.platform.toUpperCase())

    const arch = escape(process.arch)

    const cpuCore = os.cpus().length

    const deps = Object.keys(pkg.dependencies || {}).length

    const lastUpdate = escape(pkg.lastupdate || 'Belum diset')

    const changelog = pkg.changelog

      ? `📝 ${escape(pkg.changelog)}`

      : escape('⛔ Tidak ada changelog')

    const totalUsers = await getTotalUsersFromSheet()

    const totalGroups = countBroadcastTargets('group')

    const totalChannels = countBroadcastTargets('channel')

    const ramUsed = escape(formatBytes(os.totalmem() - os.freemem()))

    const ramTotal = escape(formatBytes(os.totalmem()))

    const totalCommands = countFilesInDir('./commands')

    const totalLib = countFilesInDir('./lib')

    const totalJson = countFilesInDir('./json', '.json')

    const totalPlugins = pluginCount

    const info = `

╭━━━〔 🤖 *INFO DONGHUA BOT* 〕━━━╮

┃ 🏷️ *Nama Bot:* ${escape(config.BOTNAME)}

┃ 👑 *Developer:* ${escape(config.OWNER_NAME)}

┃ 📦 *Versi:* v${escape(pkg.version)}

┃ 🔁 *Update Terakhir:* ${lastUpdate}

┃ 🔩 *Plugin Aktif:* ${pluginCount}

┃ 📚 *Dependencies:* ${deps}

┃ 👥 *Total User:* ${totalUsers}

┃ 👨‍👩‍👧‍👦 *Grup Tersimpan:* ${totalGroups}

┃ 📣 *Channel Tersimpan:* ${totalChannels}

┃ 🕐 *Uptime:* ${escape(prettyMs(process.uptime() * 1000))}

┃ 💻 *Platform:* ${platform}

┃ ⚙️ *Arsitektur:* ${arch}

┃ 🧮 *CPU Core:* ${cpuCore}

┃ 🧠 *RAM:* ${ramUsed} / ${ramTotal}

┃ 🔢 *Commands:* ${totalCommands}

┃ 🛠 *Modules:* ${totalLib}

┃ 📚 *JSON DB:* ${totalJson}

┃ 🧩 *Plugins:* ${totalPlugins}

╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

📌 *Changelog Terbaru:*

${changelog}

📚 *Gunakan:* /menu atau /botmenu untuk melihat fitur bot  

☕ *Jangan lupa donasi untuk bantu update dan support project ini ya!*  

📍 _Scan QRIS atau ketik /donasi untuk mendukung developer_

    `

    await ctx.reply(escape(info), { parse_mode: 'MarkdownV2' })

  }

}