import  logErrorToSheet  from '../../lib/loggerSheet.js';
import { config } from '../../config.js'; // OWNER_ID harus diset di config.js

export default {
  command: ['cataterror'],
  tags: ['bot'],
  desc: '📄 Catat error log ke Google Sheets (khusus developer)',
  handler: async (ctx) => {
    const isOwner = ctx.from?.id == config.OWNER_ID;
    if (!isOwner) {
      return ctx.reply('🚫 *Akses Ditolak!*\nFitur ini hanya dapat digunakan oleh *Owner Bot*.');
    }

    const plugin = ctx.args[0] || '❓ Tidak Diketahui';
    const errorMessage = ctx.args.slice(1).join(' ') || '📭 Tidak ada pesan error yang diberikan.';
    const userId = ctx.from?.id || 'unknown_id';
    const username = ctx.from?.username || ctx.from?.first_name || '-';

    try {
      await logErrorToSheet({
        plugin,
        userId,
        username,
        errorMessage
      });

      return ctx.reply(
`╭───〔 *🧾 ERROR LOGGER* 〕───╮
│ 🔧 *Plugin:* ${plugin}
│ 👤 *User:* ${username} \`(${userId})\`
│ 🐞 *Error:*
│ ${errorMessage}
╰✅ *Berhasil dicatat di Google Sheet!*`
      );
    } catch (err) {
      return ctx.reply(`❌ Gagal mencatat error: ${err.message}`);
    }
  }
};