import { google } from 'googleapis';

import fs from 'fs/promises';

import path from 'path';

// Path ke file kredensial Google Service Account

const CREDENTIALS_PATH = path.join(process.cwd(), 'credentials.json');

// ID Spreadsheet dan nama sheet

const SPREADSHEET_ID = '1V8PsmNbKxeFC_3qSOQNlMRY-9vp3jA8BN1ss7bYsIEg';

const SHEET_NAME = 'Tokens';

async function authGoogleSheets() {

  const content = await fs.readFile(CREDENTIALS_PATH, 'utf-8');

  const credentials = JSON.parse(content);

  const auth = new google.auth.GoogleAuth({

    credentials,

    scopes: ['https://www.googleapis.com/auth/spreadsheets'],

  });

  return google.sheets({ version: 'v4', auth });

}

async function appendTokenToSheet(token) {

  const sheets = await authGoogleSheets();

  // Data yang akan ditambahkan

  const values = [[token, new Date().toISOString()]];

  await sheets.spreadsheets.values.append({

    spreadsheetId: SPREADSHEET_ID,

    range: `${SHEET_NAME}!A:B`,

    valueInputOption: 'RAW',

    requestBody: { values },

  });

}

export default {

  command: ['addbot'],

  tags: ['bot'],

  desc: 'Tambah bot token ke Google Sheets',

  owner: true,

  async handler(ctx) {

    const input = ctx.message.text.split(' ').slice(1).join(' ').trim();

    if (!input) {

      return ctx.reply(

        `⚠️ *Format salah!*\n\n` +

        `Gunakan command:\n` +

        `\`/addbot <token>\`\n\n` +

        `Contoh:\n` +

        `\`/addbot 123abc456def789ghi\``,

        { parse_mode: 'Markdown' }

      );

    }

    try {

      await appendTokenToSheet(input);

      await ctx.reply(

        `┌─〔 *BOT TOKEN ADDED* 〕─\n` +

        `│ ✅ Token berhasil ditambahkan ke Google Sheets.\n` +

        `│ \n` +

        `│ 🕒 Ditambahkan pada: ${new Date().toLocaleString()}\n` +

        `└───────────────────────`,

        { parse_mode: 'Markdown' }

      );

    } catch (e) {

      console.error(e);

      await ctx.reply(

        `❌ *Gagal menyimpan ke Google Sheets!*\n\n` +

        `Error: ${e.message}`,

        { parse_mode: 'Markdown' }

      );

    }

  },

};