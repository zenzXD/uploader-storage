import { isVersionSatisfied, getCurrentVersion } from '../../lib/versionChecker.js'
import { Markup } from 'telegraf'

export default {
  command: ['fiturbaru'],
  tags: ['bot'],
  desc: '🔒 Fitur baru yang dikunci hingga versi tertentu',

  async handler(ctx) {
    const versiMinimal = '1.6.0'
    const currentVersion = await getCurrentVersion()
    const satisfy = await isVersionSatisfied(versiMinimal)

    if (!satisfy) {
      const pesan = `
╭━━━〔 🔒 *FITUR TERKUNCI* 〕━━━⬣
┃ 🚫 *Fitur ini belum tersedia di versi saat ini.*
┃ 
┃ 📌 *Versi minimal:* v${versiMinimal}
┃ 📦 *Versi bot kamu:* v${currentVersion}
┃
┃ 🔄 Silakan update bot untuk membuka fitur ini.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
      `.trim()

      return await ctx.reply(pesan, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.url('🔄 Cek Update Bot', 'https://t.me/LinQiye2')],
          [Markup.button.callback('🆘 Bantuan Update', 'help_update')]
        ])
      })
    }

    await ctx.reply(`
✅ *Fitur berhasil digunakan!*
Versi bot kamu: v${currentVersion} ✅ memenuhi syarat (v${versiMinimal}+)
`, { parse_mode: 'Markdown' })
  }
}