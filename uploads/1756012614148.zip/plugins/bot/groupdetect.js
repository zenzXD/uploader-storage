import { google } from 'googleapis';
import { config } from '../../config.js';

const sheetGroupsId = config.SHEET_GROUPS_ID;
const sheetWhitelistId = config.SHEET_WHITELISTS_ID;
const logGroupId = config.LOG_GROUP_ID;

async function getAuth() {
  const auth = new google.auth.GoogleAuth({
    keyFile: 'credentials.json',
    scopes: ['https://www.googleapis.com/auth/spreadsheets']
  });
  return await auth.getClient();
}

async function readCol(spreadsheetId, range) {
  const auth = await getAuth();
  const sheets = google.sheets({ version: 'v4', auth });
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range
  });
  return (res.data.values || []).flat();
}

async function appendRow(spreadsheetId, range, row) {
  const auth = await getAuth();
  const sheets = google.sheets({ version: 'v4', auth });
  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range,
    valueInputOption: 'USER_ENTERED',
    requestBody: { values: [row] }
  });
}

export default {
  command: ['cekgrup', 'whitelistgrup'],
  tags: ['group'],
  desc: '📌 Deteksi grup & manajemen whitelist via Google Sheets',

  async handler(ctx) {
    if (ctx.chat.type === 'private') return ctx.reply('❌ Perintah hanya bisa digunakan di grup.');

    const admins = await ctx.getChatAdministrators();
    const isAdmin = admins.some(a => a.user.id === ctx.from.id);

    const groupId = ctx.chat.id.toString();
    const groupName = ctx.chat.title || 'Tanpa Nama';

    const whitelist = await readCol(sheetWhitelistId, 'Whitelists!A:A');
    const isWl = whitelist.includes(groupId);

    if (ctx.command === 'cekgrup') {
      return ctx.reply(
        `📊 Info Grup:
🆔 ID: \`${groupId}\`
📛 Nama: *${groupName}*
👥 Jumlah Admin: ${admins.length}
📌 Status: ${isWl ? '✅ Whitelisted' : '❌ Tidak Terdaftar'}
`, { parse_mode: 'Markdown' });
    }

    if (ctx.command === 'whitelistgrup') {
      if (!isAdmin) return ctx.reply('🚫 Hanya admin yang bisa menambah whitelist.');
      if (isWl) return ctx.reply('⚠️ Grup sudah ada di whitelist.');

      await appendRow(sheetWhitelistId, 'Whitelists!A:A', [groupId]);
      return ctx.reply('✅ Grup berhasil ditambahkan ke whitelist.');
    }
  },

  async onJoin(ctx) {
    const groupId = ctx.chat.id.toString();
    const groupName = ctx.chat.title || 'Tanpa Nama';
    const admins = await ctx.getChatAdministrators();

    const whitelist = await readCol(sheetWhitelistId, 'Whitelists!A:A');
    const isWl = whitelist.includes(groupId);

    if (!isWl) {
      await ctx.reply('❌ Grup ini tidak terdaftar whitelist, saya keluar.');
      await ctx.leaveChat();
      return;
    }

    // Tambah ke sheet groups jika belum
    const groups = await readCol(sheetGroupsId, 'Groups!A:A');
    if (!groups.includes(groupId)) {
      await appendRow(sheetGroupsId, 'Groups!A:C', [
        groupId,
        groupName,
        new Date().toISOString()
      ]);
    }

    const mentions = admins
      .map(a => `• [${a.user.first_name}](tg://user?id=${a.user.id})`)
      .join('\n');
    const notif = `🛰 *Bot aktif di grup baru!*

📛 Grup: *${groupName}*
🆔 ID: \`${groupId}\`
👥 Admin: ${admins.length}
👮 Tag Admin:
${mentions}`;

    await ctx.reply(notif, { parse_mode: 'Markdown' });
    await ctx.telegram.sendMessage(
      logGroupId,
      `📥 Bot masuk grup:
📛 *${groupName}*
🆔 \`${groupId}\`
👥 Admin: ${admins.length}
✅ Status: Whitelisted`,
      { parse_mode: 'Markdown' }
    );
  }
};