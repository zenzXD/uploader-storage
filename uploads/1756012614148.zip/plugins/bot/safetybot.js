import fs from 'fs'
import { Markup } from 'telegraf'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

export default {
  command: ['safetybot'],
  tags: ['bot'],
  owner: true,
  desc: '🛡️ Mengecek dan mengamankan bot dari abuse, spam, dan banned',

  async handler(ctx) {
    // Ambil config log group
    const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../../config.json')))
    const logGroup = config.LOG_GROUP_ID || false

    // Ambil versi dari package.json
    const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '../../package.json')))
    const BOT_VERSION = pkg.version

    // Info bot
    const botInfo = await ctx.telegram.getMe()

    // Deteksi grup mencurigakan
    const suspiciousGroups = []
    const groupsFile = './json/groups.json'
    if (fs.existsSync(groupsFile)) {
      const groups = JSON.parse(fs.readFileSync(groupsFile))
      for (const group of groups) {
        if (!group.whitelisted) suspiciousGroups.push(group)
      }
    }

    const statusText = `
╭━━━〔 🛡️ *SAFETY STATUS BOT* 〕━━━╮
┃ 🤖 *Nama Bot:* ${botInfo.first_name}
┃ 🆔 *Username:* @${botInfo.username}
┃ 🛠️ *Versi:* ${BOT_VERSION}
┃ 
┃ 🚨 *Grup Mencurigakan:* ${suspiciousGroups.length}
┃ 🔒 *Proteksi Aktif:* 
┃   ┗ 🛑 Anti-Spam
┃   ┗ 🔗 Anti-Link
┃   ┗ 🧬 Anti-Bajak
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`.trim()

    // Kirim log ke grup log jika ada grup mencurigakan
    if (logGroup && suspiciousGroups.length) {
      await ctx.telegram.sendMessage(logGroup, `
🚨 *Deteksi Aktivitas Mencurigakan!*
📌 Terdapat *${suspiciousGroups.length}* grup tidak dikenal yang belum masuk whitelist.

Segera cek dan ambil tindakan manual atau otomatis via /safetybot.
`.trim(), { parse_mode: 'Markdown' })
    }

    // Inline tombol aksi cepat
    await ctx.reply(statusText, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🧹 Bersihkan Grup Asing', 'clear_suspicious_groups')],
        [Markup.button.url('📁 Panel Grup', 'https://t.me/yourpanel')],
        [Markup.button.callback('🔄 Reload Proteksi', 'reload_protection')]
      ])
    })
  }
}