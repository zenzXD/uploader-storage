import { spawn } from "child_process"

export default {

  command: ["restart", "reboot"],

  tags: ["bot"],

  desc: "Restart bot tanpa nodemon atau pm2",

  owner: true,

  async handler(ctx) {

    const progressMessage = await ctx.reply("🔄 Restarting bot...\n[░░░░░░░░░░] 0%\n\nMemulai proses restart...")

    const barLength = 10

    const getProgressBar = (percent) => {

      const filledLength = Math.floor((percent / 100) * barLength)

      const emptyLength = barLength - filledLength

      const filled = "█".repeat(filledLength)

      const empty = "░".repeat(emptyLength)

      return filled + empty

    }

    const getStatusText = (percent) => {

      if (percent < 30) return "Menghentikan layanan..."

      if (percent < 60) return "Menyiapkan ulang sumber daya..."

      if (percent < 90) return "Restarting proses bot..."

      if (percent < 100) return "Menutup proses..."

      return "Restart berhasil, menunggu bot online kembali..."

    }

    const delay = ms => new Promise(res => setTimeout(res, ms))

    let progress = 0

    while (progress < 100) {

      progress += 1

      if (progress > 100) progress = 100

      try {

        await ctx.telegram.editMessageText(

          ctx.chat.id,

          progressMessage.message_id,

          null,

          `🔄 Restarting bot...\n[${getProgressBar(progress)}] ${progress}%\n\n${getStatusText(progress)}`

        )

      } catch (e) {

        // ignore error kalau pesan sudah dihapus/diedit

      }

      const randomDelay = 50 + Math.floor(Math.random() * 50)

      await delay(randomDelay)

    }

    await ctx.reply("✅ Restart sukses, tunggu sebentar...")

    const subprocess = spawn(process.argv[0], [process.argv[1]], {

      stdio: "inherit",

      detached: true,

    })

    subprocess.unref()

    process.exit(0)

  }

}