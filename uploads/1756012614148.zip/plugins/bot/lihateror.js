import  lihatErrorTerakhir  from '../../lib/loggerSheet.js'
import { config } from '../../config.js'

export default {
  command: ['lihateror'],
  tags: ['bot'],
  desc: '📝 Melihat 10 error terakhir dari Google Sheets (khusus owner)',
  handler: async (ctx) => {
    const isOwner = ctx.from?.id == config.OWNER_ID
    if (!isOwner) 
      return ctx.reply('🚫 *Akses Ditolak!*\nFitur ini hanya bisa digunakan oleh *Owner Bot*.')

    const logs = await lihatErrorTerakhir()
    if (!logs.length)
      return ctx.reply('📭 Tidak ada log error ditemukan.')

    const pesan = logs.map((log, i) => {
      const [plugin, userId, username, errorMessage, waktu] = log
      return `*${i + 1}.* [${waktu}]
🔧 Fitur: *${plugin}*
👤 User: ${username} \`(${userId})\`
🐞 Error: ${errorMessage}`
    }).join('\n\n')

    return ctx.reply(`╭━━━〔 *📜 ERROR TERAKHIR* 〕━━━╮\n\n${pesan}`)
  }
}