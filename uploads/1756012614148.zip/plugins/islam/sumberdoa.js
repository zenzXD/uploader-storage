import fetch from "node-fetch";
import { Markup } from "telegraf";

export default {
    command: ["sumberdoa", "listsumberdoa", "doasumber"],
    tags: ["islam"],
    desc: "📚 Menampilkan daftar sumber doa yang tersedia",

    async handler(ctx) {
        try {
            const res = await fetch(
                "https://cloudku.us.kg/api/murotal/list/source/doa"
            );
            if (!res.ok) throw "Gagal mengakses sumber doa.";

            const data = await res.json();
            if (!Array.isArray(data) || data.length === 0) {
                return ctx.reply("⚠️ Tidak ada sumber doa tersedia.");
            }

            // Format list sumber doa
            const teks = `
╭───〔 📚 *DAFTAR SUMBER DOA* 〕───╮
${data.map((s, i) => `│ ${i + 1}. ${s}`).join("\n")}
╰────────────────────────────╯

Ketik: *caridoa [sumber]*
Contoh: \`caridoa Doa Harian\`
      `.trim();

            await ctx.reply(teks, {
                parse_mode: "Markdown",
                ...Markup.inlineKeyboard([
                    Markup.button.callback("🔍 Cari Doa", "trigger_search_doa")
                ])
            });
        } catch (err) {
            console.error(err);
            await ctx.reply("❌ Gagal memuat sumber doa.");
        }
    }
};
