import fetch from 'node-fetch'
import { Markup } from 'telegraf'

export default {
  command: ['searchdoa', 'caridoa', 'daftardoa'],
  tags: ['islam'],
  desc: '🔎 Menampilkan daftar doa yang bisa dicari',

  async handler(ctx) {
    try {
      const res = await fetch('https://cloudku.us.kg/api/murotal/search/doa')
      if (!res.ok) throw 'Gagal mengambil daftar doa.'

      const data = await res.json()
      if (!Array.isArray(data) || data.length === 0) {
        return ctx.reply('❌ Tidak ada daftar doa tersedia.')
      }

      // Format daftar
      const daftar = data
        .slice(0, 20) // Batasi 20 dulu
        .map((item, i) => `*${i + 1}. ${item.judul}*`)
        .join('\n')

      const teks = `
╭───〔 📖 *DAFTAR DOA* 〕───╮
│ Berikut ini daftar doa:
│
${daftar}
│
╰──── Ketik judul atau nomor
contoh: _doa 5_ atau _doa tidur_
      `.trim()

      // Kirim daftar dengan tombol refresh
      await ctx.reply(teks, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          Markup.button.callback('🔁 Refresh', 'refresh_doa_list')
        ])
      })
    } catch (err) {
      console.error(err)
      await ctx.reply('⚠️ Gagal mengambil daftar doa.')
    }
  }
}