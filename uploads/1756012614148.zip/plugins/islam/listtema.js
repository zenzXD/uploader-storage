import fetch from 'node-fetch'

export default {
  command: ['listtema', 'tema', 'temaislam'],
  tags: ['islam'],
  desc: '📚 Menampilkan daftar tema konten Islami',

  async handler(ctx) {
    try {
      const res = await fetch('https://cloudku.us.kg/api/murotal/themes')
      const data = await res.json()

      if (!Array.isArray(data) || data.length === 0) {
        return ctx.reply('⚠️ Tema tidak ditemukan.')
      }

      const teks = `
╭───〔 🌙 *DAFTAR TEMA ISLAMI* 〕───╮
${data.map((tema, i) => `│ ${i + 1}. ${tema}`).join('\n')}
╰────────────────────────────╯

Ketik:
- /caritema [nama tema]
Contoh:
- /caritema Doa Harian
      `.trim()

      await ctx.reply(teks)
    } catch (e) {
      console.error(e)
      ctx.reply('❌ Gagal memuat daftar tema.')
    }
  }
}