import fetch from 'node-fetch'

export default {
  command: ['doa', 'doaacak', 'randomdoa'],
  tags: ['islam'],
  desc: '🤲 Menampilkan doa pendek harian secara acak',

  async handler(ctx) {
    try {
      const res = await fetch('https://cloudku.us.kg/api/murotal/random/doa')
      if (!res.ok) throw 'Gagal mengambil data dari API'

      const data = await res.json()
      const teks = `
╭───〔 🤲 *Doa Harian Acak* 〕───╮
│
│ 📜 *Judul:* ${data?.judul || 'Tidak diketahui'}
│
│ 🕌 *Lafaz Arab:*
│ ${data?.arab || '-'}
│
│ 🌐 *Terjemahan Indonesia:*
│ ${data?.indo || '-'}
│
╰────────────────────────────╯
📌 _Amalkan dan sebarkan kebaikan._
      `
      await ctx.reply(teks.trim(), { parse_mode: 'Markdown' })
    } catch (err) {
      await ctx.reply('❌ Gagal mengambil doa. Coba beberapa saat lagi.')
      console.error(err)
    }
  }
}