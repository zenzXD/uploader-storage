import fetch from 'node-fetch'

export default {
  command: ['hadistarbain', 'arbain'],
  tags: ['islam'],
  desc: '📜 Menampilkan hadis acak dari Arbain Nawawi',

  async handler(ctx) {
    try {
      const res = await fetch('https://cloudku.us.kg/api/murotal/random/hadist/arbain')
      if (!res.ok) throw 'Gagal mengakses API'
      const data = await res.json()

      const teks = `
╭───〔 📖 *Hadis Arbain Nawawi* 〕───╮
│
│ 🏷️ *Nomor:* ${data?.no || 'Tidak diketahui'}
│
│ 📝 *Teks Arab:*
│ ${data?.arab || '-'}
│
│ 🌐 *Terjemahan:*
│ ${data?.id || '-'}
│
╰──────────────────────────────╯
📌 _Mari amalkan dan sebarkan ilmu._
      `

      await ctx.reply(teks.trim(), { parse_mode: 'Markdown' })
    } catch (err) {
      await ctx.reply('❌ Gagal mengambil hadis.\nCoba lagi nanti.')
      console.error(err)
    }
  }
}