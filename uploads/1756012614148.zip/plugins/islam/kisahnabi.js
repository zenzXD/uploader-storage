// plugins/islam/kisahnabi.js
import fetch from 'node-fetch'

export default {
  command: ['kisahnabi'],
  tags: ['islam'],
  desc: '📖 Menampilkan kisah Nabi berdasarkan nama',

  async handler(ctx) {
    const text = ctx.text?.trim()
    if (!text) {
      return ctx.reply(`💳 *PREMIUM BANKING ISLAMIC MODE*\n\n📌 Masukkan nama nabi!\nContoh: /kisahnabi adam`, { parse_mode: 'Markdown' })
    }

    try {
      const res = await fetch(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/main/data/kisahNabi/${text.toLowerCase()}.json`)
      if (!res.ok) throw new Error('Nabi tidak ditemukan.')

      const data = await res.json()

      const hasil = `
╭──────❏ *🕌 ISLAMIC BANKING ZONE* ❏──────╮
│ 👤 *Nama Nabi:* ${data.name}
│ 📅 *Tahun Lahir:* ${data.thn_kelahiran}
│ 🏞️ *Tempat:* ${data.tmp}
│ 🎂 *Usia:* ${data.usia} tahun
╰─────────────────────────────────────╯

╭───〔 📖 *PREMIUM KISAH* 〕───────╮
${data.description}
╰────────────────────────────────╯

*🔍 Tips:* Gunakan nama nabi kecil semua.
Contoh: /kisahnabi musa
`.trim()

      await ctx.reply(hasil, { parse_mode: 'Markdown' })
    } catch (e) {
      await ctx.reply(`❌ *Kisah tidak ditemukan!*\nPastikan nama nabi benar dan huruf kecil.\n\n📝 Contoh: /kisahnabi nuh`, { parse_mode: 'Markdown' })
    }
  }
}
