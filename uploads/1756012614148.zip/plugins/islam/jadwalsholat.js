import fetch from 'node-fetch'
import moment from 'moment-timezone'

export default {
  command: ['jadwalsholat', 'sholat'],
  tags: ['islam'],
  desc: '🕌 Menampilkan jadwal sholat dengan hiasan',

  async handler(ctx) {
    const args = ctx.text?.split(' ').slice(1)
    const kota = args.join(' ') || 'Jakarta'

    try {
      const res = await fetch(`https://zenzxz.dpdns.org/islam/jadwalsholat?kota=${encodeURIComponent(kota)}`)
      const json = await res.json()

      if (!json.status || !json.result) {
        return ctx.reply(`❌ Jadwal sholat untuk *${kota}* tidak ditemukan.`, { parse_mode: 'Markdown' })
      }

      const { kota: lokasi, provinsi, jadwal } = json.result

      const teks = `
╭───〔 🕌 *JADWAL SHOLAT HARI INI* 〕───⬣
┃ 📍 *Kota*     : *${lokasi}*
┃ 🗺️ *Provinsi* : *${provinsi}*
┃ 📅 *Tanggal*  : *${jadwal.tanggal}*
┣━━━━━━━━━━━━━━━━━━━━⬣
┃ 🌅 *Subuh*    : *${jadwal.subuh}*
┃ ☀️ *Dzuhur*   : *${jadwal.dzuhur}*
┃ 🌇 *Ashar*    : *${jadwal.ashar}*
┃ 🌆 *Maghrib*  : *${jadwal.maghrib}*
┃ 🌃 *Isya*     : *${jadwal.isya}*
╰────────────────────⬣
📌 Gunakan: \`/jadwalsholat [nama kota]\`
💡 Contoh: \`/jadwalsholat Medan\`
      `.trim()

      await ctx.reply(teks, { parse_mode: 'Markdown' })
    } catch (e) {
      console.error(e)
      await ctx.reply('❌ Gagal mengambil data jadwal sholat.', { parse_mode: 'Markdown' })
    }
  }
}