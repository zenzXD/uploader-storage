import fetch from 'node-fetch'

export default {
  command: ['hadistbukhari', 'bukhari'],
  tags: ['islam'],
  desc: '📜 Menampilkan hadis acak dari Shahih Bukhari',

  async handler(ctx) {
    try {
      const res = await fetch('https://cloudku.us.kg/api/murotal/random/hadist/bukhari')
      if (!res.ok) throw 'Gagal mengakses API'
      const data = await res.json()

      const teks = `
╭───〔 *📖 Hadis Shahih Bukhari* 〕───✧
│
│ 🕌 *No Hadis:* ${data?.no || 'Tidak diketahui'}
│
│ 📝 *Teks Arab:*
│ ${data?.arab || '-'}
│
│ 📘 *Terjemahan:*
│ ${data?.id || '-'}
│
╰─────────────────────────────╯
📌 _Gunakan ilmu ini dengan niat yang baik._
      `

      await ctx.reply(teks.trim(), { parse_mode: 'Markdown' })
    } catch (err) {
      await ctx.reply('❌ Gagal mengambil hadis.\nCoba lagi nanti.')
      console.error(err)
    }
  }
}