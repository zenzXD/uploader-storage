import fetch from 'node-fetch'

export default {
  command: ['asmaulhusna'],
  tags: ['islam'],
  desc: '🕌 Menampilkan Asmaul Husna (99 nama Allah)',

  async handler(ctx) {
    let teks = ctx.text?.split(' ').slice(1).join(' ')
    const url = 'https://api.npoint.io/0a21697cf8372f7fc1a8'

    try {
      const res = await fetch(url)
      const data = await res.json()

      if (!Array.isArray(data)) throw '❌ Format data tidak sesuai.'

      let start = 1, end = 99

      if (teks) {
        if (/^\d+$/.test(teks)) {
          start = end = parseInt(teks)
        } else if (/^\d+\s*-\s*\d+$/.test(teks)) {
          const [a, b] = teks.split('-').map(n => parseInt(n.trim()))
          start = a
          end = b
        }
        if (start < 1 || end > 99 || start > end) {
          return ctx.reply('⚠️ *Input tidak valid!*\nGunakan format seperti:\n`/asmaulhusna 1-10`\n`/asmaulhusna 45`', { parse_mode: 'Markdown' })
        }
      }

      let result = `╭───❑ *🕋 Asmaul Husna* ❑───╮\n│ 📖 Total: *${start == end ? 1 : end - start + 1}* dari 99 Nama Allah\n╰───────────────╯\n\n`

      for (let i = start - 1; i < end; i++) {
        const n = data[i]
        result += `*${i + 1}.* 🌟 *${n.arabic}* — _${n.latin}_\n     ➤ *Arti:* ${n.arti}\n\n`
      }

      result += `📿 Ketik: \`/asmaulhusna [nomor]\` atau \`/asmaulhusna [dari]-[sampai]\`\nContoh: \`/asmaulhusna 1-5\` atau \`/asmaulhusna 99\``

      await ctx.reply(result.trim(), { parse_mode: 'Markdown' })
    } catch (e) {
      console.error(e)
      await ctx.reply('❌ Terjadi kesalahan saat mengambil data Asmaul Husna.')
    }
  }
}