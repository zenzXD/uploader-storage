// plugins/islami/randomsurah.js

import fetch from 'node-fetch'

export default {

  command: ['surahacak', 'randomsurah'],

  tags: ['islam'],

  desc: '📖 Mendapatkan murotal acak dari Al-Qur\'an',

  async handler(ctx) {

    try {

      const res = await fetch('https://cloudku.us.kg/api/murotal/random/surah')

      const data = await res.json()

      if (!data?.status || !data?.result?.audio_url) {

        throw new Error('Gagal ambil murotal.')

      }

      const surah = data.result

      const caption = `

╭───〔 *📖 Surah Acak* 〕───⬣

│ 📜 *Surat:* ${surah.name_long} (${surah.name_id})

│ 🔢 *Nomor:* ${surah.number}

│ 🕋 *Golongan:* ${surah.revelation_id} (${surah.revelation_en})

│ 🧩 *Jumlah Ayat:* ${surah.number_of_verses}

│ 💠 *Arti:* ${surah.translation_id}

╰─────────────⬣

📝 *Tafsir Singkat:*

${surah.tafsir}

🎧 _Dibacakan oleh Mishary Rashid Alafasy_

`.trim()

      await ctx.replyWithMarkdown(caption)

      await ctx.replyWithAudio(

        { url: surah.audio_url },

        {

          title: surah.name_id,

          performer: "Mishary Rashid Alafasy",

        }

      )

    } catch (err) {

      console.error(err)

      await ctx.reply('❌ Gagal mengambil murotal.')

    }

  }

}