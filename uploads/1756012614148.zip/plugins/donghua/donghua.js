import fetch from "node-fetch"

import * as cheerio from "cheerio"

export default {

  command: ["donghua"],

  tags: ["anime"],

  desc: "📺 Cari info Donghua (anime China)",

  owner: false,

  group: false,

  async handler(ctx) {

    const query = ctx.body?.split(" ")?.slice(1)?.join(" ")

    if (!query) {

      return await ctx.reply("✨ *Cara Pakai:*\n`/donghua [judul donghua]`\n\n📌 *Contoh:*\n`/donghua Perfect World`", {

        parse_mode: "Markdown",

      })

    }

    await ctx.reply("🔎 *Sedang mencari informasi donghua...*\nMohon tunggu sebentar ya~", {

      parse_mode: "Markdown",

    })

    try {

      const res = await fetch(`https://kuramanime.vip/?s=${encodeURIComponent(query)}`)

      const html = await res.text()

      const $ = cheerio.load(html)

      const firstResult = $(".animepost").first()

      if (!firstResult.length) {

        return await ctx.reply("❌ *Oops! Donghua tidak ditemukan...*\nPastikan judul sudah benar ya!", {

          parse_mode: "Markdown",

        })

      }

      const title = firstResult.find("h2").text().trim()

      const link = firstResult.find("a").attr("href")

      const thumb = firstResult.find("img").attr("src")

      const detailRes = await fetch(link)

      const detailHtml = await detailRes.text()

      const $$ = cheerio.load(detailHtml)

      const desc = $$(".entry-content p").first().text().trim()

      const genre = $$(".genres-content").text().trim() || "-"

      const status = $$(".status-content").text().trim() || "-"

      const episode = $$(".eps").first().text().trim() || "?"

      const message = `*📺 Judul:* ${title}\n*🎬 Episode Terbaru:* ${episode}\n*📡 Status:* ${status}\n*🎭 Genre:* ${genre}\n\n*📝 Sinopsis:*\n${desc}\n\n🔗 [Tonton Sekarang](${link})`

      await ctx.replyWithPhoto({ url: thumb }, {

        caption: message,

        parse_mode: "Markdown",

      })

    } catch (e) {

      console.error(e)

      await ctx.reply("❌ *Gagal mengambil informasi donghua.*\nCoba lagi nanti ya!", {

        parse_mode: "Markdown",

      })

    }

  }

}