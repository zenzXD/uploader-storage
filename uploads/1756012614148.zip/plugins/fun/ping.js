export default {
  command: ['ping'],
  tags: ['fun'],
  desc: 'Cek respon bot.',
  handler: async (ctx) => {
    const start = Date.now();
    await ctx.reply('🏓 Pong!');
    const end = Date.now();
    await ctx.reply(`⏱️ ${end - start}ms`);
  }
};