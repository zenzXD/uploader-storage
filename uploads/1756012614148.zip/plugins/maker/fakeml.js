import { createCanvas, loadImage, registerFont } from 'canvas';

import fs from 'fs';

import path from 'path';

import axios from 'axios';

export default {

  command: ['fakeml'],

  tags: ['maker'],

  desc: 'Buat fake profil Mobile Legends',

  usage: '/fakeml <nickname> (reply ke foto)',

  async handler(ctx) {

    try {

      const args = ctx.message.text?.split(' ').slice(1) || [];

      const nickname = args.join(' ') || 'Player';

      // Cek apakah ada foto yang direply atau dikirim langsung

      const reply = ctx.message.reply_to_message;

      const photo = ctx.message.photo || reply?.photo;

      if (!photo) {

        return ctx.reply('⚠️ Kirim `/fakeml <nickname>` sambil membalas atau mengirim foto.', { parse_mode: 'Markdown' });

      }

      await ctx.reply('⏳ Tunggu sebentar, sedang memproses...');

      // Download font jika belum ada

      const tmpDir = process.cwd();

      const fontPath = path.join(tmpDir, 'CL8QHRYN.ttf');

      if (!fs.existsSync(fontPath)) {

        const fontUrl = 'https://cloudkuimages.com/uploads/files/CL8QHRYN.ttf';

        const fontRes = await axios.get(fontUrl, { responseType: 'arraybuffer' });

        fs.writeFileSync(fontPath, Buffer.from(fontRes.data));

      }

      registerFont(fontPath, { family: 'CustomFont' });

      // Ambil file foto dari Telegram

      const fileId = photo[photo.length - 1].file_id;

      const fileLink = await ctx.telegram.getFileLink(fileId);

      const imgRes = await axios.get(fileLink.href, { responseType: 'arraybuffer' });

      const userImage = await loadImage(Buffer.from(imgRes.data));

      // Load background & frame

      const bg = await loadImage('https://files.catbox.moe/liplnf.jpg');

      const frame = await loadImage('https://files.catbox.moe/2vm2lt.png');

      // Buat canvas

      const canvas = createCanvas(bg.width, bg.height);

      const c = canvas.getContext('2d');

      // Gambar background

      c.drawImage(bg, 0, 0, canvas.width, canvas.height);

      // Hitung posisi avatar

      const avatarSize = 205;

      const frameSize = 293;

      const centerX = (canvas.width - frameSize) / 2;

      const centerY = (canvas.height - frameSize) / 2 - 282;

      const avatarX = centerX + (frameSize - avatarSize) / 2;

      const avatarY = centerY + (frameSize - avatarSize) / 2 - 3;

      // Crop & gambar avatar

      const { width, height } = userImage;

      const minSide = Math.min(width, height);

      const cropX = (width - minSide) / 2;

      const cropY = (height - minSide) / 2;

      c.drawImage(userImage, cropX, cropY, minSide, minSide, avatarX, avatarY, avatarSize, avatarSize);

      // Gambar frame

      c.drawImage(frame, centerX, centerY, frameSize, frameSize);

      // Tulis nickname

      const maxFontSize = 36;

      const minFontSize = 24;

      const maxChar = 11;

      let fontSize = maxFontSize;

      if (nickname.length > maxChar) {

        fontSize = Math.max(minFontSize, maxFontSize - (nickname.length - maxChar) * 2);

      }

      c.font = `${fontSize}px CustomFont`;

      c.fillStyle = '#ffffff';

      c.textAlign = 'center';

      c.fillText(nickname, canvas.width / 2 + 13, centerY + frameSize + 15);

      // Kirim hasil

      const buffer = canvas.toBuffer('image/png');

      await ctx.replyWithPhoto({ source: buffer }, { caption: '✅ Selesai!' });

    } catch (err) {

      console.error(err);

      ctx.reply(`❌ Terjadi kesalahan: ${err.message}`);

    }

  }

};