export default {

  command: ['poll', 'polling'],

  tags: ['group'],

  desc: '📊 Buat polling dengan pilihan jawaban',

  async handler(ctx) {

    const { message, args, chat } = ctx

    const isGroup = chat?.type?.endsWith('group')

    if (!isGroup) {

      return ctx.reply('❗ Command ini hanya bisa digunakan di grup.')

    }

    if (args.length < 3) {

      return ctx.reply(`📊 *Format penggunaan:*

/poll [pertanyaan]; [pilihan 1]; [pilihan 2]; [pilihan 3]; dst

Contoh:

/poll Siapa ketua kita?; Reyzz; Lin Qiye; Admin`)

    }

    const full = args.join(' ')

    const parts = full.split(';').map(v => v.trim()).filter(Boolean)

    const question = parts[0]

    const options = parts.slice(1)

    if (options.length < 2 || options.length > 10) {

      return ctx.reply('❗ Polling harus memiliki minimal 2 dan maksimal 10 pilihan.')

    }

    try {

      await ctx.telegram.sendPoll(chat.id, question, options, {

        is_anonymous: false,

        allows_multiple_answers: false

      })

    } catch (err) {

      console.error(err)

      ctx.reply('❌ Gagal mengirim polling.')

    }

  }

}