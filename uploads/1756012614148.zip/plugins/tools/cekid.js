import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const paths = {
  user: path.join(__dirname, '..', '..', 'json', 'users.json'),
  group: path.join(__dirname, '..', '..', 'json', 'groups.json'),
  channel: path.join(__dirname, '..', '..', 'json', 'channels.json'),
}

// Pastikan semua DB JSON ada
for (const key in paths) {
  if (!fs.existsSync(paths[key])) {
    fs.writeFileSync(paths[key], JSON.stringify([]))
  }
}

function saveToJson(filePath, newData, matchKey = 'id') {
  let db = []
  try {
    db = JSON.parse(fs.readFileSync(filePath))
  } catch (e) {}
  const index = db.findIndex(d => d[matchKey] === newData[matchKey])
  if (index === -1) db.push(newData)
  else db[index] = { ...db[index], ...newData }
  fs.writeFileSync(filePath, JSON.stringify(db, null, 2))
}

export default {
  command: ['cekid'],
  tags: ['tools'],
  desc: '🛠️ Cek dan simpan ID user, grup, atau channel',

  async handler(ctx) {
    try {
      const msg = ctx.message
      const chat = msg.chat
      const from = msg.from

      const waktu = new Date().toISOString()

      // Save user
      if (from && ['private', 'group', 'supergroup'].includes(chat.type)) {
        const userData = {
          id: from.id,
          first_name: from.first_name || '',
          last_name: from.last_name || '',
          username: from.username || '',
          type: chat.type,
          last_seen: waktu
        }
        saveToJson(paths.user, userData)
      }

      // Save group
      if (chat.type === 'group' || chat.type === 'supergroup') {
        const groupData = {
          id: chat.id,
          title: chat.title || '',
          type: chat.type,
          updated_at: waktu
        }
        saveToJson(paths.group, groupData)
      }

      // Save channel
      if (chat.type === 'channel') {
        const channelData = {
          id: chat.id,
          title: chat.title || '',
          type: chat.type,
          updated_at: waktu
        }
        saveToJson(paths.channel, channelData)
      }

      // Format output
      let title = ''
      let infoText = ''

      if (chat.type === 'private') {
        const name = `${from.first_name || ''} ${from.last_name || ''}`.trim()
        title = '🧍 INFO PENGGUNA'
        infoText = `
👤 *Nama:* ${name}
🔖 *Username:* @${from.username || '-'}
🆔 *User ID:* \`${from.id}\`
💬 *Chat Type:* Private
📅 *Terakhir Aktif:* ${new Date().toLocaleString('id-ID')}
        `.trim()
      } else {
        title = chat.type === 'channel' ? '📣 INFO CHANNEL' : '👥 INFO GRUP'
        infoText = `
🏷️ *Nama:* ${chat.title || '-'}
🆔 *${chat.type === 'channel' ? 'Channel ID' : 'Group ID'}:* \`${chat.id}\`
💬 *Chat Type:* ${chat.type.charAt(0).toUpperCase() + chat.type.slice(1)}
📅 *Waktu:* ${new Date().toLocaleString('id-ID')}
        `.trim()
      }

      const finalText = `
╭───[ ${title} ]
${infoText}
╰───────────────

✅ Data berhasil disimpan ke database.
`.trim()

      await ctx.reply(finalText, { parse_mode: 'Markdown' })

    } catch (e) {
      console.error('❌ CekID error:', e)
      ctx.reply('❌ Gagal cek ID.')
    }
  }
}