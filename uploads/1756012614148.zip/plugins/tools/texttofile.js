import fs from "fs"

import path from "path"

import { fileURLToPath } from "url"

import mime from "mime-types"

const __filename = fileURLToPath(import.meta.url)

const __dirname = path.dirname(__filename)

export default {

  command: ["texttofile", "ttf"],

  tags: ["tools"],

  desc: "📄 Ubah teks menjadi file\nFormat: /texttofile namafile.js | isi file",

  owner: false,

  group: false,

  async handler(ctx) {

    const input = ctx.body?.split(" ")?.slice(1)?.join(" ")

    if (!input || !input.includes("|")) {

      return await ctx.reply(

        "╭──❖「 *📄 TEXT TO FILE* 」\n" +

        "│ Format: `/texttofile namafile.js | isi file`\n" +

        "│ Contoh: `/texttofile hello.js | console.log('Hi')`\n" +

        "╰──⏳ Menunggu input...",

        { parse_mode: "Markdown" }

      )

    }

    const [filenameRaw, ...contentArr] = input.split("|")

    const filename = filenameRaw.trim()

    const content = contentArr.join("|").trim()

    // Validasi nama file

    if (!filename.match(/^[\w.\-]+$/)) {

      return await ctx.reply("❌ Nama file tidak valid! Hanya huruf, angka, titik, strip, dan underscore.")

    }

    // Batas maksimal isi file (20 MB)

    const maxSize = 20 * 1024 * 1024

    const contentSize = Buffer.byteLength(content, "utf-8")

    if (contentSize > maxSize) {

      return await ctx.reply("⚠️ Ukuran file terlalu besar (maksimal 20 MB).")

    }

    // Siapkan folder temp

    const tempPath = path.join(__dirname, "../../temp")

    if (!fs.existsSync(tempPath)) fs.mkdirSync(tempPath)

    const filePath = path.join(tempPath, filename)

    try {

      // Tulis file

      fs.writeFileSync(filePath, content)

      // Preview isi file (maks 300 baris)

      const previewLines = content.split("\n").slice(0, 300).join("\n")

      const extension = path.extname(filename).slice(1)

      const mimeType = mime.lookup(extension) || "text/plain"

      const timeStr = new Date().toLocaleString("id-ID")

      await ctx.reply(

        "╭───❖「 *✅ FILE BERHASIL DIBUAT* 」\n" +

        `├ 📝 *Nama:* \`${filename}\`\n` +

        `├ 📂 *Tipe:* \`${mimeType}\`\n` +

        `├ 📦 *Ukuran:* \`${(contentSize / 1024).toFixed(2)} KB\`\n` +

        `├ 🕒 *Waktu:* \`${timeStr}\`\n` +

        "├ 📃 *Preview (maks 300 baris):*\n" +

        `╰───⬇️\n` +

        `\`\`\`${extension}\n${previewLines}\n\`\`\``,

        { parse_mode: "Markdown" }

      )

      // Kirim file ke user

      await ctx.replyWithDocument({ source: filePath, filename })

      // Hapus file setelah dikirim

      fs.unlinkSync(filePath)

    } catch (err) {

      console.error(err)

      await ctx.reply("❌ Gagal membuat file!")

    }

  },

}