import moment from 'moment-timezone'
import { appendRequestToSheet } from '../../lib/googleSheet.js'
import { config } from '../../config.js'

export default {
  command: ['req', 'request'],
  tags: ['tools'],
  desc: '🛠️ Kirim saran/fitur ke developer (tersimpan)',

  async handler(ctx) {
    const args = ctx.message?.text?.split(' ').slice(1)
    const text = args.join(' ')
    const user = ctx.from
    const isOwner = String(user.id) === String(config.OWNER_ID)

    if (args[0] === 'clear') {
      return await ctx.reply('❌ Fitur clear tidak tersedia karena data disimpan di Google Sheet.')
    }

    if (!text) {
      return await ctx.reply('❗ Contoh penggunaan:\n/req Tambahkan fitur musik', {
        parse_mode: 'Markdown',
      })
    }

    const username = user.username ? `@${user.username}` : `user_${user.id}`
    const waktu = moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')
    const asal = ctx.chat?.type?.includes('group')
      ? `${ctx.chat.title} (${ctx.chat.id})`
      : 'Chat Pribadi'

    const newRequest = {
      waktu,
      id: user.id,
      nama: user.first_name,
      username,
      asal,
      text,
    }

    try {
      await appendRequestToSheet(newRequest)
    } catch (err) {
      console.error('❌ Gagal menyimpan ke Google Sheet:', err)
      return await ctx.reply('⚠️ Gagal menyimpan permintaan. Coba lagi nanti.')
    }

    const notif = `
╭━━━[ 💡 Permintaan Baru Masuk ]━━━⬣
┃
┃ 🧑 Nama: ${user.first_name}
┃ 🔗 Username: ${username}
┃ 🆔 ID: \`${user.id}\`
┃
┃ 🌐 Asal: ${asal}
┃ 🕒 Tanggal: ${waktu}
┃
┃ 💬 Permintaan:
┃ \`\`\`
┃ ${text}
┃ \`\`\`
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━⬣
🔧 Dikirim via \`/req\`
`.trim()

    if (config.LOG_CHANNEL_ID) {
      try {
        await ctx.telegram.sendMessage(config.LOG_CHANNEL_ID, notif, {
          parse_mode: 'Markdown',
        })
      } catch (e) {
        console.error('❌ Gagal kirim ke channel log:', e.message)
      }
    }

    if (config.OWNER_ID) {
      try {
        await ctx.telegram.sendMessage(config.OWNER_ID, notif, {
          parse_mode: 'Markdown',
        })
      } catch (e) {
        console.error('❌ Gagal kirim ke owner:', e.message)
      }
    }

    await ctx.reply('✅ *Terima kasih!*\nPermintaanmu sudah dicatat di Google Sheet dan dikirim ke developer 💌', {
      parse_mode: 'Markdown',
    })
  },
}