import moment from 'moment-timezone';
import { config } from '../../config.js';

export default {
  command: ['wanumber', 'searchno', 'searchnumber'],
  tags: ['tools'],
  desc: '🔍 Cari nomor WA aktif berdasarkan pola',

  async handler(ctx) {
    const args = ctx.message.text.split(' ').slice(1);
    const text = args.join(' ');
    const reply = (text) => ctx.reply(
`╭───⌈ *SearchNumber Bot* ⌋
│
${text}
╰───────────────`, { parse_mode: 'Markdown' });

    if (!text) {
      return reply(`⚠️ *Masukkan nomor dengan huruf "x" sebagai digit acak!*\n\nContoh:\n\`${config.prefix}searchno 62812345xxx\``);
    }

    const inputnumber = text.split(' ')[0];

    function countInstances(string, word) {
      return string.split(word).length - 1;
    }

    const number0 = inputnumber.split('x')[0];
    const number1 = inputnumber.split('x')[countInstances(inputnumber, 'x')] || '';
    const random_length = countInstances(inputnumber, 'x');

    const total = 10 ** random_length;
    const digitSet = ['0', '1','2','3','4','5','6','7','8','9'];

    let resultText = `╭───📱 *Ditemukan Akun WhatsApp* ───\n│\n`;
    let noBio = `│\n├ 🚫 *Tanpa Bio:*\n`;
    let notFound = `│\n├ ❌ *Tidak ditemukan di WhatsApp:*\n`;

    await reply(`🔍 *Sedang mencari hingga* \`${total}\` *nomor...\``);

    for (let i = 0; i < total; i++) {
      const randomDigits = Array.from({ length: random_length }, () => digitSet[Math.floor(Math.random() * 10)]).join('');
      const fullNumber = `${number0}${randomDigits}${number1}`;
      const jid = `${fullNumber}@s.whatsapp.net`;

      try {
        const check = await ctx.bot.onWhatsApp(jid);
        if (!check?.length) {
          notFound += `│  • ${fullNumber}\n`;
          continue;
        }

        let status;
        try {
          status = await ctx.bot.fetchStatus(jid);
        } catch {
          status = null;
        }

        if (!status || !status.status) {
          noBio += `│  • wa.me/${fullNumber}\n`;
        } else {
          resultText += `│  🪀 *Nomor:* wa.me/${fullNumber}\n│  🎗️ *Bio:* ${status.status}\n│  ⏱️ *Update:* ${moment(status.setAt).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}\n│\n`;
        }
      } catch (e) {
        notFound += `│  • ${fullNumber}\n`;
      }
    }

    const output = 
`${resultText}${noBio}${notFound}╰─────────────────────`;

    ctx.reply(output, { parse_mode: 'Markdown' });

    // Tambah EXP
    if (global.db?.users) {
      const userId = String(ctx.from.id);
      if (!global.db.users[userId]) global.db.users[userId] = { exp: 0 };
      global.db.users[userId].exp += 300;
    }
  }
};