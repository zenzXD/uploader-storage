import axios from 'axios'

export default {
  command: ['nikparse'],
  tags: ['tools', 'info'],
  help: ['nikparse <NIK>'],
  desc: '🔎 Mengecek & mengurai informasi dari NIK Indonesia',

  async handler(ctx) {
    const text = ctx.text?.split(' ')?.slice(1)?.join(' ')
    if (!text || text.length < 16)
      return ctx.reply('⚠️ Contoh penggunaan:\n/nikparse 3175090402010003')

    const nik = text.trim()

    try {
      await ctx.reply('🔄 Sedang memproses NIK...')

      const res = await axios.get(`https://zenzxz.dpdns.org/tools/nikparse?nik=${nik}`)
      const data = res.data

      if (!data.status) return ctx.reply(`❌ Gagal mengambil data NIK.\n🧾 Pesan: ${data.message || 'Tidak diketahui.'}`)

      const {
        provinsi,
        kota,
        kecamatan,
        kodepos,
        kelamin,
        tanggal_lahir,
        umur
      } = data.result

      const teks = `
╭━━━〔 🆔 HASIL PARSING NIK 〕━━⬣
┃ 🧾 *NIK:* \`${nik}\`
┃ 🗓️ *Tanggal Lahir:* \`${tanggal_lahir}\`
┃ 🎂 *Umur:* \`${umur} tahun\`
┃ 🚻 *Jenis Kelamin:* \`${kelamin}\`
┃ 
┃ 🏙️ *Provinsi:* \`${provinsi}\`
┃ 🏘️ *Kota/Kabupaten:* \`${kota}\`
┃ 🏡 *Kecamatan:* \`${kecamatan}\`
┃ 📮 *Kode Pos:* \`${kodepos}\`
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

      await ctx.reply(teks, { parse_mode: 'Markdown' })

    } catch (err) {
      console.error(err)
      return ctx.reply('❌ Terjadi kesalahan saat mengambil data NIK.\nSilakan coba lagi nanti.')
    }
  }
}