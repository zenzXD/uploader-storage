// plugins/tools/get.js

import axios from 'axios'

import mime from 'mime-types'

import fs from 'fs/promises'

import path from 'path'

export default {

  command: ['get'],

  tags: ['tools'],

  desc: '🔗 Mengambil file dari URL dan mengirimkannya',

  

  async handler(ctx) {

    const args = ctx.message?.text?.split(' ').slice(1)

    const url = args?.[0]?.trim()

    if (!url || !/^https?:\/\//i.test(url)) {

      return await ctx.reply(

        '❗ Masukkan URL yang valid!\nContoh: `/get https://example.com/image.jpg`',

        { parse_mode: 'Markdown' }

      )

    }

    try {

      const res = await axios.get(url, {

        responseType: 'arraybuffer',

        headers: { 'User-Agent': 'LinQiyeBot/1.0 (+https://t.me/YourBot)' }

      })

      const contentType = res.headers['content-type'] || ''

      const buffer = Buffer.from(res.data)

      const ext = mime.extension(contentType) || 'bin'

      const filename = `fetched_${Date.now()}.${ext}`

      const tmpPath = path.join('/tmp', filename)

      if (/image\//.test(contentType)) {

        return await ctx.replyWithPhoto({ source: buffer }, {

          caption: `📸 Berhasil mengambil gambar dari:\n${url}`

        })

      }

      if (/audio\//.test(contentType)) {

        return await ctx.replyWithAudio({ source: buffer }, {

          title: filename,

          performer: '📥 From URL',

          caption: `🎵 Audio dari:\n${url}`

        })

      }

      if (/application\/json/.test(contentType)) {

        const json = JSON.parse(buffer.toString())

        const text = JSON.stringify(json, null, 2)

        return await ctx.replyWithMarkdown(`📄 JSON dari:\n\`\`\`json\n${text.slice(0, 3900)}\n\`\`\``)

      }

      if (/text\/html/.test(contentType)) {

        await fs.writeFile(tmpPath, buffer)

        await ctx.replyWithDocument({ source: tmpPath, filename }, {

          caption: `🌐 HTML dari:\n${url}`

        })

        return await fs.unlink(tmpPath)

      }

      await fs.writeFile(tmpPath, buffer)

      await ctx.replyWithDocument({ source: tmpPath, filename }, {

        caption: `📦 File dari:\n${url}`

      })

      await fs.unlink(tmpPath)

    } catch (err) {

      console.error('GET Error:', err)

      return await ctx.reply(`❌ Gagal mengambil file:\n${err.message}`)

    }

  }

}