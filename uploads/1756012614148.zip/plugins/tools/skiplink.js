import axios from 'axios'

export default {

  command: ['skiplink', 'skiplinksub4unlock'],

  tags: ['tools'],

  desc: '🔗 Skip link Sub4Unlock dan ambil direct link-nya',

  async handler(ctx) {

    const input = ctx.text?.split(' ')[1]

    const reply = (msg, opt) => ctx.reply(msg, opt)

    if (!input) {

      return reply(`❗ *Tautan tidak ditemukan!*

Gunakan perintah ini untuk mem-bypass tautan dari Sub4Unlock dan mendapatkan *direct link* tanpa iklan/subs.

📌 *Contoh penggunaan:*

\`\`\`

/skiplink https://sub4unlock.co/S9oU0

\`\`\``, {

        parse_mode: 'Markdown'

      })

    }

    await reply('⏳ *Memproses link kamu...*\nMohon tunggu sebentar...', {

      parse_mode: 'Markdown'

    })

    try {

      const api = `https://fgsi.koyeb.app/api/tools/skip/sub4unlock?apikey=fgsiapi-171dc826-6d&url=${encodeURIComponent(input)}`

      const { data: json } = await axios.get(api)

      if (!json.status || !json.data?.linkGo) {

        return reply('❌ *Link tidak valid!*\nPastikan itu adalah link dari *sub4unlock.co* dan coba lagi.', {

          parse_mode: 'Markdown'

        })

      }

      return reply(`✅ *Link berhasil di-skip!*

🔗 *Direct Link:*

${json.data.linkGo}

🎉 Selamat menikmati tanpa harus melewati iklan/sub4unlock!`, {

        parse_mode: 'Markdown',

        disable_web_page_preview: false

      })

    } catch (err) {

      console.error('Error skiplink:', err)

      return reply(`🚫 *Terjadi kesalahan saat memproses link:*

\`${err.message}\`

Silakan coba beberapa saat lagi.`, {

        parse_mode: 'Markdown'

      })

    }

  }

}