import axios from 'axios'
import { bold, italic } from 'telegraf/format'

export default {
  command: ['ffsearch', 'ffplayer'],
  tags: ['tools'],
  desc: '🔍 Cari data akun Free Fire berdasarkan nickname',
  
  async handler(ctx) {
    const args = ctx.message.text.split(' ').slice(1)
    const nickname = args.join(' ')

    if (!nickname) {
      return ctx.reply('⚠️ Mohon kirim nickname Free Fire-nya!\n\nContoh:\n`/ffsearch LinQiye`', { parse_mode: 'Markdown' })
    }

    try {
      await ctx.reply('🔍 Sedang mencari data akun FF...')

      const { data } = await axios.get(`https://discordbot.freefirecommunity.com/search_player_api?nickname=${encodeURIComponent(nickname)}`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
          'Accept': '*/*',
          'Referer': 'https://www.freefirecommunity.com/ff-player-search/'
        }
      })

      if (data?.error) {
        return ctx.reply(`❌ *Skill Issue:* ${data.error}`, { parse_mode: 'Markdown' })
      }

      let message = `🎮 *Hasil Pencarian Nickname:* _${nickname}_\n\n`

      data.forEach((player, index) => {
        const lastLogin = new Date(player.lastLogin * 1000).toLocaleDateString('id-ID')
        message += `*${index + 1}. ${player.nickname}*\n`
        message += `🆔 ID Akun: \`${player.accountId}\`\n`
        message += `📈 Level: ${player.level}\n`
        message += `🌍 Region: ${player.region}\n`
        message += `📅 Login Terakhir: ${lastLogin}\n\n`
      })

      ctx.reply(message.trim(), { parse_mode: 'Markdown' })
    } catch (e) {
      console.error(e)
      ctx.reply('❌ Terjadi kesalahan saat memproses data.')
    }
  }
}
