import fs from 'fs'
import path from 'path'
import Jimp from 'jimp'
import { performance } from 'perf_hooks'
import { fileURLToPath } from 'url'
import { downloadMediaMessage } from '../../lib/functions.js'
import { Markup } from 'telegraf'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const tmpDir = path.join(__dirname, '../../tmp')
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

export default {
  command: ['toimage', 'foto'],
  tags: ['tools'],
  desc: '🖼️ Ubah stiker atau WebP menjadi gambar dengan pilihan format (PNG, JPG, JPEG)',

  async handler(ctx) {
    const msg = ctx.message.reply_to_message
    if (!msg || (!msg.sticker && !msg.document && !msg.photo)) {
      return ctx.reply('📎 *Balas stiker, WebP, atau foto dengan perintah /toimage!*', { parse_mode: 'Markdown' })
    }

    let fileId = null
    if (msg.sticker) fileId = msg.sticker.file_id
    else if (msg.document && msg.document.mime_type === 'image/webp') fileId = msg.document.file_id
    else if (msg.photo) fileId = msg.photo.at(-1).file_id

    if (!fileId) return ctx.reply('❌ *Tidak ditemukan file yang bisa dikonversi!*', { parse_mode: 'Markdown' })

    const inputPath = path.join(tmpDir, `input-${ctx.message.message_id}.webp`)
    const outputPath = path.join(tmpDir, `output-${ctx.message.message_id}.png`)

    const start = performance.now()
    try {
      await downloadMediaMessage(ctx.telegram, fileId, inputPath)

      const image = await Jimp.read(inputPath)
      await image.writeAsync(outputPath)

      const stats = fs.statSync(outputPath)
      const fileSizeKB = (stats.size / 1024).toFixed(2)
      const { bitmap } = image
      const duration = (performance.now() - start).toFixed(1)

      const hiasan = `🖼️ *Konversi Gambar*\n\n` +
                     `📌 *Format:* PNG\n` +
                     `📐 *Ukuran:* ${bitmap.width}×${bitmap.height}px\n` +
                     `📁 *Size:* ${fileSizeKB} KB\n` +
                     `⏱️ *Waktu:* ${duration} ms`

      await ctx.replyWithPhoto({ source: outputPath }, {
        caption: hiasan,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [
            Markup.button.callback('🖼️ PNG', 'toimg_png'),
            Markup.button.callback('📷 JPG', 'toimg_jpg'),
            Markup.button.callback('🖼️ JPEG', 'toimg_jpeg'),
          ],
          [
            Markup.button.callback(`📏 ${bitmap.width}×${bitmap.height}`, 'no_action'),
            Markup.button.callback(`⏱️ ${duration} ms`, 'no_action')
          ]
        ])
      })

    } catch (e) {
      console.error(e)
      ctx.reply('❌ *Gagal mengubah gambar!*', { parse_mode: 'Markdown' })
    } finally {
      if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath)
      if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath)
    }
  }
}