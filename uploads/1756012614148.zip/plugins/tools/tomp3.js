// plugins/tools/tomp3.js
import axios from 'axios'
import FormData from 'form-data'
import { downloadMedia } from '../../lib/download.js' // pastikan punya ini
import fs from 'fs/promises'
import path from 'path'

async function tomp3(url) {
  const headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'Bearer null',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://www.freeconvert.com/mp3-converter/download'
  }

  const fname = url.split('/').pop()
  const datajob = {
    tasks: {
      import: {
        operation: "import/url",
        url: url,
        filename: fname
      },
      convert: {
        operation: "convert",
        input: "import",
        input_format: "mp4",
        output_format: "mp3",
        options: {
          audio_codec: "libmp3lame",
          audio_rate_control_mp3: "auto",
          audio_sample_rate_mp3_dts_ac3: "auto",
          audio_channel_mp3: "no-change",
          audio_filter_volume: 100,
          audio_filter_fade_in: false,
          audio_filter_fade_out: false,
          audio_filter_reverse: false
        }
      },
      "export-url": {
        operation: "export/url",
        input: "convert"
      }
    }
  }

  const procres = await axios.post('https://api.freeconvert.com/v1/process/jobs', datajob, { headers })
  const idjob = procres.data.id

  async function checkjobs() {
    const statsres = await axios.get(`https://api.freeconvert.com/v1/process/jobs/${idjob}`, { headers })

    if (statsres.data.status === 'completed') {
      const taskex = statsres.data.tasks.find(task => task.name === 'export-url')
      if (taskex?.result?.url) return taskex.result.url
      throw new Error('❌ URL MP3 tidak ditemukan!')
    }

    if (statsres.data.status === 'failed') throw new Error('❌ Proses konversi gagal!')

    await new Promise(resolve => setTimeout(resolve, 3000))
    return checkjobs()
  }

  return await checkjobs()
}

async function Uguu(buffer, filename) {
  const form = new FormData()
  form.append('files[]', buffer, { filename })

  const { data } = await axios.post('https://uguu.se/upload.php', form, {
    headers: form.getHeaders()
  })

  if (data.files?.[0]) {
    return {
      name: data.files[0].name,
      url: data.files[0].url,
      size: data.files[0].size
    }
  }

  throw new Error('❌ Upload video gagal!')
}

export default {
  command: ['tomp3'],
  tags: ['tools'],
  desc: '🎵 Konversi video menjadi MP3',
  async handler(ctx) {
    const q = ctx.message.reply_to_message
    const mime = q?.video ? 'video/mp4' : ''

    if (!mime.startsWith('video/')) {
      return ctx.reply('📼 Kirim atau reply video terlebih dahulu!')
    }

    const waiting = await ctx.reply('🔄 Sedang mengunduh video...')

    const buffer = await downloadMediaMessage(q)
    const tempPath = path.join('/tmp', `video_${Date.now()}.mp4`)
    await fs.writeFile(tempPath, buffer)

    try {
      await ctx.telegram.editMessageText(ctx.chat.id, waiting.message_id, null, '📤 Uploading video...')
      const uploaded = await Uguu(buffer, 'video.mp4')

      await ctx.telegram.editMessageText(ctx.chat.id, waiting.message_id, null, '🎧 Mengonversi ke MP3...')
      const mp3Url = await tomp3(uploaded.url)

      await ctx.telegram.editMessageText(ctx.chat.id, waiting.message_id, null, '✅ Selesai! Mengirim file...')

      await ctx.replyWithDocument(
        { url: mp3Url },
        {
          caption: '🎶 Berikut hasil konversi videonya ke MP3!',
          filename: 'hasil.mp3'
        }
      )
    } catch (e) {
      await ctx.telegram.editMessageText(ctx.chat.id, waiting.message_id, null, `❌ Terjadi kesalahan:\n${e.message}`)
    } finally {
      await fs.unlink(tempPath).catch(() => null)
    }
  }
}
