import fs from 'fs'
const userPath = './json/users.json'

function loadUsers() {
  if (!fs.existsSync(userPath)) fs.writeFileSync(userPath, '[]')
  return JSON.parse(fs.readFileSync(userPath))
}

export default {
  command: ['saldo'],
  tags: ['tools'],
  desc: '💳 Cek saldo kamu',
  async handler(ctx) {
    const senderId = ctx.senderId || ctx.from?.id?.toString() || 'unknown'
    const users = loadUsers()
    const user = users.find(u => u.id === senderId)

    if (!user) return ctx.reply('❗ Kamu belum terdaftar. Ketik /daftar untuk mendaftar.')

    return ctx.reply(`💰 Saldo kamu saat ini: *${user.saldo}* coin`, { parse_mode: 'Markdown' })
  }
}