import fetch from 'node-fetch'
import FormData from 'form-data'
import { config } from '../../config.js'

export default {
  command: ['deploy'],
  tags: ['tools'],
  desc: '🌐 Deploy script HTML atau ZIP ke subdomain',

  async handler(ctx) {
    try {
      const message = ctx.message
      const reply = message.reply_to_message
      const text = ctx.message.text?.split(' ').slice(1).join(' ')
      const quoted = reply || message
      const document = quoted?.document

      if (!document || (!document.mime_type.includes('zip') && !document.mime_type.includes('html'))) {
        return await ctx.reply('❌ *File tidak valid!*\nMohon reply ke file `.zip` atau `.html` untuk deploy.')
      }

      if (!text) return ctx.reply('❌ *Masukkan nama subdomain!*\nContoh: `/deploy botku123`')

      const inputName = text.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
      if (!/^[a-z0-9-]{3,64}$/.test(inputName)) {
        return ctx.reply('🚫 *Subdomain tidak valid!*\nGunakan huruf kecil, angka, dan strip (-).\nMinimal 3 karakter.')
      }

      const subdomain = inputName

      await ctx.reply('⏳ *Mengunduh file...*')

      const file = await ctx.telegram.getFileLink(document.file_id)
      const resFile = await fetch(file.href)
      const buffer = await resFile.buffer()

      await ctx.reply('🚀 *Mendeploy...*')

      const form = new FormData()
      form.append('subdomain', subdomain)
      form.append('file', buffer, {
        filename: document.file_name || 'project.zip'
      })

      const resApi = await fetch('https://apii.baguss.web.id/deploy', {
        method: 'POST',
        body: form
      })

      const json = await resApi.json()

      if (!json.success) {
        return ctx.reply(`❌ *Gagal deploy!*\n${json.message || 'Terjadi kesalahan pada server.'}`)
      }

      await ctx.replyWithMarkdown(
        `✅ *Berhasil Dideploy!*\n\n` +
        `🌍 Subdomain: \`${json.fullDomain}\`\n` +
        `🕐 Website aktif dalam *1–5 menit*.\n` +
        `🔁 Coba refresh jika belum muncul.\n`,
        {
          reply_markup: {
            inline_keyboard: [[
              { text: '🌐 Kunjungi Website', url: json.fullDomain }
            ]]
          }
        }
      )

    } catch (err) {
      await ctx.reply(`❌ *Error terjadi:*\n\`${err.message}\``, { parse_mode: 'Markdown' })
    }
  }
}
