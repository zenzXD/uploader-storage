import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const basePath = path.join(__dirname, '../../json/broadcast');

function getAllJsonFiles(type) {
  const folder = path.join(basePath, type);
  if (!fs.existsSync(folder)) return [];

  const files = [];

  function walk(dir) {
    fs.readdirSync(dir).forEach(file => {
      const fullPath = path.join(dir, file);
      if (fs.statSync(fullPath).isDirectory()) {
        walk(fullPath);
      } else if (file.endsWith('.json')) {
        files.push(fullPath);
      }
    });
  }

  walk(folder);
  return files;
}

function loadTargetsFromFiles(files) {
  const all = [];

  for (const file of files) {
    const content = JSON.parse(fs.readFileSync(file));
    const relPath = path.relative(basePath, file);
    const parts = relPath.split(path.sep);
    const type = parts[0];
    const category = parts[1];
    const tag = parts[2].replace('.json', '');

    for (const target of content) {
      all.push({
        ...target,
        file,
        category,
        tag,
        type,
      });
    }
  }

  return all;
}

export default (bot) => {
  bot.command('cekaktif', async (ctx) => {
    if (!ctx.isOwner) return ctx.reply('❌ Hanya Owner yang bisa menggunakan perintah ini.');

    const args = ctx.message.text.trim().split(' ');
    const type = args[1]?.toLowerCase();

    if (!['user', 'group', 'channel'].includes(type)) {
      return ctx.reply(`📊 Format salah!\nGunakan: /cekaktif [user|group|channel]`);
    }

    const files = getAllJsonFiles(type);
    if (!files.length) return ctx.reply(`📂 Tidak ada data pada kategori broadcast *${type}*`);

    const targets = loadTargetsFromFiles(files);
    if (!targets.length) return ctx.reply(`📂 File ditemukan, tapi tidak ada target untuk dicek.`);

    await ctx.reply(`🔍 Mengecek ${targets.length} ID dari *${files.length} file*...`, { parse_mode: 'Markdown' });

    const active = [];
    const failed = [];

    for (const target of targets) {
      try {
        await ctx.telegram.sendChatAction(target.id, 'typing');
        active.push(target);
      } catch (e) {
        failed.push(target);
      }
      await new Promise(r => setTimeout(r, 200));
    }

    let reply = `📋 *Hasil cek aktif* kategori *${type}*\n\n✅ Aktif: ${active.length}\n❌ Gagal: ${failed.length}\n\n`;

    if (active.length) {
      reply += `✅ *Aktif*\n` + active
        .map(u => `• \`${u.id}\` - ${u.name} (${u.category}/${u.tag})`).join('\n') + '\n\n';
    }

    if (failed.length) {
      reply += `❌ *Gagal*\n` + failed
        .map(u => `• \`${u.id}\` - ${u.name} (${u.category}/${u.tag})`).join('\n');
    }

    await ctx.reply(reply, { parse_mode: 'Markdown' });
  });
};