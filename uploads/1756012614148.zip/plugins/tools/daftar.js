import fs from 'fs'
import path from 'path'

const userPath = path.join('./json/users.json')
const logChannelId = '-1001234567890' // Ganti dengan ID channel log kamu

function loadUsers() {
  if (!fs.existsSync(userPath)) fs.writeFileSync(userPath, '[]')
  return JSON.parse(fs.readFileSync(userPath))
}

function saveUsers(data) {
  fs.writeFileSync(userPath, JSON.stringify(data, null, 2))
}

export default {
  command: ['daftar'],
  tags: ['tools'],
  desc: '📥 Daftar sebagai pengguna dan dapatkan saldo',

  async handler(ctx) {
    const senderId = ctx.from?.id?.toString()
    const name = ctx.from?.first_name || 'Pengguna'

    if (!senderId) return ctx.reply('❌ Gagal mengambil ID pengguna.')

    const users = loadUsers()
    if (users.find(u => u.id === senderId)) {
      return ctx.reply('✅ Kamu sudah terdaftar sebelumnya!')
    }

    // Minta umur
    await ctx.reply('🎂 Berapa umur kamu? (Balas angka saja)')

    ctx.session.awaitingAge = true
    ctx.session.tmpId = senderId
    ctx.session.tmpName = name
  },

  async onText(ctx) {
    if (ctx.session.awaitingAge) {
      const umur = parseInt(ctx.message.text)
      if (isNaN(umur)) {
        return ctx.reply('⚠️ Umur harus berupa angka. Coba lagi.')
      }
      if (umur < 13) {
        ctx.session.awaitingAge = false
        return ctx.reply('❌ Maaf, umur minimal untuk mendaftar adalah 13 tahun.')
      }

      const id = ctx.session.tmpId
      const name = ctx.session.tmpName

      const users = loadUsers()
      users.push({ id, name, umur, saldo: 1000, waktu: Date.now() })
      saveUsers(users)

      ctx.session.awaitingAge = false

      await ctx.reply(`🎉 Pendaftaran berhasil!\n👤 Nama: *${name}*\n🆔 ID: \`${id}\`\n🎂 Umur: *${umur}*\n💰 Saldo awal: *1000 coin*`, { parse_mode: 'Markdown' })

      // Kirim notifikasi ke channel log
      await ctx.telegram.sendMessage(logChannelId, `
📥 *Pengguna Baru Terdaftar!*
━━━━━━━━━━━━━━
👤 Nama: *${name}*
🆔 ID: \`${id}\`
🎂 Umur: *${umur}*
💰 Saldo Awal: *1000 coin*
🕒 Waktu: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
      `.trim(), { parse_mode: 'Markdown' })
    }
  }
}