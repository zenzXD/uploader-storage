export default {

  command: ['idtolink'],

  tags: ['tools'],

  desc: 'Ubah ID Telegram ke tautan klik (user, grup, channel)',

  async handler(ctx) {

    const arg = ctx.text?.split(' ')[1] || ''

    const reply = ctx.message?.reply_to_message

    const replyFrom = reply?.from

    const replyId = replyFrom?.id

    const replyName = replyFrom?.first_name + (replyFrom?.last_name ? ' ' + replyFrom.last_name : '')

    const id = arg || replyId?.toString()

    if (!id) return ctx.reply('⚠️ Kirim ID sebagai argumen atau reply pesan pengguna.')

    let link = ''

    let info = ''

    let displayName = ''

    if (id.startsWith('@')) {

      // Username publik

      const username = id.replace('@', '')

      link = `https://t.me/${username}`

      info = '🌐 *Username Publik*'

      displayName = `@${username}`

    } else if (id.startsWith('-100')) {

      // Grup/Channel Private

      const stripped = id.replace('-100', '')

      link = `https://t.me/c/${stripped}/1`

      info = '👥 *Grup / Channel*'

      displayName = `ID: \`${id}\``

    } else if (/^\d+$/.test(id)) {

      // User biasa

      link = `tg://user?id=${id}`

      info = '🙋‍♂️ *Pengguna Telegram*'

      displayName = replyName ? `${replyName}` : `ID: \`${id}\``

    } else {

      return ctx.reply('❌ Format ID tidak valid.\nGunakan reply, ID angka, atau @username.')

    }

    const msg = `

╭───╼〔 *ID to Link Converter* 〕

│

│ 📌 Tipe: ${info}

│ 👤 Nama: ${displayName}

│ 🔗 Tautan: [Klik untuk membuka](${link})

│

╰───╼ *Powered by Bot*

`

    await ctx.reply(msg.trim(), {

      parse_mode: 'Markdown',

      disable_web_page_preview: true

    })

  }

}