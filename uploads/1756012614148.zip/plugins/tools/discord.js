import { sendToDiscordWebhook } from '../../lib/discord.js';
import axios from 'axios';

export default {
  command: ['discord'],
  tags: ['tools'],
  desc: 'Kirim pesan atau media ke Discord via Webhook',

  /**
   * @param {import('telegraf').Context} ctx 
   */
  async handler(ctx) {
    const msgText = ctx.message?.text || '';
    const args = msgText.split(' ').slice(1).join(' ').trim();
    const webhook = ctx.config?.DISCORD_WEBHOOK_URL;

    if (!webhook || !/^https:\/\/discord\.com\/api\/webhooks\//.test(webhook)) {
      return ctx.reply('❌ DISCORD_WEBHOOK_URL belum diatur atau tidak valid.');
    }

    const userTag = ctx.from.username ? `@${ctx.from.username}` : `ID ${ctx.from.id}`;

    // Jika reply ke pesan media
    if (ctx.message?.reply_to_message) {
      const mediaMsg = ctx.message.reply_to_message;
      let fileId, fileType;

      if (mediaMsg.photo) {
        fileId = mediaMsg.photo[mediaMsg.photo.length - 1].file_id;
        fileType = 'photo';
      } else if (mediaMsg.video) {
        fileId = mediaMsg.video.file_id;
        fileType = 'video';
      } else if (mediaMsg.document) {
        fileId = mediaMsg.document.file_id;
        fileType = 'document';
      } else if (mediaMsg.audio) {
        fileId = mediaMsg.audio.file_id;
        fileType = 'audio';
      } else if (mediaMsg.voice) {
        fileId = mediaMsg.voice.file_id;
        fileType = 'voice';
      } else {
        return ctx.reply('❌ Jenis media tidak didukung.');
      }

      try {
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const fileUrl = fileLink.href;

        const embed = {
          title: '📦 Media dari Telegram',
          description: `👤 ${userTag}\n✉️ ${args || 'Tanpa teks tambahan.'}`,
          color: 0x00b0f4,
          ...(fileType === 'photo' && { image: { url: fileUrl } }),
          ...(fileType === 'video' && { video: { url: fileUrl } }),
        };

        const payload = {
          embeds: [embed],
          ...(fileType !== 'photo' && fileType !== 'video' && { content: `${userTag}: ${fileUrl}` }),
        };

        await axios.post(webhook, payload);
        return ctx.reply('✅ Media berhasil dikirim ke Discord!');
      } catch (err) {
        console.error(err);
        return ctx.reply('❌ Gagal mengirim media ke Discord.');
      }
    }

    // Jika hanya teks biasa
    if (!args) return ctx.reply('📩 *Contoh:* /discord Halo dari Telegram! (atau balas media)');

    const text = `📢 *Pesan dari Telegram*\n👤 ${userTag}\n✉️ ${args}`;
    const success = await sendToDiscordWebhook(webhook, text);

    return ctx.reply(success
      ? '✅ Pesan berhasil dikirim ke Discord!'
      : '❌ Gagal mengirim ke Discord.');
  }
};