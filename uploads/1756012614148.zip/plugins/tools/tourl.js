// plugins/tools/tourl.js

import fetch from 'node-fetch'

import fs from 'fs/promises'

import path from 'path'

import FormData from 'form-data'

import { config } from '../../config.js'

export default {

  command: ['tourl'],

  tags: ['tools'],

  desc: '🔗 Upload file (foto, video, dokumen, audio) dan dapatkan URL-nya',

  async handler(ctx) {

    const q = ctx.message?.reply_to_message

    if (!q || !(q.document || q.photo || q.video || q.audio)) {

      return await ctx.reply('📌 Balas file dengan perintah /tourl\n\nSupport: photo, video, document, audio')

    }

    const loadingMsg = await ctx.reply('⏳ Uploading file...')

    try {

      let fileId, fileName = 'file', mime = 'application/octet-stream'

      if (q.document) {

        fileId = q.document.file_id

        fileName = q.document.file_name || 'document'

        mime = q.document.mime_type || mime

      } else if (q.photo) {

        const photoList = q.photo

        fileId = photoList[photoList.length - 1].file_id

        fileName = 'photo.jpg'

        mime = 'image/jpeg'

      } else if (q.video) {

        fileId = q.video.file_id

        fileName = q.video.file_name || 'video.mp4'

        mime = q.video.mime_type || 'video/mp4'

      } else if (q.audio) {

        fileId = q.audio.file_id

        fileName = q.audio.file_name || 'audio.mp3'

        mime = q.audio.mime_type || 'audio/mpeg'

      }

      const fileLink = await ctx.telegram.getFileLink(fileId)

      const fileBuffer = await fetch(fileLink.href).then(res => res.buffer())

      const filename = `upload_${Date.now()}_${fileName}`

      const tempPath = `/tmp/${filename}`

      await fs.writeFile(tempPath, fileBuffer)

      const form = new FormData()

      form.append('file', await fs.readFile(tempPath), filename)

      const uploadRes = await fetch('https://cloudkuimages.guru/upload.php', {

        method: 'POST',

        body: form

      })

      const uploadJson = await uploadRes.json()

      if (!uploadJson?.status || !uploadJson?.data?.url) {

        throw new Error('Gagal upload ke cloudkuimages.guru')

      }

      const url = uploadJson.data.url

      const fileSize = (fileBuffer.length / 1024 / 1024).toFixed(2)

      const responseText = `✅ *File berhasil diupload!*

📁 *Filename:* ${fileName}

📦 *Size:* ${fileSize} MB

📄 *Type:* ${mime}

🔗 *URL:* ${url}`

      await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, undefined, responseText, {

        parse_mode: 'Markdown'

      })

      try {

        await fs.unlink(tempPath)

      } catch {}

    } catch (err) {

      const errorText = `❌ Upload gagal

Error: ${err.message}`

      try {

        await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, undefined, errorText)

      } catch {

        await ctx.reply(errorText)

      }

    }

  }

}