import fetch from 'node-fetch'

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

async function spamngl(link, pesan, jumlah) {
  if (!link.startsWith('https://ngl.link/')) throw new Error('❌ Link harus dimulai dengan https://ngl.link/')
  if (!pesan) throw new Error('❌ Pesan tidak boleh kosong.')
  if (isNaN(jumlah) || jumlah < 1) throw new Error('❌ Jumlah minimal harus 1')

  const username = link.split('https://ngl.link/')[1]
  if (!username) throw new Error('❌ Username tidak ditemukan dari link')

  for (let i = 0; i < jumlah; i++) {
    try {
      await fetch('https://ngl.link/api/submit', {
        method: 'POST',
        headers: {
          'accept': '*/*',
          'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
        },
        body: `username=${username}&question=${encodeURIComponent(pesan)}&deviceId=1`
      })
      await delay(1000)
    } catch (err) {
      console.error('❌ Gagal kirim:', err)
    }
  }

  return `✅ Berhasil kirim ${jumlah} pesan ke @${username}`
}

export default {
  command: ['spamngl'],
  tags: ['tools'],
  desc: 'Kirim spam pesan ke akun NGL.link',
  async handler(ctx) {
    let input = ctx.message.text.split(' ').slice(1).join(' ')
    if (!input.includes('|')) {
      return ctx.reply('📌 Format salah!\n\nContoh:\n`/spamngl https://ngl.link/username|5|halo ngl bot!`', { parse_mode: 'Markdown' })
    }

    let [link, jumlahStr, ...pesanArr] = input.split('|')
    let jumlah = parseInt(jumlahStr)
    let pesan = pesanArr.join('|').trim()

    ctx.reply('🕐 Tunggu sebentar, sedang mengirim pesan...')

    try {
      let hasil = await spamngl(link.trim(), pesan, jumlah)
      ctx.reply(hasil)
    } catch (e) {
      ctx.reply(`❌ Error: ${e?.message || e}`)
    }
  }
}