import AdmZip from 'adm-zip'

import fs from 'fs/promises'

import path from 'path'

import os from 'os'

// Animasi progress bar sederhana hitam putih

function progressBar(percent, length = 10) {

  const filledLength = Math.round((percent / 100) * length)

  const emptyLength = length - filledLength

  return '█'.repeat(filledLength) + ' '.repeat(emptyLength)

}

// Escape MarkdownV2

function escapeMarkdownV2(text) {

  return text.replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, '\\$&')

}

export default {

  command: ['filetozip'],

  tags: ['tools'],

  desc: 'Zip file yang kamu kirim (balas file dengan /filetozip) dan kirimkan hasil zip',

  async handler(ctx) {

    try {

      const message = ctx.message

      const reply = message.reply_to_message

      if (!reply || !reply.document) {

        return await ctx.reply('⚠️ Balas file dengan perintah /filetozip untuk mengompres menjadi ZIP')

      }

      const fileName = reply.document.file_name || 'file'

      const safeFileName = escapeMarkdownV2(fileName)

      const baseName = fileName.replace(/\.[^/.]+$/, "")

      const zipFileName = `${baseName}.zip`

      // Kirim pesan progress awal

      const progressMessage = await ctx.reply(`⏳ Mulai mendownload file untuk dikompres...\n\n[${progressBar(0)}] 0%`)

      // Download file

      const fileLink = await ctx.telegram.getFileLink(reply.document.file_id)

      const response = await fetch(fileLink.href)

      if (!response.ok) throw new Error('Gagal download file')

      const buffer = await response.arrayBuffer()

      // Temp folder

      const tempDir = path.join(os.tmpdir(), `filetozip_${ctx.chat.id}_${Date.now()}`)

      await fs.mkdir(tempDir, { recursive: true })

      // Simpan file asli

      const originalFilePath = path.join(tempDir, fileName)

      await fs.writeFile(originalFilePath, Buffer.from(buffer))

      await ctx.telegram.editMessageText(ctx.chat.id, progressMessage.message_id, null,

        `⏳ File berhasil didownload.\n\n[${progressBar(50)}] 50%`

      )

      // Buat zip

      const zip = new AdmZip()

      zip.addLocalFile(originalFilePath)

      const zipPath = path.join(tempDir, zipFileName)

      zip.writeZip(zipPath)

      await ctx.telegram.editMessageText(ctx.chat.id, progressMessage.message_id, null,

        `✅ File berhasil dikompres ke ZIP.\n\n[${progressBar(100)}] 100%`

      )

      // Kirim file ZIP

      await ctx.replyWithDocument({ source: zipPath }, { caption: `🗜️ File ZIP: ${safeFileName}`, parse_mode: 'MarkdownV2' })

      // Opsional hapus tempDir

      // await fs.rm(tempDir, { recursive: true, force: true })

    } catch (err) {

      await ctx.reply(`❌ Error saat compress ke ZIP: ${err.message}`)

    }

  }

}