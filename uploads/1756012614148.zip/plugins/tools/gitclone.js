import fetch from "node-fetch";
import { config } from "../../config.js";

export default {
    command: ["gitclone"],
    tags: ["tools"],
    desc: "📁 Clone repo GitHub dan kirim file zip",
    owner: false,
    premium: false,

    async handler(ctx) {
        const args = ctx.message.text.split(" ").slice(1);
        const reply = text =>
            ctx.reply(`┌─❖ *GitClone Bot*\n│\n${text}\n└─────────────`, {
                parse_mode: "Markdown"
            });

        if (!args[0])
            return reply(
                `│ ⚠️ *Dimana linknya?*\n│\n│ Contoh:\n│ \`${config.prefix}gitclone https://github.com/username/repo\``
            );

        if (!isValidGithubUrl(args[0]))
            return reply(
                `│ 🚫 *Link tidak valid!*\n│ Link harus mengandung \`github.com\``
            );

        const regex =
            /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;
        let [, user, repo] = args[0].match(regex) || [];
        if (!user || !repo)
            return reply("│ ❌ *Gagal mengekstrak user dan repo dari URL!*");

        repo = repo.replace(/.git$/, "");
        const zipUrl = `https://api.github.com/repos/${user}/${repo}/zipball`;

        try {
            const res = await fetch(zipUrl, { method: "HEAD" });
            const disposition = res.headers.get("content-disposition");
            const filename =
                disposition.match(/filename=(.*)/)?.[1] || `${repo}.zip`;

            await ctx.replyWithDocument(
                { url: zipUrl, filename: filename },
                {
                    caption:
                        `┌─❖ *GitHub Clone Result*\n│\n` +
                        `│ ✅ *Berhasil!* Repository berhasil di-*clone*.\n` +
                        `│ 📦 Repo: \`${user}/${repo}\`\n` +
                        `│ 📁 File: \`${filename}\`\n` +
                        `└─────────────`,
                    parse_mode: "Markdown"
                }
            );

            // Tambah EXP user (opsional)
            if (global.db?.users) {
                const userId = String(ctx.from.id);
                if (!global.db.users[userId])
                    global.db.users[userId] = { exp: 0 };
                global.db.users[userId].exp += 300;
            }
        } catch (err) {
            console.error(err);
            reply("│ ❌ *Terjadi kesalahan saat mengunduh ZIP dari GitHub!*");
        }
    }
};

// Utilitas
function isValidGithubUrl(url) {
    return /^https?:\/\/(www\.)?github\.com\/[^\/]+\/[^\/]+/i.test(url);
}
