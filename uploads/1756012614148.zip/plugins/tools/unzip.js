import AdmZip from 'adm-zip'

import fs from 'fs/promises'

import path from 'path'

import os from 'os'

// Fungsi rekursif untuk dapatkan semua file dalam folder (termasuk subfolder)

async function getAllFiles(dir) {

  let results = []

  const list = await fs.readdir(dir, { withFileTypes: true })

  for (const dirent of list) {

    const fullPath = path.join(dir, dirent.name)

    if (dirent.isDirectory()) {

      const subFiles = await getAllFiles(fullPath)

      results = results.concat(subFiles)

    } else if (dirent.isFile()) {

      results.push(fullPath)

    }

  }

  return results

}

// Fungsi buat animasi progress bar hitam putih

function progressBar(percent, length = 10) {

  const filledLength = Math.round((percent / 100) * length)

  const emptyLength = length - filledLength

  return '█'.repeat(filledLength) + ' '.repeat(emptyLength)

}

// Escape MarkdownV2 (tambahkan escape karakter minus/hyphen)

function escapeMarkdownV2(text) {

  return text.replace(/[_*[\]()~`>#+\-=|{}.!\\-]/g, '\\$&')

}

export default {

  command: ['unzip'],

  tags: ['tools'],

  desc: 'Unzip file ZIP yang kamu kirim dan otomatis kirim semua file hasil ekstrak dengan animasi progress hitam putih',

  async handler(ctx) {

    try {

      const message = ctx.message

      const reply = message.reply_to_message

      if (!reply || !reply.document) {

        return await ctx.reply('⚠️ Balas file ZIP dengan perintah /unzip')

      }

      const fileName = reply.document.file_name || ''

      if (!fileName.toLowerCase().endsWith('.zip')) {

        return await ctx.reply('⚠️ File yang dibalas bukan file ZIP')

      }

      // Kirim pesan awal dan simpan ID pesan untuk edit animasi progress

      const progressMessage = await ctx.reply(

        `⏳ Mulai mendownload dan mengekstrak file ZIP...\n\n[${progressBar(0)}] 0%`

      )

      const fileLink = await ctx.telegram.getFileLink(reply.document.file_id)

      const response = await fetch(fileLink.href)

      if (!response.ok) throw new Error('Gagal download file ZIP')

      const buffer = await response.arrayBuffer()

      // Simpan buffer ZIP ke temp file

      const tempDir = path.join(os.tmpdir(), `unzip_${ctx.chat.id}_${Date.now()}`)

      await fs.mkdir(tempDir, { recursive: true })

      const zipPath = path.join(tempDir, fileName)

      await fs.writeFile(zipPath, Buffer.from(buffer))

      // Update progress 30%

      try {

        await ctx.telegram.editMessageText(

          ctx.chat.id,

          progressMessage.message_id,

          null,

          `⏳ File ZIP berhasil di-download.\n\n[${progressBar(30)}] 30%`

        )

      } catch {}

      const zip = new AdmZip(zipPath)

      zip.extractAllTo(tempDir, true)

      // Update progress 60%

      try {

        await ctx.telegram.editMessageText(

          ctx.chat.id,

          progressMessage.message_id,

          null,

          `📂 File berhasil diekstrak.\n\n[${progressBar(60)}] 60%`

        )

      } catch {}

      // Ambil semua file (rekursif)

      const allFiles = await getAllFiles(tempDir)

      // Hapus file ZIP asli dari list kalau masih ada

      const files = allFiles.filter(f => path.basename(f) !== fileName)

      if (files.length === 0) {

        return await ctx.reply('⚠️ Tidak ada file biasa yang bisa dikirim setelah ekstrak.')

      }

      // Buat list file dengan path relatif agar lebih rapi dan escape markdown

      const relativeFiles = files.map(f => escapeMarkdownV2(path.relative(tempDir, f)))

      const safeFileName = escapeMarkdownV2(fileName.replace('.zip', ''))

      let replyText = `

📂 *File berhasil diekstrak!* 🎉

🗂️ *Isi folder "${safeFileName}" beserta subfoldernya:*

───────────────────────────────

${relativeFiles.map((f, i) => `📄 ${i + 1}. ${f}`).join('\n')}

───────────────────────────────

📥 *Mengirim file satu per satu, harap tunggu...*

      `.trim()

      await ctx.reply(replyText, { parse_mode: 'MarkdownV2' })

      // Kirim file satu per satu dengan progress animasi

      for (let i = 0; i < files.length; i++) {

        const f = files[i]

        const relativePath = relativeFiles[i]

        // Hitung progress persentase kirim file

        const percent = 60 + Math.floor(((i + 1) / files.length) * 40)

        try {

          await ctx.telegram.editMessageText(

            ctx.chat.id,

            progressMessage.message_id,

            null,

            `📤 Mengirim file ke-${i + 1} dari ${files.length}:\n` +

              `*${relativePath}*\n\n` +

              `[${progressBar(percent)}] ${percent}%`,

            { parse_mode: 'MarkdownV2' }

          )

        } catch {}

        try {

          await ctx.replyWithDocument({ source: f }, { caption: `📄 File: ${relativePath}`, parse_mode: 'MarkdownV2' })

          await new Promise(res => setTimeout(res, 800))

        } catch (e) {

          await ctx.reply(`❌ Gagal mengirim file ${relativePath}: ${e.message}`)

        }

      }

      // Setelah selesai, update pesan progress jadi 100%

      try {

        await ctx.telegram.editMessageText(

          ctx.chat.id,

          progressMessage.message_id,

          null,

          `✅ Semua file berhasil dikirim!\n\n[${progressBar(100)}] 100%`,

          { parse_mode: 'MarkdownV2' }

        )

      } catch {}

      // Opsional hapus folder tempDir

      // await fs.rm(tempDir, { recursive: true, force: true })

    } catch (err) {

      await ctx.reply(`❌ Error saat unzip: ${err.message}`)

    }

  }

}