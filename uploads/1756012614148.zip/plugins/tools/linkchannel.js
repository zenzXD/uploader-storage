export const command = ['linkchannel', 'linkch'];
export const tags = ['info'];
export const desc = 'Menampilkan link channel (khusus admin & owner bot)';

import { config } from '../../config.js';

export default (bot) => {
  bot.command(command, async (ctx) => {
    const userId = ctx.from.id;
    const chat = ctx.chat;

    try {
      if (chat.type !== 'channel') {
        return ctx.reply('❌ Command ini hanya bisa digunakan di *channel*.', {
          parse_mode: 'Markdown'
        });
      }

      const isOwner = userId === config.OWNER_ID;
      let isAdmin = false;

      if (!isOwner) {
        const admins = await ctx.getChatAdministrators(chat.id);
        isAdmin = admins.some(admin => admin.user.id === userId);
        if (!isAdmin) {
          return ctx.reply('🚫 Hanya *admin channel* atau *owner bot* yang bisa menggunakan command ini.', {
            parse_mode: 'Markdown'
          });
        }
      }

      const fullChat = await ctx.telegram.getChat(chat.id);

      let inviteLink = fullChat.invite_link;
      if (!inviteLink) {
        inviteLink = await ctx.telegram.exportChatInviteLink(chat.id);
      }

      const timeStr = new Date().toLocaleString('id-ID', {
        dateStyle: 'full',
        timeStyle: 'short',
      });

      const message = [
        `╭━━━〔 📢 *LINK CHANNEL* 〕━━━╮`,
        `│`,
        `├ 📛 *Nama:* ${fullChat.title}`,
        `├ 🆔 *ID Channel:* \`${chat.id}\``,
        `├ 👑 *Akses:* ${isOwner ? 'Owner Bot' : 'Admin Channel'}`,
        `├ 🔗 *Link:*`,
        `│   ${inviteLink}`,
        `│`,
        `╰━━━━━━━━━━━━━━━━━━━━╯`,
        `🕒 *Waktu:* ${timeStr}`,
        `_Gunakan link di atas untuk share channel ini._`
      ].join('\n');

      await ctx.reply(message, { parse_mode: 'Markdown' });

    } catch (err) {
      console.error('❌ Gagal mengambil link channel:', err);
      return ctx.reply('❌ Gagal mengambil link channel. Pastikan bot adalah admin channel.');
    }
  });
};