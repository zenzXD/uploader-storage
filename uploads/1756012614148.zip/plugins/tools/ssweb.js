// plugins/tools/ssweb.js

import fetch from "node-fetch";

export default {

  command: ["ssweb", "webshot"],

  tags: ["tools"],

  desc: "📸 Ambil screenshot halaman web via API ssweb",

  async handler(ctx) {

    const url = ctx.message.text.split(" ").slice(1).join(" ");

    if (!url) {

      return ctx.reply(

        `⚠️ *Format Salah!*\n` +

        `\n📌 *Contoh:* \`/ssweb https://example.com\`` +

        `\n🖼️ Bot akan mengambil screenshot halaman web tersebut.`,

        { parse_mode: "Markdown" }

      );

    }

    await ctx.reply(

      `🖥️ **Screenshot Request**\n` +

      `━━━━━━━━━━━━━━━━━━━━\n` +

      `🌐 URL : \`${url}\`\n` +

      `⏳ Status : Sedang memproses...\n` +

      `━━━━━━━━━━━━━━━━━━━━`,

      { parse_mode: "Markdown" }

    );

    try {

      const apiUrl = `https://www.sankavollerei.com/tools/ssweb?apikey=planaai&url=${encodeURIComponent(url)}`;

      const res = await fetch(apiUrl);

      if (!res.ok) throw new Error(`API Error: ${res.status}`);

      const buffer = await res.buffer();

      await ctx.replyWithPhoto(

        { source: buffer },

        {

          caption:

            `📸 **Screenshot Berhasil**\n` +

            `━━━━━━━━━━━━━━━━━━━━\n` +

            `🌐 URL : ${url}\n` +

            `✅ Status : *Selesai*\n` +

            `━━━━━━━━━━━━━━━━━━━━\n` +

            `_Diproses oleh AI Screenshot Service_`,

          parse_mode: "Markdown"

        }

      );

    } catch (err) {

      console.error(err);

      ctx.reply(

        `❌ *Gagal mengambil screenshot!*\n` +

        `💡 Pesan error: \`${err.message}\``,

        { parse_mode: "Markdown" }

      );

    }

  }

};