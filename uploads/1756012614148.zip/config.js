export const config = {
    // ─── 🔐 API TOKEN ──────────────────────────────
    TOKEN: "8220489715:AAFmVMvCFCH5CLem35x_NBh3BlzCWpYOPdw",
    DISCORD_TOKEN: "",

    // ─── 👑 OWNER CONFIG ───────────────────────────
    OWNER_ID: 7375830866,
    OWNER_NAME: "Reyz",
    OWNER_USERNAME: "ReyzID12",
    

    // ─── 💰 TRIPAY PAYMENT ─────────────────────────
    TRIPAY_API_KEY: "api_key_anda",
    TRIPAY_PRIVATE_KEY: "private_key_anda",
    TRIPAY_MERCHANT_CODE: "kode_merchant",
    TRIPAY_CALLBACK_URL: "https://domainanda.com/tripay-callback",
    TRIPAY_RETURN_URL: "https://t.me/username_bot",

    // ─── 💸 E-WALLET ───────────────────────────────
    DANA: "6282313745397",
    OVO: "6282313745397",
    SHOPEEPAY: "6282313745397",
    LINKAJA: "6282313745397",

    // ─── ⚙️ CONFIG LAIN ─────────────────────────────
    saldoPath: "./json/saldo.json",
    VIRTUALSIM_API_KEY: "mkVLIGla9DsJ8XjCdqKpOHiM63zoWf",
    okekey: "",
    BOTCAHX_API_KEY: null //ambil apikey di web https://api.botcahx.eu.org/
    zenzxApi: "https://zenzxz.dpdns.org",

    // ─── 📝 IDENTITAS ──────────────────────────────
    BOTNAME: "Lin-Qiye",
    TRAKTEER: "reyz2902",

    // ─── 📢 NOTIFIKASI / LOG ───────────────────────
    LOG_DONASI: -1002778325483,
    LOG_CHANNEL_ID: -1002778325483,
    NOTIF_CHANNEL: -1002778325483,
    SHEET_WHITELISTS_ID: "1M2FbrL2juglwsmsTiLmORKPJ-l7Pe_NCr0ucTa4j8mQ",
    SHEET_GROUPS_ID: "1fjqCEO519jB07XPpg69pBKQy4ybt7DomFSI5TkB3k5Y",

    // ─── 🔄 BACKUP & GIT ────────────────────────────
    BACKUP_PASSWORD: "Slay The Gods",
    GITHUB_REPO: "https://github.com/Reyz2902/Ishimi",
    GITHUB_EMAIL: "reyzz4263@gmail.com",
    GITHUB_BRANCH: "main",
    // ─── 🌐 DISCORD ────────────────────────────────
    DISCORD_WEBHOOK_URL:
        "https://discord.com/api/webhooks/1398623065587580978/WdGH5nbkxg27IZnK_8Pm-sXvzvrwjjvvIZGPJUnhfaMvnlKaY8iJpex5OVlvypru4Nly",

    // ─── 📱 MENU BUTTONS ───────────────────────────
    menuButtons: {
        reload_text: "🔄 Reload Plugins",
        shutdown_text: "❌ Shutdown",
        dev_text: "👨‍💻 Developer",
        update_text: "📡 Update",
        DEV_URL: "https://t.me/ReyzID12",
        UPDATE_URL: "https://t.me/LinQiyeLiMuwan"
    },

    // ─── 📎 INFO BUTTONS ───────────────────────────
    infoButtons: {
        SOURCE: "https://github.com/Reyz2902/Lin-Qiye.git",
        OWNER: "https://t.me/ReyzID12",
        CHANNEL: "https://t.me/LinQiyeLiMuwan",
        SUPPORT: "https://t.me/+BylhDrp2490zMmM1",
        OWNER_LINK: "https://t.me/ReyzID12"
    }
};
