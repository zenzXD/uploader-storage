import { Telegraf } from 'telegraf';
import { config } from './config.js';
import { sendToDiscord } from './bridge.js';
import { logMessage } from './lib/logger.js';

const bot = new Telegraf(config.TOKEN);

// 🚀 Bot aktif
bot.launch().then(() => {
  console.log(`🤖 Telegram bot aktif sebagai @${config.OWNER_USERNAME}`);
}).catch(err => {
  console.error('❌ Gagal menjalankan bot Telegram:', err.message);
});

// 🎯 Handler pesan masuk
bot.on('text', async (ctx) => {
  try {
    const from = ctx.from.username || `${ctx.from.first_name} ${ctx.from.last_name || ''}`;
    const type = ctx.chat.type || 'unknown'; // private, group, etc.
    const id = ctx.chat.id;
    const text = ctx.message.text || '[non-text]';
    const time = new Date(ctx.message.date * 1000).toLocaleString('id-ID');

    // ✅ Logging ke terminal
    logMessage({
      text,
      type,
      id,
      user: from,
      platform: 'telegram', // pakai 'telegram' agar tidak rancu dengan discord
    });

    // 🔁 Relay ke Discord
    const relay = `📥 *From Telegram*\n👤 *${from}*\n💬 ${text}\n🕒 ${time}\n📌 Type: ${type}`;
    await sendToDiscord(relay);
  } catch (err) {
    console.error('❌ Error saat handle pesan Telegram:', err.message);
  }
});

// 🚦 Fungsi alternatif jika dipanggil manual
export const startTelegramBot = () => bot.launch().catch(err => {
  console.error('❌ Error saat memulai bot Telegram:', err.message);
});