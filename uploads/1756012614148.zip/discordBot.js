import { Client, GatewayIntentBits } from 'discord.js';
import { config } from './config.js';
import { sendToTelegram } from './bridge.js';
import { logMessage } from './lib/logger.js'; // Logger untuk tampilkan info

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('ready', () => {
  console.log(`🤖 Discord bot siap sebagai ${client.user.tag}`);
  global.discordClient = client; // Untuk bridge.js
});

client.on('messageCreate', (msg) => {
  if (msg.author.bot || !msg.content) return;

  const user = msg.author.username;
  const text = msg.content;
  const type = msg.channel.type; // text, dm, etc
  const id = msg.channel.id;
  const platform = 'dc';

  // 🔁 Relay ke Telegram
  const relay = `📥 *From Discord*\n👤 *${user}*\n💬 ${text}\n📌 Channel Type: ${type}`;
  sendToTelegram(relay);

  // 📃 Logging ke console
  logMessage({
    text,
    type,
    id,
    user,
    platform,
  });
});

export const startDiscordBot = () => client.login(config.DISCORD_TOKEN);