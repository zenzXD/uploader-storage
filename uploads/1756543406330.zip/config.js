export const config = {

 //───────────────────────────────

  // ─── 👑 OWNER CONFIG ───────────────────────────

  //───────────────────────────────

 

    OWNER_ID: 7375830866,

    OWNER_USERNAME:"ReyzID12",
    OWNERNAME: "Lin or Li",
    

  

  //───────────────────────────────

  // ─── 🤖 BOT CONFIG ──────────────────────────────

  //───────────────────────────────

  

    BOTNAME: "LinQiye",

    TOKEN: "8220489715:AAFmVMvCFCH5CLem35x_NBh3BlzCWpYOPdw",
USE_AUTOCHECK: false,
};
