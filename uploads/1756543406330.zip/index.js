import cluster from "cluster";

import { Telegraf } from "telegraf";

import { config } from "./config.js";

import { loadPlugins } from "./lib/loader.js";

import fs from "fs";

import path from "path";

import { fileURLToPath } from "url";

import chalk from "chalk";

// import opsional (tidak langsung dipanggil)

let batchAutoFix, watchPlugins;

if (config.USE_AUTOCHECK) {

  // Alias BatchAutoCheck → batchAutoFix

  ({ BatchAutoCheck: batchAutoFix } = await import("./lib/autoCheckBatch.js"));

  ({ watchPlugins } = await import("./lib/autoCheckLive.js"));

}

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const LOCK_FILE = path.join(__dirname, "off.lock");

if (cluster.isPrimary) {

  console.clear();

  console.log(chalk.cyan("🌟 Memulai bot dengan sistem Auto-Restart...\n"));

  const startWorker = () => {

    const worker = cluster.fork();

    worker.on("exit", (code, signal) => {

      console.log(chalk.red(`\n❌ Bot mati (code: ${code}, signal: ${signal})`));

      console.log(chalk.yellow("🔁 Restarting bot in 3 detik..."));

      setTimeout(startWorker, 3000);

    });

  };

  startWorker();

} else {

  (async () => {

    try {

      if (!config.TOKEN) {

        console.log(chalk.red("\n⛔ TOKEN BOT TIDAK DITEMUKAN!"));

        process.exit(1);

      }

      if (fs.existsSync(LOCK_FILE)) {

        console.log(chalk.red("🚫 Bot sedang dimatikan (OFF mode)."));

        process.exit(0);

      }

      const bot = new Telegraf(config.TOKEN);

      bot.context.pluginMeta = {};

      bot.context.pluginList = [];

      bot.context.globalHandlers = [];

      bot.use((ctx, next) => {

        ctx.isOwner = ctx.from?.id === config.OWNER_ID;

        ctx.config = config;

        ctx.bot = bot;

        return next();

      });

      // ===== LOAD PLUGINS =====

      await loadPlugins(bot);

      bot.botInfo = await bot.telegram.getMe();

      // ===== AUTOFIX OPSIONAL =====

      if (config.USE_AUTOCHECK) {

        await batchAutoFix(bot.context);

        watchPlugins(bot.context);

        console.log(chalk.green("✅ AutoCheck Aktif (Batch + Live Watcher)"));

      } else {

        console.log(

          chalk.yellow("⚠️ AutoCheck DIMATIKAN (skip lib/autoCheckBatch.js & autoCheckLive.js)")

        );

      }

      // ===== LOG PESAN MASUK =====

      bot.on("message", async (ctx) => {

        const msg = ctx.message;

        const user = ctx.from;

        const chat = ctx.chat;

        if (!msg || !user) return;

        let text =

          msg.text ||

          msg.caption ||

          (msg.reply_to_message?.text || msg.reply_to_message?.caption);

        if (!text) return;

        let commandUsed = "-";

        if (msg.entities?.length) {

          const cmdEntity = msg.entities.find((e) => e.type === "bot_command");

          if (cmdEntity) {

            commandUsed = text.slice(cmdEntity.offset, cmdEntity.offset + cmdEntity.length);

          }

        }

        const chatType = chat?.type?.includes("group") ? "Group" : "Private";

        const groupId = chat?.id || "-";

        const groupName = chat?.title || chat?.first_name || "-";

        console.log(chalk.magenta("\n┏━━━━━━━━━━━━━━━ 📥 Pesan Masuk ━━━━━━━━━━━━━━━┓"));

        console.log(chalk.blue(`┃ 🧾 Teks Pesan        : ${text}`));

        console.log(chalk.green(`┃ 👤 Username          : @${user.username || "-"}`));

        console.log(chalk.yellow(`┃ 🏷 Nama Depan        : ${user.first_name || "-"}`));

        console.log(chalk.cyan(`┃ 🏷 Nama Belakang     : ${user.last_name || "-"}`));

        console.log(chalk.white(`┃ ⚡ Command Digunakan : ${commandUsed}`));

        console.log(chalk.red(`┃ 🗂 Tipe Chat         : ${chatType}`));

        console.log(chalk.redBright(`┃ 🆔 ID Grup/Private   : ${groupId}`));

        console.log(chalk.magenta(`┃ 📌 Nama Grup/Private : ${groupName}`));

        console.log(chalk.magenta("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"));

      });

      await bot.launch();

      console.log(chalk.green("\n✨ Bot Telegram AKTIF tanpa AI Botcahx"));

      console.log(chalk.yellow("⚡ Mode: Clean & Fast 🚀"));

      process.once("SIGINT", () => bot.stop("SIGINT"));

      process.once("SIGTERM", () => bot.stop("SIGTERM"));

    } catch (err) {

      console.error(chalk.red("❌ Terjadi kesalahan saat startup:"), err);

      process.exit(1);

    }

  })();

}
