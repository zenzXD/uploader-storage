export default {
  command: ["listadmin", "admins", "daftaradmin"],

  tags: ["admin"],

  desc: "Menampilkan daftar admin grup",

  async handler(ctx) {
    if (!["group", "supergroup"].includes(ctx.chat.type)) {
      return ctx.reply(
        `

💢 𝗘𝗿𝗿𝗼𝗿!  

╔════════════════════╗  

Hei, ini perintah khusus  

buat di grup ya 😤  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    }

    try {
      const admins = await ctx.telegram.getChatAdministrators(ctx.chat.id);

      if (!admins || admins.length === 0) {
        return ctx.reply(
          `

😒 𝗚𝗮 𝗔𝗱𝗮 𝗔𝗱𝗺𝗶𝗻?  

╔════════════════════╗  

Lah kok grup ini nggak ada  

adminnya... aneh banget 😑  

╚════════════════════╝

        `.trim(),
          { parse_mode: "Markdown" },
        );
      }

      // List emoji random

      const emojis = [
        "🌸",
        "🌼",
        "🍀",
        "🌟",
        "🔥",
        "💎",
        "🍁",
        "🌹",
        "🐾",
        "⚡",
        "💫",
        "🌈",
        "🎯",
        "🎉",
        "🪐",
      ];

      const randomEmoji = () =>
        emojis[Math.floor(Math.random() * emojis.length)];

      // Pisahkan owner dan admin

      let owner = admins.filter((a) => a.status === "creator");

      let adminList = admins.filter((a) => a.status === "administrator");

      const formatMention = (u) => {
        return u.username
          ? `[@${u.username}](https://t.me/${u.username})`
          : `[${u.first_name}](tg://user?id=${u.id})`;
      };

      let ownerText = owner

        .map((o, i) => `${randomEmoji()} 👑 Owner — ${formatMention(o.user)}`)

        .join("\n");

      let adminText = adminList

        .map((a, i) => `${randomEmoji()} 🔧 Admin — ${formatMention(a.user)}`)

        .join("\n");

      ctx.reply(
        `

 𝗗𝗮𝗳𝘁𝗮𝗿 𝗔𝗱𝗺𝗶𝗻   
-
╔════════════════════╗  

👑 *Owner Grup*  

${ownerText || "-"}  

🔧 *Admin Grup*  

${adminText || "-"}  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    } catch (e) {
      console.error(e);

      ctx.reply(
        `

💔 𝗚𝗮𝗴𝗮𝗹 𝗔𝗺𝗯𝗶𝗹 𝗗𝗮𝘁𝗮 💔  

╔════════════════════╗  

Yah... aku nggak bisa ambil  

daftar adminnya nih 😤  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    }
  },
};
