import { config } from "../../config.js";

export default {
  command: ["delmsg", "deletemessage"],

  tags: ["admin"],

  desc: "❌ Hapus pesan apapun dengan reply (Admin/Owner Only)",

  async handler(ctx) {
    const fromId = ctx.from.id;

    // Cek hak akses Owner/Admin

    if (fromId != config.OWNER_ID && !config.ADMIN_IDS?.includes(fromId)) {
      return ctx.reply(
        "❌ Kamu bukan Owner/Admin, tidak bisa menghapus pesan.",
      );
    }

    // Pastikan reply ada

    const replyMsg = ctx.message.reply_to_message;

    if (!replyMsg) {
      return ctx.reply(
        `❌╔═══「 HAPUS PESAN 」═══╗\n` +
          `Gunakan:\n<code>/delmsg</code> dengan reply ke pesan yang ingin dihapus.\n` +
          `╚═════════════════════╝`,

        { parse_mode: "HTML" },
      );
    }

    const chatId = ctx.chat.id;

    const messageId = replyMsg.message_id;

    try {
      await ctx.telegram.deleteMessage(chatId, messageId);

      return ctx.reply(
        `✅╔═══「 PESAN TERHAPUS 」═══╗\n` +
          `🆔 Chat ID    : <code>${chatId}</code>\n` +
          `📝 Message ID : <code>${messageId}</code>\n` +
          `💫 Pesan berhasil dihapus!\n` +
          `╚══════════════════════╝`,

        { parse_mode: "HTML" },
      );
    } catch (e) {
      return ctx.reply(
        `⚠️╔═══「 GAGAL HAPUS PESAN 」═══╗\n` +
          `Error : <code>${e.message}</code>\n` +
          `╚═════════════════════════╝`,

        { parse_mode: "HTML" },
      );
    }
  },
};
