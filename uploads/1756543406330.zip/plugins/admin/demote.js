export default {
  command: ["removeadmin", "demote"],

  tags: ["admin"],

  desc: "Menurunkan admin menjadi member biasa",

  async handler(ctx) {
    // Pastikan perintah di grup

    if (!["group", "supergroup"].includes(ctx.chat.type)) {
      return ctx.reply(
        `

💢 𝗘𝗿𝗿𝗼𝗿!  

╔════════════════════╗  

😒 Perintah ini cuma bisa  

dipakai di grup, ngerti nggak sih?!  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    }

    // Cek apakah user adalah admin grup

    let isAdmin = false;

    try {
      const member = await ctx.telegram.getChatMember(ctx.chat.id, ctx.from.id);

      isAdmin = ["administrator", "creator"].includes(member.status);
    } catch (e) {
      console.error("Gagal cek status admin:", e);
    }

    if (!isAdmin) {
      return ctx.reply(
        `

🚫 𝗣𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗗𝗶𝘁𝗼𝗹𝗮𝗸!  

╔════════════════════╗  

Hei! Kamu bukan admin grup  

atau pemilikku, jadi jangan  

sok nyuruh ya 😤  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    }

    // Cek izin bot

    try {
      const botMember = await ctx.telegram.getChatMember(
        ctx.chat.id,
        ctx.botInfo.id,
      );

      if (
        botMember.status !== "administrator" ||
        !botMember.can_promote_members
      ) {
        return ctx.reply(
          `

🚫 𝗚𝗮𝗴𝗮𝗹!  

╔════════════════════╗  

Aku nggak punya izin *Can Promote Members*!  

Kasih izin dulu kalau mau aku nurut! 💢  

╚════════════════════╝

        `.trim(),
          { parse_mode: "Markdown" },
        );
      }
    } catch (e) {
      console.error("Gagal cek izin bot:", e);
    }

    // Ambil target (reply)

    const target = ctx.message.reply_to_message?.from;

    if (!target) {
      return ctx.reply(
        `

📌 𝗣𝗮𝗻𝗱𝘂𝗮𝗻!  

╔════════════════════╗  

Balas chat orang yang mau  

diturunin jadi member biasa! 😏  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    }

    try {
      await ctx.telegram.promoteChatMember(ctx.chat.id, target.id, {
        can_change_info: false,

        can_delete_messages: false,

        can_invite_users: false,

        can_restrict_members: false,

        can_pin_messages: false,

        can_promote_members: false,
      });

      ctx.reply(
        `

🌸 𝗦𝘂𝗸𝘀𝗲𝘀! 🌸  

╔════════════════════╗  

✅ *${target.first_name}* sekarang  

udah balik jadi member biasa 💕  

Jangan ngambek ya 😏  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    } catch (err) {
      console.error(err);

      ctx.reply(
        `

💔 𝗚𝗮𝗴𝗮𝗹! 💔  

╔════════════════════╗  

Aku nggak bisa nurunin dia...  

Pastikan aku punya izin  

yang bener ya! 💢  

╚════════════════════╝

      `.trim(),
        { parse_mode: "Markdown" },
      );
    }
  },
};
