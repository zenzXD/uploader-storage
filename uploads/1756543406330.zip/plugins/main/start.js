// plugins/main/start.js
import { config } from "../../config.js";

export default {
  command: "start",
  tags: ["main"],
  desc: "👋 Mulai bot",

  async handler(ctx) {
    const user = ctx.from.first_name || ctx.from.username || "Pengguna";
    const isGroup = ctx.chat?.type?.includes("group");

    if (isGroup) {
      // 👥 Kalau dipanggil di grup
      const teksGroup = `
👋 Hai *${user}*!

Aku adalah *${config.BOTNAME}* 🚀
Bot ini siap menjaga grup kamu dengan fitur-fitur:

🛡️ Anti Link
🔇 Mute / Warn / Ban
🚷 Anti Toxic / Anti Spam
untuk versi baru bot harap hubungin owner sc @ReyzID12

Ketik */menu* untuk melihat daftar fitur.
`.trim();

      await ctx.reply(teksGroup, {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "📦 Menu", callback_data: "menu" },
              { text: "👨‍💻 Owner", url: config.OWNER_LINK },
            ],
          ],
        },
      });
    } else {
      // 💬 Kalau di private chat
      const teksPrivate = `
👋 Halo *${user}*!

Selamat datang di *${config.BOTNAME}* 🚀
Aku bisa membantu kamu dengan berbagai fitur:

📥 Downloader (Mediafire, Tiktok, dll)
untuk versi baru bot harap hubungin owner sc @ReyzID12

➡️ Gunakan */menu* untuk melihat semua fitur.
`.trim();

      await ctx.reply(teksPrivate, {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "📦 Menu Utama", callback_data: "menu" },
              { text: "👨‍💻 Owner", url: config.OWNER_LINK },
            ],
            [
              {
                text: "➕ Tambahkan ke Grup",
                url: `https://t.me/${config.BOTUSERNAME}?startgroup=true`,
              },
            ],
          ],
        },
      });
    }
  },
};
