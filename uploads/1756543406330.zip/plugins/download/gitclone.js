import fetch from "node-fetch";

import { config } from "../../config.js";

export default {
  command: ["gitclone"],

  tags: ["downloader"],

  desc: "📁 Clone repo GitHub dan kirim file zip",

  owner: false,

  premium: false,

  async handler(ctx) {
    const args = ctx.message.text.split(" ").slice(1);

    const reply = (text) =>
      ctx.reply(`╭─❖ *${config.BOTNAME}* ❖─\n${text}\n╰─────────────`, {
        parse_mode: "Markdown",
      });

    if (!args[0])
      return reply(
        `│ ⚠️ *Dimana linknya?*\n│\n│ Contoh:\n│ \`${config.prefix}gitclone https://github.com/username/repo\``,
      );

    if (!isValidGithubUrl(args[0]))
      return reply(
        `│ 🚫 *Link tidak valid!*\n│ Link harus mengandung \`github.com\``,
      );

    const regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;

    let [, user, repo] = args[0].match(regex) || [];

    if (!user || !repo)
      return reply("│ ❌ *Gagal mengekstrak user dan repo dari URL!*");

    repo = repo.replace(/.git$/, "");

    const zipUrl = `https://api.github.com/repos/${user}/${repo}/zipball`;

    try {
      const startTime = Date.now();

      const res = await fetch(zipUrl, { method: "HEAD" });

      const endTime = Date.now();

      const disposition = res.headers.get("content-disposition");

      const filename =
        disposition?.match(/filename=(.*)/)?.[1] || `${repo}.zip`;

      const contentLength = res.headers.get("content-length");

      const sizeMB = contentLength
        ? (parseInt(contentLength) / (1024 * 1024)).toFixed(2)
        : "Unknown";

      const timeSeconds = ((endTime - startTime) / 1000).toFixed(2);

      await ctx.replyWithDocument(
        { url: zipUrl, filename: filename },

        {
          caption:
            `╭─❖ *${config.BOTNAME} Clone Result* ❖─\n` +
            `│\n` +
            `│ 🌟 ✅ *Berhasil!* Repository berhasil di-*clone*\n` +
            `│ ──────────────────────────\n` +
            `│ 🔹 Repo   : \`${user}/${repo}\`\n` +
            `│ 📦 File   : \`${filename}\`\n` +
            `│ ⏱️ Time   : ${timeSeconds} detik\n` +
            `│ 💾 Size   : ${sizeMB} MB\n` +
            `│ ──────────────────────────\n` +
            `│ ✨ Terima kasih telah menggunakan *${config.BOTNAME}*!\n` +
            `╰─────────────`,

          parse_mode: "Markdown",
        },
      );
    } catch (err) {
      console.error(err);

      reply("│ ❌ *Terjadi kesalahan saat mengunduh ZIP dari GitHub!*");
    }
  },
};

// Utilitas

function isValidGithubUrl(url) {
  return /^https?:\/\/(www\.)?github\.com\/[^\/]+\/[^\/]+/i.test(url);
}
