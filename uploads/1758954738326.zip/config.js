import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.prefix = ["."], 
global.config = {
    /*============== INFO LINK ==============*/
    instagram: '–',
    github: '–',
    group: 'https://chat.whatsapp.com/IPhNxvkkbvBGNjLI32RXcT',
    website: '',

    /*============== PAYMENT ==============*/
    dana: '6287823745178',
    ovo: 'Kosong',
    gopay: 'Kosong',
    pulsa: 'Kosong',

    /*============== STAFF ==============*/
    owner: [
    ['6287821124251', 'zen', true],
    ['63 9972895613', 'zengntengg', true],
    ['573238329287', 'dontol kek kontol', true]
],

    /*============= PAIRING =============*/
    pairingNumber: "62895326858840",
    pairingAuth: true,
    
    /*============= HIASAN =============*/
    gris: '`', // Perbaiki di sini, hapus "global."

    /*============== API ==============*/
    APIs: {
        lol: 'https://api.lolhuman.xyz',
        rose: 'https://api.itsrose.rest',
        xzn: 'https://skizo.tech',
        botcahx: 'https://api.botcahx.eu.org'
    },

    APIKeys: {
        'https://api.lolhuman.xyz': 'RyAPI',
        'https://api.itsrose.rest': 'Rk-f5d4b183e7dd3dd0a44653678ba5107c',
        'https://skizo.tech': 'RyHar',
        'https://api.botcahx.eu.org': 'RyAPI'
    },

    /*============== TEXT ==============*/
    watermark: 'Vynex - MultiDevice',

    author: 'ZenzzXD',

    loading: 'Mohon ditunggu...',

    errorMsg: 'Error :)',

    stickpack: 'Made With',

    stickauth: 'Vynex-Multidevice',

    digi: {

        username: "",

        apikey: ""

    },

    OK: {

        ID: "",

        Apikey: ""

    },

    

    taxRate: 0.05,

    taxMax: 2000

}

global.loading = (m, conn, back = false) => {

    if (!back) {

        return conn.sendReact(m.chat, "🕒", m.key)

    } else {

        return conn.sendReact(m.chat, "", m.key)

    }

}

/*============== EMOJI ==============*/
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            skata: '🧩',
            bitcoin: '☸️',
            polygon: '☪️',
            dogecoin: '☯️',
            etherium: '⚛️',
            solana: '✡️',
            memecoin: '☮️',
            donasi: '💸',
            ammn: '⚖️',
            bbca: '💵',
            bbni: '💴',
            cuan: '🧱',
            bbri: '💶',
            msti: '📡',
            steak: '🥩',
            ayam_goreng: '🍗',
            ribs: '🍖',
            roti: '🍞',
            udang_goreng: '🍤',
            bacon: '🥓',
            gandum: '🌾',
            minyak: '🥃',
            garam: '🧂',
            babi: '🐖',
            ayam: '🐓',
            sapi: '🐮',
            udang: '🦐'
        }
        if (typeof emot[string] !== 'undefined') {
            return emot[string]
        } else {
            return ''
        }
    }
}

//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'config.js'"))
    import(`${file}?update=${Date.now()}`)
})