import axios from 'axios'

let handler = async (m, {
    conn,
    args,
    text,
    usedPrefix,
    command
}) => {
    if (!text) return m.reply(`⚠️ Masukkan kata kunci.\n\nContoh: *${usedPrefix + command} Fyp lucu*`)
    m.reply('⏳ Sedang mencari video TikTok...')
    tiktoks(text).then(a => {
        let cap = `🎬 *${a.title}*`
        conn.sendMessage(m.chat, { 
            video: { url: a.no_watermark }, 
            caption: cap 
        }, { quoted: m })
    }).catch(err => {
        console.error(err)
        m.reply('❌ Gagal mengambil data TikTok. Coba lagi nanti.')
    })
}

handler.help = ['tiktoksearch <query>']
handler.tags = ['search']
handler.command = /^(ttsearch|tiktoksearch)$/i
handler.limit = true
handler.register = true

export default handler

async function tiktoks(query) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await axios({
                method: 'POST',
                url: 'https://tikwm.com/api/feed/search',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Cookie': 'current_language=en',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
                },
                data: {
                    keywords: query,
                    count: 10,
                    cursor: 0,
                    HD: 1
                }
            })
            const videos = response.data.data.videos
            if (!videos || videos.length === 0) {
                reject("Tidak ada video ditemukan.")
            } else {
                const randomIndex = Math.floor(Math.random() * videos.length)
                const video = videos[randomIndex]

                resolve({
                    title: video.title,
                    cover: video.cover,
                    origin_cover: video.origin_cover,
                    no_watermark: video.play,
                    watermark: video.wmplay,
                    music: video.music
                })
            }
        } catch (error) {
            reject(error)
        }
    })
}