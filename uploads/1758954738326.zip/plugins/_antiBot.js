export async function before(m, { conn, isAdmin, isBotAdmin }) {
    if (!m.isGroup) return

    let chat = global.db.data.chats[m.chat]
    if (!chat.antiBot) return
    if (m.fromMe) return

    const idsToCheck = []

    const mainId = m.key?.id || ''
    if (mainId) idsToCheck.push(mainId)
    const quotedId = m.quoted?.id || m.quoted?.key?.id
    if (quotedId) idsToCheck.push(quotedId)

    const trueBotPatterns = [
        { prefix: 'B1EY', length: 20 },
        { prefix: 'BAE5', length: 16 },
        { prefix: '3EB0', length: 22 },
        { prefix: '3EB0', length: 40 },
        { prefix: 'DFFF', length: 32 },
        { prefix: 'BED6', length: 32 },
        { prefix: '177A', length: 32 },
        { prefix: '0CEE', length: 32 },
        { prefix: '2B2A', length: 32 },
        { prefix: 'IZUMI-', lengthMin: 16 },
        { prefix: 'ACWA', length: 20 },
        { prefix: 'CAE5', length: 16 },
        { prefix: 'BA', length: 12 },
        { prefix: 'E3E0', length: 22 },
        { prefix: 'C1A1', lengthMin: 18 },
        { prefix: 'A1B2', lengthMin: 16 },
        { prefix: 'ZXC', lengthMin: 20 },
        { prefix: 'FAKE', length: 24 },
        // FTG- sudah tidak dicek apapun!
    ]

    const isRealBotId = (id = '') => {
        return trueBotPatterns.some(p => {
            if (p.length) return id.startsWith(p.prefix) && id.length === p.length
            if (p.lengthMin) return id.startsWith(p.prefix) && id.length >= p.lengthMin
            return false
        })
    }

    const suspiciousMatches = idsToCheck.filter(id => isRealBotId(id))
    const isFromBot = m.sender === conn.user.jid
    const isProcessableType = !!(m.text || m.quoted?.text)
    const user = global.db.data.users ? global.db.data.users[m.sender] : null
    const isNewMember = user && user.joinedAt && (Date.now() - user.joinedAt < 2 * 60 * 1000)

    // ⚠️ BLOK INI DIHAPUS:
    // if (isFTG && !isFromBot && isProcessableType) { ... }

    // Kick logic:
    if (suspiciousMatches.length && !isFromBot && isProcessableType && isNewMember) {
        if (isBotAdmin) {
            await m.reply(`🚫 *Terindikasi Bot!*\nID mencurigakan: *${suspiciousMatches[0] || 'Unknown'}*\n\nMaaf, karena kamu dianggap bot, kamu akan dikeluarkan dari grup.`)
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant
                }
            })
            await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        } else {
            await m.reply(`⚠️ Terindikasi Bot!\nID mencurigakan: *${suspiciousMatches[0] || 'Unknown'}*\nNamun bot tidak admin.`)
        }
    }
}