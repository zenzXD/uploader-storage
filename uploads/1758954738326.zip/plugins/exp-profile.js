import fs from 'fs'
import fetch from 'node-fetch'
import { createCanvas, loadImage } from 'canvas'

let handler = async (m, { conn }) => {
  try {
    await global.loading(m, conn)

    const who = m.mentionedJid && m.mentionedJid[0] 
      ? m.mentionedJid[0] 
      : m.fromMe 
        ? conn.user.jid 
        : m.sender
    const user = global.db.data.users[who]
    if (!user) return m.reply('Pengguna tidak ada di database')

    const name = user.registered ? user.name : conn.getName(who)

    let pp
    try {
      pp = await conn.profilePictureUrl(who, 'image')
    } catch {
      pp = './src/avatar_contact.png'
    }

    const bg = await loadImage('https://uploader.zenzxz.dpdns.org/uploads/1757086626573.jpeg')
    const avatar = await loadImage(pp)

    const canvas = createCanvas(bg.width, bg.height)
    const ctx = canvas.getContext('2d')

    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height)

    const avatarSize = 120
    const avatarX = 50
    const avatarY = (canvas.height / 2) - (avatarSize / 2)
    const centerX = avatarX + avatarSize / 2
    const centerY = avatarY + avatarSize / 2

    ctx.beginPath()
    ctx.arc(centerX, centerY, avatarSize / 2 + 5, 0, Math.PI * 2)
    ctx.fillStyle = '#fff'
    ctx.fill()
    ctx.closePath()

    ctx.save()
    ctx.beginPath()
    ctx.arc(centerX, centerY, avatarSize / 2, 0, Math.PI * 2)
    ctx.clip()
    ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize)
    ctx.restore()

    ctx.font = 'bold 30px Sans-Serif'
    ctx.fillStyle = '#fff'
    ctx.textAlign = 'center'
    ctx.fillText('Profile RPG', canvas.width / 2, 60)

    ctx.textAlign = 'left'
    ctx.font = '20px Sans-Serif'
    ctx.fillStyle = '#fff'
    const textX = avatarX + avatarSize + 30
    ctx.fillText(`Name : ${name}`, textX, 120)
    ctx.fillText(`Umur : ${user.umur || '-'}`, textX, 150)
    ctx.fillText(`Money : ${toRupiah(user.money)}`, textX, 180)
    ctx.fillText(`Level : ${user.level}`, textX, 210)

    const expNow = user.exp || 0
    const expMax = user.expMax || ((user.level + 1) * 8000) 
    const progress = Math.min(expNow / expMax, 1)

    const barX = textX
    const barY = 240
    const barWidth = 350
    const barHeight = 30

    ctx.fillStyle = '#6c3483'
    ctx.fillRect(barX, barY, barWidth, barHeight)

    ctx.fillStyle = '#f4d03f'
    ctx.fillRect(barX, barY, barWidth * progress, barHeight)

    ctx.lineWidth = 3
    ctx.strokeStyle = '#000'
    ctx.strokeRect(barX, barY, barWidth, barHeight)

    ctx.font = 'bold 16px Sans-Serif'
    ctx.fillStyle = '#000'
    ctx.textAlign = 'center'
    ctx.fillText(`Exp : ${toRupiah(expNow)} / ${toRupiah(expMax)}`, barX + barWidth / 2, barY + barHeight / 1.6)

    const buffer = canvas.toBuffer()
    await conn.sendFile(m.chat, buffer, 'profile-card.png', `✨ Profile RPG`, m)

  } catch (e) {
    m.reply(`❌ Error\nLogs error : ${e.message}`)
  } finally {
    await global.loading(m, conn, true)
  }
}

handler.help = ['profile']
handler.tags = ['xp']
handler.command = /^(profile)$/i
export default handler

const toRupiah = number => parseInt(number || 0).toLocaleString().replace(/,/g, ".")