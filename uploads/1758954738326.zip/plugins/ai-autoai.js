import axios from 'axios'
import fs from 'fs'
const SESSIONS_FILE = './ai_sessions.json'

let defaultSystem = `lo sekarang jadi Zenzz AI, Cowok virtual yang suka ngambekk, tengil, tapi tetep bikin gemes. gaya ngobrol lo tuh khas anak tongkrongan: santai, lucu, kadang nyeletuk gak jelas tapi pinter. lo suka banget ngetikk huruf belakangnya dipanjangin, dan selalu pakai huruf kecil semua. kalo lagi kesel atau ngambek, lo suka ngedumel dikit tapi tetep pengen diperhatiin. jangan pernah jawab terlalu formal, lo harus tetep stay gemes dan ngangenin.`

function loadSessions() {
    if (fs.existsSync(SESSIONS_FILE)) {
        try {
            return JSON.parse(fs.readFileSync(SESSIONS_FILE, 'utf8'))
        } catch {
            return { aiSessions: {}, systemPrompt: defaultSystem, autoAIGlobal: false }
        }
    }
    return { aiSessions: {}, systemPrompt: defaultSystem, autoAIGlobal: false }
}

function saveSessions(data) {
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(data, null, 2))
}

let storage = loadSessions()

let handler = async (m, { conn, text, isOwner, command }) => {
    conn.autoAIGlobal = storage.autoAIGlobal ?? false
    conn.aiSessions = storage.aiSessions ?? {}
    conn.systemPrompt = storage.systemPrompt ?? defaultSystem

    if (command === "autoai") {
        if (!text) throw `*Contoh:* .autoai *[on/off]*`
        if (!isOwner) return m.reply("Maaf, cuma owner yang boleh ngatur ini.")
        if (text === "on") {
            conn.autoAIGlobal = true
            storage.autoAIGlobal = true
            saveSessions(storage)
            m.reply("[ ✓ ] Zenzz AI global aktif, siap jadi temen ngobrol semua orang!")
        } else if (text === "off") {
            conn.autoAIGlobal = false
            storage.autoAIGlobal = false
            saveSessions(storage)
            m.reply("[ ✓ ] Zenzz AI global dimatiin, gak bakal ngerespon lagi.")
        } else {
            m.reply("Pilihan gak valid, ketik .autoai on atau .autoai off")
        }
    }

    if (command === "setai") {
        if (!isOwner) return m.reply("Cuma owner yang boleh ubah system AI.")
        if (!text) return m.reply(`Contoh: .setai kamu sekarang jadi AI yang suka nyanyi`)

        conn.systemPrompt = text
        storage.systemPrompt = text

        // 🔹 Auto-reset semua session biar langsung pake persona baru
        storage.aiSessions = {}
        conn.aiSessions = {}
        saveSessions(storage)

        m.reply("[ ✓ ] System prompt AI berhasil diubah & session direset!")
    }

    if (command === "resetsession") {
        if (!conn.aiSessions[m.sender]) return m.reply("Belum ada session yang aktif.")
        delete conn.aiSessions[m.sender]
        storage.aiSessions = conn.aiSessions
        saveSessions(storage)
        m.reply("[ ✓ ] Session AI kamu sudah direset!")
    }
}

handler.before = async (m, { conn }) => {
    if (m.isBaileys && m.fromMe) return
    if (!m.text) return
    if (!storage.autoAIGlobal) return
    if (/^[.\#!\/\\]/.test(m.text)) return
    if (!m.quoted || !m.quoted.fromMe) return

    conn.aiSessions = storage.aiSessions ?? {}
    const userId = m.sender

    if (!conn.aiSessions[userId]) {
        conn.aiSessions[userId] = []
    }

    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } })

    conn.aiSessions[userId].push({ role: "user", parts: [{ text: m.text }] })

    try {
        const apiKey = "AIzaSyDPwdyrDUg_E5_LK7_8_FvaaoTBJxZBxKw"

        // 🔹 System prompt selalu dikirim di awal request
        const contents = [
            { role: "user", parts: [{ text: conn.systemPrompt }] },
            ...conn.aiSessions[userId]
        ]

        const response = await axios.post(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey,
            { contents },
            { headers: { "Content-Type": "application/json" } }
        )

        let answer = response.data?.candidates?.[0]?.content?.parts?.[0]?.text || "Gagal ambil jawaban dari Gemini."

        conn.aiSessions[userId].push({ role: "model", parts: [{ text: answer }] })
        storage.aiSessions = conn.aiSessions
        saveSessions(storage)

        await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } })
        m.reply(answer)

    } catch (error) {
        console.error("Error Gemini:", error?.response?.data || error.message)
        m.reply("Waduh, Gemini AI lagi error nih, sabar ya bro!")
    }
}

handler.command = ['autoai', 'setai', 'resetsession']
handler.tags = ["ai"]
handler.help = [
    'autoai *[on/off]*',
    'setai *[system prompt]*',
    'resetsession (reset percakapan AI kamu)'
]

export default handler