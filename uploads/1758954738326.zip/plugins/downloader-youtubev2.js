/*
* Nama fitur : Youtube Downloader MP3 & MP4
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6chx1LI8YVtJJJ9a0Y
* Author : ZenzzXD
*/

import fetch from "node-fetch"

let handler = async (m, { text, command, conn }) => {
  try {
    if (!text) throw Error('masukin url youtube')
    m.reply('wett')
    let res
    if (command == 'ytmp3v2') {
      const r = await fetch(`https://api.zenzxz.my.id/downloader/ytmp3v2?url=${encodeURIComponent(text)}`)
      if (!r.ok) throw Error(`Gagal fetch API (ytmp3v2): ${r.status}`)
      res = await r.json()
      if (!res.status) throw Error('API ytmp3v2 error')
      await conn.sendMessage(
        m.chat,
        { audio: { url: res.download_url }, mimetype: 'audio/mpeg', ptt: false },
        { quoted: m }
      )
    } else if (command == 'ytmp4v2') {
      const r = await fetch(`https://api.zenzxz.my.id/downloader/ytmp4v2?url=${encodeURIComponent(text)}`)
      if (!r.ok) throw Error(`Gagal fetch API (ytmp4v2): ${r.status}`)
      res = await r.json()
      if (!res.status) throw Error('API ytmp4v2 error')
      await conn.sendMessage(
        m.chat,
        { video: { url: res.download_url }, mimetype: 'video/mp4' },
        { quoted: m }
      )
    } else throw Error('command gk di kenali')
  } catch (err) {
    m.reply(`Eror kak : ${err.message}`)
  }
}

handler.command = ['ytmp3v2','ytmp4v2']
handler.help = ['ytmp3v2 <url>','ytmp4v2 <url>']
handler.tags = ['downloader']

export default handler