import { createRequire } from 'module';
const require = createRequire(import.meta.url);

const jimp_1 = require('jimp');

let handler = async (m, { conn, command, usedPrefix }) => {
    m.reply('wett'); // reply awal

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    if (/image/g.test(mime) && !/webp/g.test(mime)) {
        try {
            let media = await q.download();
            let { img } = await pepe(media);

            // Ganti foto profil bot
            await conn.updateProfilePicture(conn.user.id, img);

            m.reply(`Sukses mengganti PP Bot`);
        } catch (e) {
            console.error(e);
            m.reply(`Eror kak : ${e.message}`);
        }
    } else {
        m.reply(`Kirim gambar dengan caption *${usedPrefix + command}* atau tag gambar yang sudah dikirim`);
    }
};

handler.help = ['setbotpp2'];
handler.tags = ['owner'];
handler.command = /^(set(botpp|ppbot)2)$/i;
handler.mods = true;
export default handler;

async function pepe(media) {
    const jimp = await jimp_1.read(media);
    const min = jimp.getWidth();
    const max = jimp.getHeight();
    const cropped = jimp.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp_1.MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(jimp_1.MIME_JPEG)
    };
}