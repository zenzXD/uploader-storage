/*
- Name : Free Fire Stalking
- Deks : Support Image Banner-Outfit
- Follow Bang : https://whatsapp.com/channel/0029Vb6D8o67YSd1UzflqU1d
- Source Scrape : https://whatsapp.com/channel/0029VagslooA89MdSX0d1X1z/526
*/
import axios from 'axios'
import moment from 'moment'

async function FFAcount(uid) {
  const url = `https://discordbot.freefirecommunity.com/player_info_api?uid=${uid}&region=id`

  try {
    const res = await axios.get(url, {
      headers: {
        'Origin': 'https://www.freefirecommunity.com',
        'Referer': 'https://www.freefirecommunity.com/ff-account-info/',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K)',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, br'
      }
    })

    const d = res.data.player_info || {}
    const b = d.basicInfo || {}
    const c = d.creditScoreInfo || {}
    const p = d.petInfo || {}
    const prof = d.profileInfo || {}
    const s = d.socialInfo || {}

    const safe = (val, fallback = 'N/A') => val !== undefined && val !== null ? val : fallback
    const formatTime = (unix) => unix ? moment.unix(unix).format('YYYY-MM-DD HH:mm:ss') : 'N/A'

    const tags = Array.isArray(s.battleTag) ? s.battleTag : []
    const tagCounts = Array.isArray(s.battleTagCount) ? s.battleTagCount : []
    
    let battleTagsText = 'N/A'
    if (tags.length > 0) {
      battleTagsText = tags.map((tag, i) => `${tag} (${tagCounts[i] || 0}x)`).join('\n')
    }

    return {
      nickname: safe(b.nickname),
      accountId: safe(b.accountId),
      region: safe(b.region),
      level: safe(b.level),
      liked: safe(b.liked),
      rank: safe(b.rank),
      maxRank: safe(b.maxRank),
      csRank: safe(b.csRank),
      exp: safe(b.exp),
      createAt: formatTime(b.createAt),
      lastLoginAt: formatTime(b.lastLoginAt),
      rankingPoints: safe(b.rankingPoints),
      releaseVersion: safe(b.releaseVersion),
      seasonId: safe(b.seasonId),
      primeLevel: safe(b.primeLevel?.level, '-'),
      diamondCost: safe(d.diamondCostRes?.diamondCost, '-'),
      petName: safe(p.name, '-'),
      petLevel: safe(p.level, '-'),
      petExp: safe(p.exp, '-'),
      petSkinId: safe(p.skinId, '-'),
      petSkillId: safe(p.selectedSkillId, '-'),
      avatarId: safe(prof.avatarId),
      clothes: Array.isArray(prof.clothes) ? prof.clothes.join(', ') : '-',
      equipedSkills: Array.isArray(prof.equipedSkills) ? prof.equipedSkills.join(', ') : '-',
      battleTags: battleTagsText,
      language: safe(s.language),
      rankShow: safe(s.rankShow),
      signature: safe(s.signature),
      creditScore: safe(c.creditScore),
      rewardState: safe(c.rewardState),
      bannerImage: `https://discordbot.freefirecommunity.com/banner_image_api?uid=${uid}&region=id`,
      outfitImage: `https://discordbot.freefirecommunity.com/outfit_image_api?uid=${uid}&region=id`
    }
  } catch (e) {
    throw new Error(`Gagal mengambil data : ${e.message}`)
  }
}

let handler = async (m, { conn, args }) => {
  try {
    if (!args[0]) return m.reply('Masukkan UID Free Fire\nContoh : .ffstalk 1215124144')
    
    const uid = args[0]
    if (!/^\d+$/.test(uid)) return m.reply('UID harus berupa angka')
    
    m.reply('Mencari data akun Free Fire...')
    
    const data = await FFAcount(uid)
    
    let text = `Nickname : ${data.nickname}
Account ID : ${data.accountId}
Region : ${data.region}
Level : ${data.level}
Likes : ${data.liked}
Rank : ${data.rank}
Max Rank : ${data.maxRank}
CS Rank : ${data.csRank}
EXP : ${data.exp}
Created At : ${data.createAt}
Last Login : ${data.lastLoginAt}
Ranking Points : ${data.rankingPoints}
Release Version : ${data.releaseVersion}
Season ID : ${data.seasonId}
Prime Level : ${data.primeLevel}
Diamond Cost : ${data.diamondCost}

Pet Info :
Name : ${data.petName}
Level : ${data.petLevel}
EXP : ${data.petExp}
Skin ID : ${data.petSkinId}
Skill ID : ${data.petSkillId}

Profile Info :
Avatar ID : ${data.avatarId}
Clothes : ${data.clothes}
Equipped Skills : ${data.equipedSkills}

Battle Tags :
${data.battleTags}

Social Info :
Language : ${data.language}
Rank Show : ${data.rankShow}
Signature : ${data.signature}

Credit Score : ${data.creditScore}
Reward State : ${data.rewardState}`

    await conn.sendMessage(m.chat, { 
      image: { url: data.bannerImage }, 
      caption: text 
    }, { quoted: m })
    
    await conn.sendMessage(m.chat, { 
      image: { url: data.outfitImage }, 
      caption: '*Outfitnya*' 
    }, { quoted: m })
    
  } catch (e) {
    m.reply(e.message)
  }
}

handler.help = ['ffstalk']
handler.command = ['ffstalk']
handler.tags = ['stalker']

export default handler