/*
* Nama fitur : To figure
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6chx1LI8YVtJJJ9a0Y
* Author : ZenzzXD
*/

import { GoogleGenAI } from '@google/genai'

const APIKEY = 'AIzaSyBTQ_N4BC7OETvR9NTB-ZljV3rXoD0Ybbs'
const PROMPT = 'Using the nano-banana model, Create an ultra-realistic image of a young man (photo attached) sitting at a computer desk in a brightly lit room. He smiles as he holds a detailed collectible figurine of himself. The figurine should be the main subject, featuring a realistic 1/7 scale. On the table next to him is a branded toy box with his photo and the same figurine design. A monitor behind him displays 3D sculpting software (such as ZBrush or Blender) displaying a grayscale 3D model of him in the same outfit. The table is littered with small toy pieces and modeling tools scattered around, creating a creative, workshop-like atmosphere. The overall composition should be cinematic, highly detailed, and realistic, with soft lighting that highlights the subject, the figurine, and the 3D model on screen.'

const handler = async (m, { conn, args }) => {
  try {
    const mime = m.quoted?.mimetype || ''
    if (!/image/.test(mime)) {
      return m.reply('reply gambar dengan command : .tofigure2')
    }

    m.reply('wett')

    const imageBuffer = await m.quoted.download()
    if (!imageBuffer) return m.reply('eror pas mengunduh gambar')

    const ai = new GoogleGenAI({ apiKey: APIKEY })
    const base64Image = imageBuffer.toString('base64')

    const contents = [
      { text: PROMPT },
      {
        inlineData: {
          mimeType: mime,
          data: base64Image
        }
      }
    ]

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents
    })

    const parts = response?.candidates?.[0]?.content?.parts || []

    for (const part of parts) {
      if (part.inlineData?.data) {
        const buffer = Buffer.from(part.inlineData.data, 'base64')
        await conn.sendFile(m.chat, buffer, 'zen.png', '', m)
      }
    }
  } catch (e) {
    m.reply(`Eror kak : ${e.message}`)
  }
}

handler.help = ['tofigure2']
handler.tags = ['ai']
handler.command = ['tofigure2']

export default handler