import { ytSearch } from "../lib/scrape.js"

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`Masukkan query!\n\nContoh:\n${usedPrefix + command} mantra hujan`)
    try {
        await global.loading(m, conn)

        let { title, uploaded, duration, views, url, thumbnail } = (await ytSearch(text))[0]

        let caption = `
*––––––『 P L A Y 』––––––*

🎧 *Title:* ${title.trim()}
📤 *Published:* ${uploaded}
⏰ *Duration:* ${duration}
👁️ *Views:* ${views}

🔗 *Url:* ${url}
`.trim()

        await conn.sendMessage(m.chat, {
            image: { url: thumbnail },
            caption,
            buttons: [
                { buttonId: `.ytmp3 ${url}`, buttonText: { displayText: 'Download MP3' }, type: 1 },
                { buttonId: `.ytmp4 ${url}`, buttonText: { displayText: 'Download MP4' }, type: 1 }
            ],
            headerType: 4,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: false,
                    mediaType: 1,
                    title: title.trim(),
                    body: null,
                    thumbnail: (await conn.getFile(thumbnail)).data,
                    renderLargerThumbnail: true,
                    mediaUrl: url,
                    sourceUrl: url
                }
            }
        }, { quoted: m })

    } catch (e) {
        m.reply(`Tidak dapat menemukan query "${text}"`)
        console.error(e)
    } finally {
        await global.loading(m, conn, true)
    }
}

handler.help = ['play']
handler.tags = ['sound']
handler.command = /^play$/i
handler.limit = true

export default handler