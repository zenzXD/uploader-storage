export async function before(m, { isAdmin, isBotAdmin, conn }) {
    if (m.isBaileys || m.fromMe) return

    let chat = global.db.data.chats[m.chat]
    if (!chat?.antiVn) return

    // Deteksi voice note (PTT)
    if (m.mtype === 'audioMessage' && m.msg?.ptt === true) {
        if (!isAdmin && isBotAdmin) {
            // Hapus voice note
            await conn.sendMessage(m.chat, { delete: m.key })

            // Kirim pesan peringatan
            await conn.sendMessage(m.chat, {
                text: `🚫 @${m.sender.split('@')[0]} mengirim *voice note*.\nFitur *anti VN* aktif, hati-hati bisa dikick.`,
                mentions: [m.sender]
            }, { quoted: m })
        }
    }

    return !0
}