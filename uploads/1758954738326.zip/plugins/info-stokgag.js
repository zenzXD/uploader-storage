/*
📌 Nama Fitur: Stok Grow a Garden
🏷️ Type: Plugin ESM
*/

import axios from 'axios'
import tough from 'tough-cookie'
import { wrapper } from 'axios-cookiejar-support'

const gardenStock = {
  api: {
    base: 'https://www.gamersberg.com',
    endpoints: {
      page: () => '/grow-a-garden/stock',
      stock: () => '/api/grow-a-garden/stock'
    }
  },

  headers: {
    'user-agent': 'Postify/1.0.0',
    'x-requested-with': 'idm.internet.download.manager.plus',
    'accept-language': 'id,en;q=0.9',
    referer: 'https://www.gamersberg.com/sw.js',
    'sec-check-site': 'same-origin',
    'sec-check-mode': 'cors',
    'sec-check-dest': 'empty'
  },

  image: (type, name) =>
    `https://www.gamersberg.com/grow-a-garden/stock/${type}/${name.replace(/\s+/g, '-').replace(/[^a-zA-Z0-9\-]/g, '')}.webp`,

  check: async () => {
    const jar = new tough.CookieJar()
    const client = wrapper(axios.create({ jar }))

    try {
      await client.get('https://www.gamersberg.com/grow-a-garden/stock', {
        headers: {
          'user-agent': gardenStock.headers['user-agent'],
          referer: gardenStock.headers.referer
        }
      })

      const { data } = await client.get('https://www.gamersberg.com/api/grow-a-garden/stock', {
        headers: gardenStock.headers,
        timeout: 15000
      })

      const payload = data?.data?.[0]
      if (!payload) {
        throw 'data grow a garden kosong'
      }

      const {
        weather,
        seeds,
        gear,
        eggs,
        cosmetic,
        updateNumber,
        timestamp
      } = payload

      const fmt = (obj, type) =>
        Object.entries(obj).map(([name, qty]) => ({
          name,
          quantity: Number(qty),
          image: gardenStock.image(type, name)
        }))

      const eggx = eggs.map(({ name, quantity }) => ({
        name,
        quantity: Number(quantity),
        image: gardenStock.image('eggs', name)
      }))

      return {
        success: true,
        result: {
          updateNumber,
          timestamp,
          weather,
          seeds: fmt(seeds, 'seeds'),
          gear: fmt(gear, 'gear'),
          cosmetic: fmt(cosmetic, 'cosmetics'),
          eggs: eggx
        }
      }
    } catch (err) {
      return {
        success: false,
        error: err?.message || 'gagal mengambil data'
      }
    }
  }
}

let handler = async (m) => {
  try {
    const json = await gardenStock.check()

    if (!json.success || !json.result) {
      throw 'data tidak ditemukan'
    }

    const data = json.result

    const formatItems = (title, items) => {
      if (!items?.length) return ''
      let text = `\n*${title.toUpperCase()}*\n`
      for (const item of items) {
        text += `${item.name} = ${item.quantity}\n`
      }
      return text
    }

    const formatWeather = (w) => {
      if (!w) return ''
      return `\n*Cuaca saat ini*\ntipe : ${w.type}\naktif : ${w.active ? 'ya' : 'tidak'}`
    }

    let output = '*Stok Grow a Garden:*\n'
    output += formatItems('seeds', data.seeds)
    output += formatItems('gear', data.gear)
    output += formatItems('eggs', data.eggs)
    output += formatItems('cosmetics', data.cosmetic)
    output += formatWeather(data.weather)
    output += `\n\nUpdate #: ${data.updateNumber}\nWaktu Update: ${new Date(data.timestamp).toLocaleString('id-ID')}`

    m.reply(output.trim())
  } catch (e) {
    m.reply('gagal mengambil data grow a garden')
    console.error(e)
  }
}

handler.help = ['stokgag']
handler.tags = ['info']
handler.command = ['stokgag']

export default handler