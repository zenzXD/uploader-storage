import fs from 'fs';
import path from 'path';
import * as acorn from 'acorn';

let cuki = async (m, { conn }) => {
    let pluginFolder = './plugins';
    let errorList = [];

    if (!fs.existsSync(pluginFolder)) {
        return m.reply('❌ Folder plugins tidak ditemukan!');
    }

    let files = fs.readdirSync(pluginFolder).filter(file => file.endsWith('.js'));

    for (let file of files) {
        try {
            let filePath = path.resolve(pluginFolder, file);
            let code = fs.readFileSync(filePath, 'utf8');

            acorn.parse(code, { sourceType: 'module', ecmaVersion: 'latest' });
        } catch (err) {
            errorList.push(`❌ ${file}: ${err.message}`);
        }
    }

    if (errorList.length === 0) {
        m.reply('✅ Semua fitur aman, tidak ada error!');
    } else {
        m.reply(`🚨 Ditemukan ${errorList.length} error pada fitur:\n\n` + errorList.join('\n'));
    }
};

cuki.help = ['checkerror'];
cuki.tags = ['owner'];
cuki.command = /^checkerror|cekeror$/i;
cuki.rowner = true;

export default cuki;