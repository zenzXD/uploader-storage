let handler = async (m, { conn, text, command }) => {
  const url = text?.trim();

  if (!url)
    return m.reply(`contoh : .capcutdl <url>`);

  if (!url.includes("capcut.com"))
    return m.reply('ngirim link apetu woy 🙄');

  try {
    const body = JSON.stringify({ url });

    const res = await fetch("https://3bic.com/api/download", {
      method: "POST",
      headers: {
        "accept": "application/json, text/plain, */*",
        "content-type": "application/json",
        "origin": "https://3bic.com",
        "referer": "https://3bic.com/",
        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36"
      },
      body
    });

    if (!res.ok) throw new Error(`Eror kak : ${res.status}`);

    const json = await res.json();

    const encoded = json.originalVideoUrl?.split("/api/cdn/")[1];
    const video = encoded ? Buffer.from(encoded, "base64").toString() : null;

    if (!video || !json.title)
      return m.reply('ngirim link apetu woy 🙄');

    const caption = `*capcut downloader*\n*judul :* ${json.title}\n*author :* ${json.authorName}`;

    await conn.sendFile(m.chat, video, 'capcut.mp4', caption, m);

  } catch (e) {
    return m.reply(`Eror kak : ${e.message}`);
  }
};

handler.command = ['capcutdl']
handler.help = ['capcutdl <url>']
handler.tags = ['downloader']

export default handler