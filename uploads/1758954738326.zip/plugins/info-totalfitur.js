import fs from 'fs'
let { generateWAMessageFromContent } = (await import("@adiwajshing/baileys")).default 

let handler = async (m, { conn }) => {
  let fitur = Object.values(plugins).filter(v => v.help && !v.disabled).map(v => v.help).flat(1)

  let totalfitur = fitur.length

  let prep = generateWAMessageFromContent(m.chat, {
    orderMessage: {
      itemCount: 2025,
      status: 200,
      surface: 999,
      message: `Jumlah Fitur Saat Ini: ${totalfitur}`,
      orderTitle: 'List Fitur',
      thumbnail: fs.readFileSync('media/thumb-1.jpg'),
      thumbnaiUrl: 'https://telegra.ph/file/ab3f28db702661e97b233.jpg',
      sellerJid: '6283867884739@s.whatsapp.net',
      token: '1',
      totalAmount1000: '10000',
      totalCurrencyCode: 'FTR',
      curreyCode: 'FTR',
      description: 'Semakin banyak fitur, semakin seru!'
    }
  }, { quoted: m })

  conn.relayWAMessage(prep)
}

handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = ['totalfitur']
export default handler