/*

# Fitur : fakefb
# Type : Plugins ESM
# Created by : https://whatsapp.com/channel/0029Vb2qri6JkK72MIrI8F1Z
# Api : local canvas

   ⚠️ _Note_ ⚠️
jangan hapus wm ini banggg

*/

import { createCanvas, loadImage } from 'canvas'
import fs from 'fs'

let handler = async (m, { text, conn, usedPrefix, command }) => {
  try {
    let [nama, komentar] = text.split('|')
    if (!nama || !komentar) throw `Format salah!\n\nContoh: ${usedPrefix + command} Cuki|Yg penting pc gaming`

    let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://i.ibb.co/3pPYd14/pp.jpg')
    let pp = await loadImage(ppUrl)

    const canvas = createCanvas(500, 120)
    const ctx = canvas.getContext('2d')

    ctx.fillStyle = '#fff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    ctx.save()
    ctx.beginPath()
    ctx.arc(30, 30, 20, 0, Math.PI * 2)
    ctx.closePath()
    ctx.clip()
    ctx.drawImage(pp, 10, 10, 40, 40)
    ctx.restore()

    ctx.font = '13px Arial'
    const namaWidth = ctx.measureText(nama.trim()).width

    ctx.font = '12px Arial'
    const komentarWidth = ctx.measureText(komentar.trim()).width

    const maxWidth = Math.max(namaWidth, komentarWidth) + 24

    ctx.fillStyle = '#f0f2f5'
    roundedRect(ctx, 65, 15, maxWidth, 42, 10)
    ctx.fill()

    ctx.fillStyle = '#050505'
    ctx.font = '13px Arial'
    ctx.fillText(nama.trim(), 72, 30)

    ctx.fillStyle = '#050505'
    ctx.font = '12px Arial'
    ctx.fillText(komentar.trim(), 72, 45)

    ctx.fillStyle = '#65676b'
    ctx.font = '10px Arial'
    ctx.fillText('2 jam · Suka · Balas · Bagikan', 72, 75)

    const out = canvas.toBuffer()
    fs.writeFileSync('./tmp/fakefb.jpg', out)

    await conn.sendMessage(m.chat, {
      image: out,
      caption: '✅ Komentar palsu berhasil dibuat'
    }, { quoted: m })

 } catch (e) {
  if (typeof e === 'string') return m.reply(e)
  console.log(e)
  m.reply(`❌ Error\nLogs error : ${e.message || e}`)
}
}

function roundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

handler.help = ['fakefb <nama>|<komentar>']
handler.tags = ['maker']
handler.command = /^fakefb$/i
export default handler