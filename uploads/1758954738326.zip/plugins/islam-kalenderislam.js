import MurotalAPI from 'cloudku-murotal';

let handler = async (m, { text }) => {
  try {
    const api = new MurotalAPI();

    let res = text
      ? await api.getHijriDate(text)
      : await api.getTodayHijriDate();

  
    const hijri = res?.result?.date[1] || 'gatau';
    const gregorian = res?.result?.date[2] || 'gatau';

    const msg = `*Kalender Islam*\n\n Masehi: ${gregorian}\nHijriah: ${hijri}`;
    m.reply(msg);
  } catch (e) {
    console.error('[ERROR] gagal mengambil data:', e);
    m.reply('eror 😅');
  }
};

handler.help = ['kalenderislam'];
handler.tags = ['islam'];
handler.command = /^kalenderislam$/i;

export default handler;