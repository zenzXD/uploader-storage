let handler = async (m, { command, text }) => {
  let quotedText = m.quoted?.text
  let input = quotedText || text

  if (!input) return m.reply('❌ Balas pesan teks atau ketik teks yang ingin diubah ke Base64.\n\nContoh:\n.reply text lalu ketik *.base64*\n\nAtau langsung:\n*.base64 Hello world*')

  let base64 = Buffer.from(input, 'utf-8').toString('base64')
  m.reply(`📦 *Hasil Encode Base64:*\n\n\`\`\`${base64}\`\`\``)
}

handler.help = ['base64']
handler.tags = ['tools']
handler.command = /^base64$/i

export default handler