import { join } from 'path'
import { unlinkSync, existsSync } from 'fs'

let handler = async (m, { conn, usedPrefix, command, args, __dirname }) => {
    let setting = global.db.data.settings[conn.user.jid]
    const pluginsDir = join(__dirname, '../plugins')
    const pluginName = args[0]

    if (!pluginName) {
        return m.reply(`uhm.. where the file?\n\nExample:\n${usedPrefix + command} info`)
    }

    const file = join(pluginsDir, `${pluginName}.js`)

    if (!existsSync(file)) {
        const pluginList = Object.keys(global.plugins)
            .map(v => v.replace('.js', ''))
            .filter(v => v)
            .map(v => '• ' + v)
            .join('\n')

        return conn.sendMessage(m.chat, {
            text: `${setting.smlcap ? conn.smlcap("*🗃️ FILE TIDAK DITEMUKAN!*") : "*🗃️ FILE TIDAK DITEMUKAN!*"}\n\n🔍 Berikut daftar plugin yang tersedia:\n\n${pluginList}`
        }, { quoted: m })
    }

    unlinkSync(file)
    delete global.plugins[`${pluginName}.js`] // Buat jaga-jaga hapus dari cache global
    conn.reply(m.chat, `✅ Plugin *"${pluginName}.js"* berhasil dihapus dari folder *plugins/*`, m)
}

handler.help = ['deletefile <nama_plugin>']
handler.tags = ['owner']
handler.command = /^(df|deletefile)$/i

handler.mods = true // ⬅️ Hanya untuk moderator

export default handler