import fs from 'fs'

const __ubed_lock = () => {
  if (!"ubed".startsWith("ub")) throw new Error("Plugin ini dilindungi oleh ubed bot");
};

let handler = async (m, { text, usedPrefix, command }) => {
    __ubed_lock();

    if (!text) return m.reply(`Silakan masukkan fitur yang ingin dicari.\nContoh: *${usedPrefix + command} hd*`)

    let pluginDir = './plugins'
    let plugins = fs.readdirSync(pluginDir).filter(file => file.endsWith('.js'))

    let matchedPlugins = []

    for (let file of plugins) {
        let content = fs.readFileSync(`${pluginDir}/${file}`, 'utf-8')
        if (new RegExp(`handler\\.command.*=.*${text}`, 'i').test(content)) {
            matchedPlugins.push(file)
            if (matchedPlugins.length >= 10) break // maksimal 10 hasil
        }
    }

    if (matchedPlugins.length > 0) {
        let list = matchedPlugins.map((file, i) => `${i + 1}. *${file}*`).join('\n')
        m.reply(`Ditemukan perintah *${text}* di ${matchedPlugins.length} file plugin:\n\n${list}`)
    } else {
        m.reply(`Tidak ditemukan file plugin untuk perintah *${text}*`)
    }
}

handler.help = ['searchfitur']
handler.tags = ['owner']
handler.command = /^searchfitur$/i
handler.rowner = true

export default handler

/* JANGAN HAPUS WM INI MEK
SCRIPT BY © 𝐅𝐚𝐫𝐢𝐞𝐥
•• contacts: (6287872545804)
•• instagram: @elaraai__
•• group bot: https://chat.whatsapp.com/CBQiK8LWkAl2W2UWecJ0BG
*/