export async function before(m) {
    this.ev.on('call', async (call) => {
        let callData = call[0];
        let setting = global.db.data.settings[this.user.jid] || {};

        if (callData.status === 'offer' && setting.anticall) {
            // Tolak panggilan
            await this.rejectCall(callData.id, callData.from);

            // Kirim peringatan ke pemanggil
            await this.sendMessage(callData.from, {
                text: `❌ *Anti Call Aktif*\nMaaf, kamu tidak diperbolehkan menelpon bot.\n\nKarena melanggar, kamu telah diblokir otomatis.`,
            });

            // Blokir pemanggil
            await this.updateBlockStatus(callData.from, "block");
        }
    });
    return !0;
}