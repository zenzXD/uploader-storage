import fetch from 'node-fetch'
import { sizeFormatter } from 'human-readable'

const formatSize = sizeFormatter({
  std: 'JEDEC', // Pakai KB/MB/GB
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}`
})

const handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`🚫 Masukkan URL Terabox!\n\nContoh:\n${command} https://terasharelink.com/s/xxxx`)

  try {
    const res = await fetch(`https://zenz.biz.id/downloader/terabox?url=${encodeURIComponent(text)}`)
    const json = await res.json()

    if (!json.status || !json.result?.direct_url) {
      return m.reply('⚠️ Gagal mendapatkan data. Pastikan URL valid.')
    }

    const {
      filename,
      size,
      thumb,
      direct_url
    } = json.result

    const sizeNum = parseInt(size)
    const thumbBuffer = await (await fetch(thumb)).buffer()

    // Paksa kirim file langsung
    await conn.sendMessage(m.chat, {
      document: { url: direct_url },
      mimetype: 'video/mp4',
      fileName: filename,
      fileLength: sizeNum,
      jpegThumbnail: thumbBuffer,
      caption: `🎬 *${filename}*\n📦 Ukuran: ${formatSize(sizeNum)}\n📁 Tipe: Video`
    }, { quoted: m })

  } catch (err) {
    console.error('❌ Gagal upload file:', err)
    m.reply('❌ Terjadi kesalahan saat mengunduh atau mengirim file.')
  }
}

handler.help = ['teradl <link>']
handler.tags = ['downloader']
handler.command = /^teradl$/i
handler.limit = true
handler.premium = false

export default handler