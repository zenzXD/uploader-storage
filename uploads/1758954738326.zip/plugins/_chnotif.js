import moment from 'moment-timezone'

const OWNER_NUMBER = '6287823745178@s.whatsapp.net' // Nomor owner
const CHANNEL_ID = '120363402532362931@newsletter' // ID channel target
const forbidden = [
  'https://crotpedia.net',
  'xnxx.com',
  'pornhub.com',
  'pixhentai.com',
  'mangasusuku.com',
  'lewatsana.com/xpanas',
  'nhentai.to',
  'nekopoi.care'
]

let handler = async (m, { conn }) => {}

handler.all = true
export default handler

export function onEvent(conn) {
  conn.ev.on('messages.upsert', async (update) => {
    if (update.type !== 'notify' || !update.messages[0]) return
    const raw = update.messages[0]

    // Deteksi pesan dari channel yang dipantau
    if (raw.key.remoteJid === CHANNEL_ID) {
      const idPesan = raw.key.id || '-'
      const isiPesan =
        raw.message?.conversation ||
        raw.message?.extendedTextMessage?.text ||
        raw.message?.imageMessage?.caption ||
        raw.message?.videoMessage?.caption ||
        raw.message?.documentMessage?.caption ||
        '[Non-text message]'

      let tipe = 'Lainnya'
      if (raw.message?.imageMessage) tipe = 'Gambar'
      else if (raw.message?.stickerMessage) tipe = 'Stiker'
      else if (raw.message?.videoMessage) tipe = 'Video'
      else if (raw.message?.audioMessage) tipe = 'Audio'
      else if (raw.message?.conversation || raw.message?.extendedTextMessage) tipe = 'Teks'

      const serverId = raw.newsletter_server_id || '-'
      const link = serverId !== '-' ? `https://whatsapp.com/channel/0029VasjrIh3gvWXKzWncf2P/${serverId}` : 'Link tidak tersedia'
      const waktu = moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm')

      await conn.sendMessage(OWNER_NUMBER, {
        text: 
`Pesan baru di channel

ID Pesan:
${idPesan}

Jenis Pesan:
${tipe}

Link Pesan:
${link}

Isi Pesan:
${isiPesan}`,
        buttons: [
          {
            buttonId: `.delch ${CHANNEL_ID},${idPesan}`,
            buttonText: { displayText: 'Hapus Pesan' },
            type: 1
          }
        ],
        footer: waktu
      })
    }

    // Deteksi kata/link terlarang di semua channel
    if (raw.key.remoteJid.endsWith('@newsletter')) {
      const idPesan = raw.key.id
      const idChannel = raw.key.remoteJid

      const isiPesan =
        raw.message?.conversation ||
        raw.message?.extendedTextMessage?.text ||
        raw.message?.imageMessage?.caption ||
        raw.message?.videoMessage?.caption ||
        raw.message?.documentMessage?.caption ||
        ''

      if (forbidden.some(word => isiPesan.toLowerCase().includes(word))) {
        try {
          await conn.sendMessage(idChannel, {
            text: 'Pesan ini melanggar pedoman dan akan dihapus.',
            edit: raw.key
          })
        } catch (e) {
          console.error('Gagal edit pesan:', e)
        }

        setTimeout(async () => {
          try {
            await conn.sendMessage(idChannel, {
              delete: {
                remoteJid: idChannel,
                fromMe: true,
                id: idPesan
              }
            })
            console.log(`Pesan ${idPesan} di ${idChannel} berhasil dihapus.`)
          } catch (e) {
            console.error('Gagal hapus pesan:', e)
          }
        }, 5000)
      }
    }
  })
}