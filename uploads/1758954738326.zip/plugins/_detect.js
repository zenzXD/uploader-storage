import { WAMessageStubType } from '@adiwajshing/baileys'

export async function before(m) {
	if (!m.messageStubType || !m.isGroup) return;
	let edtr = `@${m.sender.split`@`[0]}`
	switch (m.messageStubType) {
		case 21:
			await conn.sendMessage(m.chat, { text: `Wih, ${edtr} baru aja ganti nama grup jadi:\n*${m.messageStubParameters[0]}*`, mentions: [m.sender] }, { quoted: m })
			break
		case 22:
			await conn.sendMessage(m.chat, { text: `Eh, ${edtr} barusan ganti icon grup nih!`, mentions: [m.sender] }, { quoted: m })
			break
		case 1: case 23: case 132:
			await conn.sendMessage(m.chat, { text: `Link grup udah di-*reset* sama ${edtr}.\nYah, yang mau nyusul jadi gak bisa tuh!`, mentions: [m.sender] }, { quoted: m })
			break
		case 24:
			await conn.sendMessage(m.chat, { text: `Deskripsi grup di-*update* oleh ${edtr}:\n\n"${m.messageStubParameters[0]}"`, mentions: [m.sender] }, { quoted: m })
			break
		case 25:
			await conn.sendMessage(m.chat, { text: `${edtr} sekarang ngatur biar *${m.messageStubParameters[0] == 'on' ? 'cuma admin' : 'semua member'}* yang bisa ubah info grup.`, mentions: [m.sender] }, { quoted: m })
			break
		case 26:
			await conn.sendMessage(m.chat, { text: `Grup ini ${m.messageStubParameters[0] == 'on' ? '*ditutup* sama' : '*dibuka* kembali oleh'} ${edtr}!\nSekarang *${m.messageStubParameters[0] == 'on' ? 'cuma admin yang bisa' : 'semua member bisa'}* kirim pesan.`, mentions: [m.sender] }, { quoted: m })
			break
		case 29:
			await conn.sendMessage(m.chat, { text: `${edtr} ngangkat @${m.messageStubParameters[0].split`@`[0]} jadi admin baru!`, mentions: [m.sender, m.messageStubParameters[0]] }, { quoted: m })
			break
		case 30:
			await conn.sendMessage(m.chat, { text: `${edtr} mencopot jabatan admin dari @${m.messageStubParameters[0].split`@`[0]}!`, mentions: [m.sender, m.messageStubParameters[0]] }, { quoted: m })
			break
		case 72:
			await conn.sendMessage(m.chat, { text: `${edtr} ganti durasi pesan sementara jadi *@${m.messageStubParameters[0]}*`, mentions: [m.sender] }, { quoted: m })
			break
		case 123:
			await conn.sendMessage(m.chat, { text: `${edtr} *menonaktifkan* fitur pesan sementara.`, mentions: [m.sender] }, { quoted: m })
			break
		default:
			console.log({
				messageStubType: m.messageStubType,
				messageStubParameters: m.messageStubParameters,
				type: WAMessageStubType[m.messageStubType],
			})
			break
	}
}

export const disabled = false