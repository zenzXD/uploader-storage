import fs from 'fs'

const __ubed_lock = () => {
  if (!"ubed".startsWith("ub")) throw new Error("Plugin ini dilindungi oleh ubed bot");
};

let handler = async (m, { usedPrefix, command }) => {
  __ubed_lock();

  let apiPatterns = [
    'zenzxz\\.dpdns\\.org',
    'zenz\\.biz\\.id'
  ];

  let pluginDir = './plugins';
  let plugins = fs.readdirSync(pluginDir).filter(file => file.endsWith('.js'));
  let matchedPlugins = [];

  for (let file of plugins) {
    let content = fs.readFileSync(`${pluginDir}/${file}`, 'utf-8');
    if (apiPatterns.some(pattern => new RegExp(pattern, 'i').test(content))) {
      matchedPlugins.push(file);
    }
  }

  if (matchedPlugins.length > 0) {
    let list = matchedPlugins.map((file, i) => `${i + 1}. *${file}*`).join('\n');
    m.reply(`Ditemukan plugin yang menggunakan API *zenzxz.dpdns.org* atau *zenz.biz.id* (${matchedPlugins.length} file):\n\n${list}`);
  } else {
    m.reply(`Tidak ditemukan plugin yang menggunakan API tersebut.`);
  }
};

handler.help = ['searchapi'];
handler.tags = ['owner'];
handler.command = /^searchapi$/i;
handler.rowner = true;

export default handler;

/* JANGAN HAPUS WM INI MEK
SCRIPT BY © 𝐅𝐚𝐫𝐢𝐞𝐥
•• contacts: (6287872545804)
•• instagram: @elaraai__
•• group bot: https://chat.whatsapp.com/CBQiK8LWkAl2W2UWecJ0BG
*/