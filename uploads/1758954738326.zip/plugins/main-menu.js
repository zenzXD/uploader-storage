import os from "os"
import fs from "fs"
import speed from "performance-now"
import moment from "moment-timezone"
import { exec } from "child_process"

let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
    const isMods = [conn.decodeJid(global.conn.user.id), ...global.config.owner.filter(([number, _, isDeveloper]) => number && isDeveloper).map(([number]) => number)].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
    const isOwner = m.fromMe || isMods || [conn.decodeJid(global.conn.user.id), ...global.config.owner.filter(([number, _, isDeveloper]) => number && !isDeveloper).map(([number]) => number)].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
    const isPrems =  isOwner || new Date() - user.premiumTime < 0
    const more = String.fromCharCode(8206)
    const readMore = more.repeat(4001)
    
    let activeFeatures = Object.values(global.plugins)
            .filter(v => v.help && !v.disabled)
            .map(v => v.help)
            .flat(1);

        let totalFeatures = activeFeatures.length;
  
    let caption = `
${ucapan()} ${m.pushName}

┏━〔 *INFO USER* 〕━┓
┃ ∘ Nama   : ${user.registered ? user.name : conn.getName(m.sender)}
┃ ∘ Status : ${isPrems ? 'Premium' : 'Free'}
┃ ∘ Limit  : ${isPrems ? 'Unlimited' : toRupiah(user.limit)}
┃ ∘ Level  : ${toRupiah(user.level)}
┃ ∘ EXP    : ${toRupiah(user.exp)}
┃ ∘ Uang   : ${toRupiah(user.money)}
┃${user.atm ? `┃ ∘ ATM    : Lv.${toRupiah(user.atm)} | ${toRupiah(user.bank)} / ${toRupiah(user.fullatm)} $` : ''}
┗━━━━━━━━━━━━━━━┛

┏━〔 *INFO BOT* 〕━┓
┃ ∘ Bot    : Vynex - MD
┃ ∘ Lib    : Baileys
┃ ∘ Node   : v21
┃ ∘ Panel  : Pterodactyl
┃ ∘ Prefix : [ . ]
┃ ∘ Fitur  : ${totalFeatures.toLocaleString()}
┃ ∘ Script : Plugin ESM
┃ ∘ Owner  : Zenzz XD
┗━━━━━━━━━━━━━━━┛
`

    
/*==========[ LIST MUSIKKKKKKKK!!!! ]==========*/
    const audioList = [
      'https://files.catbox.moe/s0bxtw.mp3',
      'https://files.catbox.moe/mlqsbj.m4a',
      'https://files.catbox.moe/yeetzf.mp3',
      'https://files.catbox.moe/py7ec6.mp3'
    ]

    const randomAudio = audioList[Math.floor(Math.random() * audioList.length)]

/*==========[ REAKSION :V ]==========*/
    await conn.sendMessage(m.chat, { react: { text: '⏰', key: m.key } })

/*==========[ MENU NYA ]==========*/
await conn.sendMessage(m.chat, {
        image: { url: "https://files.catbox.moe/tfwn4x.jpg" },
        caption,
        footer: 'ᴀʟʟ ᴛᴇᴀᴍ - ᴠʏɴᴇx - ᴍᴅ',
        buttons: [
            {
                buttonId: 'mainmenu',
                buttonText: { displayText: '*ᴠʏɴᴇx-ᴍᴅ ᴍᴇɴᴜ*' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: 'ᴠʏɴᴇx-ᴍᴅ ᴍᴇɴᴜ',
                        sections: [
                            {
                                title: "ᴍᴇɴᴜʟɪsᴛ ᴠʏɴᴇx-ᴍᴅ",
                                highlight_label: "🔥",
                                rows: [
  { title: "All", description: "📋 Semua menu", id: ".menulist all" },
  { title: "Main", description: "🏠 Menu utama", id: ".menulist main" },
  { title: "Topup", description: "💸 Menu Topup", id: ".menulist topup" },
  { title: "AI", description: "🤖 Menu AI", id: ".menulist ai" },
  { title: "Store", description: "🛒 Menu Store", id: ".menulist store" },
  { title: "Game", description: "🎮 Menu Game", id: ".menulist game" },
  { title: "RPG", description: "🎲 Menu RPG", id: ".menulist rpg" },
  { title: "XP", description: "📈 Menu XP/Level", id: ".menulist xp" },
  { title: "Sticker", description: "🖼️ Menu Sticker", id: ".menulist sticker" },
  { title: "Kerang", description: "🐚 Menu Kerang", id: ".menulist kerang" },
  { title: "Quotes", description: "💬 Menu Quotes", id: ".menulist quotes" },
  { title: "Fun", description: "🎉 Menu Fun", id: ".menulist fun" },
  { title: "Anime", description: "🎥 Menu Anime", id: ".menulist anime" },
  { title: "Group", description: "👥 Menu Group", id: ".menulist group" },
  { title: "Premium", description: "🌟 Menu Premium", id: ".menulist premium" },
  { title: "NSFW", description: "🔞 Menu NSFW", id: ".menulist nsfw" },
  { title: "Internet", description: "🌐 Menu Internet", id: ".menulist internet" },
  { title: "Genshin", description: "🎮 Menu Genshin", id: ".menulist genshin" },
  { title: "News", description: "📰 Menu Berita", id: ".menulist news" },
  { title: "Downloader", description: "📥 Menu Downloader", id: ".menulist downloader" },
  { title: "Search", description: "🔍 Menu Search", id: ".menulist search" },
  { title: "Tools", description: "🛠️ Menu Tools", id: ".menulist tools" },
  { title: "Primbon", description: "📜 Menu Primbon", id: ".menulist primbon" },
  { title: "Nulis", description: "✍️ Menu Nulis", id: ".menulist nulis" },
  { title: "Audio", description: "🔊 Menu Audio", id: ".menulist audio" },
  { title: "Maker", description: "🎨 Menu Maker", id: ".menulist maker" },
  { title: "Database", description: "💾 Menu Database", id: ".menulist database" },
  { title: "Quran", description: "📖 Menu Quran", id: ".menulist quran" },
  { title: "Owner", description: "👤 Menu Owner", id: ".menulist owner" },
  { title: "Info", description: "ℹ️ Menu Info", id: ".menulist info" },
  { title: "Sound", description: "🔉 Menu Sound", id: ".menulist sound" },
  { title: "Panel", description: "🔲 Menu Panel", id: ".menulist panel" }
]
                            }
                        ]
                    })
                }
            },
            {
                buttonId: 'moremenu',
                buttonText: { displayText: '*ᴠʏɴᴇx-ᴍᴅ ɪɴғᴏ*' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: 'ᴠʏɴᴇx-ᴍᴅ ɪɴғᴏ',
                        sections: [
                            {
                                title: "ɪɴғᴏ - ᴠʏɴᴇx",
                                highlight_label: "🚀",
                                rows: [
  { title: "👑 Owner", description: "Informasi tentang pemilik bot", id: ".owner" },
  { title: "🧹 Clear Session", description: "Hapus session saat ini", id: ".clearsession" },
  { title: "⚙️ Total Fitur", description: "Jumlah fitur yang tersedia", id: ".totalfitur" },
  { title: "📶 Ping", description: "Cek kecepatan respon bot", id: ".ping" },
  { title: "🙏 Thanks To", description: "Ucapan terima kasih & kredit", id: ".tqto" }
                                ]
                            }
                        ]
                    })
                }
            }
        ],
        headerType: 6,
        viewOnce: true,
        document: fs.readFileSync("./media/vynex.jpg"),
  mimetype: 'image/jpg',
  fileLength: 9999,
  jpegThumbnail: fs.readFileSync('./media/vynex.jpg'),
fileName: `${ucapan()}`,
  caption: caption,
  contextInfo: {
  externalAdReply: {
  title: `ᴠ ʏ ɴ ᴇ x - ᴍ ᴅ`,
      body: ` ᴢ ᴇ ɴ ᴢ x ᴢ`,
      thumbnailUrl: 'https://files.cloudkuimages.guru/images/4F7PMoGO.jpg',
      sourceUrl: '',
      mediaType: 1,
      renderLargerThumbnail: true,
}
}
    }, { quoted: fkon })

/*==========[ AUDIO CUY ]==========*/
    await conn.sendMessage(m.chat, {
  audio: { url: randomAudio },
  mimetype: 'audio/mpeg',
  ptt: true
}, { quoted: m })
}

handler.command = ['menu']
handler.tags = ['main']
handler.help = ['menu']
handler.register = true

export default handler

const toRupiah = number => parseInt(number).toLocaleString().replace(/,/g, ".")
/*=========[ FUNC WAKTU ]========*/
function ucapan() {
    const time = moment.tz('Asia/Jakarta').format('HH')
    if (time >= 4 && time < 10) return "sᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ 🌄" 
    if (time >= 10 && time < 15) return "sᴇʟᴀᴍᴀᴛ sɪᴀɴɢ ☀️" 
    if (time >= 15 && time < 18) return "sᴇʟᴀᴍᴀᴛ sᴏʀᴇ 🌇" 
    if (time >= 18 || time < 4) return "sᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ 🌙" 
    return "ʏᴀʜᴏᴏ~"
}