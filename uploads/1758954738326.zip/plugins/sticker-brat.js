import axios from 'axios'
import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, command, usedPrefix, text }) => {
  text = m.quoted && !text ? m.quoted.text : text
  if (!text) return m.reply(`Masukkan teks!\n\nContoh:\n${usedPrefix + command} hello word`)

  if (typeof m.react === 'function') await m.react('🕐')
  await global.loading(m, conn)

  try {
    let imageUrl = `https://brat.siputzx.my.id/image?text=${encodeURIComponent(text)}`
    let imageBuffer = (await axios.get(imageUrl, { responseType: 'arraybuffer' })).data
    let stiker = await sticker(imageBuffer, false, global.config.stickpack, global.config.stickauth)
    await conn.sendFile(m.chat, stiker, '', '', m)
    if (typeof m.react === 'function') await m.react('✅')
  } catch (e) {
    m.reply('❌ Gagal membuat stiker.')
  } finally {
    await global.loading(m, conn, true)
  }
}

handler.help = ['brat']
handler.tags = ['sticker']
handler.command = /^(brat)$/i

export default handler