import { createCanvas, loadImage } from 'canvas'

const handler = async (m, { conn, text }) => {
  try {
    const parts = text.split('|')
    if (parts.length < 3) throw `Example:\n.fthreads dennis.id|1h|Just testing the bot feature|https://linkpp.com/avatar.jpg`

    const nama = parts[0].trim()
    const waktu = parts[1].trim()
    let ppurl = null

    const lastPart = parts[parts.length - 1].trim()
    if (lastPart.startsWith('http://') || lastPart.startsWith('https://')) {
      ppurl = parts.pop().trim()
    }

    const teks = parts.slice(2).join('|').trim()
    if (!nama || !waktu || !teks) throw `Example:\n.fthreads dennis.id|1h|Just testing the bot feature|https://linkpp.com/avatar.jpg`

    let pp = ppurl || await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://i.ibb.co/0jqHpnp/user.png')
    let bg = await loadImage('https://files.catbox.moe/2m1cfv.jpg')
    let plus = await loadImage('https://files.catbox.moe/z6qx7u.jpg')
    let avatar
    try {
      avatar = await loadImage(pp)
    } catch {
      avatar = await loadImage('https://i.ibb.co/0jqHpnp/user.png')
    }

    const canvasWidth = bg.width
    const canvasHeight = bg.height
    const canvas = createCanvas(canvasWidth, canvasHeight)
    const ctx = canvas.getContext('2d')
    ctx.drawImage(bg, 0, 0)

    // Draw avatar
    ctx.save()
    ctx.beginPath()
    ctx.arc(60, 65, 40, 0, Math.PI * 2)
    ctx.closePath()
    ctx.clip()
    ctx.drawImage(avatar, 20, 25, 80, 80)
    ctx.restore()

    // Draw name
    ctx.font = 'bold 28px Sans-serif'
    ctx.fillStyle = '#ffffff'
    ctx.fillText(nama, 115, 60)

    const namaWidth = ctx.measureText(nama).width
    const waktuX = 115 + namaWidth + 15

    // Draw time
    ctx.font = '26px Sans-serif'
    ctx.fillStyle = '#777777'
    ctx.fillText(waktu, waktuX, 60)

    // Draw text
    ctx.font = '26px Sans-serif'
    ctx.fillStyle = '#ffffff'
    const lines = teks.split('\n')
    let startY = 110
    for (let i = 0; i < lines.length; i++) {
      ctx.fillText(lines[i], 115, startY + i * 35)
    }

    // You can now use the 'plus' image if you want, for example, to draw a '+' button
    // ctx.drawImage(plus, x, y, width, height)

    let buffer = canvas.toBuffer('image/jpeg')
    await conn.sendFile(m.chat, buffer, 'fakethreads.jpg', '', m)
  } catch (e) {
    m.reply(`Error\n${e}`)
  }
}

handler.command = ['fthreads', 'fakethreads']
handler.help = ['fthreads nama|waktu|teks|ppurl']
handler.tags = ['maker']
export default handler