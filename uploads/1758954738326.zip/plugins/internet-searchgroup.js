/*
* Nama fitur : Search Group Wangsaff
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6chx1LI8YVtJJJ9a0Y
* Author : ZenzzXD
* Sumber skrep : Gienetic https://whatsapp.com/channel/0029Vb5EZCjIiRotHCI1213L/457
*/

import axios from 'axios'
import cheerio from 'cheerio'

let handler = async (m, { conn, command, text }) => {
  if (!text) return m.reply('Contoh : .searchgroup <keyword>')

  try {
    m.reply('wett')
    const searchUrl = `https://whatsgrouplink.com/?s=${encodeURIComponent(text)}`
    const { data } = await axios.get(searchUrl, { timeout: 10000 })
    const $ = cheerio.load(data)
    const results = []

    $('article').each((_, el) => {
      const title = $(el).find('.entry-title a').text().trim()
      const url = $(el).find('.entry-title a').attr('href')
      if (title && url) {
        results.push({ title, url })
      }
    })

    if (!results.length) return m.reply('gk ada hasil yg ditemukan')

    let message = 'Hasil :\n\n'
    for (let i = 0; i < results.length; i++) {
      message += `${i + 1}). ${results[i].title}\n${results[i].url}\n\n`
    }

    m.reply(message)
  } catch (e) {
    m.reply(`Eror kak : ${e.message}`)
  }
}

handler.help = ['searchgroup <keyword>']
handler.tags = ['internet']
handler.command = ['searchgroup']

export default handler