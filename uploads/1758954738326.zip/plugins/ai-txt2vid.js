/*
* Nama Fitur : Text to video ( aivideogenerator )
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6Zs8yEgGfRQWWWp639
* Author : ZenzXD
*/

import axios from 'axios'
import crypto from 'crypto'

async function veo3(prompt, { model = 'veo-3-fast', auto_sound = false, auto_speech = false } = {}) {
    try {
        const _model = ['veo-3-fast', 'veo-3']
        
        if (!prompt) throw new Error('Prompt is required')
        if (!_model.includes(model)) throw new Error(`Available models: ${_model.join(', ')}`)
        if (typeof auto_sound !== 'boolean') throw new Error('Auto sound must be a boolean')
        if (typeof auto_speech !== 'boolean') throw new Error('Auto speech must be a boolean')
        
        const { data: cf } = await axios.get('https://api.nekorinn.my.id/tools/rynn-stuff', {
            params: {
                mode: 'turnstile-min',
                siteKey: '0x4AAAAAAANuFg_hYO9YJZqo',
                url: 'https://aivideogenerator.me/features/g-ai-video-generator',
                accessKey: 'e2ddc8d3ce8a8fceb9943e60e722018cb23523499b9ac14a8823242e689eefed'
            }
        })
        
        const uid = crypto.createHash('md5').update(Date.now().toString()).digest('hex')
        const { data: task } = await axios.post('https://aiarticle.erweima.ai/api/v1/secondary-page/api/create', {
            prompt: prompt,
            imgUrls: [],
            quality: '720p',
            duration: 8,
            autoSoundFlag: auto_sound,
            soundPrompt: '',
            autoSpeechFlag: auto_speech,
            speechPrompt: '',
            speakerId: 'Auto',
            aspectRatio: '16:9',
            secondaryPageId: 1811,
            channel: 'VEO3',
            source: 'aivideogenerator.me',
            type: 'features',
            watermarkFlag: true,
            privateFlag: true,
            isTemp: true,
            vipFlag: true,
            model: model
        }, {
            headers: {
                uniqueid: uid,
                verify: cf.result.token
            }
        })
        
        while (true) {
            const { data } = await axios.get(`https://aiarticle.erweima.ai/api/v1/secondary-page/api/${task.data.recordId}`, {
                headers: {
                    uniqueid: uid,
                    verify: cf.result.token
                }
            })
            
            if (data.data.state === 'success') return JSON.parse(data.data.completeData)
            await new Promise(res => setTimeout(res, 1000))
        }
    } catch (error) {
        throw new Error(error.message)
    }
}

const handler = async (m, { text, conn }) => {
  if (!text) return m.reply('masukin prompt untuk buat video bre\ncontoh : txt2vid a beautiful sunset over a mountain')

  try {
    await m.reply('waitt')
    const result = await veo3(text)
    if (!result?.data?.video_url) return m.reply('gagal dapetin hasil video bre')
    await conn.sendFile(m.chat, result.data.video_url, 'video.mp4', `video dri prompt : ${text}`, m)
  } catch (e) {
    m.reply(`Eror kak : ${e?.message || e}`)
  }
}

handler.command = ['txt2vid']
handler.tags = ['ai']
handler.help = ['txt2vid <prompt>']

export default handler