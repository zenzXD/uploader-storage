import fs from 'fs'
import syntaxError from 'syntax-error'
import path from 'path'

const _fs = fs.promises

let handler = async (m, { text, usedPrefix, command, __dirname }) => {
    if (!text) return m.reply(`
📝 *Penggunaan*: ${usedPrefix}${command} <nama file>
📌 *Contoh*: 
${usedPrefix}getfile main.js
${usedPrefix}getplugin owner
`.trim())

    if (/p(lugin)?|gp/i.test(command)) {
        const filename = text.replace(/plugin(s)?\//i, '') + (/\.js$/i.test(text) ? '' : '.js')
        const pathFile = path.join(__dirname, filename)

        try {
            await _fs.access(pathFile)
            const file = await _fs.readFile(pathFile, 'utf8')
            await conn.sendMessage(m.chat, { text: file }, { quoted: m })

            const error = syntaxError(file, filename, {
                sourceType: 'module',
                allowReturnOutsideFunction: true,
                allowAwaitOutsideFunction: true
            })

            if (error) {
                await m.reply(`
❗ *Syntax Error* ditemukan di *${filename}*:
\`\`\`
${error}
\`\`\`
`.trim())
            }
        } catch (e) {
            const allPlugins = (await _fs.readdir(__dirname))
                .filter(file => file.endsWith('.js'))
                .map(f => f.replace(/\.js$/, '')) 
                .sort()

            const listText = `*🗃️ NOT FOUND!*
==================================

${allPlugins.join('\n')}
`
            await m.reply(listText.trim())
        }

    } else {
        const isJavascript = /\.js$/i.test(text)
        try {
            const file = await _fs.readFile(text, isJavascript ? 'utf8' : 'base64')

            if (isJavascript) {
                conn.sendMessage(m.chat, { text: file }, { quoted: m })

                const error = syntaxError(file, text, {
                    sourceType: 'module',
                    allowReturnOutsideFunction: true,
                    allowAwaitOutsideFunction: true
                })

                if (error) {
                    await m.reply(`
❗ *Syntax Error* ditemukan di *${text}*:
\`\`\`
${error}
\`\`\`
`.trim())
                }
            } else {
                await m.reply(Buffer.from(file, 'base64'))
            }
        } catch (e) {
            await m.reply(`❗ Gagal membaca file *${text}*.`)
        }
    }
}

handler.help = ['getfile', 'getplugin']
handler.tags = ['owner']
handler.command = /^(getfile|gf|getplugin|gp)$/i
handler.owner = true

export default handler