/*
 * JANGAN HAPUS WM !!
⌬────────────────────⌬
 © Bot Plana AI 2024
 • Credits : wa.me/6282375165100 [ Sanka Vollerei ]
 • Owner: 6282375165100,6285838836448
⌬────────────────────⌬

*Dilarang memperjualbelikan script ini tanpa seizin developer!*
*/

import fs from 'fs'
import archiver from 'archiver'
import path from 'path'

let cuki = async (m, { conn }) => {
    // Hanya untuk primary instance (jika multi-session bot)
    if (conn.user.jid !== global.conn.user.jid) return

    let backupName = path.join('/home/container/tmp/', `backup_Script.zip`)
    let Namebackup = `backup_Script.zip`
    let output = fs.createWriteStream(backupName)
    let archive = archiver('zip', { zlib: { level: 9 } })

    await conn.reply(m.chat, '🔄 *Sedang membuat backup script...*', m)

    output.on('close', async () => {
        let size = (archive.pointer() / 1024 / 1024).toFixed(2)
        let caption = `🗂️ Backup selesai.\n\n📁 Nama file: *${Namebackup}*\n📦 Ukuran: *${size} MB*\n\nSilakan simpan file ini secara manual.`
        await conn.sendFile(m.sender, backupName, Namebackup, caption, m)
    })

    archive.on('warning', err => {
        if (err.code !== 'ENOENT') throw err
    })

    archive.on('error', err => {
        throw err
    })

    archive.pipe(output)

    // Arsipkan semua kecuali folder sensitif
    archive.glob('**/*', {
        ignore: [
            'node_modules/**',
            'tmp/**',
            '.npm/**',
            '.cache/**',
            'sessions/**',
            backupName
        ]
    })

    await archive.finalize()
}

cuki.help = ['backupsc']
cuki.tags = ['owner']
cuki.command = /^(backupsc)$/i
cuki.owner = true

export default cuki