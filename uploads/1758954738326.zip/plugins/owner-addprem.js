let handler = async (m, { conn, args, usedPrefix, command }) => {
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false
    if (!who) return m.reply('Masukan Nomor Atau Tag Orangnya!')
    if (!global.db.data.users[who]) global.db.data.users[who] = { name: who.split('@')[0], premium: false, premiumTime: 0 }
    let user = global.db.data.users[who]
    let txt = args[1]
    if (!txt) return m.reply('Masukan Jumlah Hari Yang Ingin Diberikan')
    if (isNaN(txt)) return m.reply(`Hanya Angka!\n\nContoh :\n${usedPrefix + command} @${m.sender.split`@`[0]} 7`)
    let jumlahHari = 86400000 * parseInt(txt)
    let now = Date.now()
    if (now < user.premiumTime) user.premiumTime += jumlahHari
    else user.premiumTime = now + jumlahHari
    user.premium = true
    let timers = user.premiumTime - now
    let days = Math.floor(timers / 86400000)
    let hours = Math.floor((timers % 86400000) / 3600000)
    let minutes = Math.floor((timers % 3600000) / 60000)
    let seconds = Math.floor((timers % 60000) / 1000)
    let countdown = `${days}d ${hours}h ${minutes}m ${seconds}s`
    await conn.reply(who, `✔️ Success! Kamu Sekarang User Premium!
📛 Name: ${user.name}
📆 Days: ${txt} days
📉 Countdown: ${countdown}`, false)
    await delay(2000)
    await m.reply(`✔️ Success
📛 Name: ${user.name}
📆 Days: ${txt} days
📉 Countdown: ${countdown}`)
}
handler.help = ['addprem']
handler.tags = ['owner']
handler.command = /^(add(prem|premium))$/i
handler.owner = true
export default handler

const delay = time => new Promise(res => setTimeout(res, time))