const handler = async (m, { conn, text, command }) => {
  await conn.reply(m.chat, `⚠️ SERVER SEDANG DALAM TAHAP PERBAIKAN ⚠️
MOHON BERSABAR KAMI SEDANG MENINGKATKAN PERFORMA SERVER
                                
                      XELVIXEL MINTA MAAF`, m)
}

handler.command = /^ip$/i

export default handler