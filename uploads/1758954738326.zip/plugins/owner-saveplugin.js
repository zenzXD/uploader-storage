import fs from 'fs'
import path from 'path'

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) return m.reply(`Kodenya mana?\n\nContoh:\n${usedPrefix + command} namaplugin`)
    if (!m.quoted || !m.quoted.text) return m.reply(`Balas pesan yang berisi kode plugin!`)

    // Buat path otomatis ke folder plugins dan tambahkan ekstensi .js
    let fileName = text.replace(/[^a-zA-Z0-9_-]/g, '') // bersihkan nama file dari karakter aneh
    let filePath = path.join('plugins', `${fileName}.js`)

    try {
        await fs.promises.writeFile(filePath, m.quoted.text)
        m.reply(`✅ Plugin berhasil disimpan ke: *${filePath}*`)
    } catch (err) {
        m.reply(`❌ Gagal menyimpan plugin:\n${err.message}`)
    }
}

handler.help = ['saveplugin', 'sp']
handler.tags = ['owner']
handler.command = /^saveplugin|sp$/i
handler.mods = true

export default handler