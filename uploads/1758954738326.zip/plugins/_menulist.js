import PhoneNumber from 'awesome-phonenumber'
import { promises } from 'fs'
import { join } from 'path'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
import moment from 'moment-timezone'
import os from 'os'
import fs from 'fs'

const defaultMenu = {
    before: `
┏━〔 *INFO USER* 〕━┓
┃ ≠ Nama       : %name
┃ ≠ Status     : %status
┃ ≠ Limit      : %limit
┃ ≠ Level      : %level
┃ ≠ Exp        : %exp / %maxexp
┃ ≠ Total Exp  : %totalexp
┃ ≠ Role       : %role
┗━━━━━━━━━━━━━━━┛

┏━〔 *INFO WAKTU* 〕━┓
┃ ≠ Hari      : %week (%weton)
┃ ≠ Tanggal   : %date
┃ ≠ Jam       : %time
┃ ≠ Uptime    : %uptime
┗━━━━━━━━━━━━━━━┛

┏━〔 *KETERANGAN CMD* 〕━┓
┃ ≠ [ ᴘ ]  = Premium
┃ ≠ [ ʟ ]  = Limit
┗━━━━━━━━━━━━━━━┛

%readmore`.trimStart(),

    header: '┏━〔 *%category* 〕━┓',
    body:   '┃ ≠ %cmd %islimit %isPremium',
    footer: '┗━━━━━━━━━━━━━━━┛\n',
    after: `*Jika menemukan fitur error, harap ketik 「.report <pesan>」 dan laporanmu akan langsung dikirim ke owner bot.*`,
}

let handler = async (m, { conn, usedPrefix, command, __dirname, isOwner, isMods, isPrems, args }) => {
    try {
        let loadd = [
            "*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . . . 10%* 🕛",
            "*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . . . 30%* 🕑",
            "*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . . . 50%* 🕓",
            "*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . . . 70%* 🕗",
            "*ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . . . 90%* 🕙",
            "*✅ ᴄ ᴏ ᴍ ᴘ ʟ ᴇ ᴛ ᴇ !*"
        ]

        let sentMessage = await conn.sendMessage(m.chat, { text: '*⌛ ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . .*' })

        for (let i = 0; i < loadd.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 200))
            await conn.sendMessage(m.chat, { text: loadd[i], edit: sentMessage.key })
        }

        let teks = `${args[0]}`.toLowerCase()
        let tags = {}
        let allTags = new Set()

        Object.values(global.plugins)
            .filter(plugin => !plugin.disabled && plugin.tags)
            .forEach(plugin => {
                const pluginTags = Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags]
                pluginTags.forEach(tag => allTags.add(tag))
            })

        if (!teks || teks === 'all') {
            allTags.forEach(tag => {
                tags[tag] = capitalize(tag)
            })
        } else if (allTags.has(teks)) {
            tags[teks] = capitalize(teks)
        } else {
            let listTags = [...allTags].map(t => `- ${capitalize(t)}`).join('\n')
            return m.reply(`*Tag/kategori "${teks}" tidak ditemukan!*\n\nBerikut daftar kategori yang tersedia:\n\n${listTags}\n\nKetik *.menulist all* untuk melihat semua menu.`)
        }

        let wib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
        let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
        let { exp, level, role } = global.db.data.users[m.sender]
        let { min, xp, max } = xpRange(level, global.multiplier)
        let tag = `@${m.sender.split('@')[0]}`
        let user = global.db.data.users[m.sender]
        let limit = isPrems ? 'Unlimited' : toRupiah(user.limit)
        let name = user.registered ? user.name : conn.getName(m.sender)
        let status = isMods ? 'Developer' : isOwner ? 'Owner' : isPrems ? 'Premium User' : user.level > 1000 ? 'Elite User' : 'Free User'
        let d = new Date(new Date + 3600000)
        let locale = 'id'
        let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
        let week = d.toLocaleDateString(locale, { weekday: 'long' })
        let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
        let time = d.toLocaleTimeString(locale, { hour: 'numeric', minute: 'numeric', second: 'numeric' })
        let _uptime = process.uptime() * 1000
        let uptime = clockString(_uptime)

        let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => ({
            help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],
            tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
            prefix: 'customPrefix' in plugin,
            limit: plugin.limit,
            premium: plugin.premium
        }))

        let groups = {}
        for (let tag in tags) {
            groups[tag] = []
            for (let plugin of help)
                if (plugin.tags && plugin.tags.includes(tag))
                    if (plugin.help) groups[tag].push(plugin)
        }

        let before = defaultMenu.before
        let header = defaultMenu.header
        let body = defaultMenu.body
        let footer = defaultMenu.footer
        let after = defaultMenu.after

        let _text = [
            before,
            ...Object.keys(tags).map(tag => {
                return header.replace(/%category/g, tags[tag]) + '\n' + [
                    ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
                        return menu.help.map(help => {
                            return body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
                                .replace(/%islimit/g, menu.limit ? '[ ʟ ]' : '')
                                .replace(/%isPremium/g, menu.premium ? '[ ᴘ ]' : '')
                                .trim()
                        }).join('\n')
                    }),
                    footer
                ].join('\n')
            }),
            after
        ].join('\n')

        let replace = {
            '%': '%',
            p: usedPrefix,
            uptime,
            me: conn.getName(conn.user.jid),
            npmname: _package.name,
            version: _package.version,
            exp: toRupiah(exp - min),
            maxexp: toRupiah(xp),
            totalexp: toRupiah(exp),
            level: toRupiah(level),
            limit,
            name,
            weton,
            week,
            date,
            time,
            role,
            status,
            wib,
            readmore: readMore
        }

        let text = _text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])

        let gifList = [
            'https://files.cloudkuimages.guru/videos/Ygo0CZLJ.mp4', 'https://uploader.zenzxz.dpdns.org/uploads/1752913203677.mp4',        'https://files.cloudkuimages.guru/videos/KHNY76Bd.mp4'
        ]
        let randomGif = gifList[Math.floor(Math.random() * gifList.length)]

        await conn.sendMessage(m.chat, {
            video: { url: randomGif },
            gifPlayback: true,
            caption: text
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.reply(m.chat, 'Terjadi kesalahan saat menampilkan menu', m)
    }
}

handler.help = ['menulist']
handler.tags = ['main']
handler.command = /^(menulist)$/i
export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

function capitalize(word) {
    return word.charAt(0).toUpperCase() + word.substr(1).toLowerCase()
}

const toRupiah = number => parseInt(number).toLocaleString().replace(/,/g, ".")