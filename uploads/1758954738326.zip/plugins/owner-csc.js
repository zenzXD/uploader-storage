import axios from 'axios'

const apiUrl = 'https://codeshare.cloudku.click/users.php'
const apiKey = 'zenzganteng' // Isi ApiKey Kamu Disini Yah

let yeon = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    await conn.sendMessage(m.chat, {
      react: {
        text: "❓",
        key: m.key
      }
    })
    return conn.sendMessage(m.chat, {
      text: `💻 *Senpai*, format yang benar adalah:\n*${usedPrefix + command}* judul|bahasa|kode\n\nContoh:\n*${usedPrefix + command}* Fungsi Node.js|javascript|const test = () => { console.log('test') }`
    })
  }

  try {
    const [title, language, ...codeParts] = text.split('|').map(part => part.trim())
    const code_content = codeParts.join('|').trim()

    if (!title||!language||!code_content) {
      await conn.sendMessage(m.chat, {
        react: {
          text: "❌",
          key: m.key
        }
      })
      return conn.sendMessage(m.chat, {
        text: `⚠️ *Senpai*, format tidak lengkap!\nGunakan: *${usedPrefix + command}* judul|bahasa|kode`
      })
    }

    await conn.sendMessage(m.chat, {
      react: {
        text: "⏳",
        key: m.key
      }
    })

    const snippetData = {
      title,
      code_content,
      language
    }

    const response = await axios.post(apiUrl, snippetData, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      }
    })

    if (response.data.status === 'success') {
      const shareUrl = `https://codeshare.cloudku.click/view?id=${response.data.share_id}`
      
      await conn.sendMessage(m.chat, {
        text: `✨ *Sukses Post Snippet*
> 📌 *Judul:* ${title}
> 🌐 *Bahasa:* ${language}`,
        footer: "ZenzzXD",
        interactiveButtons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "Lihat Code",
              url: `${shareUrl}`,
              merchant_url: 'https://codeshare.cloudku.click'
            })
          },
          {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
              display_text: "Salin Link",
              copy_code: `${shareUrl}`
            })
          }
        ]
          
      })

      await conn.sendMessage(m.chat, {
        react: {
          text: "✅",
          key: m.key
        }
      })
    } else {
      throw new Error(response.data.message||'Gagal membuat snippet')
    }

  } catch (e) {
    await conn.sendMessage(m.chat, {
      react: {
        text: "⛔️",
        key: m.key
      }
    })
    await conn.sendMessage(m.chat, {
      text: `😢 *Yahh Senpai..* Gagal membuat code snippet!\n${e.message||'Server mungkin sedang sibuk~'}`
    })
  }
}

yeon.help = ['csc <judul>|<bahasa>|<kode>']
yeon.tags = ['owner']
yeon.command = /^(csc|codeshare)$/i
yeon.owner = true
yeon.register = true
export default yeon