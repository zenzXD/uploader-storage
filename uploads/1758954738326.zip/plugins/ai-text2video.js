/*
* Nama fitur : Text To Video (Veo 3)
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6chx1LI8YVtJJJ9a0Y
* Author : ZenzzXD
*/

import axios from 'axios'
import crypto from 'crypto'

let handler = async (m, { conn, command, text }) => {
  if (!text) return m.reply('Contoh : .text2video <prompt>')
  m.reply('wett')
  try {
    let result = await text2video(veo3)(text, { image: m.quoted?.mimetype?.includes('image') ? await conn.downloadAndSaveMediaMessage(m.quoted) : null })
    if (!result.videoUrl) return m.reply('Gagal mendapatkan video')
    await conn.sendMessage(m.chat, { video: { url: result.videoUrl }, caption: 'Nih hasilnya kak' }, { quoted: m })
  } catch (e) {
    m.reply(`Eror kak : ${e.message}`)
  }
}

handler.help = ['text2video <prompt>']
handler.tags = ['ai']
handler.command = ['text2video']

export default handler

async function text2video(veo3)(prompt, { image = null } = {}) {
  if (!prompt) throw new Error('Prompt is required')
  const { data: cf } = await axios.post('https://cf.nekolabs.my.id/action', {
    mode: 'turnstile-min',
    siteKey: '0x4AAAAAAANuFg_hYO9YJZqo',
    url: 'https://aivideogenerator.me/features/g-ai-video-generator'
  })
  const num = Math.floor(Math.random() * 100) + 1700
  const uid = crypto.createHash('md5').update(Date.now().toString()).digest('hex')
  const { data: task } = await axios.post('https://aiarticle.erweima.ai/api/v1/secondary-page/api/create', {
    prompt: prompt,
    imgUrls: image ? [image] : [],
    quality: '720p',
    duration: 8,
    autoSoundFlag: false,
    soundPrompt: '',
    autoSpeechFlag: false,
    speechPrompt: '',
    speakerId: 'Auto',
    aspectRatio: '16:9',
    secondaryPageId: num,
    channel: 'VEO3',
    source: 'aivideogenerator.me',
    type: 'features',
    watermarkFlag: true,
    privateFlag: true,
    isTemp: true,
    vipFlag: true,
    model: 'veo-3-fast'
  }, {
    headers: {
      uniqueid: uid,
      verify: cf.token
    }
  })
  while (true) {
    const { data } = await axios.get(`https://aiarticle.erweima.ai/api/v1/secondary-page/api/${task.data.recordId}`, {
      headers: {
        uniqueid: uid,
        verify: cf.token
      }
    })
    if (data.data.state === 'fail') return JSON.parse(data.data.completeData)
    if (data.data.state === 'success') return JSON.parse(data.data.completeData)
    await new Promise(res => setTimeout(res, 1000))
  }
}