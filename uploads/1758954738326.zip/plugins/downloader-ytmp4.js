import fetch from 'node-fetch'

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `📌 Contoh:\n${usedPrefix + command} https://youtu.be/abc123`

  global.db = global.db || {}
  global.db.data = global.db.data || {}
  global.db.data.temp = global.db.data.temp || {}

  if (global.db.data.temp[m.id]) return
  global.db.data.temp[m.id] = true

  const proses = await conn.sendMessage(m.chat, {
    react: { text: '⏳', key: m.key }
  })

  try {
    const result = await ytmp3mobi(text, 'mp4') // default: 'mp3', kita pake 'mp4'
    if (!result || !result.downloadURL) throw '❌ Gagal mendapatkan link download.'

    await conn.sendMessage(m.chat, {
      video: { url: result.downloadURL },
      mimetype: 'video/mp4',
      fileName: `${result.title || 'yt_video'}.mp4`,
      caption: `*${result.title}*`
    }, { quoted: m })

  } catch (e) {
    await m.reply(`❌ Error:\n${e.message || e}`)
  } finally {
    if (proses?.key) await conn.sendMessage(m.chat, { delete: proses.key })
    delete global.db.data.temp[m.id]
  }
}

handler.help = ['ytmp4 <url>']
handler.tags = ['downloader']
handler.command = ['ytmp4']
export default handler

// ================= SCRAPER =================

const ytmp3mobi = async (youtubeUrl, format = 'mp4') => {
  const regYoutubeId = /https:\/\/(www\.youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/|youtube\.com\/watch\?v=)([^&|^?]+)/;
  const videoId = youtubeUrl.match(regYoutubeId)?.[2]
  if (!videoId) throw Error("❌ Tidak bisa ambil video ID dari URL YouTube.")

  const availableFormat = ["mp3", "mp4"]
  if (!availableFormat.includes(format.toLowerCase()))
    throw Error(`${format} format tidak valid. Pilih salah satu: ${availableFormat.join(", ")}`)

  const urlParam = {
    v: videoId,
    f: format,
    _: Math.random()
  }

  const headers = {
    "Referer": "https://id.ytmp3.mobi/",
    "User-Agent": "Mozilla/5.0"
  }

  const fetchJson = async (url, desc) => {
    const res = await fetch(url, { headers })
    if (!res.ok) throw Error(`fetch gagal (${desc}) | ${res.status} ${res.statusText}`)
    return res.json()
  }

  const initUrl = "https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=" + Math.random()
  const { convertURL } = await fetchJson(initUrl, "get convertURL")

  const finalURL = `${convertURL}&${new URLSearchParams(urlParam).toString()}`
  const { progressURL, downloadURL } = await fetchJson(finalURL, "get progressURL dan downloadURL")

  let progress = 0
  let title = ''
  while (progress != 3) {
    const json = await fetchJson(progressURL, "fetch progressURL")
    if (json.error) throw Error(`❌ Error konversi: ${json.error}`)
    progress = json.progress
    title = json.title
    let statusToPrint = progress === 1 ? "[loading]" :
                        progress === 2 ? "[converting]" :
                        progress === 3 ? "[ready]" : "[unknown]"
    console.log(`${statusToPrint} ${title}`)
    await new Promise(res => setTimeout(res, 1000)) // delay 1s biar aman
  }

  return { title, downloadURL }
}