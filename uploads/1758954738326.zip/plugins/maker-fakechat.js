/*
* Nama fitur : Fake chat 
* Type : Plugin Esm
* Sumber : https://whatsapp.com/channel/0029Vb6chx1LI8YVtJJJ9a0Y
* Author : ZenzzXD
*/

import axios from 'axios'
import moment from 'moment-timezone'

const handler = async (m, { text, conn }) => {
  if (!text) return m.reply('Contoh : .fakechat hi bg')

  try {
    const jam = moment().tz('Asia/Jakarta').format('HH:mm')
    const response = await axios.get('https://www.velyn.mom/api/maker/chat', {
      params: {
        message: text,
        position: 'left',
        jam
      }
    })

    const url = response.data?.result?.url
    if (!url) return m.reply('gk ada url dri api')

    await m.reply('wett')
    await conn.sendFile(m.chat, url, 'jenneskdi.png', '', m)
  } catch (e) {
    m.reply(`Eror kak : ${e.message}`)
  }
}

handler.command = ['fakechat']
handler.tags = ['maker']
handler.help = ['fakechat <text>']

export default handler