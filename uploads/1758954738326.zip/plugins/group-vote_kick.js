/*
• Fitur 
*group-votekick* 
• Type Plugins Esm
• By Alecia Md
• Sumber: https://whatsapp.com/channel/0029VbAaNTlGpLHU4sWbwT36
*/

let Fruatre = async (m, { conn, args, isAdmin }) => {
    let who;
    
    if (m.quoted && m.quoted.sender) {
        who = m.quoted.sender;
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        who = m.mentionedJid[0];
    } else {
        throw `Siapa yang ingin Anda pilih?`;
    }

    const groupMetadata = await conn.groupMetadata(m.chat);
    const groupOwner = groupMetadata.owner;
    const participants = groupMetadata.participants.map(p => p.id);

    if (who === m.sender || who === groupOwner || who === conn.user.jid) {
        throw `Anda tidak dapat memilih pembuat grup, bot, atau diri Anda sendiri!`;
    }

    // Inisialisasi data user jika belum ada
    global.db.data.users = global.db.data.users || {};
    global.db.data.users[who] = global.db.data.users[who] || {};
    let user = global.db.data.users[who];

    // Inisialisasi properti jika belum ada
    if (!user.votekick) user.votekick = 0;
    if (!user.lastVotedBy) user.lastVotedBy = '';

    if (user.lastVotedBy === m.sender) {
        throw `Anda tidak dapat memilih orang yang sama lagi selama masa pemungutan suara!`;
    }

    user.lastVotedBy = m.sender;
    user.votekick += 1;

    let cap = `@${m.sender.split("@")[0]} telah memilih @${who.split("@")[0]} untuk dihapus!\n*Total Pemungutan Suara:* ${user.votekick}/5`;

    if (user.votekick >= 5) {
        cap += `\n\nPengguna telah mencapai 5 suara dan telah dihapus dari grup.`;
        if (isAdmin) {
            await conn.groupParticipantsUpdate(m.chat, [who], "remove");
        } else {
            cap += `\nNamun, bot bukan admin jadi tidak bisa menghapus.`;
        }
        user.votekick = 0;
        user.lastVotedBy = '';
    } else {
        // Reset vote setelah 5 menit
        if (user.votingTimeout) clearTimeout(user.votingTimeout);
        user.votingTimeout = setTimeout(() => {
            user.lastVotedBy = '';
            user.votekick = 0;
            conn.reply(m.chat, `⏳ Pemungutan suara terhadap @${who.split("@")[0]} telah berakhir. Tidak mencapai 5 suara.`, m, {
                contextInfo: { mentionedJid: [who] }
            });
        }, 5 * 60 * 1000);
    }

    await conn.reply(m.chat, cap, null, {
        contextInfo: { mentionedJid: [m.sender, who] }
    });
};

Fruatre.help = ['vote_kick'];
Fruatre.command = /^(vote_kick|vk|votekick)$/i;
Fruatre.tags = ['group'];
Fruatre.group = true;
Fruatre.botAdmin = true;

export default Fruatre;