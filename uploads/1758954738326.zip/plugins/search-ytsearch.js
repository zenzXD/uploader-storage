import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Masukkan query!\n\nContoh:\n${usedPrefix + command} Night Changes`)

  try {
    await global.loading(m, conn)

    const res = await fetch(`https://cloudkutube.eu/api/yts?q=${encodeURIComponent(text)}`)
    const json = await res.json()

    if (json.status !== 'success' || !json.result?.length) {
      return m.reply('❌ Tidak ada hasil ditemukan.')
    }

    const data = json.result.slice(0, 10)
    const rows = data.map(video => ({
      header: '🎵 YouTube Result',
      title: video.title,
      description: `${video.author} • ${video.views} views • ${video.duration.timestamp}`,
      id: `.play ${video.url}`
    }))

    const msg = {
      text: `✅ Ditemukan ${rows.length} hasil untuk *${text}*`,
      footer: '© Vynexx - FizzxyDev',
      buttons: [
        {
          buttonId: ' ',
          buttonText: { displayText: '🎧 Hasil Pencarian' },
          type: 1
        },
        {
          buttonId: 'action',
          buttonText: { displayText: '📜 Pilih Video' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Hasil YouTube Search',
              sections: [
                {
                  title: 'Powered by ZenzzXD',
                  highlight_label: '🎬 Pilih salah satu',
                  rows
                }
              ]
            })
          }
        }
      ],
      headerType: 1,
      viewOnce: true
    }

    await conn.sendMessage(m.chat, msg, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply('❌ Error terjadi wak :v')
  } finally {
    await global.loading(m, conn, true)
  }
}

handler.help = ['ytsearch']
handler.tags = ['search']
handler.command = /^(yt(s|search)|youtubesearch)$/i
handler.limit = true

export default handler