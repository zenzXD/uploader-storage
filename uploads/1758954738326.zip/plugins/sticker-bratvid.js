import axios from 'axios'
import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, command, usedPrefix, text }) => {
  text = m.quoted && !text ? m.quoted.text : text
  if (!text) {
    return m.reply(`Masukkan teks!\n\nContoh:\n${usedPrefix + command} hello word`)
  }

  await conn.sendMessage(m.chat, {
    react: {
      text: '⏱️',
      key: m.key
    }
  })

  await global.loading(m, conn)

  try {
    let imageUrl = `https://brat.siputzx.my.id/gif?text=${encodeURIComponent(text)}`
    let imageBuffer = (await axios.get(imageUrl, { responseType: 'arraybuffer' })).data
    let stiker = await sticker(imageBuffer, false, global.config.stickpack, global.config.stickauth)
    await conn.sendFile(m.chat, stiker, '', '', m)
  } catch (e) {
    m.reply('Gagal membuat stiker dari bratgif.')
  } finally {
    await global.loading(m, conn, true)
  }
}

handler.help = ['bratvid']
handler.tags = ['sticker']
handler.command = /^bratvid$/i
handler.limit = true

export default handler