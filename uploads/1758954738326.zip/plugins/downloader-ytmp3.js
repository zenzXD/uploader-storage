import fetch from 'node-fetch'
import axios from 'axios'

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh penggunaan:\n${usedPrefix + command} https://youtu.be/E7XkLEEYZnE`

  global.db = global.db || {}
  global.db.data = global.db.data || {}
  global.db.data.temp = global.db.data.temp || {}

  if (global.db.data.temp[m.id]) return
  global.db.data.temp[m.id] = true

  const proses = await conn.sendMessage(m.chat, {
    react: { text: '⏳', key: m.key }
  })

  try {
    const url = text
    const meta = await getMetadata(url)
    if (!meta.status) throw `Gagal ambil metadata`

    const { title, thumbnail, duration, views, downloadUrl } = meta.result

    const audioRes = await fetch(downloadUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0'
      }
    })
    if (!audioRes.ok) throw `Gagal download audio: ${audioRes.statusText}`
    const audioBuffer = await audioRes.arrayBuffer()

    await conn.sendMessage(m.chat, {
      audio: Buffer.from(audioBuffer),
      mimetype: 'audio/mpeg',
      fileName: `${title || 'yt_audio'}.mp3`,
      ptt: false,
      contextInfo: {
        forwardingScore: 999999,
        isForwarded: true,
        externalAdReply: {
          title: `YTMP3 - Zenzxz`,
          body: `${title} | Durasi: ${duration} | Views: ${views?.toLocaleString('id-ID') || '-'}`,
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: thumbnail,
          sourceUrl: url
        }
      }
    }, { quoted: m })

  } catch (err) {
    await m.reply(`Error:\n${err}`)
  } finally {
    if (proses?.key) await conn.sendMessage(m.chat, { delete: proses.key })
    delete global.db.data.temp[m.id]
  }
}

handler.help = ['ytmp3 <url>']
handler.tags = ['downloader']
handler.command = ['ytmp3']

export default handler

async function getMetadata(url) {
  try {
    const q = encodeURIComponent(url)
    const res = await axios.get(`https://api.zenzxz.my.id/downloader/ytmp3?url=${q}`)
    const data = res.data

    if (!data.status) throw 'Gagal ambil data'

    return {
      status: true,
      result: {
        title: data.title,
        thumbnail: data.thumbnail,
        duration: data.duration,
        views: 0,
        downloadUrl: data.download_url
      }
    }
  } catch (err) {
    return { status: false, error: err.message }
  }
}