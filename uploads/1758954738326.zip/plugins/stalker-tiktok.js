import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh:\n${usedPrefix + command} zenzzx26`

  m.reply('waitt')

  try {
    const res = await fetch(`https://api.arincy.site/api/ttstalk?username=${encodeURIComponent(text)}`)
    if (!res.ok) throw 'Gagal menghubungi API.'

    const json = await res.json()
    if (!json.status || !json.data?.user) throw 'User tidak ditemukan atau data tidak tersedia.'

    const data = json.data
    const user = data.user
    const stats = data.stats

    const caption = `
*Tiktok Stalker*

Username: ${user?.uniqueId || '-'}
Nama: ${user?.nickname || '-'}
ID: ${user?.id || '-'}
Short ID: ${user?.shortId || '-'}
Terverifikasi: ${user?.verified ? 'Ya' : 'Tidak'}
Privat: ${user?.privateAccount ? 'Ya' : 'Tidak'}
Bio: ${user?.signature || 'Tidak tersedia'}
Region: ${user?.region || '-'}
Bahasa: ${user?.language || '-'}
Room ID: ${user?.roomId || 'Tidak ada'}
Organisasi: ${user?.isOrganization ? 'Ya' : 'Tidak'}

Statistik
- Pengikut: ${stats?.followerCount?.toLocaleString('id-ID') || '0'}
- Mengikuti: ${stats?.followingCount?.toLocaleString('id-ID') || '0'}
- Likes: ${stats?.heartCount?.toLocaleString('id-ID') || '0'}
- Video: ${stats?.videoCount?.toLocaleString('id-ID') || '0'}
- Teman: ${stats?.friendCount?.toLocaleString('id-ID') || '0'}

Profil: https://www.tiktok.com/@${user?.uniqueId}
`.trim()

    await conn.sendFile(m.chat, user?.avatarLarger || user?.avatarMedium || user?.avatarThumb, 'tiktok.jpg', caption, m)
  } catch (err) {
    console.error(err)
    m.reply(`❌ Gagal mengambil data pengguna.\n\n*Detail:* ${err.message}`)
  }
}

handler.help = ['stalktiktok <username>']
handler.tags = ['stalker']
handler.command = /^(stalktiktok|ttstalk|tiktokstalk)$/i

export default handler