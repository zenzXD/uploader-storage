import fetch from 'node-fetch'
import { sizeFormatter } from 'human-readable'

global.db = global.db || {}
global.db.data = global.db.data || {}
global.db.data.temp = global.db.data.temp || {}

function isProcessing(key) {
  return !!global.db.data.temp[key]
}

function setProcessing(key) {
  global.db.data.temp[key] = true
}

function clearProcessing(key) {
  delete global.db.data.temp[key]
}

const formatSize = sizeFormatter({
  std: 'JEDEC',
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`
})

async function GDriveDl(url) {
  let id
  if (!url || !url.match(/drive\.google/i)) return null
  try {
    id = (url.match(/\/d\/(.*?)\//i) || url.match(/id=([^&]+)/i))[1]
    if (!id) throw 'ID file tidak ditemukan.'

    const res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, {
      method: 'POST',
      headers: {
        'accept-encoding': 'gzip, deflate, br',
        'content-length': 0,
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'origin': 'https://drive.google.com',
        'user-agent': 'Mozilla/5.0',
        'x-client-data': 'CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
        'x-drive-first-party': 'DriveWebUi',
        'x-json-requested': 'true'
      }
    })

    const json = JSON.parse((await res.text()).slice(4))
    if (!json.downloadUrl) throw '❌ Link download sudah mencapai limit!'

    const fileRes = await fetch(json.downloadUrl)
    if (!fileRes.ok) throw '❌ Gagal mengunduh file dari URL langsung.'

    return {
      downloadUrl: json.downloadUrl,
      fileName: json.fileName,
      fileSize: formatSize(json.sizeBytes),
      mimetype: fileRes.headers.get('content-type')
    }
  } catch (e) {
    console.log('[GDRIVE ERROR]', e)
    return null
  }
}

const handler = async (m, { conn, args }) => {
  if (!(args[0] || '').match(/(drive\.google\.com)/)) {
    return m.reply('📦 Masukkan link Google Drive yang valid.\nContoh: .drive https://drive.google.com/file/d/FILE_ID/view')
  }

  const key = m.chat + m.sender
  if (isProcessing(key)) return m.reply('⏳ Tunggu proses sebelumnya selesai!')
  setProcessing(key)

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  try {
    const result = await GDriveDl(args[0])
    if (!result) throw new Error('Tidak bisa mengambil link download.')

    const caption = `📁 *GOOGLE DRIVE DOWNLOADER*\n\n`
      + `📄 *Nama:* ${result.fileName}\n`
      + `📦 *Ukuran:* ${result.fileSize || 'N/A'}\n`
      + `🧾 *Tipe:* ${result.mimetype || 'unknown'}\n`
      + `🔗 *Link:* ${result.downloadUrl}`

    await conn.sendFile(m.chat, result.downloadUrl, result.fileName, caption, m, false, {
      mimetype: result.mimetype,
      fileName: result.fileName,
      contextInfo: {
        externalAdReply: {
          title: result.fileName,
          sourceUrl: args[0],
          thumbnailUrl: 'https://logowik.com/content/uploads/images/996_google_drive.jpg',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    })
  } catch (e) {
    console.error(e)
    m.reply(`❌ Terjadi error:\n${e?.message || e}`)
  } finally {
    clearProcessing(key)
  }
}

handler.help = ['drive <url>']
handler.tags = ['downloader']
handler.command = /^(gdrive|drive)$/i
handler.limit = true
handler.register = true

export default handler