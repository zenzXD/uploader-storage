import axios from 'axios'
import cheerio from 'cheerio'

async function getToken() {
  try {
    const { data } = await axios.get('https://getfvid.online/')
    const $ = cheerio.load(data)
    return $('#token').val()
  } catch (e) {
    throw 'Gagal ambil token'
  }
}

async function zenn(url) {
  if (!url) throw 'mana url nya bg?'
  const token = await getToken()

  const form = new URLSearchParams()
  form.append('url', url)
  form.append('token', token)

  const { data } = await axios.post('https://getfvid.online/wp-json/aio-dl/video-data/', form, {
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      origin: 'https://getfvid.online',
      referer: 'https://getfvid.online/',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
    }
  })

  return data
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  let url = args[0] || (m.quoted && m.quoted.text)
  if (!url) return m.reply(`
Gunakan : .aio <url>

Support platform :
> YouTube
> Twitter
> Threads
> Tumblr
> TikTok
> Telegram
> TED
> Streamable
> Soundcloud
> Snapchat
> Share Chat
> Rumble
> Reddit
> PuhuTV
> Pinterest
> Ok.ru
> MxTakatak
> Moj
> Mixcloud
> Mastodon
> Mashable
> LinkedIn
> Likee
> Kwai
> Izlesene
> Instagram
> Imgur
> IMDB
> Ifunny
> Flickr
> Febspot
> Facebook
> ESPN
> Douyin
> Dailymotion
> Chingari
> Capcut
> Buzzfeed
> BluTV
> Blogger
> Bitchute
> Bilibili
> Bandcamp
> Akıllı TV
> 9GAG

Contoh:
.aio https://www.facebook.com/share/p/1CWzvgc8cb/
`.trim())

  try {
    m.reply('wett')
    let result = await zenn(url)

    if (!result || !result.medias || result.medias.length === 0) throw 'Gagal ambil media'

    for (let media of result.medias) {
      if (media.url) {
        await conn.sendFile(m.chat, media.url, null, result.title || '', m)
      }
    }
  } catch (e) {
    m.reply(`Eror kak : ${e.message || e}`)
  }
}

handler.help = ['aio']
handler.tags = ['downloader']
handler.command = ['aio']

export default handler