import { tebakkata } from "@bochilteam/scraper";

class HangmanGame {
  constructor(id) {
    this.sessionId = id;
    this.guesses = [];
    this.maxAttempts = 0;
    this.currentStage = 0;
  }

  getRandomQuest = async () => {
    try {
      const { jawaban, soal } = await tebakkata();
      return { clue: soal, quest: jawaban.toLowerCase() };
    } catch (error) {
      console.error("Gagal mengambil soal:", error);
      throw new Error("Gagal mengambil soal permainan.");
    }
  };

  initializeGame = async () => {
    try {
      this.quest = await this.getRandomQuest();
      this.maxAttempts = this.quest.quest.length;
    } catch (error) {
      console.error("Gagal memulai permainan:", error);
      throw new Error("Gagal memulai permainan.");
    }
  };

  displayBoard = () => {
    const emojiStages = ["😐", "😕", "😟", "😧", "😢", "😨", "😵"];
    let board = `*Tahap Saat Ini:* ${emojiStages[this.currentStage]}\n\`\`\`==========\n|    |\n|   ${emojiStages[this.currentStage]}\n|   ${this.currentStage >= 3 ? "/" : ""}${this.currentStage >= 4 ? "|" : ""}${this.currentStage >= 5 ? "\\" : ""} \n|   ${this.currentStage >= 1 ? "/" : ""} ${this.currentStage >= 2 ? "\\" : ""} \n|      \n|      \n==========\`\`\`\n*Petunjuk:* ${this.quest.clue}`;
    return board;
  };

  displayWord = () =>
    this.quest.quest
      .split("")
      .map((char) => (this.guesses.includes(char) ? `${char}` : "__"))
      .join(" ");

  makeGuess = (letter) => {
    if (!this.isAlphabet(letter)) return "invalid";
    letter = letter.toLowerCase();
    if (this.guesses.includes(letter)) return "repeat";

    this.guesses.push(letter);

    if (!this.quest.quest.includes(letter)) {
      this.currentStage = Math.min(
        this.quest.quest.length,
        this.currentStage + 1,
      );
    }

    return this.checkGameOver()
      ? "over"
      : this.checkGameWin()
        ? "win"
        : "continue";
  };

  isAlphabet = (letter) => /^[a-zA-Z]$/.test(letter);

  checkGameOver = () => this.currentStage >= this.maxAttempts;

  checkGameWin = () =>
    [...new Set(this.quest.quest)].every((char) => this.guesses.includes(char));

  getHint = () => `*Jawaban:* ${this.quest.quest}`;
}

const handler = async (m, { conn, usedPrefix, command, args }) => {
  conn.hangman = conn.hangman || {};
  let [action, inputs] = args;

  try {
    switch (action) {
      case "end":
        if (
          conn.hangman[m.chat] &&
          conn.hangman[m.chat].sessionId === m.sender
        ) {
          delete conn.hangman[m.chat];
          await m.reply("Permainan Hangman berhasil dihentikan. 👋");
        } else {
          await m.reply("Tidak ada sesi permainan aktif atau kamu bukan pemainnya.");
        }
        break;

      case "start":
        if (conn.hangman[m.chat]) {
          await m.reply(
            `Sesi permainan Hangman sedang berlangsung. Gunakan *${usedPrefix + command} end* untuk mengakhirinya.`,
          );
        } else {
          conn.hangman[m.chat] = new HangmanGame(m.sender);
          const gameSession = conn.hangman[m.chat];
          await gameSession.initializeGame();
          await m.reply(
            `Permainan Hangman dimulai. 🎉\n\n*ID Pemain:* ${gameSession.sessionId}\n${gameSession.displayBoard()}\n\n*Tebak Kata:*\n${gameSession.displayWord()}\n\nKirim huruf untuk menebak, contoh: *${usedPrefix + command} guess a*`,
          );
        }
        break;

      case "guess":
        if (conn.hangman[m.chat]) {
          if (!inputs || !/^[a-zA-Z]$/.test(inputs)) {
            await m.reply(`Masukkan huruf setelah *guess*. Contoh: *${usedPrefix + command} guess a*`);
            return;
          }

          const gameSession = conn.hangman[m.chat];
          const userGuess = inputs.toLowerCase();
          const result = gameSession.makeGuess(userGuess);

          const messages = {
            invalid: "Masukkan huruf yang valid (a-z).",
            repeat: "Huruf ini sudah ditebak sebelumnya. Coba huruf lain.",
            continue: `*Huruf yang Sudah Ditebak:*\n${gameSession.guesses.join(", ")}\n${gameSession.displayBoard()}\n\n*Kata Saat Ini:*\n${gameSession.displayWord()}\n\n*Sisa Kesempatan:* ${gameSession.maxAttempts - gameSession.currentStage}`,
            over: `Game Over! Kamu kalah. Jawabannya adalah *${gameSession.quest.quest}*. 💀`,
            win: "Selamat! Kamu menang dalam permainan Hangman. 🎉",
          };

          await m.reply(messages[result]);

          if (result === "over" || result === "win") {
            delete conn.hangman[m.chat];
          }
        } else {
          await m.reply("Belum ada permainan Hangman yang aktif. Gunakan *start* untuk memulai.");
        }
        break;

      case "hint":
        if (conn.hangman[m.chat]) {
          const gameSession = conn.hangman[m.chat];
          await m.reply(gameSession.getHint());
        } else {
          await m.reply("Tidak ada sesi permainan Hangman aktif. Gunakan *start* untuk memulai.");
        }
        break;

      case "help":
        await m.reply(
          `*[ PERMAINAN HANGMAN ]* 🎮\n\n*Perintah:*\n- *${usedPrefix + command} start :* Memulai permainan Hangman.\n- *${usedPrefix + command} end :* Mengakhiri sesi permainan.\n- *${usedPrefix + command} guess [huruf] :* Menebak huruf dalam kata.\n- *${usedPrefix + command} hint :* Menampilkan jawaban kata.`,
        );
        break;

      default:
        await m.reply(`Perintah tidak dikenal. Gunakan *${usedPrefix + command} help* untuk melihat bantuan.`);
    }
  } catch (error) {
    console.error("Terjadi kesalahan dalam handler hangman:", error);
    await m.reply("Terjadi kesalahan saat menjalankan permainan Hangman. Silakan coba lagi.");
  }
};

handler.help = ["hangman"];
handler.tags = ["game"];
handler.command = ["hangman"];
handler.group = true;
handler.limit = true;

export default handler;