
✅ Harga Reseller Diamond Free Fire ✅
🔥 Top Up Murah & Cepat! 🔥

💎 Diamond Kecil

5 DM ➜ Rp 1.000

10 DM ➜ Rp 1.900

15 DM ➜ Rp 2.900

20 DM ➜ Rp 3.900

25 DM ➜ Rp 4.900

30 DM ➜ Rp 5.900


💎 Diamond Menengah

50 DM ➜ Rp 7.500

55 DM ➜ Rp 8.500

60 DM ➜ Rp 9.500

70 DM ➜ Rp 10.500

80 DM ➜ Rp 12.500

100 DM ➜ Rp 15.000

120 DM ➜ Rp 18.000

140 DM ➜ Rp 20.500

150 DM ➜ Rp 22.000


💎 Diamond Besar

190 DM ➜ Rp 27.500

210 DM ➜ Rp 30.500

280 DM ➜ Rp 40.000

355 DM ➜ Rp 50.000

425 DM ➜ Rp 60.000

495 DM ➜ Rp 70.500

565 DM ➜ Rp 80.500

635 DM ➜ Rp 90.500

720 DM ➜ Rp 100.500

860 DM ➜ Rp 120.500


💎 Diamond Sultan

1075 DM ➜ Rp 150.500

1440 DM ➜ Rp 200.500

2160 DM ➜ Rp 300.500

2880 DM ➜ Rp 400.500

3600 DM ➜ Rp 500.500

4320 DM ➜ Rp 600.500

7290 DM ➜ Rp 1.000.500

36.500 DM ➜ Rp 4.990.500


📌 Keuntungan:
✅ Proses Cepat & Aman
✅ Harga Termurah
✅ Bisa untuk Akun Sendiri atau Jualan!

🚀 Order sekarang sebelum harga naik! 🚀

