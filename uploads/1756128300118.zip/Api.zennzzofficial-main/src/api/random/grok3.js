const express = require('express')
const { randomUUID } = require('crypto')
const fetch = require('node-fetch')

module.exports = function (app) {
  app.get('/ai/grok3', async (req, res) => {
    const { prompt } = req.query

    if (!prompt) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter prompt tidak boleh kosong'
      })
    }

    const systemPrompt = `
Kamu adalah Grok 3 Mini — AI asisten yang cepat tanggap, jujur, dan berani memberikan opini. Kamu bisa menjawab pertanyaan secara langsung dan kritis, tapi tetap menghargai konteks, budaya, dan etika. Gunakan bahasa Indonesia sehari-hari yang alami, jelas, kadang santai, tapi tetap informatif. Gaya bicara kamu fleksibel: bisa to the point, bisa bercanda, tergantung suasana. Tujuan utama kamu adalah membantu pengguna dengan cara yang ringkas, tepat, dan insightful.
`.trim()

    try {
      const apiUrl = 'https://widget-api.overchat.ai/v1/chat/completions'

      const messages = [
        {
          id: randomUUID(),
          role: "user",
          content: prompt
        },
        {
          id: randomUUID(),
          role: "system",
          content: systemPrompt
        }
      ]

      const body = {
        model: "x-ai/grok-3-mini-beta",
        messages,
        personaId: "grok-3-beta-mini",
        frequency_penalty: 0,
        max_tokens: 2048,
        presence_penalty: 0,
        stream: false,
        temperature: 0.5,
        top_p: 0.95
      }

      const headers = {
        "accept": "*/*",
        "content-type": "application/json",
        "x-device-language": "id-ID",
        "x-device-platform": "web",
        "x-device-uuid": randomUUID(),
        "x-device-version": "1.0.44"
      }

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(body)
      })

      const raw = await response.text()

      const lines = raw
        .split('\n')
        .map(line => line.trim())
        .filter(line => line.startsWith('data: {') && !line.includes('[DONE]'))

      let result = ''
      for (const line of lines) {
        try {
          const json = JSON.parse(line.replace(/^data:\s*/, ''))
          const delta = json?.choices?.[0]?.delta?.content
          if (delta) result += delta
        } catch (e) {
          console.error('Parse error:', e)
        }
      }

      res.status(200).json({
        status: true,
        creator: 'ZenzzXD',
        result: result.trim()
      })

    } catch (err) {
      console.error(err)
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal mengambil respons dari Grok 3 Mini',
        error: err?.message || String(err)
      })
    }
  })
}
