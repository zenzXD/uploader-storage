const axios = require('axios');
const cheerio = require('cheerio');

const primbon = {
    sifatbisnis: async (tgl, bln, thn) => {
        try {
            const { data } = await axios.post('https://primbon.com/sifat_usaha_bisnis.php',
                new URLSearchParams({ tgl, bln, thn, submit: " Submit! " }),
                { headers: { 'content-type': 'application/x-www-form-urlencoded' } }
            );

            const $ = cheerio.load(data);
            const fetchText = $('#body').text();
            return {
                status: true,
                creator: 'ZenzzXD',
                message: {
                    hari_lahir: fetchText.split('Hari Lahir Anda: ')[1].split(thn)[0].trim(),
                    usaha: fetchText.split(thn)[1].split('< Hitung Kembali')[0].trim(),
                    catatan: 'Sifat bisnis berdasarkan weton untuk referensi bidang usaha.'
                }
            };
        } catch {
            return { status: false, creator: 'ZenzzXD', message: 'Input salah atau error' };
        }
    },

    rejekihoki: async (tgl, bln, thn) => {
        try {
            const { data } = await axios.post('https://primbon.com/rejeki_hoki_weton.php',
                new URLSearchParams({ tgl, bln, thn, submit: " Submit! " }),
                { headers: { 'content-type': 'application/x-www-form-urlencoded' } }
            );

            const $ = cheerio.load(data);
            const fetchText = $('#body').text();
            return {
                status: true,
                creator: 'ZenzzXD',
                message: {
                    hari_lahir: fetchText.split('Hari Lahir: ')[1].split(thn)[0].trim(),
                    rejeki: fetchText.split(thn)[1].split('< Hitung Kembali')[0].trim(),
                    catatan: 'Hasil rejeki berdasarkan primbon Jawa.'
                }
            };
        } catch {
            return { status: false, creator: 'ZenzzXD', message: 'Input salah atau error' };
        }
    },

    tanggalnikah: async (tgl, bln, thn) => {
        try {
            const { data } = await axios.get(`https://primbon.com/tanggal_jadian_pernikahan.php?tgl=${tgl}&bln=${bln}&thn=${thn}&proses=+Submit%21+`);
            const $ = cheerio.load(data);
            const fetchText = $('#body').text();
            return {
                status: true,
                creator: 'ZenzzXD',
                message: {
                    tanggal: fetchText.split('Tanggal: ')[1].split('Karakteristik: ')[0].trim(),
                    karakteristik: fetchText.split('Karakteristik: ')[1].split('< Hitung Kembali')[0].trim(),
                    catatan: 'Referensi tanggal pernikahan.'
                }
            };
        } catch {
            return { status: false, creator: 'ZenzzXD', message: 'Input salah atau error' };
        }
    },

    kecocokan: async (nama1, nama2) => {
        try {
            const { data } = await axios.get(`https://primbon.com/kecocokan_nama_pasangan.php?nama1=${nama1}&nama2=${nama2}&proses=+Submit%21+`);
            const $ = cheerio.load(data);
            const fetchText = $('#body').text();
            return {
                status: true,
                creator: 'ZenzzXD',
                message: {
                    nama_anda: nama1,
                    nama_pasangan: nama2,
                    sisi_positif: fetchText.split('Sisi Positif Anda: ')[1].split('Sisi Negatif Anda: ')[0].trim(),
                    sisi_negatif: fetchText.split('Sisi Negatif Anda: ')[1].split('< Hitung Kembali')[0].trim(),
                    gambar: 'https://primbon.com/ramalan_kecocokan_cinta2.png',
                    catatan: 'Kecocokan pasangan berdasarkan primbon.'
                }
            };
        } catch {
            return { status: false, creator: 'ZenzzXD', message: 'Input salah atau error' };
        }
    },

    mimpi: async (value) => {
        try {
            const { data } = await axios.get(`https://primbon.com/tafsir_mimpi.php?mimpi=${value}&submit=+Submit+`);
            const $ = cheerio.load(data);
            const fetchText = $('#body').text();
            return {
                status: true,
                creator: 'ZenzzXD',
                message: {
                    mimpi: value,
                    arti: fetchText.split(`Hasil pencarian untuk kata kunci: ${value}`)[1].split('\n')[0].trim(),
                    solusi: fetchText.split('Solusi -')[1].trim()
                }
            };
        } catch {
            return { status: false, creator: 'ZenzzXD', message: `Tafsir mimpi "${value}" tidak ditemukan.` };
        }
    },

    artinama: async (value) => {
        try {
            const { data } = await axios.get(`https://primbon.com/arti_nama.php?nama1=${value}&proses=+Submit%21+`);
            const $ = cheerio.load(data);
            const fetchText = $('#body').text();
            return {
                status: true,
                creator: 'ZenzzXD',
                message: {
                    nama: value,
                    arti: fetchText.split('memiliki arti: ')[1].split('Nama:')[0].trim(),
                    catatan: 'Arti nama berdasarkan primbon Jawa.'
                }
            };
        } catch {
            return { status: false, creator: 'ZenzzXD', message: `Arti nama "${value}" tidak ditemukan.` };
        }
    }
};

module.exports = function (app) {
    app.get('/primbon/artimimpi', async (req, res) => {
        if (!req.query.q) return res.status(400).json({ status: false, creator: 'ZenzzXD', message: 'Parameter ?q= harus diisi' });
        const result = await primbon.mimpi(req.query.q);
        res.json(result);
    });

    app.get('/primbon/artinama', async (req, res) => {
        if (!req.query.q) return res.status(400).json({ status: false, creator: 'ZenzzXD', message: 'Parameter ?q= harus diisi' });
        const result = await primbon.artinama(req.query.q);
        res.json(result);
    });

    app.get('/primbon/kecocokan', async (req, res) => {
        const { nama1, nama2 } = req.query;
        if (!nama1 || !nama2) return res.status(400).json({ status: false, creator: 'ZenzzXD', message: 'Parameter ?nama1=&nama2= harus diisi' });
        const result = await primbon.kecocokan(nama1, nama2);
        res.json(result);
    });

    app.get('/primbon/tanggalnikah', async (req, res) => {
        const { tgl, bln, thn } = req.query;
        if (!tgl || !bln || !thn) return res.status(400).json({ status: false, creator: 'ZenzzXD', message: 'Parameter ?tgl=&bln=&thn= harus diisi' });
        const result = await primbon.tanggalnikah(tgl, bln, thn);
        res.json(result);
    });

    app.get('/primbon/rejekihoki', async (req, res) => {
        const { tgl, bln, thn } = req.query;
        if (!tgl || !bln || !thn) return res.status(400).json({ status: false, creator: 'ZenzzXD', message: 'Parameter ?tgl=&bln=&thn= harus diisi' });
        const result = await primbon.rejekihoki(tgl, bln, thn);
        res.json(result);
    });

    app.get('/primbon/sifatbisnis', async (req, res) => {
        const { tgl, bln, thn } = req.query;
        if (!tgl || !bln || !thn) return res.status(400).json({ status: false, creator: 'ZenzzXD', message: 'Parameter ?tgl=&bln=&thn= harus diisi' });
        const result = await primbon.sifatbisnis(tgl, bln, thn);
        res.json(result);
    });
};
