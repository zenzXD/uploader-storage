const axios = require('axios');

module.exports = function (app) {
  app.get('/maker/bratvid', async (req, res) => {
    const text = req.query.text;
    if (!text) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: "Parameter 'text' wajib diisi"
      });
    }

    const primaryUrl = `https://brat.siputzx.my.id/gif?text=${encodeURIComponent(text)}`;
    const fallbackUrl = `https://api.fasturl.link/maker/brat/animated?text=${encodeURIComponent(text)}&mode=animated`;

    try {
      const response = await axios.get(primaryUrl, { responseType: 'stream' });
      res.setHeader('Content-Type', response.headers['content-type'] || 'application/octet-stream');
      res.setHeader('Creator', 'ZenzzXD');
      return response.data.pipe(res);
    } catch (err1) {
      console.warn('[BratVid] Primary API gagal, mencoba fallback...');
      try {
        const fallbackResponse = await axios.get(fallbackUrl, { responseType: 'stream' });
        res.setHeader('Content-Type', fallbackResponse.headers['content-type'] || 'application/octet-stream');
        res.setHeader('Creator', 'ZenzzXD');
        return fallbackResponse.data.pipe(res);
      } catch (err2) {
        console.error('[BratVid] Fallback API juga gagal:', err2.message);
        return res.status(502).json({
          status: false,
          creator: 'ZenzzXD',
          message: 'Gagal mengambil data',
          error: err2.message
        });
      }
    }
  });
};
