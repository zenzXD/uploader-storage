const axios = require('axios');
const cheerio = require('cheerio');

async function scrapeKomikuChapter(chapterUrl) {
    try {
        const { data } = await axios.get(chapterUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile)'
            }
        });
        const $ = cheerio.load(data);

        // Chapter title
        const chapterTitle = $('#Judul h1').text().trim();

        // Manga metadata URL
        const mangaUrl = $('ul#breadcrumb li a').eq(1).attr('href');
        const mangaTitle = $('ul#breadcrumb li a').eq(1).text().trim();

        // Manga metadata scrape
        const mangaMetadata = await scrapeMangaMetadata(mangaUrl);

        // Release date & read direction
        const releaseDate = $('table.tbl tr:contains("Tanggal Rilis") td').eq(1).text().trim();
        const readDirection = $('table.tbl tr:contains("Arah Baca") td').eq(1).text().trim();

        // Description (chapter)
        const description = $('#Baca_Komik h2').text().trim();

        // Comic images
        const bacaKomik = [];
        $('#Baca_Komik img').each((i, el) => {
            const img = $(el).attr('src');
            if (img) bacaKomik.push(img.trim());
        });

        // Closing description
        const closingDesc = $('#Komentar p').text().trim();

        const result = {
            status: true,
            creator: "ZenzzXD",
            type: "chapter",
            title: chapterTitle,
            manga_title: mangaTitle,
            manga_url: mangaUrl,
            release_date: releaseDate,
            read_direction: readDirection,
            description: description,
            baca_komik: bacaKomik,
            closing_description: closingDesc,
            manga_metadata: mangaMetadata
        };

        return result;

    } catch (err) {
        console.error("❌ Error scraping:", err.message);
        return {
            status: false,
            creator: "ZenzzXD",
            message: "Error scraping: " + err.message
        };
    }
}

async function scrapeMangaMetadata(mangaUrl) {
    try {
        const { data } = await axios.get(mangaUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile)'
            }
        });
        const $ = cheerio.load(data);

        const title = $('h1').first().text().trim();
        const titleIndo = $('.j2').first().text().trim();
        const type = $('table.inftable tr:contains("Jenis Komik") td').eq(1).text().trim();
        const author = "Shueisha"; // Hardcode
        const status = $('table.inftable tr:contains("Status") td').eq(1).text().trim();
        const synopsis = $('#Sinopsis p').first().text().trim();

        return {
            title: title || null,
            title_indonesia: titleIndo || null,
            type: type || null,
            author: author || null,
            status: status || null,
            synopsis: synopsis || null
        };

    } catch (err) {
        console.error("❌ Error scraping metadata:", err.message);
        return null;
    }
}

module.exports = function (app) {
    app.get('/anime/komikudetail', async (req, res) => {
        const chapterUrl = req.query.url;

        if (!chapterUrl) {
            return res.status(400).json({
                status: false,
                creator: "ZenzzXD",
                message: "paremeter url di butuhkan"
            });
        }

        const result = await scrapeKomikuChapter(chapterUrl);

        res.json(result);
    });
};
