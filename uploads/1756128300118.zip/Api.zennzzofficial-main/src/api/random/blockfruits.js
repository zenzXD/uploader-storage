const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function (app) {
  app.get('/info/blockfruitsstock', async (req, res) => {
    try {
      const html = await axios.get('https://fruityblox.com/stock');
      const $ = cheerio.load(html.data);
      const result = [];

      $('.border-secondary').each((i, el) => {
        const name = $(el).find('h3').text().trim();
        const type = $(el).find('.text-xs').text().trim();
        const priceDolar = $(el).find('.text-sm').eq(0).text().trim();
        const priceR = $(el).find('.text-sm').eq(1).text().trim();
        const thumb = $(el).find('img').attr('src');

        result.push({
          name,
          type,
          priceDolar,
          priceR,
          thumb
        });
      });

      res.json({
        status: true,
        creator: 'ZenzzXD',
        count: result.length,
        data: result
      });
    } catch (err) {
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal mengambil data stock',
        detail: err.message
      });
    }
  });
};
