const axios = require('axios');

module.exports = function (app) {
  app.get('/maker/brat', async (req, res) => {
    try {
      const { text } = req.query;
      if (!text) {
        return res.status(400).json({
          status: false,
          message: 'Parameter "text" wajib diisi',
          creator: 'ZenzzXD'
        });
      }

      const response = await axios.get(
        `https://xyro666-brats.hf.space/?text=${encodeURIComponent(text)}`,
        {
          responseType: 'arraybuffer',
          headers: {
            'accept': 'image/png',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/58.0.3029.110 Safari/537.3'
          }
        }
      );

      res.set('Content-Type', 'image/png');
      res.send(response.data);
    } catch (err) {
      console.error('ERR:', err?.response?.data || err.message || err);
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Terjadi kesalahan saat memproses permintaan'
      });
    }
  });
};
