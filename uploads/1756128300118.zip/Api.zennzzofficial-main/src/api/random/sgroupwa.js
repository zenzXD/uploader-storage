const axios = require('axios');
const cheerio = require('cheerio');

async function searchGroups(keywords) {
    const headers = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Referer": "https://groupda1.link/add/group/search",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept": "text/html, /; q=0.01",
        "Host": "groupda1.link",
        "Origin": "https://groupda1.link",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    };

    const results = [];
    const keywordList = keywords.split(',');

    for (const name of keywordList) {
        const keyword = name.trim();

        const data = {
            group_no: "0", // cuma ambil halaman pertama
            search: true,
            keyword: keyword
        };

        try {
            const response = await axios.post(
                "https://groupda1.link/add/group/loadresult",
                new URLSearchParams(data),
                { headers, timeout: 5000 }
            );

            if (response.status !== 200 || !response.data) continue;

            const $ = cheerio.load(response.data);

            for (const maindiv of $('.maindiv').toArray()) {
                const tag = $(maindiv).find('a[href]');
                if (!tag.length) continue;

                const link = tag.attr('href');
                const title = tag.attr('title').replace('Whatsapp group invite link: ', '');
                const description_tag = $(maindiv).find('p.descri');
                const description = description_tag.text().trim() || 'Tidak ada deskripsi';
                const group_id = link.split('/').pop();
                const group_link = `https://chat.whatsapp.com/${group_id}`;

                if (!results.some(g => g.Code === group_id)) {
                    results.push({
                        Name: title,
                        Code: group_id,
                        Link: group_link,
                        Description: description,
                        Keyword: keyword
                    });
                }
            }

        } catch (error) {
            continue; // skip kalau error
        }
    }

    return results;
}

module.exports = function (app) {
    app.get('/search/sgroupwa', async (req, res) => {
        let { q } = req.query;

        if (!q) {
            return res.status(400).json({
                status: false,
                creator: "ZenzzXD",
                message: "Parameter 'q' tidak boleh kosong."
            });
        }

        // Fix query string: ganti spasi jadi +
        q = decodeURIComponent(q).replace(/\s+/g, ' ').trim();

        try {
            const groups = await searchGroups(q);
            if (!groups.length) {
                return res.status(404).json({
                    status: false,
                    creator: "ZenzzXD",
                    message: `Tidak ada grup WhatsApp ditemukan untuk keyword: ${q}`
                });
            }

            res.json({
                status: true,
                creator: "ZenzzXD",
                total: groups.length,
                data: groups
            });

        } catch (err) {
            res.status(500).json({
                status: false,
                creator: "ZenzzXD",
                message: "Gagal mencari grup WhatsApp.",
                error: err.message
            });
        }
    });
};
