const axios = require('axios');

async function getOtakudesuDetail(url) {
    try {
        const apiUrl = `https://api.siputzx.my.id/api/anime/otakudesu/detail?url=${encodeURIComponent(url)}`;
        const { data } = await axios.get(apiUrl);

        if (!data.status || !data.data) {
            return {
                status: false,
                creator: "ZenzzXD",
                message: "gagal mengambil data"
            };
        }

        const animeInfo = data.data.animeInfo;
        const episodes = data.data.episodes;

        const animeData = {
            judul: animeInfo.title,
            japanese: animeInfo.japaneseTitle,
            skor: animeInfo.score,
            produser: animeInfo.producer,
            tipe: animeInfo.type,
            status: animeInfo.status,
            total_episodes: animeInfo.totalEpisodes,
            durasi: animeInfo.duration,
            release_date: animeInfo.releaseDate,
            studio: animeInfo.studio,
            genre: animeInfo.genres.split(',').map(g => g.trim()),
            image_url: animeInfo.imageUrl,
            episode_list: episodes.map(ep => ({
                title: ep.title,
                episode_url: ep.link,
                date: ep.date
            }))
        };

        return {
            status: true,
            creator: "ZenzzXD",
            result: animeData
        };

    } catch (err) {
        console.error("API fetch error:", err.message);
        return {
            status: false,
            creator: "ZenzzXD",
            message: "Failed"
        };
    }
}

module.exports = function (app) {
    app.get('/anime/otakudesu/detail', async (req, res) => {
        const url = req.query.url;
        if (!url) {
            return res.json({
                status: false,
                creator: "ZenzzXD",
                message: "Missing 'url' query parameter."
            });
        }

        const result = await getOtakudesuDetail(url);
        res.json(result);
    });
};
