const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function (app) {
    app.get('/stalker/minecraft', async (req, res) => {
        const username = req.query.username;

        if (!username || username.trim() === '') {
            return res.status(400).json({
                status: false,
                creator: "ZenzzXD",
                message: "Parameter 'username' wajib diisi",
            });
        }

        const url = `https://xboxgamertag.com/search/${username}`;

        try {
            const { data: html } = await axios.get(url, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                },
            });

            const $ = cheerio.load(html);
            const profileData = {};

            profileData.gamertag = $('div.page-header h1 a').text().trim();
            if (!profileData.gamertag) {
                return res.status(404).json({
                    status: false,
                    creator: "ZenzzXD",
                    message: "Gamertag tidak ditemukan",
                });
            }

            profileData.profilePictureUrl = $('.avatar img').attr('src');

            $('.profile-detail-item').each((index, element) => {
                const el = $(element);
                const label = el.find('span').text().trim();
                const value = el.text().replace(label, '').trim();

                if (label === 'Gamerscore') {
                    profileData.gamerscore = value;
                } else if (label === 'Games Played') {
                    profileData.gamesPlayed = value;
                }
            });

            profileData.gameHistory = [];
            $('.recent-games .game-card').each((index, element) => {
                const card = $(element);
                const game = {};

                game.name = card.find('.game-card-desc h3').text().trim();
                game.lastPlayed = card.find('.game-card-desc p.text-sm').text().trim();

                card.find('.game-card-desc .row').each((i, row) => {
                    const label = $(row).find('span.badge').text().trim();
                    const value = $(row).find('.col-9').text().trim();

                    if (label === 'Gamerscore') {
                        game.gamerscore = value;
                    } else if (label === 'Achievements') {
                        game.achievements = value;
                    }
                });

                if (game.name) {
                    profileData.gameHistory.push(game);
                }
            });

            return res.status(200).json({
                status: true,
                creator: "ZenzzXD",
                result: profileData
            });

        } catch (error) {
            console.error('Error:', error.message);
            return res.status(500).json({
                status: false,
                creator: "ZenzzXD",
                message: "Gagal mengambil data",
                error: error.message
            });
        }
    });
};
