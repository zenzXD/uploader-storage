const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function (app) {
  app.get('/info/blockfruitsvalues', async (req, res) => {
    try {
      const html = await axios.get('https://fruityblox.com/blox-fruits-value-list');
      const $ = cheerio.load(html.data);
      const result = [];

      $('.transition-colors').each((i, el) => {
        const name = $(el).find('.flex-1 p').eq(0).text().toUpperCase().trim();
        const type = $(el).find('.text-xs').text().trim();
        const pricePerma = $(el).find('.text-sm').eq(0).text().trim();
        const priceBasic = $(el).find('.text-sm').eq(1).text().trim() || '0';

        // FIX THUMBNAIL
        const rawThumb = $(el).find('img').attr('src');
        const thumb = rawThumb?.startsWith('http') ? rawThumb : `https://fruityblox.com${rawThumb}`;

        result.push({
          name,
          type,
          pricePerma,
          priceBasic,
          thumb
        });
      });

      res.json({
        status: true,
        creator: 'ZenzzXD',
        count: result.length,
        data: result
      });
    } catch (err) {
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal mengambil data value',
        detail: err.message
      });
    }
  });
};
