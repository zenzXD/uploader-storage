const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function(app) {
    app.get('/anime/otakudesu', async (req, res) => {
        const url = 'https://otakudesu.cloud/';

        try {
            const { data } = await axios.get(url, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
                }
            });

            const $ = cheerio.load(data);
            const animeList = [];

            $('.venz li').each((index, element) => {
                const item = $(element);

                const title = item.find('h2.jdlflm').text().trim();
                const itemUrl = item.find('.thumb a').attr('href');
                const imageUrl = item.find('.thumbz img').attr('src');
                const published = item.find('.newnime').text().trim();

                if (title && itemUrl && imageUrl && published) {
                    animeList.push({
                        title,
                        url: itemUrl,
                        image: imageUrl,
                        published,
                    });
                }
            });

            if (animeList.length === 0) {
                return res.json({
                    status: false,
                    creator: "ZenzzXD",
                    message: "Tidak menemukan data"
                });
            }

            res.json({
                status: true,
                creator: "ZenzzXD",
                result: animeList
            });

        } catch (error) {
            let errorMessage = "Terjadi kesalahan tidak diketahui";
            if (error.response) {
                errorMessage = `Server error ${error.response.status}`;
            } else if (error.request) {
                errorMessage = "Tidak ada respon dari server.";
            } else {
                errorMessage = `Request error: ${error.message}`;
            }

            res.json({
                status: false,
                creator: "ZenzzXD",
                message: errorMessage
            });
        }
    });
};
