const axios = require('axios');

module.exports = function (app) {
  app.get('/maker/ngl', async (req, res) => {
    const { text } = req.query;

    if (!text) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter "text" harus diisi.'
      });
    }

    try {
      const response = await axios.post('https://lemon-ngl.vercel.app/api/generate-image', {
        text
      }, {
        responseType: 'arraybuffer',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', 'inline; filename="ngl-result.png"');
      res.send(Buffer.from(response.data));
    } catch (err) {
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal memproses permintaan.',
        error: err.message
      });
    }
  });
};
