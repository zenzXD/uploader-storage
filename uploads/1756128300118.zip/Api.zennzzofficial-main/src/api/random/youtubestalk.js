const axios = require('axios');

// 🔥 Format angka jadi lebih manusiawi
function formatNumber(number, suffix) {
  if (number >= 1_000_000_000) return (number / 1_000_000_000).toFixed(2) + ' miliar' + (suffix || '');
  if (number >= 1_000_000) return (number / 1_000_000).toFixed(2) + ' juta' + (suffix || '');
  if (number >= 1_000) return (number / 1_000).toFixed(2) + ' ribu' + (suffix || '');
  return number.toFixed(2) + (suffix || '');
}

module.exports = function (app) {
  app.get('/stalker/youtube', async (req, res) => {
    const { username } = req.query;

    if (!username) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: "Parameter ?username= harus diisi"
      });
    }

    try {
      const channelUrl = `https://youtube.com/@${username}`;
      const endpoint = 'https://www.livereacting.com/api/youtube-channel-data';

      const response = await axios.post(endpoint, {
        channelUrl: channelUrl
      }, {
        headers: { 'Content-Type': 'application/json' },
        timeout: 7000
      });

      const data = response.data;

      // 🔥 Return hanya versi formatted
      const result = {
        title: data.title,
        subscriberCount: formatNumber(data.subscriberCount, ' subscribers'),
        viewCount: formatNumber(data.viewCount, ' views'),
        videoCount: formatNumber(data.videoCount, ' videos'),
        createdAt: data.createdAt,
        monthlyViews: formatNumber(data.monthlyViews, ' views/bulan'),
        totalRevenue: 'Rp' + formatNumber(data.totalRevenue),
        monthlyRevenue: 'Rp' + formatNumber(data.monthlyRevenue, '/bulan'),
        category: data.category,
        defaultCPM: data.defaultCPM,
        thumbnailUrl: data.thumbnailUrl
      };

      return res.json({
        status: true,
        creator: 'ZenzzXD',
        result
      });

    } catch (err) {
      console.error('[YouTube Stalk ERROR]', err.message);
      return res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Terjadi kesalahan saat memproses permintaan',
        error: err.message
      });
    }
  });
};
