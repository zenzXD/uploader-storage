const axios = require("axios");

async function SnackVideo(url) {
    try {
        const response = await axios.post(
            "https://api.snackdownloader.com/get-data",
            { url },
            {
                headers: {
                    "content-type": "application/json",
                    "origin": "https://snackdownloader.com",
                    "referer": "https://snackdownloader.com",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
                }
            }
        );

        const { video } = response.data;

        if (!video) throw new Error("Gagal mengambil video. Cek linknya!");

        return {
            status: true,
            creator: "ZenzzXD",
            video
        };

    } catch (err) {
        return {
            status: false,
            creator: "ZenzzXD",
            message: err.message || "error."
        };
    }
}

module.exports = function (app) {
    app.get("/downloader/snackvid", async (req, res) => {
        const { url } = req.query;
        if (!url) {
            return res.status(400).json({
                status: false,
                creator: "ZenzzXD",
                message: "Parameter url diperlukan"
            });
        }

        const result = await SnackVideo(url);
        res.json(result);
    });
};
