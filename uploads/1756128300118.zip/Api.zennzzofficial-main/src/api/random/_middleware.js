export default async function middleware(req, res, next) {
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress;

    console.log(`
📥 New API Request
🌐 URL: ${req.method} ${req.url}
📌 IP: ${ip}
🕒 Time: ${new Date().toLocaleString()}
    `);

    next();
}
