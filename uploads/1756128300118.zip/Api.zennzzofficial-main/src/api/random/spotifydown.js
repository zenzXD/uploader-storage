const axios = require("axios");

async function spotifydl(spotifyUrl) {
    try {
        const response = await axios.get(`https://api.fabdl.com/spotify/get?url=${encodeURIComponent(spotifyUrl)}`);
        const trackInfo = response.data.result;
        if (!trackInfo) throw new Error("Gagal mendapatkan data lagu");

        const { id, name, image, artists, duration_ms, gid } = trackInfo;
        const convertResponse = await axios.get(`https://api.fabdl.com/spotify/mp3-convert-task/${gid}/${id}`);
        const convertData = convertResponse.data.result;
        if (!convertData || !convertData.download_url) throw new Error("Gagal mendapatkan link download");

        return {
            title: name,
            artist: artists,
            duration: Math.ceil(duration_ms / 1000),
            thumbnail: image,
            downloadUrl: `https://api.fabdl.com${convertData.download_url}`,
        };
    } catch (error) {
        return null;
    }
}

module.exports = function (app) {
    app.get("/downloader/spotify", async (req, res) => {
        const { url } = req.query;
        if (!url) {
            return res.status(400).json({
                status: false,
                creator: "ZenzzXD",
                message: "Parameter 'url' wajib diisi",
            });
        }

        try {
            const downloadData = await spotifydl(url);

            if (!downloadData) {
                return res.status(500).json({
                    status: false,
                    creator: "ZenzzXD",
                    message: "Gagal mendapatkan link download",
                });
            }

            res.json({
                status: true,
                creator: "ZenzzXD",
                result: {
                    title: downloadData.title,
                    artist: downloadData.artist,
                    duration: downloadData.duration,
                    thumbnail: downloadData.thumbnail,
                    spotifyUrl: url,
                    downloadUrl: downloadData.downloadUrl,
                },
            });
        } catch (err) {
            res.status(500).json({
                status: false,
                creator: "ZenzzXD",
                message: err.message || "Terjadi kesalahan",
            });
        }
    });
};
