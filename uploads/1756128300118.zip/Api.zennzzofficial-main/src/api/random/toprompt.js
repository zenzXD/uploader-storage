/**
 * @✨ Route: GET /tools/toprompt?url=<image_url>
 * @Focus: Mengubah gambar menjadi prompt AI via DocsBot
 * @Author: ZenzzXD
 */

const axios = require('axios');
const ua = require('user-agents');

module.exports = function (app) {
  app.get('/tools/toprompt', async (req, res) => {
    const imageUrl = req.query.url;

    if (!imageUrl) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Masukkan parameter url'
      });
    }

    try {
      // Download gambar sebagai buffer
      const img = await axios.get(imageUrl, {
        responseType: 'arraybuffer'
      });

      const buffer = Buffer.from(img.data);

      // Kirim ke DocsBot API
      const { data } = await axios.post('https://docsbot.ai/api/tools/image-prompter', {
        image: buffer.toString('base64'),
        type: 'prompt'
      }, {
        headers: {
          'content-type': 'application/json',
          'user-agent': new ua().toString()
        }
      });

      res.json({
        status: true,
        creator: 'ZenzzXD',
        input: imageUrl,
        result: data
      });

    } catch (err) {
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: err?.response?.data?.message || err.message || 'Gagal memproses gambar'
      });
    }
  });
};
