const axios = require('axios');
const cheerio = require('cheerio');

const BASE_URL = 'https://komiku.org';

async function scrapeKomikuSearch(query) {
    try {
        const API_URL = `https://api.komiku.org/?post_type=manga&s=${encodeURIComponent(query)}`;

        const { data } = await axios.get(API_URL, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
            }
        });

        const $ = cheerio.load(data);
        const results = [];

        $('div.bge').each((index, element) => {
            const titleElement = $(element).find('.kan a h3');
            const relativeUrl = $(element).find('.kan a').attr('href');
            const imageUrl = $(element).find('.bgei a img').attr('src');
            const updateText = $(element).find('.kan p').text().trim();

            // Ambil Awal & Terbaru chapter
            const awalEl = $(element).find('.new1:contains("Awal") a');
            const terbaruEl = $(element).find('.new1:contains("Terbaru") a');

            const manga = {
                title: titleElement.text().trim(),
                url: relativeUrl.startsWith('http') ? relativeUrl : `${BASE_URL}${relativeUrl}`,
                url_image: imageUrl.startsWith('http') ? imageUrl : `${BASE_URL}${imageUrl}`,
                update: updateText || 'Tidak ada update info',
                new_chapter: {
                    text: awalEl.find('span').last().text().trim(),
                    url: awalEl.attr('href') ? (awalEl.attr('href').startsWith('http') ? awalEl.attr('href') : `${BASE_URL}${awalEl.attr('href')}`) : null
                },
                initial_chapter: {
                    text: terbaruEl.find('span').last().text().trim(),
                    url: terbaruEl.attr('href') ? (terbaruEl.attr('href').startsWith('http') ? terbaruEl.attr('href') : `${BASE_URL}${terbaruEl.attr('href')}`) : null
                }
            };

            if (manga.title && manga.url) {
                results.push(manga);
            }
        });

        if (results.length === 0) {
            return {
                status: false,
                creator: "ZenzzXD",
                message: "No results found"
            };
        } else {
            return {
                status: true,
                creator: "ZenzzXD",
                query: query,
                results: results
            };
        }
    } catch (err) {
        console.error('❌ Failed to fetch data:', err.message);
        return {
            status: false,
            creator: "ZenzzXD",
            message: err.message
        };
    }
}

module.exports = function (app) {
    app.get('/anime/komikusearch', async (req, res) => {
        const query = req.query.q;

        if (!query) {
            return res.status(400).json({
                status: false,
                creator: "ZenzzXD",
                message: "Missing 'q' query parameter"
            });
        }

        const result = await scrapeKomikuSearch(query);
        res.json(result);
    });
};
