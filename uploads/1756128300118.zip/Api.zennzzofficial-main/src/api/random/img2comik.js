const axios = require('axios');
const FormData = require('form-data');

/**
 * Mengubah gambar menjadi style komik.
 * @param {string} imageUrl - URL gambar yang akan diubah
 * @returns {Promise<string>} URL hasil komik
 */
async function Image2Comic(imageUrl) {
  try {
    const imageRes = await axios.get(imageUrl, { responseType: 'arraybuffer' });
    const imageBuffer = Buffer.from(imageRes.data);

    const form = new FormData();
    form.append('hidden_image_width', '1712');
    form.append('hidden_image_height', '2560');
    form.append('upload_file', imageBuffer, {
      filename: 'image.jpg',
      contentType: 'image/jpeg'
    });
    form.append('brightness', '50');
    form.append('line_size', '2');
    form.append('screentone', 'true');

    const id = Math.random().toString(36).substring(2, 15);
    const uploadUrl = `https://tech-lagoon.com/canvas/image-to-comic?id=${id}&new_file=true`;

    const uploadRes = await axios.post(uploadUrl, form, {
      headers: {
        ...form.getHeaders(),
        'origin': 'https://tech-lagoon.com',
        'referer': 'https://tech-lagoon.com/imagechef/en/image-to-comic.html',
        'x-requested-with': 'XMLHttpRequest',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
      },
    });

    if (!Array.isArray(uploadRes.data)) {
      throw new Error('Gagal mendapatkan hasil');
    }

    const [resId] = uploadRes.data;
    const n = Math.floor(Math.random() * 9000 + 1000);

    return `https://tech-lagoon.com/imagechef/image-to-comic/${resId}?n=${n}`;
  } catch (err) {
    console.error('Error:', err.message);
    throw err;
  }
}

module.exports = function (app) {
  app.get('/maker/img2comic', async (req, res) => {
    const imageUrl = req.query.url;

    if (!imageUrl) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter ?url= harus diisi'
      });
    }

    try {
      const comicUrl = await Image2Comic(imageUrl);

      // Fetch hasil komik & kirim langsung sebagai image
      const imageStream = await axios.get(comicUrl, { responseType: 'stream' });
      res.setHeader('Content-Type', 'image/jpeg');
      imageStream.data.pipe(res);

    } catch (err) {
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal memproses gambar',
        error: err.message
      });
    }
  });
};
