const axios = require('axios');

module.exports = function (app) {
  const creatorName = "ZenzzXD";

  app.get('/search/lahelu', async (req, res) => {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({
        status: false,
        creator: creatorName,
        message: 'Masukkan parameter q (query pencarian)'
      });
    }

    try {
      const response = await axios.get(`https://lahelu.com/api/post/get-search?query=${encodeURIComponent(q)}`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          'Accept': 'application/json'
        },
        timeout: 15000
      });

      const data = response.data?.postInfos;
      if (!data || !Array.isArray(data) || data.length === 0) {
        return res.status(404).json({
          status: false,
          creator: creatorName,
          message: 'Tidak ada hasil ditemukan untuk query tersebut.'
        });
      }

      const results = data.map(item => ({
        postId: item.postId,
        username: item.userUsername,
        title: item.title,
        media: item.media,
        mediaType: item.mediaType,
        mediaThumbnail: item.mediaThumbnail,
        userAvatar: item.userAvatar,
        topicTitle: item.topicTitle
      }));

      res.json({
        status: true,
        creator: creatorName,
        result: results
      });

    } catch (err) {
      res.status(500).json({
        status: false,
        creator: creatorName,
        message: 'Terjadi kesalahan saat mengambil data',
        error: err.message
      });
    }
  });
};
