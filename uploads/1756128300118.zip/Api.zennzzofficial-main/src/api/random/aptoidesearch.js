const axios = require('axios');

module.exports = function (app) {
  /**
   * GET /search/aptoide
   * Query Params:
   *   - query: The app name to search (e.g., ?query=whatsapp)
   */
  app.get('/search/aptoide', async (req, res) => {
    const searchQuery = req.query.query;

    if (!searchQuery || typeof searchQuery !== 'string' || searchQuery.trim() === '') {
      return res.status(400).json({
        success: false,
        creator: "ZenzzXD",
        message: 'Missing or invalid "query" parameter. Example: ?query=whatsapp',
      });
    }

    try {
      const apiUrl = `https://ws75.aptoide.com/api/7/apps/search?query=${encodeURIComponent(
        searchQuery
      )}&limit=10`;

      const response = await axios.get(apiUrl, {
        headers: {
          'User-Agent': 'Aptoide/9.20.0.0 (Linux; Android 11)',
        },
      });

      const apps = response.data.datalist?.list || [];

      if (apps.length === 0) {
        return res.json({
          success: true,
          creator: "ZenzzXD",
          searchQuery,
          results: [],
        });
      }

      const results = apps.map((app) => ({
        appName: app.name,
        appPhotoUrl: app.icon,
        appUrl: `https://en.aptoide.com/search?query=${encodeURIComponent(
          app.package
        )}&type=apps`,
        downloads: app.stats?.downloads || 0,
        developer: app.developer || 'Unknown',
        lastUpdate: app.modified,
        size: `${(app.size / (1024 * 1024)).toFixed(2)} MB`,
        rating: app.stats?.rating?.avg || 0,
      }));

      res.json({
        success: true,
        creator: "ZenzzXD",
        searchQuery,
        results,
      });
    } catch (error) {
      console.error('Error fetching Aptoide API:', error.message);
      res.status(500).json({
        success: false,
        creator: "ZenzzXD",
        message: 'Failed to fetch data from Aptoide API.',
        error: error.message,
      });
    }
  });
};
