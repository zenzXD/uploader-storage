const fetch = require('node-fetch')

module.exports = function (app) {
  app.get('/ai/text2img', async (req, res) => {
    try {
      const { prompt } = req.query

      if (!prompt) {
        return res.status(400).json({
          status: false,
          creator: 'ZenzzXD',
          message: 'prompt harus diisi'
        })
      }

      const apiUrl = `https://flowfalcon.dpdns.org/ai/kivotos?prompt=${encodeURIComponent(prompt)}`

      const response = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0'
        }
      })

      if (!response.ok) {
        return res.status(response.status).json({
          status: false,
          creator: 'ZenzzXD',
          message: `error: ${response.statusText}`
        })
      }

      res.setHeader('Content-Type', response.headers.get('content-type') || 'image/png')
      response.body.pipe(res)
    } catch (err) {
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: err.message || 'Internal Server Error'
      })
    }
  })
}
