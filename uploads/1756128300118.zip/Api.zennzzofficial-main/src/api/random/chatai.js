const axios = require('axios');
const crypto = require('crypto');

// ===== GLOBAL SESSION MEMORY =====
global.chatUpAISessions = global.chatUpAISessions || new Map();

// ===== CHATUPAI MAIN OBJECT =====
const chatUpAI = {
  api: {
    base: 'https://api.appzone.tech',
    endpoint: '/v1/chat/completions'
  },
  headers: {
    authorization: 'Bearer az-chatai-key',
    'content-type': 'application/json',
    'user-agent': 'okhttp/4.9.2',
    'x-app-version': '3.0',
    'x-requested-with': 'XMLHttpRequest',
    'x-user-id': '$RCAnonymousID:84947a7a4141450385bfd07a66c3b5c4'
  },
  sessions: global.chatUpAISessions,
  generateId: () => crypto.randomBytes(8).toString('hex'),
  config: { maxMessages: 100, expiry: 3 * 60 * 60 * 1000 }, // 3 jam

  cleanupSessions: () => {
    const now = Date.now();
    for (const [id, session] of chatUpAI.sessions) {
      if (now - session.lastActive > chatUpAI.config.expiry) {
        chatUpAI.sessions.delete(id);
      }
    }
  },

  sanitizeResponse: (text) => {
    // Hilangkan <think>...</think>
    let cleanText = text.replace(/<think>[\s\S]*?<\/think>/gi, '');
    // Ganti {current_time} ke waktu realtime
    const now = new Date();
    const currentTime = now.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' });
    cleanText = cleanText.replace(/\{current_time\}/g, currentTime);
    return cleanText.trim();
  },

  chat: async (input, sessionId, retry = 0) => {
    if (!input?.trim()) {
      return { success: false, code: 400, result: { error: "Input kosong" } };
    }
    if (!sessionId || !chatUpAI.sessions.has(sessionId)) {
      return { success: false, code: 400, result: { error: "Session tidak ditemukan atau sudah expired" } };
    }

    try {
      const session = chatUpAI.sessions.get(sessionId);
      const preMsg = session.messages || [];
      const rolePrompt = session.role || null;
      const messages = [];

      if (rolePrompt) messages.push({ role: "system", content: rolePrompt });
      messages.push(...preMsg, { role: "user", content: input });

      const response = await axios.post(
        chatUpAI.api.base + chatUpAI.api.endpoint,
        {
          messages: messages.map(m => ({
            role: m.role,
            content: [{ type: "text", text: m.content }]
          })),
          model: "gpt-4.1",
          isSubscribed: true
        },
        { headers: chatUpAI.headers }
      );

      let fullText = '';
      const lines = response.data.split('\n\n').map(line => line.replace(/^data:\s*/, ''));
      for (const line of lines) {
        if (line.trim() === '[DONE]') continue;
        try {
          const d = JSON.parse(line);
          if (d.choices && d.choices[0].delta && d.choices[0].delta.content) {
            fullText += d.choices[0].delta.content;
          }
        } catch (err) { }
      }

      const cleanOutput = chatUpAI.sanitizeResponse(fullText);

      const asm = { role: "assistant", content: cleanOutput, timestamp: Date.now() };
      const ups = [...preMsg, { role: "user", content: input }, asm];

      chatUpAI.sessions.set(sessionId, {
        role: session.role,
        messages: ups.slice(-chatUpAI.config.maxMessages),
        lastActive: Date.now()
      });

      chatUpAI.cleanupSessions();

      return {
        success: true,
        code: 200,
        result: asm.content,
        sessionId,
        sessionExpiry: new Date(Date.now() + chatUpAI.config.expiry).toISOString(),
        messageCount: { current: ups.length, max: chatUpAI.config.maxMessages }
      };

    } catch (err) {
      if (err.response?.status === 429 && retry < 3) {
        // Auto retry jika kena rate limit
        await new Promise(resolve => setTimeout(resolve, 1000));
        return chatUpAI.chat(input, sessionId, retry + 1);
      }
      return {
        success: false,
        code: err.response?.status || 500,
        result: { error: err.message }
      };
    }
  }
};

// ===== EXPRESS ROUTES =====
module.exports = function (app) {
  const creator = "ZenzzXD";

  // Create Session
  app.get('/ai/chatai/create', (req, res) => {
    const { role } = req.query;
    const sessionId = chatUpAI.generateId();

    chatUpAI.sessions.set(sessionId, {
      role: role || null,
      messages: [],
      lastActive: Date.now()
    });

    res.json({
      success: true,
      creator,
      sessionId,
      message: "Sesi AI berhasil dibuat",
      role
    });
  });

  // Chat
  app.get('/ai/chatai/chat', async (req, res) => {
    const { text, sessionId } = req.query;
    if (!text || !sessionId) {
      return res.status(400).json({
        success: false,
        creator,
        result: { error: "Parameter 'text' dan 'sessionId' wajib diisi" }
      });
    }

    const result = await chatUpAI.chat(text, sessionId);
    res.status(result.code).json({ ...result, creator });
  });

  // Delete Session
  app.get('/ai/chatai/delete', (req, res) => {
    const { sessionId } = req.query;
    if (!sessionId) {
      return res.status(400).json({
        success: false,
        creator,
        result: { error: "Parameter 'sessionId' wajib diisi" }
      });
    }
    const deleted = chatUpAI.sessions.delete(sessionId);
    res.json({
      success: deleted,
      creator,
      message: deleted ? "Session berhasil dihapus." : "Session tidak ditemukan."
    });
  });

  // Clear Chat Only (Keep Role)
  app.get('/ai/chatai/clear', (req, res) => {
    const { sessionId } = req.query;
    if (!sessionId || !chatUpAI.sessions.has(sessionId)) {
      return res.status(400).json({
        success: false,
        creator,
        result: { error: "Session tidak ditemukan atau parameter kosong" }
      });
    }
    const session = chatUpAI.sessions.get(sessionId);
    session.messages = [];
    session.lastActive = Date.now();
    chatUpAI.sessions.set(sessionId, session);

    res.json({
      success: true,
      creator,
      message: "Riwayat chat telah dibersihkan, role tetap disimpan."
    });
  });
};
