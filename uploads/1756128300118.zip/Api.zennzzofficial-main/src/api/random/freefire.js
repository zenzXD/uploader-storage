const axios = require('axios');
const moment = require('moment');

/**
 * Ambil data akun Free Fire berdasarkan UID
 * @param {string} uid
 * @returns {Promise<object|null>}
 */
async function FFAcount(uid) {
  const url = `https://discordbot.freefirecommunity.com/player_info_api?uid=${uid}&region=id`;

  try {
    const res = await axios.get(url, {
      headers: {
        'Origin': 'https://www.freefirecommunity.com',
        'Referer': 'https://www.freefirecommunity.com/ff-account-info/',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K)',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, br'
      }
    });

    const d = res.data.player_info || {};
    const b = d.basicInfo || {};
    const c = d.creditScoreInfo || {};
    const p = d.petInfo || {};
    const prof = d.profileInfo || {};
    const s = d.socialInfo || {};

    const safe = (val, fallback = 'N/A') => val !== undefined && val !== null ? val : fallback;
    const formatTime = (unix) => unix ? moment.unix(unix).format('YYYY-MM-DD HH:mm:ss') : 'N/A';

    return {
      creator: "ZenzzXD",
      account: {
        nickname: safe(b.nickname),
        accountId: safe(b.accountId),
        region: safe(b.region),
        level: safe(b.level),
        likes: safe(b.liked),
        rank: safe(b.rank),
        maxRank: safe(b.maxRank),
        csRank: safe(b.csRank),
        exp: safe(b.exp),
        createdAt: formatTime(b.createAt),
        lastLogin: formatTime(b.lastLoginAt),
        rankingPoints: safe(b.rankingPoints),
        releaseVersion: safe(b.releaseVersion),
        seasonId: safe(b.seasonId),
        primeLevel: safe(b.primeLevel?.level, '-'),
        diamondCost: safe(d.diamondCostRes?.diamondCost, '-')
      },
      pet: {
        name: safe(p.name, '-'),
        level: safe(p.level, '-'),
        exp: safe(p.exp, '-'),
        skinId: safe(p.skinId, '-'),
        selectedSkillId: safe(p.selectedSkillId, '-')
      },
      profile: {
        avatarId: safe(prof.avatarId),
        clothes: Array.isArray(prof.clothes) ? prof.clothes : [],
        equippedSkills: Array.isArray(prof.equipedSkills) ? prof.equipedSkills : []
      },
      social: {
        battleTags: Array.isArray(s.battleTag) ? s.battleTag.map((tag, i) => ({
          tag,
          count: s.battleTagCount?.[i] || 0
        })) : [],
        language: safe(s.language),
        rankShow: safe(s.rankShow),
        signature: safe(s.signature)
      },
      creditScore: {
        score: safe(c.creditScore),
        rewardState: safe(c.rewardState)
      },
      images: {
        bannerImage: `https://discordbot.freefirecommunity.com/banner_image_api?uid=${uid}&region=id`,
        outfitImage: `https://discordbot.freefirecommunity.com/outfit_image_api?uid=${uid}&region=id`
      }
    };
  } catch (e) {
    console.error('[FREEFIRE STALK ERROR]', e.message);
    return null;
  }
}

module.exports = function (app) {
  /**
   * GET /stalker/freefire?uid=1215124144
   */
  app.get('/stalker/freefire', async (req, res) => {
    const uid = req.query.uid;

    if (!uid || isNaN(uid)) {
      return res.status(400).json({
        success: false,
        creator: "ZenzzXD",
        message: 'Parameter "uid" harus diisi'
      });
    }

    const data = await FFAcount(uid);

    if (!data) {
      return res.status(404).json({
        success: false,
        creator: "ZenzzXD",
        message: `Data akun dengan UID "${uid}" tidak ditemukan atau gagal diambil.`
      });
    }

    res.json({
      success: true,
      creator: "ZenzzXD",
      uid,
      data
    });
  });
};
