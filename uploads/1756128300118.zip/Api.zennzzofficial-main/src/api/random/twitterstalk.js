const axios = require("axios");
const { CookieJar } = require("tough-cookie");
const { wrapper } = require("axios-cookiejar-support");

class Twitter {
  constructor(username) {
    this.username = username;
  }

  flatten(tweet) {
    const { user, ...rest } = tweet;
    const flatUser = {};
    if (user && typeof user === "object") {
      for (const key in user) {
        flatUser[`user_${key}`] = user[key];
      }
    }
    return { ...rest, ...flatUser };
  }

  async stalkNow() {
    const jar = new CookieJar();
    const client = wrapper(
      axios.create({
        jar,
        withCredentials: true,
        timeout: 7000, // timeout scraping 7 detik
      })
    );

    // Init session
    await client.get("https://twitterviewer.net");

    const dataBody = { username: this.username };
    const headers = {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    };

    // Fetch user data
    const { data } = await client.post(
      "https://twitterviewer.net/api/get-user",
      dataBody,
      headers
    );

    // Fetch user tweets
    const { data: tweetsRes } = await client.post(
      "https://twitterviewer.net/api/get-user-tweets",
      dataBody,
      headers
    );

    return {
      ...data,
      tweets: tweetsRes.tweets.map(this.flatten),
    };
  }

  async fallbackAPI() {
    // Public API fallback (vxtwitter)
    const res = await axios.get(`https://api.vxtwitter.com/${this.username}`, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        Accept: "application/json",
      },
      timeout: 5000,
    });
    const data = res.data;
    return {
      id: data.id,
      name: data.name,
      username: data.screen_name,
      description: data.description,
      followers_count: data.followers_count,
      following_count: data.friends_count,
      tweet_count: data.statuses_count,
      profile_image_url: data.profile_image_url_https,
      created_at: data.created_at,
      tweets: [], // fallback tanpa tweet detail
    };
  }
}

module.exports = function (app) {
  app.get("/stalker/twitter", async (req, res) => {
    const username = req.query.username;

    if (!username) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'username' harus diisi",
      });
    }

    try {
      const twitter = new Twitter(username);

      let profileData;
      try {
        // 🕵️‍♂️ Try scrape
        profileData = await twitter.stalkNow();
      } catch (scrapeErr) {
        console.warn("[SCRAPE FAIL] Fallback ke API →", scrapeErr.message);
        // 📥 Fallback ke API
        profileData = await twitter.fallbackAPI();
      }

      res.json({
        status: true,
        creator: "ZenzzXD",
        data: profileData,
      });
    } catch (err) {
      console.error("[Twitter Stalk ERROR]", err.message);
      res.status(500).json({
        status: false,
        message: "Gagal mengambil data Twitter.",
        error: err.message,
      });
    }
  });
};
