const axios = require('axios');
const FormData = require('form-data');

async function JHLoveFSwap(sourceUrl, targetUrl) {
  const getBuffer = async (url) =>
    (await axios.get(url, { responseType: 'arraybuffer' })).data;

  const randomName = () => `Fiony_${Math.random().toString(36).substring(2, 10)}.jpg`;

  try {
    const sourceImg = await getBuffer(sourceUrl);
    const targetImg = await getBuffer(targetUrl);

    const form = new FormData();
    form.append("source_image", sourceImg, randomName());
    form.append("target_image", targetImg, randomName());

    const headers = {
      ...form.getHeaders(),
      accept: "application/json",
      Referer: "https://lovefaceswap.com/"
    };

    const createRes = await axios.post(
      "https://api.lovefaceswap.com/api/face-swap/create-poll",
      form,
      { headers }
    );

    const jobId = createRes.data?.data?.task_id;
    if (!jobId) throw new Error("Job ID not found");

    const start = Date.now();
    const maxTime = 300000;

    while (Date.now() - start < maxTime) {
      const statusRes = await axios.get(
        `https://api.lovefaceswap.com/api/face-swap/get?job_id=${jobId}`,
        { headers }
      );

      const code = statusRes.data?.code;
      if (code === 200) {
        const url = statusRes.data?.data?.image_url?.[0];
        const duration = ((Date.now() - start) / 1000).toFixed(2);
        return {
          status: true,
          creator: "ZenzzXD",
          image: url,
          job_id: jobId,
          duration: `${duration}s`
        };
      }

      if (code !== 202) {
        throw new Error("Unexpected response: " + JSON.stringify(statusRes.data));
      }

      await new Promise((r) => setTimeout(r, 2000));
    }

    return {
      status: false,
      creator: "ZenzzXD",
      job_id: jobId,
      message: "Task timeout (lebih dari 5 menit), mungkin wajah terlalu burik 🤭"
    };

  } catch (e) {
    const detail = e.response?.data || e.message;
    return {
      status: false,
      creator: "ZenzzXD",
      error: typeof detail === "string" ? detail : JSON.stringify(detail, null, 2)
    };
  }
}

module.exports = function (app) {
  app.get('/ai/faceswap', async (req, res) => {
    const { source, target } = req.query;

    if (!source || !target) {
      return res.status(400).json({
        status: false,
        creator: "ZenzzXD",
        message: "Parameter 'source' dan 'target' harus diisi (URL gambar)"
      });
    }

    const result = await JHLoveFSwap(source, target);
    res.json(result);
  });
};
