const axios = require('axios');
const cheerio = require('cheerio');
const qs = require('qs');

// === Scraper Douyin (via TikVideo.app) ===
async function douyin(url) {
  const postData = qs.stringify({
    q: url,
    lang: 'id',
    cftoken: ''
  });

  try {
    const response = await axios.post(
      'https://tikvideo.app/api/ajaxSearch',
      postData,
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Accept': '*/*',
          'X-Requested-With': 'XMLHttpRequest'
        }
      }
    );

    if (response.data.status === 'ok') {
      const html = response.data.data;
      const $ = cheerio.load(html);
      const results = [];

      $('.tik-video').each((i, elem) => {
        const title = $(elem).find('.thumbnail .content h3').text().trim();
        const duration = $(elem).find('.thumbnail .content p').first().text().trim();
        const thumbnail = $(elem).find('.thumbnail img').attr('src');

        const downloadLinks = [];
        $(elem).find('.dl-action a').each((j, link) => {
          downloadLinks.push({
            label: $(link).text().trim(),
            url: $(link).attr('href')
          });
        });

        results.push({ title, duration, thumbnail, downloadLinks });
      });

      return results;
    } else {
      throw new Error(`Gagal mendapatkan data dari server TikVideo`);
    }
  } catch (error) {
    throw new Error(error.message || 'Gagal mengambil data dari Douyin');
  }
}

// === Route Express: /downloader/douyin ===
module.exports = function (app) {
  app.get('/downloader/douyin', async (req, res) => {
    const { url } = req.query;

    if (!url || !/^https?:\/\/(www\.)?(v\.douyin\.com|douyin\.com)\//.test(url)) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter "url" tidak valid atau tidak ditemukan'
      });
    }

    try {
      const result = await douyin(url);

      if (!result.length) {
        return res.status(404).json({
          status: false,
          creator: 'ZenzzXD',
          message: 'Data tidak ditemukan atau link tidak valid'
        });
      }

      return res.json({
        status: true,
        creator: 'ZenzzXD',
        data: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: err.message
      });
    }
  });
};
