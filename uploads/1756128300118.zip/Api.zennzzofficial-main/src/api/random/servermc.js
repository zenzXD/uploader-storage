/*
By Fruatre
wa.me/6285817597752
Saluran : https://whatsapp.com/channel/0029VaNR2B6BadmioY6mar3N
*/

const fetch = require('node-fetch');

// Fungsi cek status server Minecraft (return JSON object)
async function cekStatusServerMC(addr, port) {
    if (!addr) return { error: 'Masukkan address dan port' };

    let fos = addr + (port ? ':' + port : '');
    let resmcser = await fetch('https://api.mcsrvstat.us/bedrock/3/' + fos);
    let omcser = await resmcser.json();

    if (!omcser.online) {
        return {
            status: false,
            error: omcser.debug?.error?.bedrock || 'Server Offline'
        };
    }

    return {
        status: true,
        ip: omcser.ip,
        port: omcser.port,
        hostname: omcser.hostname || null,
        version: omcser.version || null,
        software: omcser.software || null,
        map: omcser.map || null,
        players: {
            online: omcser.players.online,
            max: omcser.players.max,
            list: omcser.players.list || []
        },
        plugins: omcser.plugins || []
    };
}

// Route Express
module.exports = function (app) {
    app.get('/stalker/servermc', async (req, res) => {
        let { addr, port } = req.query;

        if (!addr) {
            return res.json({
                status: false,
                creator: 'ZenzzXD',
                message: 'Masukkan query ?addr=ip&port=port'
            });
        }

        try {
            let result = await cekStatusServerMC(addr, port);
            if (result.error) {
                return res.json({
                    status: false,
                    creator: 'ZenzzXD',
                    message: result.error
                });
            }

            res.json({
                status: true,
                creator: 'ZenzzXD',
                result
            });
        } catch (err) {
            res.json({
                status: false,
                creator: 'ZenzzXD',
                message: 'Terjadi kesalahan saat mengambil data',
                error: err.message
            });
        }
    });
};
