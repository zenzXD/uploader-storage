const axios = require('axios');

module.exports = function (app) {
  app.get('/maker/tosdmtinggi', async (req, res) => {
    const imageUrl = req.query.url;

    if (!imageUrl) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter ?url= harus diisi',
      });
    }

    try {
      const promptText = `Edit this photo with the following steps:
1. Remove the background entirely.
2. Replace the background with solid red color (#FF0000).
3. Convert the main subject to black and white (grayscale).
4. Add a thick black censor bar over the eyes (horizontal).`;

      // Call API fasturl.link
      const apiUrl = `https://api.fasturl.link/aiimage/gemini?prompt=${encodeURIComponent(
        promptText
      )}&imageUrl=${encodeURIComponent(imageUrl)}`;

      const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

      // Return result image
      res.setHeader('Content-Type', 'image/png');
      res.send(response.data);
    } catch (err) {
      console.error('tosdmtinggi Error:', err?.response?.data || err.message);
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Terjadi kesalahan saat memproses gambar',
        error: err?.message || String(err),
      });
    }
  });
};
