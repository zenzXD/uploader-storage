const axios = require('axios');

async function npmstalk(packageName) {
  const stalk = await axios.get(`https://registry.npmjs.org/${packageName}`);
  const versions = stalk.data.versions;
  const allver = Object.keys(versions);
  const verLatest = allver[allver.length - 1];
  const verPublish = allver[0];
  const packageLatest = versions[verLatest] || {};
  const packagePublish = versions[verPublish] || {};
  return {
    name: packageName,
    versionLatest: verLatest,
    versionPublish: verPublish,
    versionUpdate: allver.length,
    latestDependencies: Object.keys(packageLatest.dependencies || {}).length,
    publishDependencies: Object.keys(packagePublish.dependencies || {}).length,
    publishTime: stalk.data.time.created,
    latestPublishTime: stalk.data.time[verLatest]
  };
}

module.exports = function (app) {
  app.get('/stalker/npmstalk', async (req, res) => {
    const creator = 'ZenzzXD';
    const packageName = req.query.namepackage;

    if (!packageName) {
      return res.status(400).json({
        status: false,
        creator,
        message: 'Parameter ?namepackage= harus diisi'
      });
    }

    try {
      const result = await npmstalk(packageName);
      res.json({
        status: true,
        creator,
        result: {
          name: result.name,
          version_latest: result.versionLatest,
          version_publish: result.versionPublish,
          total_release: result.versionUpdate,
          dependencies_first: result.publishDependencies,
          dependencies_latest: result.latestDependencies,
          publish_time: result.publishTime,
          latest_publish_time: result.latestPublishTime
        }
      });
    } catch (e) {
      console.error('npmstalk error:', e.message);
      res.status(404).json({
        status: false,
        creator,
        message: 'Package tidak ditemukan atau error.'
      });
    }
  });
};
