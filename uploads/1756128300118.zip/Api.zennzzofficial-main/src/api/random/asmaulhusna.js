const axios = require('axios');

async function getAsmaulHusna(id = 1) {
  try {
    const url = `https://cloudku.us.kg/api/murotal/husna?id=${id}`;
    const { data } = await axios.get(url);

    if (data.status !== 'success' || !data.result) {
      return {
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal mengambil data Asmaul Husna'
      };
    }

    return {
      status: true,
      creator: 'ZenzzXD',
      asmaulhusna: data.result
    };
  } catch (e) {
    return {
      status: false,
      creator: 'ZenzzXD',
      message: 'Terjadi kesalahan saat mengambil data',
      error: e.message
    };
  }
}

module.exports = function (app) {
  app.get('/islam/asmaulhusna', async (req, res) => {
    const id = parseInt(req.query.id) || 1;

    const result = await getAsmaulHusna(id);
    res.json(result);
  });
};
