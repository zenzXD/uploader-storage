const axios = require('axios');

async function getTikTokTrending(region = 'ID') {
  const url = 'https://tikwm.com/api/feed/list';

  try {
    const response = await axios.post(
      url,
      {
        count: 20,
        hd: 1,
        region: region.toUpperCase()
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0' // ✅ Diperbaiki di sini
        },
        timeout: 10000
      }
    );

    if (response.data.code !== 0) {
      return {
        success: false,
        error: response.data.msg || 'Unknown API error'
      };
    }

    const trendingVideos = response.data.data.map(video => ({
      id: video.id,
      region: video.region,
      title: video.title,
      duration: video.duration,
      play_url: video.play,
      stats: {
        views: video.play_count,
        likes: video.digg_count,
        comments: video.comment_count,
        shares: video.share_count,
        downloads: video.download_count
      },
      author: {
        user_id: video.author.id,
        username: video.author.unique_id,
        nickname: video.author.nickname
      },
      cover_url: video.cover,
      created_at: video.create_time
    }));

    return {
      success: true,
      data: trendingVideos
    };

  } catch (error) {
    console.error('TikTok Trending Error:', error.message);
    return {
      success: false,
      error: error.message,
      response: error.response?.data
    };
  }
}

module.exports = function (app) {
  app.get('/search/tiktoktrending', async (req, res) => {
    const { region } = req.query;
    const result = await getTikTokTrending(region);

    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: result.error
      });
    }
  });
};
