const axios = require('axios');

module.exports = function (app) {
    async function randomMeme() {
        try {
            // Ambil list dari repo
            const { data } = await axios.get(
                'https://raw.githubusercontent.com/KazukoGans/database/refs/heads/main/meme/darkjoke.json'
            );

            // Pilih random URL
            return data[Math.floor(Math.random() * data.length)];
        } catch (error) {
            throw error;
        }
    }

    app.get('/random/meme', async (req, res) => {
        try {
            const randomUrl = await randomMeme();

            // kalau ?json=true → balikin url
            if (req.query.json === 'true') {
                return res.json({ url: randomUrl });
            }

            // kalau engga → langsung stream gambar
            const response = await axios.get(randomUrl, { responseType: 'arraybuffer' });
            res.writeHead(200, {
                'Content-Type': response.headers['content-type'] || 'image/jpeg',
                'Content-Length': response.data.length
            });
            res.end(response.data);
        } catch (error) {
            console.error('❌ Error:', error.message);
            res.status(500).send(`Error: ${error.message}`);
        }
    });
};
