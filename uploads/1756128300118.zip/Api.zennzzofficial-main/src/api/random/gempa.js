const fetch = require('node-fetch');

const getInfoGempa = async () => {
    const res = await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json');
    const json = await res.json();
    const data = json.Infogempa.gempa;

    return {
        waktu: data.DateTime,
        coordinates: data.Coordinates,
        magnitude: data.Magnitude,
        kedalaman: data.Kedalaman,
        wilayah: data.Wilayah,
        potensi: data.Potensi,
        shakemap: `https://data.bmkg.go.id/DataMKG/TEWS/${data.Shakemap}`
    };
};

module.exports = function (app) {
    app.get('/info/gempa', async (req, res) => {
        try {
            const info = await getInfoGempa();
            res.json({
                status: true,
                creator: "ZenzzXD",
                data: info
            });
        } catch (err) {
            res.status(500).json({
                status: false,
                creator: "ZenzzXD",
                message: "Gagal mengambil data gempa",
                error: err.message
            });
        }
    });
};
