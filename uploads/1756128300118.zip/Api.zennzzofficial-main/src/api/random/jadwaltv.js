const axios = require('axios');
const cheerio = require('cheerio');

async function getJadwalTV(channel) {
  try {
    const url = `https://www.jadwaltv.net/channel/${channel.toLowerCase()}`;
    const res = await axios.get(url);
    const $ = cheerio.load(res.data);

    const jadwal = [];
    $('table tbody tr').each((i, el) => {
      const jam = $(el).find('td').eq(0).text().trim();
      const acara = $(el).find('td').eq(1).text().trim();

      // Filter baris promosi & header tabel
      if (
        jam &&
        acara &&
        jam.toLowerCase() !== 'jam' &&
        acara.toLowerCase() !== 'acara' &&
        !/jadwal tv selengkapnya/i.test(acara)
      ) {
        jadwal.push({ time: jam, program: acara });
      }
    });

    if (!jadwal.length) {
      return {
        status: false,
        creator: 'ZenzzXD',
        message: `Channel "${channel}" tidak ditemukan atau tidak ada jadwalnya.`
      };
    }

    return {
      status: true,
      creator: 'ZenzzXD',
      channel: channel.toUpperCase(),
      jadwal
    };

  } catch (err) {
    console.error(err.message);
    return {
      status: false,
      creator: 'ZenzzXD',
      message: 'Gagal mengambil data.'
    };
  }
}

module.exports = function (app) {
  app.get('/info/jadwaltv', async (req, res) => {
    const channel = req.query.channel;
    if (!channel) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter ?channel= harus diisi'
      });
    }

    const result = await getJadwalTV(channel);
    res.json(result);
  });
};
