const axios = require('axios');

module.exports = function (app) {
    app.get('/stalker/github', async (req, res) => {
        const user = req.query.user;
        if (!user) {
            return res.status(400).json({
                status: false,
                creator: 'ZenzzXD',
                message: 'Parameter ?user= harus diisi'
            });
        }

        try {
            const { data } = await axios.get('https://api.github.com/users/' + user);

            const result = {
                status: true,
                creator: 'ZenzzXD',
                message: {
                    username: data.login || 'gaada wok',
                    nickname: data.name || 'gaada wok',
                    bio: data.bio || 'gaada wok',
                    id: data.id || 'gaada wok',
                    nodeId: data.node_id || 'gaada wok',
                    profile_pic: data.avatar_url || 'gaada wok',
                    url: data.html_url || 'gaada wok',
                    type: data.type || 'gaada wok',
                    admin: data.site_admin ? 'Ya' : 'Tidak',
                    company: data.company || 'gaada wok',
                    blog: data.blog || 'gaada wok',
                    location: data.location || 'gaada wok',
                    email: data.email || 'gaada wok',
                    public_repo: data.public_repos || 0,
                    public_gists: data.public_gists || 0,
                    followers: data.followers || 0,
                    following: data.following || 0,
                    created_at: data.created_at || 'gaada wok',
                    updated_at: data.updated_at || 'gaada wok'
                }
            };

            res.json(result);
        } catch (err) {
            res.status(404).json({
                status: false,
                creator: 'ZenzzXD',
                message: 'User tidak ditemukan atau error'
            });
        }
    });
};
