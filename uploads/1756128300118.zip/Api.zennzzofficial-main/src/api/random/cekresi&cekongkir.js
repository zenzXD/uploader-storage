// ✨ Tools Cek Resi & Ongkir by Loman API
// 👤 Creator: ZenzzXD

const axios = require('axios');
const qs = require('qs');

const loman = {
  api: {
    base: 'https://loman.id/resapp',
    locations: 'https://loeman.loman.id',
    endpoints: {
      getCouriers: '/getdropdown.php',
      track: '/',
      searchLocation: '?cari=',
      calculateShipping: '/'
    }
  },

  headers: {
    'user-agent': 'Postify/1.0.0',
    'content-type': 'application/x-www-form-urlencoded'
  },

  ntext(text) {
    return text.toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]/g, '')
      .replace(/\s+/g, '');
  },

  async searchLocation(query) {
    try {
      const res = await axios.get(`${this.api.locations}${this.api.endpoints.searchLocation}${encodeURIComponent(query)}`, {
        headers: this.headers, timeout: 5000
      });
      if (!Array.isArray(res.data) || !res.data.length) {
        return { success: false, code: 404 };
      }
      return {
        success: true, code: 200,
        result: res.data.map(x => ({
          id: x.id, name: x.nama, normalized: this.ntext(x.nama)
        }))
      };
    } catch {
      return { success: false, code: 500 };
    }
  },

  async findLocationId(name) {
    const s = await this.searchLocation(name);
    if (!s.success) return null;
    const n = this.ntext(name);
    return s.result.find(x => x.normalized === n)?.id || s.result[0]?.id || null;
  },

  async getCourierList() {
    try {
      const res = await axios.get(`${this.api.base}${this.api.endpoints.getCouriers}`, {
        headers: this.headers, timeout: 5000
      });
      if (res.data?.status !== 'berhasil') return { success: false };
      return {
        success: true,
        result: res.data.data.map(x => ({
          name: x.title,
          normalized: this.ntext(x.title)
        }))
      };
    } catch {
      return { success: false };
    }
  },

  async track(resi, ekspedisi) {
    const couriers = await this.getCourierList();
    if (!couriers.success) return { success: false, message: 'Gagal ambil data kurir' };
    const key = this.ntext(ekspedisi);
    const match = couriers.result.find(c => c.normalized.includes(key));
    if (!match) {
      return {
        success: false,
        message: `Kurir "${ekspedisi}" gak ketemu`,
        couriers: couriers.result.map(c => c.name)
      };
    }

    const data = qs.stringify({ resi, ex: match.name });
    try {
      const res = await axios.post(`${this.api.base}${this.api.endpoints.track}`, data, {
        headers: this.headers, timeout: 10000
      });
      if (res.data?.status !== 'berhasil') return { success: false, message: 'Tracking gagal' };
      return {
        success: true,
        result: {
          resi,
          ekspedisi: match.name,
          status: res.data.details?.status || '',
          message: res.data.details?.infopengiriman || '',
          history: res.data.history?.map(x => ({
            waktu: x.tanggal,
            keterangan: x.details
          })) || []
        }
      };
    } catch {
      return { success: false, message: 'Error saat tracking' };
    }
  },

  async calculateShippingByCity(asal, tujuan, berat) {
    const [idAsal, idTujuan] = await Promise.all([
      this.findLocationId(asal), this.findLocationId(tujuan)
    ]);
    if (!idAsal || !idTujuan) return { success: false, message: 'ID lokasi tidak ditemukan' };

    const data = qs.stringify({ idAsal, idTujuan, berat });
    try {
      const res = await axios.post(`${this.api.locations}${this.api.endpoints.calculateShipping}`, data, {
        headers: this.headers, timeout: 10000
      });
      if (res.data?.status !== 'berhasil') return { success: false, message: 'Gagal hitung ongkir' };

      return {
        success: true,
        result: {
          route: res.data.detail,
          couriers: res.data.data?.map(c => ({
            name: c.ekspedisi,
            services: c.daftarHarga?.map(s => ({
              service: s.service,
              price: s.harga,
              desc: s.description,
              estimate: s.estimasi
            }))
          }))
        }
      };
    } catch {
      return { success: false, message: 'Error saat hitung ongkir' };
    }
  }
};

module.exports = function (app) {
  // 📦 Route cek resi
  app.get('/tools/cekresi', async (req, res) => {
    const { noresi, ekspedisi } = req.query;
    if (!noresi || !ekspedisi) {
      return res.status(400).json({
        creator: 'ZenzzXD',
        success: false,
        message: 'noresi & ekspedisi diperlukan'
      });
    }

    const result = await loman.track(noresi, ekspedisi);
    res.json({ creator: 'ZenzzXD', ...result });
  });

  // 🚚 Route cek ongkir
  app.get('/tools/cekongkir', async (req, res) => {
    const { asal, tujuan, berat } = req.query;
    if (!asal || !tujuan || !berat) {
      return res.status(400).json({
        creator: 'ZenzzXD',
        success: false,
        message: 'asal, tujuan & berat diperlukan'
      });
    }

    const result = await loman.calculateShippingByCity(asal, tujuan, berat);
    res.json({ creator: 'ZenzzXD', ...result });
  });
};
