/*
  base   : https://convert.ytmp3.wf
  fitur  : download audio (mp3 128kbps) & video (mp4 1080p)
  node   : v24.5.0
  update : 23 agustus 2025 (fix gzip/zstd)
  by     : wolep
*/

const fetch = require("node-fetch")

const yt = {
    get url() {
        return {
            origin: 'https://convert.ytmp3.wf',
        }
    },

    get randomCookie() {
        const length = 26
        const charset = '0123456789abcdefghijklmnopqrstuvwxyz'
        const charsetArray = charset.split("")
        const pickRandom = (array) => array[Math.floor(Math.random() * array.length)]
        const result = Array.from({ length }, _ => pickRandom(charsetArray)).join("")
        return result
    },

    formatHandling(userFormat) {
        const validFormat = ['audio', 'best_video', '144p', '240p', '360p', '480p', '720p', '1080p', '1440p', '2160p']
        if (!validFormat.includes(userFormat)) throw Error(`invalid format!. available format: ${validFormat.join(', ')}`)
        let isVideo = false, quality = null
        if (userFormat != 'audio') {
            isVideo = true
            if (userFormat == 'best_video') {
                quality = '10000'
            } else {
                quality = userFormat.match(/\d+/)[0]
            }
        }
        return { isVideo, quality }
    },

    async download(youtubeUrl, userFormat = 'audio') {
        const f = this.formatHandling(userFormat)
        const pathButton = f.isVideo ? '/vidbutton/' : '/button/'
        const pathConvert = f.isVideo ? '/vidconvert/' : '/convert/'

        const cookie = `PHPSESSID=${this.randomCookie}`
        const headers = {
            "accept-encoding": "gzip, deflate, br", // FIX: hapus zstd
            "cookie": cookie,
            "referer": this.url.origin,
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }

        const hit = async (method, path, body, returnType = 'text') => {
            try {
                const url = `${this.url.origin}${path}`
                const opts = { method, body, headers }
                const r = await fetch(url, opts)
                const raw = await r.text() // ambil raw dulu

                if (!r.ok) throw Error(`${r.status} ${r.statusText}\n${raw}`)

                return returnType == "json" ? JSON.parse(raw) : raw
            } catch (e) {
                throw Error(`gagal hit ${path}. karena ${e.message}`)
            }
        }

        // step 1
        const html = await hit('get', `${pathButton}?url=${youtubeUrl}`)
        let m1 = html.match(/data: (.+?)\n\t\t\t\tsuccess/ms)?.[1].replace('},', '}').trim()
        if (f.isVideo) m1 = m1.replace(`$('#height').val()`, f.quality)
        const payload = eval("(" + m1 + ")")

        // step 2
        headers.referer = `${this.url.origin}${pathButton}?url=${youtubeUrl}`
        headers.origin = this.url.origin
        headers["x-requested-with"] = "XMLHttpRequest"
        const j2 = await hit('post', pathConvert, new URLSearchParams(payload), 'json')

        // step 3 (progress loop)
        let j3, fetchCount = 0
        const MAX_FETCH_ATTEMPT = 60
        do {
            fetchCount++
            j3 = await hit('get', `${pathConvert}?jobid=${j2.jobid}&time=${Date.now()}`, null, 'json')
            if (j3.dlurl) return j3
            if (j3.error) throw Error(`oops.. ada kesalahan nih.\n${JSON.stringify(j3, null, 2)}`)
            await new Promise(r => setTimeout(r, 3000))
        } while (fetchCount < MAX_FETCH_ATTEMPT)

        throw Error(`mencapai maksimal limit fetch`)
    }
}

// Export untuk Express
module.exports = function (app) {
    // MP4 (1080p)
    app.get("/downloader/yt4", async (req, res) => {
        try {
            const url = req.query.url
            if (!url) return res.status(400).json({ Creator: "ZenzzXD", error: "parameter url required" })
            const data = await yt.download(url, "1080p")
            res.json({ 
                status: true,
                format: "mp4", 
                quality: "1080p", 
                ...data 
            })
        } catch (e) {
            res.status(500).json({ Creator: "ZenzzXD", status: false, error: e.message })
        }
    })

    // MP3 (128kbps)
    app.get("/downloader/yt3", async (req, res) => {
        try {
            const url = req.query.url
            if (!url) return res.status(400).json({ Creator: "ZenzzXD", error: "parameter url required" })
            const data = await yt.download(url, "audio")
            res.json({ 
                status: true, 
                format: "mp3", 
                quality: "128kbps", 
                ...data 
            })
        } catch (e) {
            res.status(500).json({ Creator: "ZenzzXD", status: false, error: e.message })
        }
    })
            }
