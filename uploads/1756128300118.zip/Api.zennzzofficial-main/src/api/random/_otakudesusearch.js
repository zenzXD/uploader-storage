const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function (app) {
    // 🔍 Search Anime
    app.get('/anime/otakudesu/search', async (req, res) => {
        const query = req.query.q;
        if (!query) {
            return res.json({
                status: false,
                creator: "ZenzzXD",
                message: "Query parameter ?q= harus diisi!"
            });
        }

        const searchUrl = `https://otakudesu.cloud/?s=${encodeURIComponent(query)}&post_type=anime`;

        try {
            const { data } = await axios.get(searchUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
            });

            const $ = cheerio.load(data);
            const searchResults = [];

            const listItems = $('.chivsrc li');

            if (listItems.length === 0) {
                return res.json({
                    status: false,
                    creator: "ZenzzXD",
                    message: `Tidak menemukan data untuk kata kunci: "${query}"`
                });
            }

            listItems.each((_, el) => {
                const element = $(el);

                const title = element.find('h2 a').text().trim();
                const animeUrl = element.find('h2 a').attr('href');
                const imageUrl = element.find('img').attr('src');
                const status = element.find('.set:contains("Status")').text().replace('Status :', '').trim();
                const ratingText = element.find('.set:contains("Rating")').text().replace('Rating :', '').trim();
                const rating = parseFloat(ratingText) || null;

                const genres = [];
                element.find('.set:contains("Genres") a').each((_, genreEl) => {
                    genres.push($(genreEl).text().trim());
                });

                if (title && animeUrl && imageUrl) {
                    searchResults.push({
                        title,
                        url: animeUrl,
                        image: imageUrl,
                        genres,
                        status,
                        rating,
                    });
                }
            });

            res.json({
                status: true,
                creator: "ZenzzXD",
                result: searchResults
            });

        } catch (error) {
            let reason = "Failed to fetch or parse the search page.";
            if (error.response) {
                reason = `Request failed with status code ${error.response.status}`;
            }
            res.json({
                status: false,
                creator: "ZenzzXD",
                message: reason
            });
        }
    });
};
