const axios = require('axios');
const CryptoJS = require('crypto-js');

const tera = {
  download: async function (url) {
    try {
      const malas = await axios.get("https://api.yogik.id/tools/tcloudflare/?url=https://teradownloader.com/&siteKey=0x4AAAAAAAivEqKZjLXwt9uG");
      const data = malas.data.data;

      const expiresAt = Date.now() + 20000;
      const payload = JSON.stringify({
        token: url,
        turn: data.token,
        expiresAt
      });

      const encryptedPayload = CryptoJS.AES.encrypt(payload, "89javhk4q98adklajsdf09q34090934kjaslkjf").toString();

      const response = await axios.get("https://teradownloader.com/api", {
        params: { data: encryptedPayload },
        headers: {
          authority: "teradownloader.com",
          accept: "*/*",
          "accept-language": "ms-MY,ms;q=0.9,en-US;q=0.8,en;q=0.7",
          referer: "https://teradownloader.com/download",
          "sec-ch-ua": '"Not A(Brand";v="8", "Chromium";v="132"',
          "sec-ch-ua-mobile": "?1",
          "sec-ch-ua-platform": '"Android"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "same-origin",
          "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36"
        }
      });

      return {
        status: true,
        result: response.data
      };

    } catch (err) {
      console.error("[Terabox Scrape] Error:", err.message);
      return {
        status: false,
        message: "Scrape error: " + err.message
      };
    }
  }
};

module.exports = function (app) {
  app.get('/downloader/terabox', async (req, res) => {
    const { url } = req.query;

    if (!url || !url.startsWith('http')) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Masukkan parameter ?url= dengan link Terabox yang valid'
      });
    }

    try {
      // 🌟 Scrape utama
      const result = await tera.download(url);

      if (result.status && result.result?.download_url) {
        return res.json({
          status: true,
          creator: 'ZenzzXD',
          result: {
            filename: result.result.filename || 'unknown',
            size: result.result.size || 'unknown',
            thumb: result.result.thumbnail || null,
            direct_url: result.result.download_url,
            backup_url: result.result.backup_url || null
          }
        });
      } else {
        throw new Error('Scrape gagal atau tidak ada link unduhan');
      }

    } catch (err) {
      console.warn('[Terabox] Scrape gagal, fallback ke Yogik.id →', err.message);

      // 🚨 Fallback API
      try {
        const fallback = await axios.get(`https://api.yogik.id/downloader/terabox?url=${encodeURIComponent(url)}`);
        const data = fallback.data;

        if (!data.status || !data.data || data.data.length === 0) {
          return res.status(500).json({
            status: false,
            creator: 'ZenzzXD',
            message: 'tidak ada data',
            detail: data
          });
        }

        const item = data.data[0];

        return res.json({
          status: true,
          creator: 'ZenzzXD',
          result: {
            filename: item.server_filename,
            size: item.size,
            thumb: item.thumbs?.url1 || item.thumbs?.icon,
            direct_url: item.dlink || item.fdlink,
            backup_url: item.fastdlink || null
          }
        });
      } catch (fallbackErr) {
        console.error('[Terabox] Fallback API gagal →', fallbackErr.message);
        return res.status(500).json({
          status: false,
          creator: 'ZenzzXD',
          message: 'Gagal memproses link Terabox',
          error: fallbackErr.message
        });
      }
    }
  });
};
