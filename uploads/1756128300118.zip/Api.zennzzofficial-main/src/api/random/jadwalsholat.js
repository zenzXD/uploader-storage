const axios = require('axios');

async function fetchPrayerTimesByCity(cityName) {
  try {
    // Langkah 1: Cari ID kota
    const searchResponse = await axios.get('https://cloudku.us.kg/api/murotal/search/kota', {
      params: { q: encodeURIComponent(cityName.toLowerCase()) }
    });

    if (searchResponse.data.status !== 'success' || !searchResponse.data.result.data.length) {
      return {
        status: false,
        creator: "ZenzzXD",
        message: `Kota "${cityName}" tidak ditemukan.`,
      };
    }

    const kotaData = searchResponse.data.result.data[0];
    const cityId = kotaData.id;
    const cityLocation = kotaData.lokasi;

    // Langkah 2: Ambil jadwal sholat untuk hari ini
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const tanggal = `${yyyy}-${mm}-${dd}`;

    const prayerResponse = await axios.get('https://cloudku.us.kg/api/murotal/jadwal', {
      params: {
        id: cityId,
        time: tanggal
      }
    });

    if (prayerResponse.data.status !== 'success') {
      return {
        status: false,
        creator: "ZenzzXD",
        message: "Gagal mengambil jadwal sholat dari server."
      };
    }

    const { daerah, jadwal } = prayerResponse.data.result;

    return {
      status: true,
      creator: "ZenzzXD",
      location: cityLocation,
      daerah: daerah,
      jadwal: {
        tanggal: jadwal.tanggal,
        imsak: jadwal.imsak,
        subuh: jadwal.subuh,
        terbit: jadwal.terbit,
        dhuha: jadwal.dhuha,
        dzuhur: jadwal.dzuhur,
        ashar: jadwal.ashar,
        maghrib: jadwal.maghrib,
        isya: jadwal.isya,
        date: jadwal.date
      }
    };

  } catch (error) {
    return {
      status: false,
      creator: "ZenzzXD",
      message: `Terjadi kesalahan saat mengambil data.`,
      error: error.message
    };
  }
}

module.exports = function (app) {
  app.get('/islam/jadwalsholat', async (req, res) => {
    const city = req.query.city;
    if (!city) {
      return res.status(400).json({
        status: false,
        creator: "ZenzzXD",
        message: "Parameter ?city= wajib diisi."
      });
    }

    const result = await fetchPrayerTimesByCity(city);
    res.json(result);
  });
};
