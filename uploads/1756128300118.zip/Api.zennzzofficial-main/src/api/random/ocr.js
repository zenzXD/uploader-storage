const axios = require('axios');
const ua = require('user-agents');

module.exports = function (app) {
  
  // OCR function
  async function docsbot(buffer) {
    try {
      if (!buffer || !Buffer.isBuffer(buffer)) {
        throw new Error('Image buffer is required');
      }

      const { data } = await axios.post(`https://docsbot.ai/api/tools/image-prompter`, {
        image: buffer.toString('base64'), 
        type: 'text' // OCR type
      }, {
        headers: {
          'content-type': 'application/json',
          'user-agent': (new ua()).toString()
        },
        timeout: 30000
      });
      
      return data;
    } catch (error) {
      if (error.response) {
        throw new Error(`DocsBot API Error: ${error.response.status} - ${error.response.statusText}`);
      } else if (error.request) {
        throw new Error('No response from DocsBot API');
      } else {
        throw new Error(`OCR Error: ${error.message}`);
      }
    }
  }

  // OCR endpoint with image URL only
  app.get('/tools/ocr', async (req, res) => {
    try {
      const { url } = req.query;
      
      if (!url) {
        return res.status(400).json({
          status: false,
          message: 'Parameter url harus diisi'
        });
      }

      // Validate URL
      try {
        new URL(url);
      } catch (e) {
        return res.status(400).json({
          status: false,
          message: 'Invalid URL format'
        });
      }

      console.log(`[OCR] Processing image from URL: ${url}`);
      
      // Download image from URL
      const imageResponse = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 15000,
        headers: {
          'user-agent': (new ua()).toString()
        }
      });

      // Check if response is an image
      const contentType = imageResponse.headers['content-type'];
      if (!contentType || !contentType.startsWith('image/')) {
        return res.status(400).json({
          status: false,
          message: 'URL does not point to a valid image file'
        });
      }

      const imageBuffer = Buffer.from(imageResponse.data);
      const result = await docsbot(imageBuffer);
      
      res.json({
        status: true,
        creator: "ZenzzXD",
        image_url: url,
        image_size: imageBuffer.length,
        content_type: contentType,
        result: result
      });
      
    } catch (error) {
      console.error('[OCR] Error:', error.message);
      
      if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        res.status(400).json({
          status: false,
          creator: "ZenzzXD",
          message: 'Failed to download image from URL. Please check if the URL is accessible.'
        });
      } else {
        res.status(500).json({
          status: false,
          creator: "ZenzzXD",
          message: error.message
        });
      }
    }
  });

  // Health check endpoint
  app.get('/tools/ocr/status', (req, res) => {
    res.json({
      status: true,
      message: "OCR API is running",
      endpoint: {
        method: "GET", 
        path: "/tools/ocr?url=IMAGE_URL",
        description: "OCR from image URL",
        example: "/tools/ocr?url=https://example.com/image.jpg"
      },
      supported_formats: ["jpg", "jpeg", "png", "gif", "bmp", "webp"],
      credits: "Powered by DocsBot.ai"
    });
  });

  // Usage examples endpoint
  app.get('/tools/ocr/examples', (req, res) => {
    res.json({
      status: true,
      message: "OCR API Usage Examples",
      example: {
        method: "GET",
        url: "/tools/ocr?url=https://example.com/image.jpg",
        description: "Extract text from image URL",
        curl_example: `curl "http://your-domain.com/tools/ocr?url=https://example.com/image.jpg"`
      },
      response_format: {
        status: "boolean",
        creator: "string",
        image_url: "string",
        image_size: "number",
        content_type: "string",
        result: "object (contains extracted text and other data)"
      }
    });
  });
};
