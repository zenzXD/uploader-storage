const axios = require('axios');

async function aioDownloader(url) {
    if (!url || !url.includes('https://')) throw new Error('Parameter url tidak valid.');
    
    const { data } = await axios.post('https://auto-download-all-in-one.p.rapidapi.com/v1/social/autolink', {
        url: url
    }, {
        headers: {
            'accept-encoding': 'gzip',
            'cache-control': 'no-cache',
            'content-type': 'application/json; charset=utf-8',
            referer: 'https://auto-download-all-in-one.p.rapidapi.com/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Mobile Safari/537.36',
            'x-rapidapi-host': 'auto-download-all-in-one.p.rapidapi.com',
            'x-rapidapi-key': '1dda0d29d3mshc5f2aacec619c44p16f219jsn99a62a516f98'
        },
        timeout: 15000
    });

    if (!data || data.error) {
        throw new Error(data?.message || 'tidak mengembalikan data yang valid.');
    }

    return data;
}

module.exports = function (app) {
    const creatorName = "ZenzzXD";

    app.get('/downloader/aio', async (req, res) => {
        const { url } = req.query;

        if (!url) {
            return res.status(400).json({
                status: false,
                creator: creatorName,
                message: "Parameter 'url' wajib diisi."
            });
        }

        try {
            const result = await aioDownloader(url);
            res.json({
                status: true,
                creator: creatorName,
                result
            });
        } catch (err) {
            console.error('[❌ AIO Downloader Error]', err.message);
            res.status(500).json({
                status: false,
                creator: creatorName,
                message: err.message
            });
        }
    });
};
