const axios = require('axios');
const cheerio = require('cheerio');

async function searchClub(q) {
  try {
    const { data } = await axios.get(`https://live.lapangbola.com/teams?q=${encodeURIComponent(q)}`);
    const $ = cheerio.load(data);

    const href = $('.panel-body .col-lg-3 a[href^="/teams/"]').first().attr('href');
    if (!href) return { status: false, creator: 'ZenzzXD', message: 'Klub tidak ditemukan' };

    return await infoClub('https://live.lapangbola.com' + href);
  } catch (e) {
    return { status: false, creator: 'ZenzzXD', message: e.message };
  }
}

async function infoClub(url) {
  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const matchHistory = [];
    $('#match-history tr').each((i, e) => {
      matchHistory.push({
        date: $(e).find('.color-primary').text().trim(),
        versus: `${$(e).find('.team-short-name').first().text().trim()} vs ${$(e).find('.team-short-name').last().text().trim()}`,
        score: $(e).find('a:has(.label)').text().trim(),
        tournament: $(e).find('a:not(:has(.label))').text().trim()
      });
    });

    const players = [];
    $('#players-list tbody tr').each((i, e) => {
      players.push({
        name: $(e).find('.color-primary').text().trim(),
        number: $(e).find('td').eq(1).text().trim(),
        position: $(e).find('td').last().text().trim()
      });
    });

    return {
      status: true,
      creator: 'ZenzzXD',
      name: $('.profile-header-title h1').text().trim(),
      logo: $('.profile-user .avatar img').attr('src'),
      stadium: $('.profile-header-title p').text().trim(),
      play: $('.widget-four .col-xl-3').eq(0).find('p').text().trim(),
      win: $('.widget-four .col-xl-3').eq(1).find('p').text().trim(),
      draw: $('.widget-four .col-xl-3').eq(2).find('p').text().trim(),
      lose: $('.widget-four .col-xl-3').eq(3).find('p').text().trim(),
      players,
      matchHistory
    };
  } catch (e) {
    return { status: false, creator: 'ZenzzXD', message: e.message };
  }
}

module.exports = function (app) {
  app.get('/search/club', async (req, res) => {
    const { q } = req.query;
    if (!q) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter q (query) wajib diisi'
      });
    }

    const result = await searchClub(q);
    res.json(result);
  });
};
