const axios = require('axios');
const { Buffer } = require('buffer');

module.exports = function (app) {
  app.get('/tools/hitamkan', async (req, res) => {
    const { imageUrl } = req.query;

    if (!imageUrl) {
      return res.status(400).send('Parameter "imageUrl" diperlukan.');
    }

    try {
      // Ambil gambar dari URL yang diberikan
      const imgRes = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      const buffer = Buffer.from(imgRes.data);
      const base64Image = buffer.toString('base64');

      // Kirim ke endpoint negro
      const response = await axios.post('https://negro.consulting/api/process-image', {
        imageData: base64Image,
        filter: 'hitam'
      });

      const base64 = response?.data?.processedImageUrl;
      if (!base64 || !base64.startsWith('data:image')) {
        return res.status(500).send('Gagal memproses gambar.');
      }

      // Parsing data:image/png;base64,.... → dapatkan mimetype dan isinya
      const matches = base64.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        return res.status(500).send('Format gambar tidak dikenali.');
      }

      const mimeType = matches[1];
      const base64Data = matches[2];
      const imageBuffer = Buffer.from(base64Data, 'base64');

      // Kirim buffer sebagai file gambar
      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Disposition', 'inline; filename="hitamkan.png"');
      res.send(imageBuffer);
    } catch (err) {
      console.error('[ERROR /tools/hitamkan]:', err.message);
      res.status(500).send('Terjadi kesalahan saat memproses.');
    }
  });
};
