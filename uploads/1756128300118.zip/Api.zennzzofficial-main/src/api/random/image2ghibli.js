const axios = require('axios');

module.exports = function (app) {
  app.get('/maker/image2ghibli', async (req, res) => {
    const image = req.query.image;
    if (!image) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: "Parameter 'image' wajib diisi"
      });
    }

    try {
      new URL(image);
    } catch (e) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: "URL gambar tidak valid"
      });
    }

    const url = `https://api.siputzx.my.id/api/image2ghibli?image=${encodeURIComponent(image)}`;

    try {
      console.log(`[image2ghibli] Processing image: ${image}`);

      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 30000, // dinaikkan jadi 30 detik
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      const contentType = response.headers['content-type'];
      if (!contentType || !contentType.startsWith('image/')) {
        return res.status(400).json({
          status: false,
          creator: 'ZenzzXD',
          message: 'Response bukan berupa gambar yang valid'
        });
      }

      console.log(`[image2ghibli] Success! Content-Type: ${contentType}, Size: ${response.data.length} bytes`);

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Length', response.data.length);
      res.setHeader('Creator', 'ZenzzXD');
      res.setHeader('Cache-Control', 'public, max-age=3600');

      res.send(Buffer.from(response.data));

    } catch (err) {
      console.error('[image2ghibli] Error:', err.message);
      return res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Terjadi kesalahan saat memproses gambar',
        error: err.message
      });
    }
  });

  app.get('/maker/image2ghibli/status', (req, res) => {
    res.json({
      status: true,
      message: "Image to Ghibli API is running",
      endpoint: "/maker/image2ghibli?image=IMAGE_URL",
      description: "Convert any image to Studio Ghibli style",
      supported_formats: ["jpg", "jpeg", "png", "webp"],
      example: "/maker/image2ghibli?image=https://example.com/photo.jpg",
      credits: "Powered by siputzx.my.id"
    });
  });
};
