const axios = require("axios");

const models = {
  miku: { voice_id: "67aee909-5d4b-11ee-a861-00163e2ac61b", voice_name: "Hatsune Miku" },
  nahida: { voice_id: "67ae0979-5d4b-11ee-a861-00163e2ac61b", voice_name: "Nahida (Exclusive)" },
  nami: { voice_id: "67ad95a0-5d4b-11ee-a861-00163e2ac61b", voice_name: "Nami" },
  ana: { voice_id: "f2ec72cc-110c-11ef-811c-00163e0255ec", voice_name: "Ana (Female)" },
  optimus_prime: { voice_id: "67ae0f40-5d4b-11ee-a861-00163e2ac61b", voice_name: "Optimus Prime" },
  goku: { voice_id: "67aed50c-5d4b-11ee-a861-00163e2ac61b", voice_name: "Goku" },
  taylor_swift: { voice_id: "67ae4751-5d4b-11ee-a861-00163e2ac61b", voice_name: "Taylor Swift" },
  elon_musk: { voice_id: "67ada61f-5d4b-11ee-a861-00163e2ac61b", voice_name: "Elon Musk" },
  mickey_mouse: { voice_id: "67ae7d37-5d4b-11ee-a861-00163e2ac61b", voice_name: "Mickey Mouse" },
  kendrick_lamar: { voice_id: "67add638-5d4b-11ee-a861-00163e2ac61b", voice_name: "Kendrick Lamar" },
  angela_adkinsh: { voice_id: "d23f2adb-5d1b-11ee-a861-00163e2ac61b", voice_name: "Angela Adkinsh" },
  eminem: { voice_id: "c82964b9-d093-11ee-bfb7-e86f38d7ec1a", voice_name: "Eminem" }
};

const userAgents = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
  "Mozilla/5.0 (Linux; Android 10; Mobile)"
];

function getRandomIp() {
  return Array.from({ length: 4 }).map(() => Math.floor(Math.random() * 256)).join(".");
}

async function generateVoice(model, voice_id, voice_name, text) {
  const payload = {
    raw_text: text,
    url: "https://filme.imyfone.com/text-to-speech/anime-text-to-speech/",
    product_id: "200054",
    convert_data: [{ voice_id, speed: "1", volume: "50", text, pos: 0 }]
  };

  const headers = {
    "Content-Type": "application/json",
    "Accept": "*/*",
    "X-Forwarded-For": getRandomIp(),
    "User-Agent": userAgents[Math.floor(Math.random() * userAgents.length)]
  };

  const config = { headers, timeout: 9000 };

  // Try up to 2x if failed
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await axios.post("https://voxbox-tts-api.imyfone.com/pc/v1/voice/tts", payload, config);
      const result = res.data?.data?.convert_result?.[0];
      return {
        model,
        voice_name,
        audio_url: result?.oss_url || null,
        channel_id: result?.channel_id ?? null
      };
    } catch (err) {
      if (attempt === 1) {
        return {
          model,
          voice_name,
          audio_url: null,
          channel_id: null
        };
      }
    }
  }
}

async function tts(text) {
  const tasks = Object.entries(models).map(([model, { voice_id, voice_name }]) =>
    generateVoice(model, voice_id, voice_name, text)
  );

  const settled = await Promise.allSettled(tasks);
  return settled.map(result =>
    result.status === "fulfilled" ? result.value : {
      model: "unknown",
      voice_name: "Unknown",
      audio_url: null,
      channel_id: null
    }
  );
}

module.exports = function (app) {
  app.get('/tools/text2speech', async (req, res) => {
    const { text } = req.query;
    if (!text) {
      return res.status(400).json({
        status: false,
        creator: "ZenzzXD",
        message: "Parameter 'text' tidak boleh kosong"
      });
    }

    try {
      const results = await tts(text);
      res.json({
        status: true,
        creator: "ZenzzXD",
        input: text,
        total: results.length,
        results
      });
    } catch (err) {
      res.status(500).json({
        status: false,
        creator: "ZenzzXD",
        message: "Gagal melakukan TTS",
        error: err.message
      });
    }
  });
};
