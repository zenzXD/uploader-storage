const axios = require('axios');
const cheerio = require('cheerio');

async function mfdl(url) {
  try {
    const response = await axios.get('https://r.jina.ai/' + url);
    const html = response.data;
    const $ = cheerio.load(html);

    // Extract specific text elements
    const title = $('body').text().match(/Title: (.*?)\n/)?.[1];
    const urlSource = $('body').text().match(/URL Source: (.*?)\n/)?.[1];
    const fileName = $('body').text().match(/File name: (.*?)\n/)?.[1];
    const fileSize = $('body').text().match(/File size: (.*?)\n/)?.[1];
    const uploadedDate = $('body').text().match(/Uploaded: (.*?)\n/)?.[1];
    const uploadRegion = $('body').text().match(/This file was uploaded from (.*?)\n/)?.[1];
    const downloadLinkMatch = $('body').text().match(/\[Download \((.*?)\)\]\((.*?)\)/);
    const downloadLink = downloadLinkMatch ? downloadLinkMatch[2] : null;

    if (!title || !downloadLink) {
      throw new Error('Gagal mengambil data Mediafire. Pastikan URL valid.');
    }

    return {
      metadata: {
        title,
        urlSource,
        fileName,
        fileSize,
        uploadedDate,
        uploadRegion
      },
      downloadLink
    };

  } catch (error) {
    console.error('Error scraping Mediafire:', error);
    throw error;
  }
}

module.exports = function (app) {
  app.get('/downloader/mediafire', async (req, res) => {
    const { url } = req.query;
    if (!url) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter url tidak boleh kosong'
      });
    }

    try {
      const result = await mfdl(url);
      res.status(200).json({
        status: true,
        creator: 'ZenzzXD',
        result
      });
    } catch (err) {
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal mengambil data Mediafire',
        error: err.message || err
      });
    }
  });
};
