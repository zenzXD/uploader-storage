const WebSocket = require('ws');

// ✅ Daftar API key yang diizinkan
const VALID_API_KEYS = [
    'zenzapis',
    'zenzapis',
    'zenzapis'
];

function growagarden() {
    return new Promise((resolve, reject) => {
        const ws = new WebSocket('wss://ws.growagardenpro.com', [], {
            headers: {
                'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                'cache-control': 'no-cache',
                connection: 'Upgrade',
                host: 'ws.growagardenpro.com',
                origin: 'https://growagardenpro.com',
                pragma: 'no-cache',
                'sec-websocket-extensions': 'permessage-deflate; client_max_window_bits',
                'sec-websocket-key': 'TBIaQ04Blb4aAA2qgBCZdA==',
                'sec-websocket-version': '13',
                upgrade: 'websocket',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'
            }
        });

        ws.onopen = () => console.log('✅ WebSocket Connected');

        ws.onmessage = (event) => {
            try {
                resolve(JSON.parse(event.data));
            } catch {
                resolve(event.data);
            }
            ws.close();
        };

        ws.onerror = reject;
        ws.onclose = () => console.log('❌ WebSocket Disconnected');
    });
}

module.exports = function (app) {
    app.get('/info/growagardenstock', async (req, res) => {
        // ✅ Ambil IP akurat
        const forwarded = req.headers['x-forwarded-for'];
        const ip = forwarded ? forwarded.split(',')[0]?.trim() : req.socket?.remoteAddress;

        // ✅ Log IP ke console
        console.log(`
===========================
📥 Grow A Garden API Request
🌐 URL: ${req.method} ${req.originalUrl}
📌 IP: ${ip}
🕒 Time: ${new Date().toLocaleString()}
===========================
        `);

        // ✅ Validasi API key
        const apikey = req.query.apikey;
        if (!apikey || !VALID_API_KEYS.includes(apikey)) {
            return res.status(401).json({
                status: false,
                creator: 'ZenzzXD',
                message: 'API key tidak valid atau tidak ditemukan.'
            });
        }

        try {
            const data = await growagarden();
            res.json({
                status: true,
                creator: 'ZenzzXD',
                data
            });
        } catch (err) {
            res.status(500).json({
                status: false,
                creator: 'ZenzzXD',
                message: 'Gagal mengambil data stock.',
                error: err?.message || err
            });
        }
    });
};
