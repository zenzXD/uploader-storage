const axios = require('axios')
const cheerio = require('cheerio')

module.exports = {
  path: '/info/transferumor',
  method: 'get',
  handler: async (req, res) => {
    try {
      const url = 'https://www.transfermarkt.co.id/geruechte/aktuellegeruechte/statistik'
      const { data } = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0',
        }
      })

      const $ = cheerio.load(data)
      const result = []

      $('table.items tbody tr').each((i, el) => {
        const cols = $(el).find('td')

        const player = $(cols[0]).find('img').attr('alt')?.trim() || ''
        const position = $(cols[0]).find('tr').last().text().trim()
        const age = $(cols[1]).text().trim()
        const fromClub = $(cols[2]).find('img').attr('alt')?.trim() || ''
        const toClub = $(cols[4]).find('img').attr('alt')?.trim() || ''
        const probabilityRaw = $(cols[6]).text().trim()
        const probability = probabilityRaw.replace(/\s+/g, ' ').match(/\d+%/)?.[0] || '0%'

        result.push({
          player,
          position,
          age,
          fromClub,
          toClub,
          probability
        })
      })

      res.json({
        status: true,
        creator: 'ZenzzXD',
        count: result.length,
        result
      })

    } catch (err) {
      res.json({
        status: false,
        creator: 'ZenzzXD',
        message: err.message || 'Terjadi kesalahan saat mengambil data.'
      })
    }
  }
}
