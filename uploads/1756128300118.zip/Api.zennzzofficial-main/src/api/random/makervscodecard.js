const axios = require('axios')

module.exports = function (app) {
  app.get('/maker/vscodecard', async (req, res) => {
    const {
      name = 'Nama Kamu',
      title = 'Pekerjaan Kamu',
      github = 'https://github.com/NamaKamu',
      ratio = '1:1'
    } = req.query

    const promptText = `Create a realistic image of a person holding a small, stylish business card that looks like a Visual Studio Code window.
The file is named "business_card.json" and displays a JSON object with the following fields: "name", "title", and "github".
Use sample values such as "name": "${name}", "title": "${title}", and "github": "${github}".
The card should use a dark theme, show line numbers, apply syntax highlighting, and have a softly blurred background.`

    try {
      const response = await axios.post('https://aifreebox.com/api/image-generator', {
        userPrompt: promptText,
        aspectRatio: ratio,
        slug: 'ai-art-generator'
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Origin': 'https://aifreebox.com',
          'Referer': `https://aifreebox.com/image-generator/ai-art-generator`,
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 Safari/537.36'
        }
      })

      const { data } = response

      if (data?.success && data.imageUrl) {
        res.json({
          status: true,
          creator: 'ZenzzXD',
          result: {
            prompt: promptText,
            ratio,
            imageUrl: data.imageUrl
          }
        })
      } else {
        throw new Error('Ga ada respon dari AIFreebox API')
      }
    } catch (err) {
      console.error('AIFreebox API Error:', err?.response?.data || err.message)
      res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal generate gambar dari AIFreebox',
        error: err.message
      })
    }
  })
}
