const axios = require('axios')

async function screenshotWebsite(url, device = 'desktop') {
  if (!/^https?:\/\//.test(url)) {
    return {
      status: false,
      creator: 'ZenzzXD',
      message: 'URL tidak valid. Harus diawali dengan http:// atau https://',
    }
  }

  const devices = {
    desktop: { device: 'desktop', fullPage: false },
    mobile:  { device: 'mobile', fullPage: false },
    tablet:  { device: 'desktop', fullPage: true }, // asumsi 'tablet' = full desktop
  }

  if (!devices[device]) {
    return {
      status: false,
      creator: 'ZenzzXD',
      message: 'Parameter "device" hanya bisa: desktop, mobile, atau tablet.',
    }
  }

  const { device: userDevice, fullPage } = devices[device]

  try {
    const payload = {
      url: url.trim(),
      device: userDevice,
      fullPage
    }

    const response = await axios.post(
      'https://api.magickimg.com/generate/website-screenshot',
      payload,
      {
        responseType: 'arraybuffer',
        headers: {
          'Content-Type': 'application/json',
          'Origin': 'https://magickimg.com',
          'Referer': 'https://magickimg.com',
          'Accept': 'application/json, text/plain, */*',
          'User-Agent': 'Mozilla/5.0',
        },
      }
    )

    return {
      status: true,
      creator: 'ZenzzXD',
      contentType: response.headers['content-type'] || 'image/png',
      buffer: Buffer.from(response.data),
    }

  } catch (error) {
    return {
      status: false,
      creator: 'ZenzzXD',
      message: error.message || 'Gagal mengambil screenshot dari website.',
    }
  }
}

module.exports = function (app) {
  app.get('/tools/ssweb', async (req, res) => {
    const { url, device = 'desktop' } = req.query

    if (!url) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter "url" wajib diisi.',
      })
    }

    const result = await screenshotWebsite(url, device.toLowerCase())

    if (!result.status) {
      return res.status(500).json({
        status: false,
        creator: result.creator,
        message: result.message,
      })
    }

    res.setHeader('Content-Type', result.contentType)
    return res.end(result.buffer)
  })
}
