const { URL } = require('url');

module.exports = function (app) {
  app.get('/downloader/videy', async (req, res) => {
    const { url } = req.query;

    // Validasi URL
    if (!url) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: "Parameter 'url' diperlukan. Contoh: ?url=https://videy.co/v?id=abc123"
      });
    }

    try {
      const parsed = new URL(url);
      const id = parsed.searchParams.get('id');

      if (!id) {
        return res.status(400).json({
          status: false,
          creator: 'ZenzzXD',
          message: "URL tidak valid atau tidak memiliki parameter id. Contoh: https://videy.co/v?id=abc123"
        });
      }

      // Bangun URL download dari ID
      const videoUrl = `https://cdn.videy.co/${id}.mp4`;

      // Kembalikan URL sebagai response JSON
      return res.json({
        status: true,
        creator: 'ZenzzXD',
        video_url: videoUrl,
        filename: `videy_${id}.mp4`,
        mimetype: 'video/mp4'
      });

    } catch (err) {
      return res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal memproses URL videy',
        error: err.message
      });
    }
  });
};
