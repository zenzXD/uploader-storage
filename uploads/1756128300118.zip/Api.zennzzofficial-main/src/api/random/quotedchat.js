const axios = require('axios');

module.exports = function (app) {
    app.get('/maker/quotedchat', async (req, res) => {
        try {
            const { text, username, fotoprofile, color } = req.query;

            if (!text) {
                return res.status(400).json({
                    status: false,
                    creator: 'ZenzzXD',
                    message: 'Parameter ?text= harus diisi'
                });
            }

            const name = username || 'Anonymous';
            const pp = fotoprofile || 'https://telegra.ph/file/320b066dc81928b782c7b.png';

            // Hanya boleh hitam / putih
            const selectedColor = (color && color.toLowerCase() === 'putih') ? '#FFFFFF' : '#000000';

            const obj = {
                "type": "quote",
                "format": "png",
                "backgroundColor": selectedColor, // hitam / putih
                "width": 512,
                "height": 768,
                "scale": 2,
                "messages": [{
                    "entities": [],
                    "avatar": true,
                    "from": {
                        "id": 1,
                        "name": name,
                        "photo": { "url": pp }
                    },
                    "text": text,
                    "replyMessage": {}
                }]
            };

            const response = await axios.post('https://btzqc.betabotz.eu.org/generate', obj, {
                headers: { 'Content-Type': 'application/json' }
            });

            const buffer = Buffer.from(response.data.result.image, 'base64');

            // Kirim langsung gambar PNG
            res.setHeader('Content-Type', 'image/png');
            res.send(buffer);

        } catch (error) {
            console.error(error.message);
            res.status(500).json({
                status: false,
                creator: 'ZenzzXD',
                message: 'Terjadi kesalahan saat membuat quoted chat',
                error: error.message
            });
        }
    });
};
