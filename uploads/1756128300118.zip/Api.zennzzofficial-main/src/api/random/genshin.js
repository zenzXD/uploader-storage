const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function (app) {
    app.get('/stalker/genshin', async (req, res) => {
        const uid = req.query.uid;
        const creatorName = "ZenzzXD";

        if (!uid) {
            return res.status(400).json({
                status: false,
                creator: creatorName,
                message: "Parameter 'uid' wajib diisi!"
            });
        }

        const URL = `https://enka.network/u/${uid}/`;

        try {
            const { data: html } = await axios.get(URL, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Accept-Language': 'en-US,en;q=0.9',
                },
            });

            const $ = cheerio.load(html);

            const extractedData = {
                username: null,
                avatar: null,
                adventureRank: null,
                worldLevel: null,
                signature: null,
                totalAchievements: null,
                spiralAbyss: null,
            };

            const playerInfo = $('.PlayerInfo');

            if (playerInfo.length === 0) {
                return res.status(404).json({
                    status: false,
                    creator: creatorName,
                    message: "Data Enka.Network tidak ditemukan untuk UID tersebut."
                });
            }

            // Username
            extractedData.username = playerInfo.find('h1').text().trim() || "gaada wok";

            // Avatar image
            const avatarSrc = playerInfo.find('.avatar-icon img').attr('src');
            const baseUrl = 'https://enka.network';
            if (avatarSrc) {
                extractedData.avatar = avatarSrc.startsWith('/')
                    ? baseUrl + avatarSrc
                    : avatarSrc;
            } else {
                extractedData.avatar = "gaada wok";
            }

            // Adventure Rank (AR) and World Level (WL)
            const arWlText = playerInfo.find('.ar').text().trim();
            const arMatch = arWlText.match(/AR\s*(\d+)/);
            const wlMatch = arWlText.match(/WL\s*(\d+)/);
            extractedData.adventureRank = arMatch ? parseInt(arMatch[1], 10) : "gaada wok";
            extractedData.worldLevel = wlMatch ? parseInt(wlMatch[1], 10) : "gaada wok";

            // Signature
            extractedData.signature = playerInfo.find('.signature').text().trim() || "gaada wok";

            // Stats table
            const statsTable = playerInfo.find('.stats');
            const totalAchievements = statsTable.find('tr').eq(0).find('td').eq(0).text().trim();
            extractedData.totalAchievements = totalAchievements || "gaada wok";

            const spiralAbyss = statsTable.find('tr').eq(1).find('td').eq(0).text().trim();
            extractedData.spiralAbyss = spiralAbyss || "gaada wok";

            // Bersihkan field kosong
            const finalData = Object.entries(extractedData).reduce((acc, [key, value]) => {
                if (value !== null && value !== '') acc[key] = value;
                return acc;
            }, {});

            return res.json({
                status: true,
                creator: creatorName,
                result: finalData
            });

        } catch (error) {
            console.error('Error scraping Enka.Network:', error.message);
            return res.status(500).json({
                status: false,
                creator: creatorName,
                message: `Gagal mengambil data : ${error.message}`
            });
        }
    });
};
