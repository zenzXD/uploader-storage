const axios = require('axios');

module.exports = function (app) {
  app.get('/maker/ustadz', async (req, res) => {
    const { text } = req.query;

    if (!text) {
      return res.status(400).json({
        status: false,
        creator: "ZenzzXD",
        message: 'Parameter text tidak boleh kosong'
      });
    }

    try {
      const response = await axios.post(
        'https://lemon-ustad.vercel.app/api/generate-image',
        {
          isi: text,
          option: 'type1'
        },
        {
          responseType: 'arraybuffer',
          headers: { 'Content-Type': 'application/json' }
        }
      );

      res.setHeader('Content-Type', 'image/png');
      res.send(response.data);
    } catch (error) {
      console.error('Ustadz Maker Error:', error?.message || error);
      res.status(500).json({
        status: false,
        creator: "ZenzzXD",
        message: 'Gagal membuat gambar ustadz',
        error: error?.message || String(error)
      });
    }
  });
};
