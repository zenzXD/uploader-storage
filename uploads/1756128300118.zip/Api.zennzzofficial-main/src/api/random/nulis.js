const axios = require('axios');

async function generateNulisImage(text) {
  if (!text) {
    throw new Error('Parameter "text" tidak boleh kosong');
  }

  const response = await axios.post(
    'https://lemon-write.vercel.app/api/generate-book',
    {
      text,
      font: 'default',
      color: '#000000',
      size: '28',
    },
    {
      responseType: 'arraybuffer',
      headers: { 'Content-Type': 'application/json' },
    }
  );

  return response.data; // Buffer image
}

module.exports = function (app) {
  app.get('/maker/nulis', async (req, res) => {
    const { text } = req.query;

    if (!text) {
      return res.status(400).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Parameter "text" wajib diisi',
      });
    }

    try {
      const imageBuffer = await generateNulisImage(text);

      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', 'inline; filename="nulis.png"');
      return res.end(imageBuffer);
    } catch (err) {
      console.error('Nulis API Error:', err.message);
      return res.status(500).json({
        status: false,
        creator: 'ZenzzXD',
        message: 'Gagal menghasilkan gambar, coba lagi nanti',
      });
    }
  });
};
