const axios = require("axios");
const EventSource = require("eventsource"); // Pakai eventsource versi Node

const CREATOR = "ZenzzXD";

module.exports = function (app) {
  app.get("/ai/deepseekr1", async (req, res) => {
    const prompt = req.query.prompt;

    if (!prompt || prompt.trim() === "") {
      return res.status(400).json({
        status: false,
        creator: CREATOR,
        error: "Parameter 'prompt' wajib diisi",
      });
    }

    try {
      const data = await deepSeekThink.chat(prompt);
      res.status(200).json({
        status: true,
        creator: CREATOR,
        data: data,
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({
        status: false,
        creator: CREATOR,
        error: "Internal Server Error",
      });
    }
  });
};

const deepSeekThink = {
  chat: async (question, useWebSearch = false) => {
    const session_hash = Math.random().toString(36).substring(2);

    const payload = {
      data: [question, [], useWebSearch],
      event_data: null,
      fn_index: 2,
      session_hash: session_hash,
    };

    // Kirim POST request
    const response = await axios.post(
      "https://ginigen-deepseek-r1-0528-api.hf.space/gradio_api/queue/join",
      payload,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    // Listen EventSource untuk mengambil hasil
    return new Promise((resolve, reject) => {
      const es = new EventSource(
        `https://ginigen-deepseek-r1-0528-api.hf.space/gradio_api/queue/data?session_hash=${session_hash}`
      );

      es.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.msg === "process_completed") {
            es.close();
            resolve(data.output);
          }
        } catch (e) {
          es.close();
          reject(new Error(`Failed to parse server response: ${e.message}`));
        }
      };

      es.onerror = (err) => {
        es.close();
        reject(new Error("EventSource connection failed."));
      };
    });
  },
};
