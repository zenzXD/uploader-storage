const fetch = require('node-fetch');

function formatSize(bytes) {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 Bytes';
    const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
    return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
}

async function GDriveDl(url) {
    let id;
    if (!(url && url.match(/drive.google/i))) throw 'URL Google Drive tidak valid.';
    id = (url.match(/\/d\/(.*?)\//i) || url.match(/id=([^&]+)/i))[1];
    if (!id) throw 'ID file Google Drive tidak ditemukan.';

    const res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, {
        method: 'POST',
        headers: {
            'accept-encoding': 'gzip, deflate, br',
            'content-length': 0,
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
            'origin': 'https://drive.google.com',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
            'x-client-data': 'CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
            'x-drive-first-party': 'DriveWebUi',
            'x-json-requested': 'true'
        }
    });

    const text = await res.text();
    const json = JSON.parse(text.slice(4));

    const { fileName, sizeBytes, downloadUrl } = json;
    if (!downloadUrl) throw 'Link download sudah mencapai batas limit.';

    const fileRes = await fetch(downloadUrl);
    if (fileRes.status !== 200) throw `Gagal mengunduh file: ${fileRes.statusText}`;

    return {
        downloadUrl,
        fileName,
        fileSize: formatSize(sizeBytes),
        mimetype: fileRes.headers.get('content-type')
    };
}

module.exports = function (app) {
    app.get('/downloader/gdrive', async (req, res) => {
        const { url } = req.query;

        if (!url) {
            return res.status(400).json({
                status: false,
                message: 'Masukkan parameter url (link Google Drive).'
            });
        }

        if (!url.includes('drive.google.com')) {
            return res.status(400).json({
                status: false,
                message: 'Link harus dari Google Drive.'
            });
        }

        try {
            const result = await GDriveDl(url);
            res.json({
                status: true,
                creator: 'ZenzzXD',
                result
            });
        } catch (err) {
            console.error('GDriveDl error:', err);
            res.status(500).json({
                status: false,
                creator: 'ZenzzXD',
                message: err.toString()
            });
        }
    });
};
