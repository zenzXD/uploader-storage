const axios = require('axios');

async function tiktoks(query) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await axios({
                method: 'POST',
                url: 'https://tikwm.com/api/feed/search',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Cookie': 'current_language=en',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
                },
                data: {
                    keywords: query,
                    count: 10,
                    cursor: 0,
                    HD: 1
                }
            });

            const videos = response.data.data.videos;
            if (!videos || videos.length === 0) {
                reject("Tidak ada video ditemukan.");
            } else {
                const randomIndex = Math.floor(Math.random() * videos.length);
                const video = videos[randomIndex];

                resolve({
                    title: video.title,
                    cover: video.cover,
                    origin_cover: video.origin_cover,
                    no_watermark: video.play,
                    watermark: video.wmplay,
                    music: video.music
                });
            }
        } catch (error) {
            reject(error);
        }
    });
}

module.exports = function (app) {
    const creatorName = "ZenzzXD";

    app.get('/search/tiktok', async (req, res) => {
        const { q } = req.query;

        if (!q) {
            return res.status(400).json({
                status: false,
                creator: creatorName,
                message: "Masukkan parameter q (kata kunci pencarian TikTok)"
            });
        }

        try {
            const data = await tiktoks(q);

            res.json({
                status: true,
                creator: creatorName,
                result: data
            });
        } catch (err) {
            console.error("Error TikTok Search:", err.message);
            res.status(500).json({
                status: false,
                creator: creatorName,
                message: "Gagal mengambil data TikTok.",
                error: err.message
            });
        }
    });
};
