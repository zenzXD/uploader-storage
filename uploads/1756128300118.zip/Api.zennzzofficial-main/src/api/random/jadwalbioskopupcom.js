const axios = require('axios');

function stripHtml(html) {
    return html.replace(/<[^>]*>?/gm, '').replace(/\s+/g, ' ').trim();
}

module.exports = function (app) {
    app.get('/info/jadwalfilmupcoming', async (req, res) => {
        try {
            const response = await axios.get('https://m.21cineplex.com/api/movies', {
                params: {
                    type: 'upcoming',
                    city_id: 72 // Ubah kalau mau kota lain
                },
                headers: {
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
                },
                timeout: 10000
            });

            const movies = response.data.data.value.content;
            if (!movies || movies.length === 0) {
                return res.status(404).json({
                    status: false,
                    creator: "ZenzzXD",
                    message: "Tidak ada film upcoming ditemukan."
                });
            }

            const result = movies.map(film => ({
                title: film.title,
                genre: film.genre,
                duration: `${film.duration} menit`,
                date_show: film.date_show,
                synopsis: stripHtml(film.synopsis), // Bersihin tag HTML
                trailer: film.trailer,
                image: film.movie_image
            }));

            res.json({
                status: true,
                creator: "ZenzzXD",
                total: result.length,
                data: result
            });

        } catch (err) {
            console.error('❌ Error:', err.message);
            res.status(500).json({
                status: false,
                creator: "ZenzzXD",
                message: "Gagal mengambil data film upcoming.",
                error: err.message
            });
        }
    });
};
