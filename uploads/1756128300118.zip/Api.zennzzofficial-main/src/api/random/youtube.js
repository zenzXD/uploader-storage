const fetch = require("node-fetch");
const crypto = require("crypto");

// SAVETUBE: ambil metadata (title, duration, thumbnail)
const savetube = {
    api: {
        base: "https://media.savetube.me/api",
        cdn: "/random-cdn",
        info: "/v2/info",
    },
    headers: {
        "accept": "*/*",
        "content-type": "application/json",
        "origin": "https://yt.savetube.me",
        "referer": "https://yt.savetube.me/",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36",
    },
    crypto: {
        decrypt: async (enc) => {
            const key = Buffer.from("C5D58EF67A7584E4A29F6C35BBC4EB12", "hex");
            const data = Buffer.from(enc, "base64");
            const iv = data.slice(0, 16);
            const content = data.slice(16);
            const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);
            const decrypted = Buffer.concat([
                decipher.update(content),
                decipher.final(),
            ]);
            return JSON.parse(decrypted.toString());
        },
    },
    youtube: (url) => {
        const patterns = [/v=([a-zA-Z0-9_-]{11})/, /youtu\.be\/([a-zA-Z0-9_-]{11})/, /shorts\/([a-zA-Z0-9_-]{11})/];
        for (let p of patterns) {
            const match = url.match(p);
            if (match) return match[1];
        }
        return null;
    },
    request: async (endpoint, data = {}, method = "post") => {
        const res = await fetch(
            `${endpoint.startsWith("http") ? "" : savetube.api.base}${endpoint}`,
            {
                method,
                headers: savetube.headers,
                body: method === "post" ? JSON.stringify(data) : undefined,
            }
        );
        if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
        return await res.json();
    },
    getCDN: async () => {
        const res = await savetube.request(savetube.api.cdn, {}, "get");
        return res.cdn;
    },
    info: async (url) => {
        try {
            const id = savetube.youtube(url);
            if (!id) throw new Error("Invalid YouTube URL");
            const cdn = await savetube.getCDN();
            const res = await savetube.request(
                `https://${cdn}${savetube.api.info}`,
                { url: `https://www.youtube.com/watch?v=${id}` }
            );
            const decrypted = await savetube.crypto.decrypt(res.data);
            return decrypted;
        } catch (err) {
            console.warn("[Savetube metadata] gagal:", err.message);
            return {}; // jika gagal metadata kosong
        }
    },
};

// Y2MATE: untuk MP3
const y2mate = {
    headers: {
        "accept": "*/*",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0"
    },

    getKey: async () => {
        const headers = {
            "content-type": "application/json",
            "origin": "https://iframe.y2meta-uk.com",
            "referer": "https://iframe.y2meta-uk.com/",
            ...y2mate.headers
        };
        const res = await fetch(`https://api.mp3youtube.cc/v2/sanity/key`, { headers });
        if (!res.ok) throw Error(`Failed get key y2mate ${res.status}`);
        return await res.json();
    },

    handleFormat: (link, formatId) => {
        const listFormat = ["128kbps", "320kbps"];
        if (!listFormat.includes(formatId)) throw Error(`Invalid formatId for mp3. Available: ${listFormat.join(", ")}`);

        const match = formatId.match(/(\d+)kbps/);
        return {
            link,
            format: "mp3",
            audioBitrate: match[1],
            filenameStyle: "pretty",
            vCodec: "h264"
        };
    },

    convert: async (youtubeUrl, formatId) => {
        const { key } = await y2mate.getKey();
        const headers = {
            "content-type": "application/x-www-form-urlencoded",
            "Key": key,
            "origin": "https://iframe.y2meta-uk.com",
            "referer": "https://iframe.y2meta-uk.com/",
            ...y2mate.headers
        };
        const payload = y2mate.handleFormat(youtubeUrl, formatId);
        const body = new URLSearchParams(payload);

        const res = await fetch(`https://api.mp3youtube.cc/v2/converter`, { headers, method: "POST", body });
        if (!res.ok) throw Error(`Failed convert y2mate ${res.status}`);
        const json = await res.json();
        json.chosenFormat = formatId;
        return json;
    }
};

// YTMP3.MOBI: untuk MP4
const ytmp3mobi = async (youtubeUrl, format = "mp4") => {
    const regYoutubeId = /https:\/\/(www.youtube.com\/watch\?v=|youtu.be\/|youtube.com\/shorts\/|youtube.com\/watch\?v=)([^&|^?]+)/;
    const videoId = youtubeUrl.match(regYoutubeId)?.[2];
    if (!videoId) throw Error("Invalid YouTube URL");

    const urlParam = {
        v: videoId,
        f: format,
        _: Math.random()
    };

    const headers = { "Referer": "https://id.ytmp3.mobi/" };

    const fetchJson = async (url, desc) => {
        const res = await fetch(url, { headers });
        if (!res.ok) throw Error(`Fetch failed (${desc}): ${res.status} ${res.statusText}`);
        return await res.json();
    };

    const { convertURL } = await fetchJson("https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=" + Math.random(), "init");
    const { progressURL, downloadURL } = await fetchJson(`${convertURL}&${new URLSearchParams(urlParam)}`, "get downloadURL");

    let { error, progress, title } = {};
    while (progress != 3) {
        ({ error, progress, title } = await fetchJson(progressURL, "progress"));
        if (error) throw Error(`Conversion error: ${error}`);
    }
    return { title, downloadURL };
};

// MAIN HANDLER
const handler = async (req, res, formatId = "128kbps") => {
    try {
        const { url } = req.query;
        if (!url) return res.status(400).json({ status: false, message: "Parameter url diperlukan" });

        // Metadata from Savetube
        const meta = await savetube.info(url);

        let result;
        if (formatId.endsWith("kbps")) {
            // MP3 pakai y2mate
            result = await y2mate.convert(url, formatId);
        } else {
            // MP4 pakai ytmp3.mobi
            result = await ytmp3mobi(url, "mp4");
        }

        const ytId = savetube.youtube(url);

        res.json({
            status: true,
            creator: "ZenzzXD",
            title: meta.title || result.title || "Unknown Title",
            duration: meta.duration || "unknown",
            thumbnail: meta.thumbnail || (ytId ? `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg` : null),
            type: formatId.endsWith("kbps") ? "audio" : "video",
            format: formatId,
            download_url: result.url || result.downloadURL,
        });
    } catch (err) {
        console.error("[Error Handler]", err);
        res.status(500).json({
            status: false,
            creator: "ZenzzXD",
            message: err.message,
        });
    }
};

module.exports = function (app) {
    app.get("/downloader/ytmp3", (req, res) => handler(req, res, "128kbps")); // default audio 128kbps
    app.get("/downloader/ytmp4", (req, res) => handler(req, res, "720p"));    // default video 720p
};
