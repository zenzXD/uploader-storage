import { jidNormalizedUser } from '@whiskeysockets/baileys';
import lid from './lid.js';
import models from './models.js';
import { fileURLToPath } from 'url';

const processedMessages = new Set();

export default (lulli, chat) => {
    if (processedMessages.has(chat.key.id)) return;
    processedMessages.add(chat.key.id);
    if (chat.key && chat.key.remoteJid === 'status@broadcast') return
    const chatId = chat.key.remoteJid;
    const botId = jidNormalizedUser(lulli.user.id || lulli.user.jid);
    const userId = lid.getSenderJid(lulli, chat.key);
    const pushname = chat.pushName || '-'

    // Database User
    if (/^\d.*(@s\.whatsapp\.net)$/.test(userId)) {
        let user = global.db.users[userId];
        if (user) {
            execute(user, models.users);
        } else {
            global.db.users[userId] = {
                jid: userId,
                name: pushname,
                ...(models?.users || {})
            }
        }
    }

    // Database Group
    if (/^\d.*(@g\.us)$/.test(chatId)) {
        let group = global.db.groups[chatId];
        if (group) {
            execute(group, models.groups);
        } else {
            let metadata = global.db.metadata[chatId];
            let subject = metadata?.subject || '';
            let owner = metadata?.owner || '';
            global.db.groups[chatId] = {
                jid: chatId,
                name: subject,
                owner,
                ...(models?.groups || {})
            }
        }
    }

    // Database Setting
    let setting = global.db.setting[botId];
    if (setting) {
        execute(setting, models.settings)
    } else {
        global.db.setting[botId] = {
            ...(models?.settings || {})
        }
    }
}

function isType(val, type) {
    const typeCheckers = {
        number: val => typeof val === 'number' && !isNaN(val),
        string: val => typeof val === 'string',
        object: val => val !== null && typeof val === 'object' && !Array.isArray(val),
        boolean: val => typeof val === 'boolean',
        array: val => Array.isArray(val),
    };
    return typeCheckers[type] ? typeCheckers[type](val) : false;
}

function execute(prefix, template, custom = {}) {
    Object.keys(template).forEach(key => {
        const defaultValue = template[key];
        const type = Array.isArray(defaultValue) ? 'array' : typeof defaultValue;

        if (!(key in prefix) || !isType(prefix[key], type)) {
            prefix[key] = defaultValue;
        }
    });

    Object.keys(custom).forEach(key => {
        if (!(key in prefix)) {
            prefix[key] = custom[key];
        }
    });
}