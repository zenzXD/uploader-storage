import fs from 'fs/promises';

import * as mongodb from './mongodb.js';
import * as localdb from './localdb.js';

class MultiDB {
    constructor() {
        this.MongoURL = global.cfg?.mongoUrl;

        if (this.MongoURL && /mongo/.test(this.MongoURL)) {
            this.init = new mongodb.default(this.MongoURL);
        } else {
            this.init = new localdb.default();
        }
    }

    initDatabase = async () => {
        let content = {};

        try {
            if (!(this.MongoURL && /mongo/.test(this.MongoURL))) {
                const data = await fs.readFile('./database/database.json', 'utf8');
                content = JSON.parse(data);
            }
        } catch (error) {
            console.error("Error reading database file:", error);
        }

        global.db = {
            users: {},
            groups: {},
            statistic: {},
            sticker: {},
            stickercmd: {},
            setting: {},
            menfes: {},
            tictactoe: {},
            petakbom: {},
            casino: {},
            chess: {},
            metadata: {},
            premium: {},
            sewabot: {},
            server: {},
            panel: {},
            renewpanel: {},
            autodonation: {
                status: false,
                amount: 519,
                lastDay: -1,
                lastTime: '08:36',
                taskDay: false,
                taskPayment: false,
                keyId: null
            },
            jadibot: [],
            owner: [],
            developer: [],
            blockcmd: [],
            paydata: [],
            testi: [],
            error: [],
            limit: {
                max: 5,
                data: []
            },
            burden: [],
            ...(await this.init.read() || content)
        };

        try {
            await this.init.save(global.db);
        } catch (error) {
            console.error("Error saving database:", error.message);
        }
    }
};

export default new MultiDB();