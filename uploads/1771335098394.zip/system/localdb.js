import fs from 'fs/promises';
import path from 'path';
import stable from 'json-stable-stringify';

export default class Database {
    constructor(name) {
        this.name = 'database.json';
        this.data = {};
        this.file = path.join(process.cwd(), 'database', this.name);
        this.backupFile = path.join(process.cwd(), 'database', 'database.bak');
    }

    read = async () => {
        let database;
        try {
            const fileContent = await fs.readFile(this.file, 'utf-8');
            if (fileContent.trim() === '') {
                console.log('File database kosong, mengembalikan dari backup...');
                const backupContent = await fs.readFile(this.backupFile, 'utf-8');
                database = JSON.parse(backupContent);
                await fs.writeFile(this.file, JSON.stringify(database, null, 2));
            } else {
                database = JSON.parse(fileContent);
            }
        } catch (error) {
            if (error.code === 'ENOENT') {
                console.log('File database tidak ada, membuat file baru...');
                await fs.writeFile(this.file, JSON.stringify(this.data, null, 2));
                database = this.data;
            } else {
                console.error('Error membaca file:', error);
                throw error;
            }
        }
        return database;
    }

    save = async data => {
        this.data = !!data ? data : global.db;
        let dirname = path.dirname(this.file);
        try {
            await fs.mkdir(dirname, { recursive: true });
            await fs.writeFile(this.file, JSON.stringify(this.data, null, 2));
            await fs.writeFile(this.backupFile, stable(this.data));
        } catch (error) {
            console.error('Error menyimpan file:', error);
            throw error;
        }
        return this.file;
    }
}