import moment from 'moment-timezone';
import chalk from 'chalk';
import cron from 'node-cron';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import func from './functions.js';
import socket from './socket.js';
import multidb from './multidb.js';
import {
    start as startBotSession
} from './jadibot.js'
import {
    createDelay,
} from './utils.js';

let alreadyRan = false;
let isCheckingSewa = false;
let events = new Set();

export default async (clients) => {
    const botId = clients.user.id ? clients.user.id.split(':')[0] + '@s.whatsapp.net' : clients.user.jid;
    const setting = global.db.setting[botId] || {};
    const ownerId = global.cfg.owner || '62895415497664@s.whatsapp.net';

    cron.schedule('0 0 0 * * *', async () => {
        if (!alreadyRan) {
            alreadyRan = true;
            Object.entries(global.db.statistic).forEach(([_, data]) => data.hittoday = 0);
            if (global.db.limit?.data && Array.isArray(global.db.limit.data) && global.db.limit.data.length > 0) {
                global.db.limit.data = [];
            }
            Object.values(global.db.groups).map(group => group.absen = {});
            const {
                name,
                size
            } = await func.backupSC();
            const caption = `✦ Berikut adalah file backup kode bot:\n- Nama file: ${name}\n- Ukuran file: ${size} MB`;
            await clients.sendMessage(ownerId, {
                document: {
                    url: name
                },
                caption: caption,
                mimetype: 'application/zip',
                fileName: name
            }, {
                quoted: func.fstatus('Automatic Script Backup')
            }).then(() => fsp.unlink(name));
        }
    }, {
        scheduled: true,
        timezone: 'Asia/Jakarta'
    });

    const isPastTime = (milliseconds) => milliseconds < Date.now();
    const isExcept = (expire) => /^PERMANENT/.test(expire);

    const checkExpiredUsers = () => {
        for (let [id, user] of Object.entries(global.db.users)) {
            if (!user.banned && user.expired.user && isPastTime(user.expired.user)) {
                console.log(chalk.green(`✓ Expired User: ${user.name}`));
                delete global.db.users[id];
            }
        }
    };

    const checkExpiredGroups = () => {
        for (let [id, group] of Object.entries(global.db.groups)) {
            if (!group.banned && group.expired && isPastTime(group.expired)) {
                console.log(chalk.green(`✓ Expired Group: ${group.name}`));
                delete global.db.groups[id];
                global.db.metadata[id] && delete global.db.metadata[id];
            }
        }
    };

    const checkExpiredPremium = async () => {
        for (let [id, user] of Object.entries(global.db.users)) {
            try {
                if (user.premium && user.expired.premium && !isExcept(user.expired.premium) && isPastTime(user.expired.premium)) {
                    await clients.sendMessageTestimony(`✦ Paket premium ${global.db.users[id]?.name || '@' + id.split('@')[0]} telah berakhir, terimakasih telah membeli dan menggunakan layanan kami.`);
                    user.expired.premium = 0;
                    user.premium = false;
                    user.limit = setting.limit.free;
                }
            } catch (error) {
                console.error(chalk.red(`✗ Error checking expired premium for ${id}: ${error.message}`));
                user.expired.premium = 0;
                user.premium = false;
                user.limit = setting.limit.free;
            }
        }
    };

    const checkExpiredJadibot = async () => {
        for (let [number, user] of Object.entries(global.db.users)) {
            if (user.jadibot && user.expired.jadibot && !isExcept(user.expired.jadibot) && isPastTime(user.expired.jadibot)) {
                await clients.sendMessageTestimony(`✦ Paket jadibot ${global.db.users[number]?.name || '@' + number.split('@')[0]} telah berakhir, terimakasih telah membeli dan menggunakan layanan kami.`);
                user.expired.jadibot = 0;
                user.jadibot = false;
                const index = global.db.jadibot.findIndex(v => v.number === number);
                if (index !== -1 && socket.cek(number)) {
                    const client = socket.get(number);
                    socket.delete(number);
                    global.db.jadibot[index].status = false;
                    await client.end();
                    client.ws.close();
                }
            }
        }
    };

    const checkExpiredBanned = async () => {
        for (let [id, user] of Object.entries(global.db.users)) {
            try {
                if (user.banned && user.expired.banned && !isExcept(user.expired.banned) && isPastTime(user.expired.banned)) {
                    await clients.sendMessageTestimony(`✦ Banned pada ${global.db.users[id]?.name || '@' + id.split('@')[0]} telah berakhir. Jangan melanggar rules agar tidak terbanned lagi.`);
                    user.expired.banned = 0;
                    user.banned = false;
                }
            } catch (error) {
                console.error(chalk.red(`✗ Error checking expired banned for ${id}: ${error.message}`));
                user.expired.banned = 0;
                user.banned = false;
            }
        }
    };

    function checkGroupOwner(groupId) {
        for (const item of Object.values(global.db.sewa)) {
            const groupData = item.data.find(group => group.id === groupId);

            if (groupData) {
                return {
                    jid: item.jid,
                    id: groupData.id,
                    subject: groupData.subject
                };
            }
        }
        return null;
    }

    const checkExpiredSewa = async () => {
        if (isCheckingSewa) {
            console.log("[CHECK SEWA] Proses sebelumnya masih berjalan, skip eksekusi ini.");
            return;
        }

        isCheckingSewa = true;

        try {
            const groupsToProcess = Object.entries(global.db.groups).filter(([groupId, group]) => {
                return group.sewa && group.sewa.status && group.sewa.expired &&
                    !isExcept(group.sewa.expired) && isPastTime(group.sewa.expired);
            });

            if (groupsToProcess.length === 0) {
                // console.log("[CHECK SEWA] Tidak ada grup dengan sewa expired.");
                isCheckingSewa = false;
                return
            }

            for (const [groupId, group] of groupsToProcess) {
                console.log(`[SEWA EXPIRING] Memproses grup: ${group.name} (${groupId})`);
                try {
                    let messageSent = false;
                    let metadata = global.db.metadata[groupId] || false;
                    let mentions = (metadata && metadata.participants) ? metadata.participants.map(x => x.id) : [];

                    if (await clients.checkInGroup(groupId)) {
                        await clients.sendMessage(groupId, {
                            text: `*Waktu sewa bot sudah habis~*\n\n*Jangan lupa perpanjang sewanya ya biar aku tetap bisa nemenin grup ini~*`,
                            mentions
                        }, {
                            quoted: null,
                            ephemeralExpiration: 7776000
                        });
                        messageSent = true;
                        console.log(`[SEWA EXPIRING] Notif berhasil dikirim oleh bot utama ke group: ${groupId}`);
                    } else {
                        const allSockets = socket.getAllSockets().filter(x => x.user);
                        for (const sock of allSockets) {
                            if (!messageSent && await sock.checkInGroup(groupId)) {
                                await sock.sendMessage(groupId, {
                                    text: `*Waktu sewa bot sudah habis~*\n\n*Jangan lupa perpanjang sewanya ya biar aku tetap bisa nemenin grup ini~*`,
                                    mentions
                                }, {
                                    quoted: null,
                                    ephemeralExpiration: 7776000
                                });
                                messageSent = true;
                                console.log(`[SEWA EXPIRING] Notif berhasil dikirim oleh bot clone (${sock.user.id}) ke group: ${groupId}`);
                                break;
                            }
                        }
                    }

                    const allBotsToLeave = socket.getAllSockets().filter(x => x.user);
                    for (let sock of allBotsToLeave) {
                        if (await sock.checkInGroup(groupId)) {
                            await sock.groupLeave(groupId);
                            console.log(`[SEWA EXPIRING] Bot (${sock.user ? sock.user.id : 'utama'}) berhasil leave group: ${groupId}`);
                            await createDelay(1000);
                        }
                    }

                    group.sewa.expired = 0;
                    group.sewa.status = false;
                    func.logAndWrite('sewa', `✓ Sewa Expire for ${group.name}`);
                    await createDelay(5000);
                } catch (error) {
                    console.error(chalk.red(`✗ Error in checkExpiredSewa for group ${groupId}: ${error.message}`));
                    group.sewa.status = false;
                    group.sewa.expired = 0;
                }
            }
        } catch (error) {
            console.error(chalk.red(`✗ Error in checkExpiredSewa: ${error.message}`));
        } finally {
            isCheckingSewa = false;
        }
    };

    const checkExpiredPanel = async () => {
        for (const [id, server] of Object.entries(global.db.server)) {
            if (server.data && server.data.length > 0) {
                const expiredData = server.data.filter(data => isPastTime(data.expired));
                for (const data of expiredData) {
                    console.log(chalk.red(`✗ Server ${data.username} has expired`));
                    await clients.sendMessage(ownerId, {
                        text: `✦ server @${id.split('@')[0]} (${data.username}) has expired and the server has been suspended.`,
                        mentions: [id]
                    }, {
                        quoted: null,
                        ephemeralExpiration: 0
                    });
                    if (data.id != null) {
                        try {
                            await fetch(`${global.cfg.panelApi.domain}/api/application/servers/${data.id}/suspend`, {
                                "method": "POST",
                                "headers": {
                                    "Accept": "application/json",
                                    "Content-Type": "application/json",
                                    "Authorization": "Bearer " + global.cfg.panelApi.apikey,
                                }
                            });
                        } catch (error) {
                            func.logAndWrite('events', `✗ Panel API error: ${error.message}`);
                        }
                    }
                    await createDelay(1000);
                }
                server.data = server.data.filter(data => !isPastTime(data.expired));
            }
        }
    };

    let interval = setInterval(async () => {
        await Promise.allSettled([
            checkExpiredUsers(),
            checkExpiredGroups(),
            checkExpiredPremium(),
            checkExpiredBanned(),
            checkExpiredSewa(),
            checkExpiredPanel(),
            checkExpiredJadibot()
        ]);

        let seconds = Number(process.uptime());
        let menit = Math.floor(seconds / 60);
        let timeset = 720 / 2;
        if (menit >= timeset) {
            clearInterval(interval);
            clients.reply(ownerId, `✦ Bot sudah berjalan selama \`${timeset / 60} jam\`, system me-restart bot secara otomatis untuk mengindari delay.`, func.fverified()).then(async () => {
                await multidb.init.save(global.db);
                process.exit(0);
            });
        }
    }, 1000 * 60);

    async function sendRestartNotif() {
        const restart = await func.restarting();
        if (restart) {
            try {
                const chatId = restart.jid;
                if (chatId.endsWith('@g.us') && !(await clients.checkInGroup(chatId))) return false;

                await clients.sendMessage(chatId, {
                    text: func.texted('monospace', '✓ Bot berhasil di restart.')
                }, {
                    quoted: null,
                    ephemeralExpiration: restart.expiration
                });
                return true;
            } catch (e) {
                console.error(chalk.red("✗ Gagal kirim notif restart:", e.message));
                return false;
            }
        }
        return false;
    }

    async function autoConnectJadibot() {
        // Auto Connect Jadibot
        for (let bot of global.db.jadibot) {
            if (bot.status && global.db.users[bot.number]?.jadibot && fs.existsSync(`${bot.session}/creds.json`) && !socket.cek(bot.number)) {
                await startBotSession(clients, bot.number);
                await createDelay(10000);
            }
        }
    }

    await Promise.allSettled([
        sendRestartNotif(),
        autoConnectJadibot(),
    ]);
};