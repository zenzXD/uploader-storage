const groupLink = 'https://chat.whatsapp.com/BgrnHVRRpRaJKHN7AxGYEa';

const main = async (m, lulli, { func, groups }) => {
    try {
        const isSewa = global.db.sewabot && global.db.sewabot[m.sender]?.session === 'link_group';
        if (!m.budy || m.isAdmin || m.isOwner || m.isDevs || isSewa) return;

        const linkRegex = /chat\.whatsapp\.com\/([a-zA-Z0-9]+)/;
        const foundLink = m.budy.match(linkRegex);

        if (!foundLink) return;

        let currentGroupInviteCode = null;
        if (m.isBotAdmin) {
            currentGroupInviteCode = await lulli.groupInviteCode(m.chat).catch(() => null);
        }
        const currentGroupLink = currentGroupInviteCode ? `chat.whatsapp.com/${currentGroupInviteCode}` : null;
        const allowedLinks = [groupLink.match(linkRegex)?.[0], currentGroupLink].filter(Boolean);
        if (allowedLinks.includes(foundLink[0])) return;
        await lulli.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.sender
            }
        });

        if (groups.antilink) {
            await lulli.sendMessage(m.chat, {
                text: `✗ Maaf @${m.sender.split('@')[0]}, link grup lain dilarang.`,
                mentions: [m.sender]
            }, {
                quoted: func.fstatus('Anti Tautan Grup Lain'),
                ephemeralExpiration: m.expiration
            });
            if (m.isBotAdmin) {
                await lulli.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            } else {
                console.warn(`✗ AntiLink] Bot bukan admin di grup ${m.chat}, tidak bisa kick ${m.sender}`);
            }
        }

    } catch (e) {
        console.error("✗ Error in _antilink.js:", e);
        return m.reply(cfg.mess.wrong(e.message));
    }
};

export default {
    main,
    group: true,
    botAdmin: true,
    location: 'plugins/event/_antilink.js'
};