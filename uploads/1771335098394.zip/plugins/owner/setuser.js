const run = async (m, lulli, { func, froms }) => {
    if (!m.quoted || !m.quoted.sender) {
        return m.reply(`✗ Reply chat target dengan caption ${m.prefix}${m.command} <nama>,<umur>,<gender>`);
    }

    const targetJid = froms;
    global.db.users = global.db.users || {};
    let user = global.db.users[targetJid];
    if (!user) {
        return m.reply('✗ Data pengguna tidak ditemukan. Pastikan pengguna ini pernah interaksi sama bot.');
    }

    const [name, ageStr, gender] = m.text.split(',').map(words => words.trim());
    if (!(name && ageStr && gender)) {
        return m.reply(func.example(m.cmd, 'Surya,19,male'));
    }

    const age = parseInt(ageStr, 10);
    if (isNaN(age)) return m.reply('✗ Umur harus berupa angka.');
    if (age < 11) return m.reply('✗ Umur minimal harus di atas 10 tahun.');
    if (age >= 50) return m.reply('✗ Umur maksimal tidak boleh lebih dari 50 tahun.');
    if (!/^(male|female)$/i.test(gender)) return m.reply('✗ Jenis kelamin harus `male` atau `female`.');

    user.name = name;
    user.age = age;
    user.gender = /^male$/i.test(gender) ? 'Laki-laki' : 'Perempuan';
    user.register = true;

    await m.reply(`✓ Berhasil mengatur data personal pengguna @${targetJid.replace(/@.+/, '')}.`);
};

export default {
    run,
    cmd: 'setuser',
    type: 'owner',
    owner: true,
    location: 'plugins/owner/setuser.js'
};