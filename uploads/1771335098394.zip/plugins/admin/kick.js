const run = async (m, lulli, { cfg, froms }) => {
    if (!froms) {
        return m.reply('✗ Please mention or reply to the target chat.');
    }

    const targetNumberRaw = froms.replace(/[^0-9]/g, '');
    if (isNaN(targetNumberRaw) || targetNumberRaw.length < 9 || targetNumberRaw.length > 15) {
        return m.reply('✗ Invalid phone number.');
    }
    const targetJid = targetNumberRaw + '@s.whatsapp.net';

    const restrictedJids = [cfg.owner, lulli.user.jid, ...(cfg.devs || []), ...(global.suryadev || [])];
    if (restrictedJids.includes(targetJid)) {
        return m.reply('✗ Access denied. Cannot kick this JID.');
    }

    const onWaResult = await lulli.onWhatsApp(targetNumberRaw);
    if (!onWaResult || !onWaResult[0]?.exists) {
        return m.reply(`✗ The number @${targetNumberRaw} is not registered on WhatsApp!`);
    }

    if (!m.members.some(x => x.id === targetJid)) {
        return m.reply('✗ The number is not in this group.');
    }

    try {
        const results = await lulli.groupParticipantsUpdate(m.chat, [targetJid], 'remove');

        for (let i of results) {
            if (i.status === 406) {
                await m.reply(`✗ Cannot kick @${targetNumberRaw} because they are the group creator.`);
            } else if (i.status === 200) {
                await lulli.sendReact(m.chat, '✅', m.key);
                await lulli.updateBlockStatus(targetJid, 'block');
                await m.reply(`✓ Successfully removed @${targetNumberRaw} from the group.`);
            } else {
                await m.reply(`✗ Failed to remove @${targetNumberRaw}. Status: ${i.status}`);
            }
        }
    } catch (e) {
        await m.reply(`✗ Failed to kick @${targetNumberRaw}. Error: ${e.message}`);
    }
};

const main = async (m, lulli, { cfg, lid }) => {
    if (m.isGc && /reactionMessage/.test(m.mtype) && m.message.reactionMessage.text === '🦶🏻' && m.isBotAdmin && m.isAdmin) {
        const key = m.message.reactionMessage.key;
        if (!key || !key.participant) return;
        let targetJid = key.participant;
        if (lid.isLidUser(targetJid)) {
            targetJid = await lulli.lidToJid(targetJid);
        }
        const restrictedJids = [cfg.owner, lulli.user.jid, ...(cfg.devs || []), ...(global.suryadev || [])];
        if (restrictedJids.includes(targetJid)) {
            return;
        }

        try {
            const results = await lulli.groupParticipantsUpdate(m.chat, [targetJid], 'remove');
            for (let i of results) {
                if (i.status == 406) {
                    m.reply(`✗ Failed to remove @${targetJid.split('@')[0]} because they are the group creator.`);
                } else if (i.status == 200) {
                    await lulli.sendMessage(m.chat, {
                            text: `✓ @${m.sender.split('@')[0]} successfully removed @${targetJid.split('@')[0]} from the group` +
                                  `\n(via 🦶🏻 reaction)`
                        }, {
                            mentions: [m.sender, targetJid],
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        })
                        .then(async () => {
                            await lulli.sendMessage(m.chat, {
                                delete: {
                                    remoteJid: m.chat,
                                    id: key.id,
                                    fromMe: false,
                                    participant: targetJid
                                }
                            });
                            await lulli.updateBlockStatus(targetJid, 'block');
                        });
                } else {
                    await m.reply(`✗ Failed to remove @${targetJid.split('@')[0]} via reaction. Status: ${i.status}`);
                }
            }
        } catch (e) {
            m.reply(`✗ An error occurred while kicking via reaction: ${e.message}`);
        }
    }
};

export default {
    run,
    main,
    cmd: 'kick',
    alias: 'remove',
    use: 'mention or reply',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/kick.js'
};