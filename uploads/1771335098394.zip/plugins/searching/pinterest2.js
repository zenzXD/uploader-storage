import axios from 'axios';

const SEARCH_API = 'https://api-faa.my.id/faa/pinterest?q=';
const DOWNLOAD_API = 'https://api-faa.my.id/faa/pin-down?url=';

// Fungsi acak array
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

export const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(`Contoh penggunaan:\n${m.cmd} boboiboy galaxy\n${m.cmd} dl https://pin.it/xxxxxx`);
    }

    lulli.sendReact(m.chat, '🕒', m.key);

    // Konfigurasi Axios agar tidak kena 403 (Bypass sederhana)
    const axiosConfig = {
        timeout: 15000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    };

    try {
        const text = m.text.trim();
        const args = text.split(/\s+/);
        const command = args[0]?.toLowerCase();

        // === MODE DOWNLOAD ===
        if (command === 'dl' || command === 'download') {
            const url = args[1];
            if (!url || (!url.includes('pin.it') && !url.includes('/pin/'))) {
                return m.reply(`Masukkan link pin yang valid!\nContoh: ${m.cmd} dl https://pin.it/732sqX53q`);
            }

            const apiUrl = DOWNLOAD_API + encodeURIComponent(url);
            const { data } = await axios.get(apiUrl, axiosConfig);

            if (!data?.status || !data?.result?.medias?.length) {
                return m.reply('Gagal mengambil media. API sedang down atau link tidak valid.');
            }

            const result = data.result;
            const medias = result.medias.slice(0, 3);

            let caption = `✦ *PINTEREST DOWNLOADER*\n\n` +
                          `• Judul: ${result.title || 'Tidak ada judul'}\n` +
                          `• Media: ${medias.length} item\n` +
                          `• Link: ${url}`;

            let lastMessage = m;

            // Kirim thumbnail/info awal
            if (result.thumbnail) {
                lastMessage = await lulli.sendMessage(m.chat, {
                    image: { url: result.thumbnail },
                    caption: caption + '\n\n*Sedang mengirim media...*'
                }, { quoted: m, ephemeralExpiration: m.expiration });
            }

            // Kirim semua media (Looping)
            for (let i = 0; i < medias.length; i++) {
                await func.delay(1500); // Delay agak lama agar tidak kena limit
                const media = medias[i];
                const mediaCap = medias.length > 1 ? `Media (${i + 1}/${medias.length})` : '';

                if (media.type === 'image' || media.type === 'photo') {
                    lastMessage = await lulli.sendMessage(m.chat, {
                        image: { url: media.url },
                        caption: mediaCap,
                        mimetype: 'image/jpeg'
                    }, { quoted: lastMessage });
                } else if (media.type === 'video') {
                    lastMessage = await lulli.sendMessage(m.chat, {
                        video: { url: media.url },
                        caption: mediaCap,
                        mimetype: 'video/mp4'
                    }, { quoted: lastMessage });
                }
            }

            lulli.sendReact(m.chat, '✅', m.key);
            return;
        }

        // === MODE SEARCH ===
        const query = text;
        const apiUrl = SEARCH_API + encodeURIComponent(query);
        const { data } = await axios.get(apiUrl, axiosConfig);

        if (!data?.status || !Array.isArray(data.result) || data.result.length === 0) {
            return m.reply(`Tidak ditemukan hasil untuk "${query}"`);
        }

        let images = data.result;
        shuffleArray(images);
        images = m.isPrem ? images.slice(0, 5) : images.slice(0, 2);

        let sentCount = 0;
        let lastSent = m;

        const header = `✦ *PINTEREST SEARCH*\n\n` +
                       `Query: ${query}\n` +
                       `Menampilkan ${images.length} hasil terpilih.\n\n` +
                       `Gunakan *${m.cmd} dl [link]* untuk download video/HD.`;

        for (let i = 0; i < images.length; i++) {
            await func.delay(1200);
            const isFirst = i === 0;
            
            lastSent = await lulli.sendMessage(m.chat, {
                image: { url: images[i] },
                caption: isFirst ? header : `Hasil ${i + 1} • ${query}`
            }, { quoted: isFirst ? m : lastSent });
            
            sentCount++;
        }

        lulli.sendReact(m.chat, '✅', m.key);

    } catch (error) {
        console.error('Pinterest error:', error.message);
        lulli.sendReact(m.chat, '❌', m.key);

        let errorMsg = error.response?.status === 403 ? 'Akses API Ditolak (CORS/Forbidden 403)' : error.message;
        m.reply(`*Terjadi Kesalahan!*\nMsg: ${errorMsg}`);
    }
};

export default {
    run,
    cmd: 'pinterest',
    alias: ['pin', 'pin'],
    use: '<query> atau dl <link>',
    type: 'searching',
    restrict: true,
    premium: false,
    location: 'plugins/searching/pinterest'
};