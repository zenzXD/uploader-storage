import axios from 'axios'
import {
    generateWAMessageContent,
    generateWAMessageFromContent,
    proto,
} from '@whiskeysockets/baileys';
const SEARCH_API = 'https://api-faa.my.id/faa/pinterest?q=';
const run = async (m, lulli, {
    func
}) => {
    const query = m.text
    if (!query) return m.reply(func.example(m.cmd, 'pohon'))
    await lulli.sendReact(m.chat, '🔍', m.key)
    const axiosConfig = {
        timeout: 15000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    };
    let caption = '```Result from:```' + '\t`' + query + '`'
    async function createImage(url) {
        const {
            imageMessage
        } = await generateWAMessageContent({
            image: {
                url: url
            }
        }, {
            upload: lulli.waUploadToServer
        });
        return imageMessage;
    }
    function shuffleArray(arr) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]]
        }
    }
    try {
        const apiUrl = SEARCH_API + encodeURIComponent(query);
        const {
            data
        } = await axios.get(apiUrl, axiosConfig);
        if (!data?.status || !Array.isArray(data.result) || data.result.length === 0) {
            return m.reply(`Tidak ditemukan hasil untuk "${query}"`);
        }
        let cards = [];
        let images = data.result;
        shuffleArray(images)
        let selected = images.slice(0, 10)
        await lulli.sendMessage(m.chat, {
            text: `Hai @${m.sender.split('@')[0]} \nBerikut hasil pencarian Pinterest untuk:\n*${query}*`,
            mentions: [m.sender]
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        })
        for (let [index, url] of selected.entries()) {
            if (typeof url !== 'string') continue
            cards.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `${images.length > 1 ? `Image *(${index + 1}/${selected.length})*` : env.mess.ok}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: 'Powered by : www.pinterest.com'
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    hasMediaAttachment: true,
                    imageMessage: await createImage(url)
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: 'Source Url',
                            url: `https://www.pinterest.com/search/pins/?rs=typed&q=${query}`,
                            merchant_url: `https://www.pinterest.com/search/pins/?rs=typed&q=${query}`
                        })
                    }]
                })
            });
        }
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: '```Result from:```'
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: '`' + caption + '`'
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: cards
                        })
                    })
                }
            }
        }, {});
        await lulli.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });
        await lulli.sendReact(m.chat, '✅', m.key)
    } catch (e) {
        console.error('Pinterest Search Error:', e)
        await lulli.sendReact(m.chat, '❌', m.key)
        m.reply(`❌ Terjadi kesalahan: ${e.message}`)
    }
}
export default {
    run,
    cmd: 'pinterest2',
    alias: ['pin2', 'pints2'],
    use: '<query>',
    type: 'searching',
    restrict: true,
    premium: false,
    location: 'plugins/searching/pinterest2.js'
}