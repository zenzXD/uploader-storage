import axios from 'axios';
import ffmpeg from 'fluent-ffmpeg';
import { path as ffmpegPath } from '@ffmpeg-installer/ffmpeg';
import fs from 'fs';
import path from 'path';
import { pipeline } from 'stream/promises';

ffmpeg.setFfmpegPath(ffmpegPath);

// --- UTILS ---
const chunkArray = (arr, size) => Array.from({ length: Math.ceil(arr.length / size) }, (v, i) => arr.slice(i * size, i * size + size));

/**
 * Mengubah detik menjadi format MM:SS
 * @param {number} seconds 
 * @returns {string} 00:00
 */
const formatDuration = (seconds) => {
    if (!seconds) return "00:00";
    const min = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
};

/**
 * Mengubah angka besar menjadi format K/M (Opsional untuk Likes)
 */
const formatLikes = (num) => {
    if (!num) return "0";
    return Intl.NumberFormat('en-US', {
        notation: "compact",
        maximumFractionDigits: 1
    }).format(num);
};

// --- MERGE ENGINE (FAST CONCAT) ---
const mergeVideos = async (filePaths, outputPath) => {
    return new Promise((resolve, reject) => {
        const command = ffmpeg();
        
        // Input semua file lokal
        filePaths.forEach(fp => command.input(fp));

        // Complex Filter: Scale video ke 540p (tetap) & normalisasi audio
        // setsar=1:1 untuk menghindari masalah aspect ratio
        // const filter = filePaths.map((_, i) => `[${i}:v]scale=trunc(oh*a/2)*2:360,setsar=1:1[v${i}];[${i}:a]aresample=44100[a${i}]`).join(';');
        const filter = filePaths.map((_, i) => `[${i}:v]scale=trunc(oh*a/2)*2:720,setsar=1:1[v${i}];[${i}:a]aresample=44100[a${i}]`).join(';');
        const concat = filePaths.map((_, i) => `[v${i}][a${i}]`).join('') + `concat=n=${filePaths.length}:v=1:a=1[v][a]`;

command
    .complexFilter([filter, concat], ['v', 'a'])
    .videoCodec('libx264')
    .audioCodec('aac')
    .outputOptions([
        '-preset veryfast', // Kecepatan render yang seimbang
        '-crf 30',          // KUNCINYA DI SINI: Naikkan ke 30 (28-32) untuk menekan size tanpa merusak mata
        '-maxrate 1.5M',    // Membatasi bitrate agar file tidak membengkak
        '-bufsize 3M',
                '-movflags +faststart' // Biar video bisa langsung di-play di WA
            ])
            .on('error', (err) => {
                console.error('FFmpeg Detailed Error:', err);
                reject(err);
            })
            .on('end', () => resolve(outputPath))
            .save(outputPath);
    });
};

const generateRandomId = (length = 19) => {
    let result = '';
    result += Math.floor(Math.random() * 9) + 1; 
    for (let i = 1; i < length; i++) {
        result += Math.floor(Math.random() * 10);
    }
    return result;
};

const generateOpenUdid = () => {
    return 'xxxxxxxxxxxxxxxx'.replace(/[x]/g, () => {
        return (Math.random() * 16 | 0).toString(16);
    });
};

const generateUUID = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};

const CONFIG = {
    BASE_URL: "https://api.tmtreader.com",
    HEADERS: {
        "Host": "api.tmtreader.com",
        "Accept": "application/json; charset=utf-8,application/x-protobuf",
        "X-Xs-From-Web": "false",
        "Age-Range": "8",
        "Sdk-Version": "2",
        "Passport-Sdk-Version": "50357",
        "X-Vc-Bdturing-Sdk-Version": "2.2.1.i18n",
        "User-Agent": "ScRaPe/9.9 (KaliLinux; Nusantara Os; My/Shannz)" //"com.worldance.drama/49819 (Linux; U; Android 9; in; SM-N976N; Build/QP1A.190711.020;tt-ok/3.12.13.17)",
    },

    COMMON_PARAMS: {
        "iid": generateRandomId(19),
        "device_id": generateRandomId(19),
        "ac": "wifi",
        "channel": "gp",
        "aid": "645713",
        "app_name": "Melolo",
        "version_code": "49819",
        "version_name": "4.9.8",
        "device_platform": "android",
        "os": "android",
        "ssmix": "a",
        "device_type": "Android",
        "device_brand": "Samsung",
        "language": "in",
        "os_api": "28",
        "os_version": "15",
        "openudid": generateOpenUdid(),
        "manifest_version_code": "49819",
        "resolution": "900*1600",
        "dpi": "320",
        "update_version_code": "49819",
        "current_region": "ID",
        "carrier_region": "ID",
        "app_language": "id",
        "sys_language": "in",
        "app_region": "ID",
        "sys_region": "ID",
        "mcc_mnc": "46002",
        "carrier_region_v2": "460",
        "user_language": "id",
        "time_zone": "Asia/Jakarta",
        "ui_language": "in",
        "cdid": generateUUID(),
    }
};

const generateRticket = () => {
    return String(Math.floor(Date.now() * 1000) + Math.floor(Math.random() * 1000));
};

const request = async (method, endpoint, params = {}, data = null, customHeaders = {}) => {
    try {
        const url = `${CONFIG.BASE_URL}${endpoint}`;

        const finalParams = {
            ...CONFIG.COMMON_PARAMS,
            ...params,
            "_rticket": generateRticket()
        };

        const config = {
            method,
            url,
            headers: { ...CONFIG.HEADERS, ...customHeaders },
            params: finalParams,
            data
        };

        const response = await axios(config);
        return response.data;
    } catch (error) {
        const errorMsg = error.response ? JSON.stringify(error.response.data) : error.message;
        throw new Error(`Melolo API Error: ${errorMsg}`);
    }
};

const melolo = {
    search: async (query, offset = 0, limit = 10) => {
        const endpoint = '/i18n_novel/search/page/v1/';
        const params = {
            "search_source_id": "clks###",
            "IsFetchDebug": "false",
            "offset": offset,
            "cancel_search_category_enhance": "false",
            "query": query,
            "limit": limit,
            "search_id": ""
        };

        const json = await request('GET', endpoint, params);
        const searchData = json?.data?.search_data || [];
        const results = [];

        if (Array.isArray(searchData)) {
            searchData.forEach(section => {
                if (section.books && Array.isArray(section.books)) {
                    section.books.forEach(book => {
                        results.push({
                            title: book.book_name,
                            book_id: book.book_id,
                            cover: book.thumb_url,
                            author: book.author,
                            sinopsis: book.abstract,
                            status: book.show_creation_status,
                            tags: book.stat_infos || [],
                            total_chapters: book.serial_count || book.last_chapter_index
                        });
                    });
                }
            });
        }
        
        return results;
    },

    detail: async (bookId) => {
        if (!bookId) throw new Error("Book ID required");

        const endpoint = '/novel/player/video_detail/v1/';

        const headers = {
            "X-Ss-Stub": "238B6268DE1F0B757306031C76B5397E",
            "Content-Type": "application/json; charset=utf-8"
        };

        const payload = {
            "biz_param": {
                "detail_page_version": 0,
                "from_video_id": "",
                "need_all_video_definition": false,
                "need_mp4_align": false,
                "source": 4,
                "use_os_player": false,
                "video_id_type": 1
            },
            "series_id": bookId
        };

        const json = await request('POST', endpoint, {}, payload, headers);
        const data = json?.data?.video_data || {}; 

        let tags = [];
        try {
            if (data.category_schema) {
                const parsed = JSON.parse(data.category_schema);
                tags = parsed.map(cat => cat.name);
            }
        } catch (e) {
            console.warn("Gagal parse category_schema");
        }

        const videoList = data.video_list || [];
        const episodes = videoList.map(v => ({
            video_id: v.vid,
            episode: v.vid_index,
            title: v.title,
            duration: v.duration,
            likes: v.digged_count,
            cover: v.cover
        }));

        return {
            book_id: data.series_id_str || bookId,
            title: data.series_title,
            intro: data.series_intro,
            cover: data.series_cover,
            total_episodes: data.episode_cnt,
            tags: tags,
            status: data.series_status === 1 ? "Ongoing" : "Completed",
            episodes: episodes
        };
    },

    stream: async (videoId) => {
        if (!videoId) throw new Error("Video ID required");

        const endpoint = '/novel/player/video_model/v1/';

        const headers = {
            "X-Ss-Stub": "B7FB786F2CAA8B9EFB7C67A524B73AFB",
            "Content-Type": "application/json; charset=utf-8"
        };

        const payload = {
            "biz_param": {
                "detail_page_version": 0,
                "device_level": 3,
                "from_video_id": "",
                "need_all_video_definition": true,
                "need_mp4_align": false,
                "source": 4,
                "use_os_player": false,
                "video_id_type": 0,
                "video_platform": 3
            },
            "video_id": videoId
        };

        const json = await request('POST', endpoint, {}, payload, headers);
        const raw = json?.data || {};

        let result = {
            status: true,
            url: raw.main_url,
            backup_url: raw.backup_url,
            expire_at: raw.expire_time,
            width: raw.video_width,
            height: raw.video_height,
            metadata: {},
            downloads: []
        };

        try {
            if (raw.video_model) {
                const model = JSON.parse(raw.video_model);
                const thumbs = model.big_thumbs || [];
                result.metadata = {
                    id: model.video_id,
                    duration: model.video_duration,
                    thumbnail: thumbs.length > 0 ? thumbs[0].img_url : null
                };

                if (model.video_list) {
                    Object.values(model.video_list).forEach(item => {
                        let videoUrl = item.main_url;

                        if (videoUrl && !videoUrl.startsWith('http')) {
                            try {
                                videoUrl = Buffer.from(videoUrl, 'base64').toString('utf-8');
                            } catch (err) {
                                console.warn("Gagal decode URL untuk kualitas:", item.definition);
                            }
                        }

                        result.downloads.push({
                            quality: item.definition,
                            size: item.size ? (item.size / 1024 / 1024).toFixed(2) + 'MB' : 'N/A',
                            fps: item.fps,
                            url: videoUrl
                        });
                    });

                    result.downloads.sort((a, b) => b.size - a.size);
                }
            }
        } catch (error) {
            console.error("Error parsing video_model:", error.message);
            result.status = false;
            result.error = "Failed to parse detailed video model";
        }

        return result;
    }
};

// --- HELPER DOWNLOAD ---
const downloadFile = async (url, dest) => {
    const response = await axios({ method: 'GET', url, responseType: 'stream' });
    await pipeline(response.data, fs.createWriteStream(dest));
};

// --- PLUGIN RUNNER ---
const run = async (m, lulli, { func }) => {
    switch (m.command) {
        case 'melolo':
        case 'listmelolo': {
            if (!m.text) return m.reply(`Contoh: ${m.prefix + m.command} selamat tinggal saudaraku`);
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                const results = await melolo.search(m.text);
                if (results.length === 0) {
                    lulli.sendReact(m.chat, '❌', m.key);
                    return m.reply('✗ Drama tidak ditemukan atau data tidak lengkap.');
                }
                let rows = results.filter(book => book.cover && book.author && book.sinopsis && book.status && book.tags && book.total_chapters).map((book, i) => ({
                    header: `${book.author} | ${book.status}`,
                    title: `${i + 1}. ${book.title}`,
                    description: book.sinopsis.substring(0, 50) + '...',
                    id: `${m.prefix}getmelolo ${book.book_id}`
                }));

                const sections = [{ title: '📺 HASIL PENCARIAN DRAMA', rows }];
                const buttons = [[
                    'list', 'Pilih Judul', sections
                ]];
                await lulli.sendButton(m.chat, '✦ *MELOLO SEARCH*', `Ditemukan *${results.length}* hasil untuk: *${m.text}*`, 'Pilih Drama', buttons, m);
                lulli.sendReact(m.chat, '✅', m.key);
            } catch (e) {
                m.reply(`Error: ${e.message}`);
            }
            break;
        }

        case 'getmelolo': {
            if (!m.args[0]) return m.reply('Sertakan ID Drama!');
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                const res = await melolo.detail(m.args[0]);
                let caption = `⋄ Judul: *${res.title}*\n` +
                              `⋄ Status: *${res.status}*\n` +
                              `⋄ Tags: *${res.tags.join(", ")}*\n` + 
                              `⋄ Total Eps: *${res.total_episodes}*\n\n` +
                              `⋄ *Sinopsis:* ${res.intro || '-'}`;

                let rows = res.episodes.map(ep => ({
                    title: `Episode ${ep.episode}`,
                    // description: `Tonton episode ${ep.episode}`,
                    description: `🎥${formatDuration(ep.duration)} || ❤️${formatLikes(ep.likes)}`,
                    id: `${m.prefix}qualitymelolo ${ep.video_id}`
                }));

                const sections = [{ title: 'DAFTAR EPISODE', rows }];
                const buttons = [[
                    'list', 'Pilih Episode', sections
                ]];
                await lulli.sendButton(m.chat, '✦ MELOLO DETAIL', caption, 'Pilih Episode', buttons, m);
                lulli.sendReact(m.chat, '✅', m.key);
            } catch (e) {
                m.reply(`Error: ${e.message}`);
            }
            break;
        }

        /*case 'getmelolo': {
            if (!m.args[0]) return m.reply('ID Drama diperlukan!');
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                const res = await melolo.detail(m.args[0]);
                if (!res.episodes.length) return m.reply('Episode tidak tersedia.');
                let caption = `⋄ Judul: *${res.title}*\n` +
                              `⋄ Status: *${res.status}*\n` +
                              `⋄ Tags: *${res.tags.join(", ")}*\n` + 
                              `⋄ Total Eps: *${res.total_episodes}*\n\n` +
                              `⋄ *Sinopsis:* ${res.intro || '-'}`;

                // SEKARANG TIAP 5 EPISODE
                const groups = chunkArray(res.episodes, 5);

                let rows = groups.map((group, i) => {
                    const start = group[0].episode;
                    const end = group[group.length - 1].episode;
                    return {
                        title: `Gabungkan Eps ${start} - ${end}`,
                        description: `🎥 Gabung ${group.length} video menjadi 1 file`,
                        id: `${m.prefix}mergemelolo ${m.args[0]}|${i}`
                    };
                });
                const sections = [{ title: 'DAFTAR EPISODE', rows }];
                const buttons = [[
                    'list', 'Pilih Episode', sections
                ]];
                await lulli.sendButton(m.chat, "✦ MELOLO DETAIL", caption, `Silakan pilih batch episode yang ingin digabungkan. Satu video akan berisi 5 episode sekaligus.`, buttons, m);
                lulli.sendReact(m.chat, '✅', m.key);
            } catch (e) { m.reply(e.message); }
            break;
        }

        /*case 'mergemelolo': {
            const [bookId, index] = m.text.split('|');
            if (!bookId || index === undefined) return m.reply('Data tidak valid.');

            m.reply('_Sedang mendownload dan menggabungkan 5 episode... Mohon tunggu sebentar._');
            lulli.sendReact(m.chat, '🕒', m.key);

            try {
                const res = await melolo.detail(bookId);
                const groups = chunkArray(res.episodes, 5);
                const selectedGroup = groups[parseInt(index)];

                if (!selectedGroup) return m.reply('Batch tidak ditemukan.');

                // Ambil link stream untuk tiap episode dalam batch
                const videoUrls = [];
                for (let ep of selectedGroup) {
                    const streamData = await melolo.stream(ep.video_id);
                    if (streamData && streamData.downloads) {
                        const res480 = streamData.downloads.find(x => x.quality === "480p" || x.quality === "360p" || x.quality === "540p");
                        videoUrls.push(res480.url);
                    }
                }

                if (videoUrls.length === 0) return m.reply('Gagal mengambil sumber video.');

                // Setup folder & file output
                if (!fs.existsSync('./temp')) fs.mkdirSync('./temp', { recursive: true });
                const outputName = `melolo_${bookId}_${Date.now()}.mp4`;
                const outputPath = path.join('./temp', outputName);

                // Proses Merging
                await mergeVideos(videoUrls, outputPath);

                // Kirim Video
                const startEps = selectedGroup[0].episode;
                const endEps = selectedGroup[selectedGroup.length - 1].episode;

                await lulli.sendMessage(m.chat, {
                    video: fs.readFileSync(outputPath),
                    caption: `✅ *BERHASIL DI-MERGE*\n\n📖 Drama: *${res.title}*\n📺 Episode: *${startEps} s/d ${endEps}*\n📦 Isi: 5 Episode jadi 1 Video`
                }, { quoted: m, ephemeralExpiration: m.expiration });

                // Hapus file sementara
                fs.unlinkSync(outputPath);
                lulli.sendReact(m.chat, '✅', m.key);

            } catch (e) {
                console.error(e);
                m.reply(`✗ Gagal memproses video: ${e.message}`);
            }
            break;
        }*/

        case 'mergemelolo': {
            const [bookId, index] = m.text.split('|');
            if (!bookId || index === undefined) return m.reply('Data tidak valid.');

            m.reply('_Sedang mendownload dan menggabungkan 5 episode... Mohon tunggu sebentar._');
            // lulli.sendReact(m.chat, '🕒', m.key);

            const tempDir = path.join('./temp', `merge_${Date.now()}`);
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

            let filePaths = [];
            try {
                const res = await melolo.detail(bookId);
                const groups = chunkArray(res.episodes, 5);
                const selectedGroup = groups[parseInt(index)];

                if (!selectedGroup) return m.reply('Batch tidak ditemukan.');

                // 1. Download satu per satu ke temp (Agar tidak SIGSEGV)                
                for (let i = 0; i < selectedGroup.length; i++) {
                    const ep = selectedGroup[i];
                    const streamData = await melolo.stream(ep.video_id);
                    
                    if (streamData && streamData.downloads) {
                        const target = streamData.downloads.find(x => x.quality === "540p") ||
                                       streamData.downloads.find(x => x.quality === "480p") ||
                                       streamData.downloads.find(x => x.quality === "720p") ||
                                       streamData.downloads.find(x => x.quality === "360p");

                        const videoUrl = target ? target.url : streamData.url;

                        if (videoUrl) {
                            const tempPath = path.join(tempDir, `temp_${bookId}_${i}.mp4`);
                            
                            // Proses download file ke lokal agar tidak SIGSEGV
                            const response = await axios({ method: 'GET', url: videoUrl, responseType: 'stream' });
                            const writer = fs.createWriteStream(tempPath);
                            response.data.pipe(writer);

                            await new Promise((resolve, reject) => {
                                writer.on('finish', resolve);
                                writer.on('error', reject);
                            });
                            
                            filePaths.push(tempPath);
                        }
                    }
                }

                if (filePaths.length === 0) return m.reply('Gagal mendownload video.');

                // 2. Proses Merge menggunakan file lokal
                const outputPath = path.join(tempDir, 'result.mp4');
                // Proses Merging
                await mergeVideos(filePaths, outputPath);

                // 3. Kirim Video
                await lulli.sendMessage(m.chat, {
                    video: fs.readFileSync(outputPath),
                    caption: `*MERGE SUCCESS (540p)*\n\n📖 *${res.title}*\n📺 Episode: *${selectedGroup[0].episode} - ${selectedGroup[selectedGroup.length-1].episode}*`
                }, { quoted: m, ephemeralExpiration: m.expiration });

                lulli.sendReact(m.chat, '✅', m.key);

            } catch (e) {
                console.error(e);
                m.reply(`✗ Error: ${e.message}`);
            } finally {
                // 4. Bersihkan folder temp
                if (fs.existsSync(tempDir)) {
                    fs.rmSync(tempDir, { recursive: true, force: true });
                }
            }
            break;
        }

        case 'streammelolo': {
            if (!m.args[0]) return m.reply('Sertakan ID Video!');
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                const data = await melolo.stream(m.args[0]);
                const videoUrl = data.url;
                if (!videoUrl) return m.reply('Gagal mendapatkan link video.');

                await lulli.sendMessage(m.chat, { 
                    video: { url: videoUrl }, 
                    caption: `✅ *Video Berhasil Dimuat*\nRes: ${data.width}x${data.height}`
                }, { quoted: m, ephemeralExpiration: m.expiration });
                lulli.sendReact(m.chat, '✅', m.key);
            } catch (e) {
                m.reply(`Error: ${e.message}`);
            }
            break;
        }

        case 'qualitymelolo': {
            if (!m.args[0]) return m.reply('ID Video diperlukan!');
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                const data = await melolo.stream(m.args[0]);
                if (data.downloads.length === 0) return m.reply('Gagal memuat kualitas video.');

                let rows = data.downloads.map(dl => ({
                    title: `Kualitas: ${dl.quality}`,
                    description: `Ukuran: ${dl.size}`,
                    id: `${m.prefix}dlmelolo ${dl.url}`
                }));
                const sections = [{ title: 'RESOLUSI TERSEDIA', rows }]
                const buttons = [[
                    'list', 'Pilih Resolusi', sections
                ]];
                await lulli.sendButton(m.chat, `✦ *PILIH KUALITAS VIDEO*\nSilakan pilih resolusi yang diinginkan.`, 'Melolo Player', 'Pilih Kualitas', buttons, m);
                lulli.sendReact(m.chat, '✅', m.key);
            } catch (e) { m.reply(e.message); }
            break;
        }

        case 'dlmelolo': {
            if (!m.args[0]) return m.reply('URL diperlukan!');
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                await lulli.sendMessage(m.chat, { video: { url: m.args[0] }, caption: 'Berhasil memuat video!' }, { quoted: m, ephemeralExpiration: m.expiration });
                lulli.sendReact(m.chat, '✅', m.key);
            } catch (e) { m.reply('Gagal mengirim video.'); }
            break;
        }
    }
};

export default {
    run,
    cmd: ['melolo', 'listmelolo', 'getmelolo', 'mergemelolo', 'streammelolo', 'qualitymelolo', 'dlmelolo'],
    use: 'Judul atau ID drama',
    type: 'searching',
    desc: 'Cari dan tonton drama pendek dari Melolo',
    premium: true,
    location: 'plugins/searching/melolo'
};