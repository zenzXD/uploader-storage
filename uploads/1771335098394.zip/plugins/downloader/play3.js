import yts from 'yt-search';
import axios from 'axios';
import * as cheerio from 'cheerio';
import FormData from 'form-data';

const youtubeMp3 = async (url) => {
    try {
        const form = new FormData();
        form.append("url", url);
        const headers = {
            ...form.getHeaders(),
        };
        const { data } = await axios.post(
            "https://www.youtubemp3.ltd/convert",
            form, { headers }
        );
        return {
            status: true,
            title: data.filename,
            downloadUrl: data.link,
        };
    } catch (error) {
        console.error('✗ Error converting YouTube to MP3:', error.message);
        return {
            status: false,
            message: `✗ Gagal mengkonversi YouTube ke MP3: ${error.message}`
        };
    }
};

async function downloadImage(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer'
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('✗ Error downloading image:', error.message);
        return null;
    }
}

const processedAudio = new Set();

const run = async (m, lulli) => {
    if (!m.text) {
        return m.reply('✗ Masukan judul lagu yang ingin dicari.');
    }
    const query = m.text.trim();
    if (processedAudio.has(query)) {
        return m.reply('✦ Masih ada proses unduhan audio yang belum selesai. Mohon tunggu.');
    }
    processedAudio.add(query);
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const searchResults = await yts(query);
        const video = searchResults.videos[0];
        if (!video) {
            return m.reply('✗ Video tidak ditemukan dari pencarian.');
        }
        let caption = '✦ *YOUTUBE - PLAY*\n\n';
        caption += `- Judul: *${video.title || '-'}*\n`;
        caption += `- Durasi: ${video.timestamp || video.duration?.timestamp || '-'}\n`;
        caption += `- Dilihat: ${video.views || '-'}\n`;
        caption += `- Upload: ${video.ago || '-'}\n`;
        caption += `- Penulis: *${video.author?.name || '-'}*\n`;
        caption += `- URL: ${video.url}\n`;
        caption += `- Deskripsi: ${video.description ? video.description.slice(0, 100) + '...' : '-'}\n\n`;
        caption += `✧ Mohon tunggu, file audio sedang dikirim...`;
        const thumbnailBuffer = await downloadImage(video.thumbnail);
        let messageResponse = await lulli.sendMessage(m.chat, {
            image: thumbnailBuffer,
            caption: caption,
            mimetype: 'image/jpeg'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
        const result = await youtubeMp3(video.url);
        if (!result.status) {
            return m.reply(`✗ ${result.message}`);
        }
        await lulli.sendMessage(m.chat, {
            audio: { url: result.downloadUrl },
            fileName: `${result.title || video.title}.mp3`,
            mimetype: 'audio/mpeg',
        }, {
            quoted: messageResponse,
            ephemeralExpiration: m.expiration
        });
    } catch (error) {
        console.error('✗ Error dalam pemrosesan YouTube Play V3:', error);
        return lulli.reply(m.chat, `✗ Terjadi kesalahan: ${error.message}`, m, {
            expiration: m.expiration
        });
    } finally {
        processedAudio.delete(query);
    }
};

export default {
    run,
    cmd: 'play3',
    use: 'judul lagu',
    type: 'downloader',
    restrict: true,
    limit: 3,
    premium: true,
    location: 'plugins/downloader/play3.js'
};