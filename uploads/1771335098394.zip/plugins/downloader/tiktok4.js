import FormData from 'form-data';
import axios from 'axios';
import * as cheerio from 'cheerio';

const headers = {
    authority: "ttsave.app",
    accept: "application/json, text/plain, */*",
    origin: "https://ttsave.app",
    referer: "https://ttsave.app/en",
    "user-agent": "Postify/1.0.0",
};

const ttsave = {
    submit: async function(url, referer) {
        const headerx = {
            ...headers,
            referer
        };
        const data = {
            query: url,
            language_id: "1"
        };
        return axios.post("https://ttsave.app/download", data, {
            headers: headerx
        });
    },

    parse: function($) {
        const uniqueId = $("#unique-id").val();
        const nickname = $("h2.font-extrabold").text().trim();
        const profilePic = $("img.rounded-full").attr("src");
        const username = $("a.font-extrabold.text-blue-400").text().trim();
        const description = $("p.text-gray-600").text().trim();

        const dlink = {
            nowm: $("a.w-full.text-white.font-bold").first().attr("href"),
            wm: $("a.w-full.text-white.font-bold").eq(1).attr("href"),
            audio: $("a[type='audio']").attr("href"),
            profilePic: $("a[type='profile']").attr("href"),
            cover: $("a[type='cover']").attr("href"),
        };

        const stats = {
            plays: "",
            likes: "",
            comments: "",
            shares: "",
        };

        $(".flex.flex-row.items-center.justify-center").each((index, element) => {
            const $element = $(element);
            const svgPath = $element.find("svg path").attr("d");
            const value = $element.find("span.text-gray-500").text().trim();

            if (svgPath && svgPath.startsWith("M10 18a8 8 0 100-16")) {
                stats.plays = value;
            } else if (svgPath && svgPath.startsWith("M3.172 5.172a4 4 0 015.656")) {
                stats.likes = value || "0";
            } else if (svgPath && svgPath.startsWith("M18 10c0 3.866-3.582")) {
                stats.comments = value;
            } else if (svgPath && svgPath.startsWith("M17.593 3.322c1.1.128")) {
                stats.shares = value;
            }
        });

        const songTitle = $(".flex.flex-row.items-center.justify-center.gap-1.mt-5")
            .find("span.text-gray-500")
            .text()
            .trim();

        const slides = $("a[type='slide']")
            .map((i, el) => ({
                number: i + 1,
                url: $(el).attr("href"),
            }))
            .get();

        return {
            uniqueId,
            nickname,
            profilePic,
            username,
            description,
            dlink,
            stats,
            songTitle,
            slides,
        };
    },

    video: async function(link) {
        try {
            const response = await this.submit(link, "https://ttsave.app/en");
            const $ = cheerio.load(response.data);
            const result = this.parse($);

            if (result.slides && result.slides.length > 0) {
                return {
                    type: "slide",
                    ...result
                };
            }

            return {
                type: "video",
                ...result,
                videoInfo: {
                    nowm: result.dlink.nowm,
                    wm: result.dlink.wm,
                },
            };
        } catch (error) {
            console.error('✗ Error ttsave.video:', error.message);
            throw error;
        }
    },
};

function generateLink(text) {
    const regex = /(https?:\/\/(?:www\.|(?!www))[^\s.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})/gi;
    return text.match(regex) || [];
}

function ttFixed(url) {
    if (!url.match(/(tiktok.com\/t\/)/g)) return url;
    let id = url.split('/t/')[1];
    return 'https://vm.tiktok.com/' + id;
}

function filterDuplicates(array) {
    return [...new Set(array)];
}

const run = async (m, lulli, { cfg, func }) => {
    let inputUrlText;

    if (m.args.length >= 1) {
        inputUrlText = m.args.join(' ');
    } else if (m.quoted && m.quoted.text) {
        inputUrlText = m.quoted.text;
    }

    if (!inputUrlText) {
        return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZSF4cWcA2/'));
    }

    if (!inputUrlText.includes('tiktok.com')) {
        return m.reply('✗ Link tidak valid. Harus link TikTok.');
    }

    const extractedLinks = generateLink(inputUrlText);
    const links = filterDuplicates(extractedLinks.filter(v => ttFixed(v).match(/^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/)));
    
    if (links.length < 1) {
        return m.reply('✗ Link TikTok tidak valid atau tidak ditemukan.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const videoResult = await ttsave.video(links[0]);
        const { type, nickname, username, description, dlink, stats, songTitle, slides } = videoResult;
        let caption = `✦ *TIKTOK DOWNLOADER*\n\n` +
                      `- Nickname: *${nickname || 'N/A'}*\n` +
                      `- Username: *${username || 'N/A'}*\n` +
                      `- Deskripsi: *${description || 'N/A'}*\n` +
                      `- Dilihat: ${stats.plays || '0'}\n` +
                      `- Suka: ${stats.likes || '0'}\n` +
                      `- Komentar: ${stats.comments || '0'}\n` +
                      `- Dibagikan: ${stats.shares || '0'}\n` +
                      `- Judul Lagu: *${songTitle || 'N/A'}*\n\n`;
        if (type === "slide") {
            caption += `- Tipe: Slide (Gambar)\n`;
            caption += `- Total Gambar : ${slides.length}\n\n`;
            caption += `Mengirim gambar slide...`;
            await m.reply(caption);

            for (const [index, slide] of slides.entries()) {
                await func.delay(1000);
                await lulli.sendMedia(m.chat, slide.url, null, {
                    expiration: m.expiration
                });
            }
        } else if (type === "video") {
            caption += `- Tipe : Video\n\n`;
            caption += `- Mengirim video...`;

            const videoLink = dlink.nowm || dlink.wm;
            if (!videoLink) {
                return m.reply('✗ Link video tidak ditemukan.');
            }
            
            const videoMessage = await lulli.sendMedia(m.chat, videoLink, m, {
                caption: caption,
                expiration: m.expiration,
                mimetype: 'video/mp4',
                fileName: `${username || 'tiktok_video'}.mp4`
            });

            if (dlink.audio) {
                await lulli.sendMessage(m.chat, {
                    audio: { url: dlink.audio },
                    mimetype: 'audio/mpeg',
                    ptt: false
                }, {
                    quoted: videoMessage,
                    ephemeralExpiration: m.expiration
                });
            }
        } else {
            return m.reply('✗ Tipe media tidak didukung.');
        }
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada TikTok Downloader (ttsave):', error);
        await lulli.reply(m.chat, `✗ Terjadi kesalahan: ${error.message}`, m, {
            expiration: m.expiration
        });
    }
};

export default {
    run,
    cmd: 'tiktok4',
    alias: 'tt4',
    use: 'link tiktok',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/tiktok4.js'
};