import FormData from 'form-data';
import axios from 'axios';
import * as cheerio from 'cheerio';

async function tiktok3(url) {
    const bodyForm = new FormData();
    bodyForm.append("q", url);
    bodyForm.append("lang", "id");
    try {
        const { data } = await axios({
            method: "post",
            url: "https://savetik.co/api/ajaxSearch",
            data: bodyForm,
            headers: {
                ...bodyForm.getHeaders(),
                "User-Agent": "PostmanRuntime/7.32.2",
                "content-type": "application/x-www-form-urlencoded",
            },
        });
        const $ = cheerio.load(data.data);
        const result = {
            status: true,
            title: $("div.video-data > div > .tik-left > div > .content > div > h3").text().trim(),
            video: $("div.video-data > div > .tik-right > div > p:nth-child(1) > a").attr("href"),
            audio: $("div.video-data > div > .tik-right > div > p:nth-child(3) > a").attr("href"),
        };
        return result;
    } catch (error) {
        console.error('✗ Error pada tiktok3 downloader:', error.message);
        return {
            status: false,
            message: `✗ Terjadi kesalahan: ${error.message}`
        };
    }
}

const run = async (m, lulli, { func, cfg }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZSF4cWcA2/'));
    }
    const tiktokUrl = m.args[0];
    if (!tiktokUrl || !tiktokUrl.includes('tiktok.com')) {
        return m.reply('✗ Link tidak valid. Harus link TikTok.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const result = await tiktok3(tiktokUrl);
        if (!result.status) {
            return m.reply(`✗ ${result.message || 'Gagal mengunduh video TikTok.'}`);
        }
        if (!result.video) {
            return m.reply('✗ Link video tidak ditemukan. Mungkin ini TikTok slide atau masalah lain.');
        }
        let caption = `✦ *TIKTOK DOWNLOADER*\n\n` +
                      `- Judul: *${result.title || 'N/A'}*\n\n` +
                      `Mengirim video...`;
        const videoMessage = await lulli.sendMessage(m.chat, {
            video: { url: result.video },
            caption: caption,
            fileName: `${result.title || 'tiktok_video'}.mp4`,
            mimetype: 'video/mp4'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
        if (result.audio) {
            await lulli.sendMessage(m.chat, {
                audio: { url: result.audio },
                mimetype: 'audio/mpeg',
                ptt: false
            }, {
                quoted: videoMessage,
                ephemeralExpiration: m.expiration
            });
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada TikTok Downloader (savetik.co):', e);
        await lulli.reply(m.chat, `✗ Terjadi kesalahan: ${e.message}`, m, {
            expiration: m.expiration
        });
    }
};

export default {
    run,
    cmd: 'tiktok3',
    alias: 'tt3',
    use: 'link tiktok',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/tiktok3.js'
};