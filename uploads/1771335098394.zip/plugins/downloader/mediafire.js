import { decode } from 'html-entities';
import * as cheerio from "cheerio";
import { fetch } from "undici";
import { lookup } from "mime-types";

async function mediafire(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await fetch(url);
            const html = await response.text();
            const $ = cheerio.load(html);

            const type = $(".dl-btn-cont").find(".icon").attr("class").split("archive")[1].trim();
            const filename = $(".dl-btn-label").attr("title");
            const sizeElement = $('.download_link .input').text().trim();
            const sizeMatch = sizeElement.match(/(.*?)/); // Fixed regex
            const size = sizeMatch ? sizeMatch[1] : 'Ukuran tidak diketahui';
            const ext = filename.split(".").pop();
            const mimetype = lookup(ext.toLowerCase()) || "application/" + ext.toLowerCase();
            const download = $(".input").attr("href");

            resolve({
                filename,
                type,
                size,
                ext,
                mimetype,
                download,
            });
        } catch (e) {
            resolve({
                error: "✗ Gagal mengambil data dari link tersebut",
            });
        }
    });
}

const run = async (m, client, {
    cfg,
    func,
    users,
}) => {
    try {
        if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://www.mediafire.com/file/0kr35i9osafzxk4/mecha-bot_v9.1.9.zip/file'));
        if (!m.args[0].match(/(https:\/\/www.mediafire.com\/)/gi)) return m.reply("✗ Link tidak valid.");

        const json = await mediafire(m.args[0]);
        if (json.error) return m.reply(json.error);

        let text = `✦ *INFORMASI MEDIAFIRE*\n\n`;
        text += `- Nama File: ${unescape(decode(json.filename))}\n`;
        text += `- Ukuran: ${json.size}\n`;
        text += `- Ekstensi: ${json.ext}\n`;
        text += `- Tipe Mime: ${json.mimetype}\n`;
        text += `- Link Unduh: ${json.download}`;

        await client.sendMessage(m.chat, {
            text
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

        await client.sendMedia(m.chat, json.download, m, {
            fileName: unescape(decode(json.filename))
        });
    } catch (e) {
        console.error(e);
        await m.reply(cfg.mess.wrong(e.message));
    }
};

export default {
    run,
    cmd: 'mediafire',
    alias: 'mf',
    use: 'link',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/mediafire.js'
};