import yts from 'yt-search';
import axios from 'axios';

const formatVideoCaption = (video, type) => {
    let caption = `✦ *YOUTUBE DOWNLOADER (${type.toUpperCase()})*\n\n`;
    caption += `- Judul: *${video.title || '-'}*\n`;
    caption += `- Durasi: ${video.timestamp || '-'}\n`;
    caption += `- Dilihat: ${video.views || '-'}\n`;
    caption += `- Upload: ${video.ago || '-'}\n`;
    caption += `- Penulis: *${video.author?.name || '-'}*\n`;
    caption += `- URL Video: ${video.url}\n`;
    caption += `- Deskripsi: ${video.description ? video.description.slice(0, 100) + '...' : '-'}\n\n`;
    caption += `Mohon tunggu, file ${type} sedang dikirim...`;
    return caption;
};

let database = {};

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'legends never die'));
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const searchResults = await yts(m.text);
        const filteredVideos = searchResults.videos.filter(video => {
            const durationParts = (video.timestamp || '0:00').split(':').map(Number);
            const durationInSeconds = durationParts.reduce((acc, time) => (60 * acc) + time, 0);
            return durationInSeconds < 3600;
        });

        if (filteredVideos.length === 0) {
            return m.reply('✗ Tidak ditemukan video yang durasinya kurang dari 1 jam.');
        }
        database[m.sender] = {
            jid: m.sender,
            search: filteredVideos,
        };
        let caption = '✦ *YOUTUBE - SEARCH*\n\n';
        caption += `Hasil Dari Query : \`${m.text}\`\n\n`;
        caption += `✧ balas pesan ini dengan *[nomor]a* untuk unduh audio.\n`;
        caption += `✧ balas pesan ini dengan *[nomor]v* untuk unduh video.\n\n`;
        filteredVideos.forEach((item, index) => {
            caption += `${index + 1}. ${item.title}\n`;
            caption += `- Durasi: ${item.timestamp}\n`;
            caption += `- Penulis: *${item.author?.name || '-'}*\n`;
            caption += `- Publikasi: ${item.ago || '-'}\n\n`;
        });
        lulli.sendMessage(m.chat, {
            text: caption
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration,
            messageId: 'LULLI' + func.makeid(22).toUpperCase() + 'YTSEARCH'
        });
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada YouTube Search:', error);
        await m.reply(`✗ Terjadi kesalahan: ${error.message}`);
    }
};

const main = async (m, lulli, { YT }) => {
    const userData = database[m.sender];

    if (userData && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('YTSEARCH') && !m.isPrefix) {
        const command = m.budy.trim().toLowerCase();
        const match = command.match(/^(\d+)([av])$/);

        if (!match) {
            return await lulli.reply(m.chat, '✗ Format balasan tidak valid. Contoh: `1a` untuk audio, `1v` untuk video.', m);
        }

        const index = parseInt(match[1], 10) - 1;
        const type = match[2];

        if (index < 0 || index >= userData.search.length) {
            return await lulli.reply(m.chat, '✗ Nomor index tidak valid.', m);
        }
        const video = userData.search[index];
        lulli.sendReact(m.chat, '🕒', m.key);
        try {
            let downloadResult;
            let mediaToSend = {};
            let captionText;
            if (type === 'a') {
                downloadResult = await YT.download(video.url, 'mp3');
                if (!downloadResult.status) throw new Error(downloadResult.error);
                mediaToSend = {
                    audio: { url: downloadResult.result.download },
                    mimetype: 'audio/mpeg',
                    fileName: `${video.title || 'audio'}.mp3`
                };
                captionText = formatVideoCaption(video, 'audio');
            } else if (type === 'v') {
                downloadResult = await YT.download(video.url, '720');
                if (!downloadResult.status) throw new Error(downloadResult.error);
                mediaToSend = {
                    video: { url: downloadResult.result.download },
                    mimetype: 'video/mp4',
                    fileName: `${video.title || 'video'}.mp4`
                };
                captionText = formatVideoCaption(video, 'video');
            }
            const thumbnailMessage = await lulli.sendMessage(m.chat, {
                image: { url: video.thumbnail },
                caption: captionText,
                mimetype: 'image/jpeg'
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            await lulli.sendMessage(m.chat, mediaToSend, {
                quoted: thumbnailMessage,
                ephemeralExpiration: m.expiration
            });
        } catch (error) {
            console.error(`✗ Error saat mengunduh ${type} dari YouTube:`, error);
            await lulli.reply(m.chat, `✗ Gagal mengunduh ${type}: ${error.message}`, m);
        } finally {
            delete database[m.sender];
        }
    }
};

export default {
    run,
    main,
    cmd: 'ytsearch',
    alias: 'yts',
    use: 'judul lagu/video',
    type: 'downloader',
    restrict: true,
    limit: 3,
    location: 'plugins/downloader/ytsearch.js'
};