import axios from 'axios';
import * as cheerio from 'cheerio';
import filetype from 'file-type';
const {
    fromBuffer
} = filetype;
import fetch from 'node-fetch';
async function instagram(url) {
    try {
        let res = await axios("https://indown.io/");
        let _$ = cheerio.load(res.data);
        let referer = _$("input[name=referer]").val();
        let locale = _$("input[name=locale]").val();
        let _token = _$("input[name=_token]").val();
        let {
            data
        } = await axios.post("https://indown.io/download", new URLSearchParams({
            link: url,
            referer,
            locale,
            _token,
        }), {
            headers: {
                cookie: res.headers["set-cookie"].join("; "),
            },
        }, );
        let $ = cheerio.load(data);
        let result = [];
        let __$ = cheerio.load($("#result").html());
        __$("video").each(function() {
            let $$ = $(this);
            result.push({
                type: "video",
                thumbnail: $$.attr("poster"),
                url: $$.find("source").attr("src"),
            });
        });
        __$("img").each(function() {
            let $$ = $(this);
            result.push({
                type: "image",
                url: $$.attr("src"),
            });
        });
        return {
            success: true,
            result
        }
    } catch (e) {
        return {
            success: false,
            error: e.message
        }
    }
}

function generateLink(text) {
    const regex = /(https?:\/\/(?:www\.|(?!www))[^\s.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})/gi;
    return text.match(regex) || [];
}

function filterDuplicates(array) {
    return [...new Set(array)];
}
const run = async (m, lulli, {
    cfg,
    func
}) => {
    let inputUrlText;
    if (m.args.length >= 1) {
        inputUrlText = m.args.join(' ');
    } else if (m.quoted && m.quoted.text) {
        inputUrlText = m.quoted.text;
    }
    if (!inputUrlText) {
        return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA=='));
    }
    const igRegex = /https:\/\/(?:www\.)?instagram\.com\/(?:p|reel|tv)\/[A-Za-z0-9_-]+\/?(?:\?.+)?$/i;
    const extractedLinks = generateLink(inputUrlText);
    const validLinks = filterDuplicates(extractedLinks.filter(v => igRegex.test(v)));
    if (validLinks.length < 1) {
        return m.reply('✗ Link Instagram tidak valid atau tidak didukung. Mohon berikan link postingan/reel/TV.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const results = await instagram(validLinks[0]);
        if (!results || !results.success || !results.result || results.result.length < 1) {
            return m.reply(`✗ Gagal mengunduh media dari Instagram: ${func.jsonFormat(results.error)}.`);
        }
        let firstMessageSent = false;
        for (const [index, data] of results.result.entries()) {
            try {
                const buffer = await func.fetchBuffer(data.url);
                const fileInfo = await fromBuffer(buffer);
                const mime = fileInfo ? fileInfo.mime : 'application/octet-stream';
                if (buffer.length > 100 * 1024 * 1024) {
                    await lulli.sendMessage(m.chat, {
                        document: buffer,
                        mimetype: mime,
                        fileName: `instagram_media.${fileInfo ? fileInfo.ext : 'bin'}`,
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                } else {
                    const mtype = /video/.test(mime) ? 'video' : 'image';
                    await lulli.sendMessage(m.chat, {
                        [mtype]: buffer,
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                }
                firstMessageSent = true;
                await func.delay(1000);
            } catch (mediaError) {
                console.error(`✗ Gagal mengirim media (${data.url}):`, mediaError);
                await m.reply(`✗ Gagal mengirim salah satu media: ${mediaError.message}`);
            }
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Instagram Downloader:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};
export default {
    run,
    cmd: 'instagram',
    alias: ['igdl', 'ig'],
    use: 'link instagram (post, reel, TV)',
    type: 'downloader',
    premium: true,
    limit: 5,
    location: 'plugins/downloader/instagram.js'
};