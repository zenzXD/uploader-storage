import fetch from 'node-fetch';

const regexRepo = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/([^\/:]+)(?:\/tree\/[^\/]+|\/blob\/[^\/]+)?(?:\/(.+))?/i;
const regexGist = /https:\/\/gist\.github\.com\/([^\/]+)\/([a-zA-Z0-9]+)/i;
const regexRawGitHub = /https:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/([^\/]+)\/(.+)/i;

const run = async (m, lulli) => {
    if (!m.text) {
        return m.reply('✗ Link GitHub-nya mana?');
    }

    const inputLink = m.args[0];

    const isRepo = regexRepo.test(inputLink);
    const isGist = regexGist.test(inputLink);
    const isRawGitHub = regexRawGitHub.test(inputLink);

    if (!isRepo && !isGist && !isRawGitHub) {
        return m.reply('✗ Link yang diberikan tidak valid atau tidak didukung.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        if (isRepo) {
            const [, user, repo] = inputLink.match(regexRepo);
            const cleanRepoName = repo.replace(/\.git$/, '');
            const downloadUrl = `https://api.github.com/repos/${user}/${cleanRepoName}/zipball`;

            const responseHead = await fetch(downloadUrl, { method: 'HEAD' });
            const contentDisposition = responseHead.headers.get('content-disposition');
            let filename = `${cleanRepoName}.zip`;
            if (contentDisposition) {
                const filenameMatch = contentDisposition.match(/attachment; filename=(.*)/);
                if (filenameMatch && filenameMatch[1]) {
                    filename = filenameMatch[1];
                }
            }
            await m.reply(`✦ Mohon tunggu, sedang mengirim repository dari GitHub...`);
            await lulli.sendMessage(m.chat, {
                document: { url: downloadUrl },
                fileName: filename,
                mimetype: "application/zip",
                caption: `✓ Hasil dari: *${inputLink}*`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });

        } else if (isGist) {
            const [, user, gistId] = inputLink.match(regexGist);
            const downloadUrl = `https://gist.github.com/${user}/${gistId}/download`;
            await m.reply(`✦ Mohon tunggu, sedang mengirim Gist dari GitHub...`);
            await lulli.sendMessage(m.chat, {
                document: { url: downloadUrl },
                fileName: `${gistId}.zip`,
                mimetype: "application/zip",
                caption: `✓ Hasil dari: *${inputLink}*`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });

        } else if (isRawGitHub) {
            const [, user, repo, branch, filepath] = inputLink.match(regexRawGitHub);
            const downloadUrl = `https://raw.githubusercontent.com/${user}/${repo}/${branch}/${filepath}`;
            const filename = filepath.split('/').pop();
            await m.reply(`✦ Mohon tunggu, sedang mengirim file dari Raw GitHub...`);
            await lulli.sendMessage(m.chat, {
                document: { url: downloadUrl },
                fileName: filename,
                mimetype: "application/octet-stream",
                caption: `✓ Hasil dari: *${inputLink}*`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        }

    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Git Clone:', e);
        await m.reply(`✗ Terjadi kesalahan saat mengunduh dari GitHub: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'gitclone',
    alias: 'clonegit',
    use: 'link repository/gist/raw GitHub',
    type: 'downloader',
    limit: true,
    location: 'plugins/downloader/gitclone.js'
};