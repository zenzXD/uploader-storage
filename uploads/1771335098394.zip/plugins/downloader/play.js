import axios from 'axios';
import yts from 'yt-search';
async function getBuffer(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer'
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('✗ Error fetching buffer:', error.message);
        return null;
    }
}

const processedAudio = new Set();
const run = async (m, lulli, {
    cfg,
    func,
    YT
}) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'melukis senja'));
    }
    let query = m.text.trim();
    let isYouTubeLink = false;
    const urlMatches = query.match(/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/);
    if (urlMatches && urlMatches[0]) {
        isYouTubeLink = true;
        query = urlMatches[0];
    } else if (func.isUrl(query)) {
        return m.reply('✗ Link yang diberikan bukan link YouTube.');
    }
    if (processedAudio.has(query)) {
        return m.reply('✦ Masih ada proses unduhan audio yang belum selesai untuk query ini.');
    }
    processedAudio.add(query);
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        let downloadResult;
        if (isYouTubeLink) {
            const apiUrl = `https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(query)}`;
            const downloaderResponse = await fetch(apiUrl);
            const downloaderJson = await downloaderResponse.json();
            if (!downloaderJson.status || !downloaderJson.result || !downloaderJson.result.mp3) {
                return m.reply('Gagal mendapatkan link unduhan audio. API mungkin sedang down.');
            }
            downloadResult = downloaderJson.result;
            await lulli.sendMessage(m.chat, {
                audio: {
                    url: downloadResult.mp3
                },
                mimetype: 'audio/mpeg',
                fileName: `${downloadResult.title || 'audio_youtube'}.mp3`,
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } else {
            const searchResults = await yts(query);
            const video = searchResults.videos[0];
            if (!video) {
                return m.reply('✗ Video tidak ditemukan dari pencarian.');
            }
            const durationParts = (video.timestamp || video.duration?.timestamp || '0:00').split(':').map(Number);
            const durationInSeconds = durationParts.reduce((acc, time) => (60 * acc) + time, 0);
            if (durationInSeconds >= 3600) {
                return m.reply('✗ Durasi video lebih dari 1 jam. Tidak dapat memutar audio.');
            }
            let caption = '✦ YOUTUBE - PLAY\n\n';
            caption += `- Judul: *${video.title || '-'}*\n`;
            caption += `- Durasi: ${video.timestamp || '-'}\n`;
            caption += `- Dilihat: ${video.views || '-'}\n`;
            caption += `- Upload: ${video.ago || '-'}\n`;
            caption += `- Penulis: *${video.author?.name || '-'}*\n`;
            caption += `- URL: ${video.url}\n`;
            caption += `- Deskripsi: ${video.description ? video.description.slice(0, 100) + '...' : '-'}\n\n`;
            caption += `✧ Mohon tunggu, file audio sedang dikirim...`;
            const thumbnailBuffer = await getBuffer(video.thumbnail);
            let messageResponse = await lulli.sendMessage(m.chat, {
                image: thumbnailBuffer,
                caption: caption,
                mimetype: 'image/jpeg'
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            const apiUrl = `https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(video.url)}`;
            const downloaderResponse = await fetch(apiUrl);
            const downloaderJson = await downloaderResponse.json();
            if (!downloaderJson.status || !downloaderJson.result || !downloaderJson.result.mp3) {
                return m.reply('Gagal mendapatkan link unduhan audio. API mungkin sedang down.');
            }
            downloadResult = downloaderJson.result;
            await lulli.sendMessage(m.chat, {
                audio: {
                    url: downloadResult.mp3
                },
                mimetype: 'audio/mpeg',
                fileName: `${video.title || 'audio_youtube'}.mp3`,
            }, {
                quoted: messageResponse,
                ephemeralExpiration: m.expiration
            });
        }
    } catch (error) {
        console.error('✗ Error dalam pemrosesan YouTube Play:', error);
        return await m.reply(`✗ Terjadi kesalahan: ${cfg.mess.wrong(error.message)}`);
    } finally {
        processedAudio.delete(query);
    }
};

export default {
    run,
    cmd: 'play',
    use: 'judul lagu / link youtube',
    type: 'downloader',
    restrict: true,
    premium: true,
    limit: 5,
    location: 'plugins/downloader/play.js'
};