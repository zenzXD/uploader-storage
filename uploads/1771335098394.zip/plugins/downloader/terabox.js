import axios from 'axios';

async function Terabox(link) {
    try {
        const res = await axios.post('https://teraboxdownloader.online/api.php', {
            url: link
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Origin': 'https://teraboxdownloader.online',
                'Referer': 'https://teraboxdownloader.online/',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                'Accept': '*/*'
            }
        });

        const data = res.data;
        if (!data?.direct_link) {
            return {
                error: '✗ Tidak ada link download ditemukan.',
                debug: data
            };
        }

        return {
            filename: data.file_name,
            size: data.size,
            sizebytes: data.sizebytes,
            directlink: data.direct_link,
            thumb: data.thumb
        };

    } catch (err) {
        console.error('✗ Error mengakses web Terabox Downloader:', err.message);
        return {
            error: '✗ Gagal mengakses web.',
            detail: err.message
        };
    }
}

const run = async (m, lulli, { func }) => {
    let inputUrlText;

    if (m.args.length >= 1) {
        inputUrlText = m.args.join(' ');
    } else if (m.quoted && m.quoted.text) {
        inputUrlText = m.quoted.text;
    }

    if (!inputUrlText) {
        return m.reply(func.example(m.cmd, 'https://terabox.com/s/1FtdPSfXTu6BRMzDSe1PMEg'));
    }

    const teraboxLinkRegex = /^https:\/\/(?:1024)?terabox\.com\/s\//;
    if (!teraboxLinkRegex.test(inputUrlText)) {
        return m.reply('✗ Link tidak valid! Harus berasal dari `terabox.com/s/` atau `1024terabox.com/s/`');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const result = await Terabox(inputUrlText);
        
        if (result.error) {
            let errorMessage = result.error;
            if (result.detail) errorMessage += `: ${result.detail}`;
            if (result.debug) errorMessage += `\n\nDEBUG: ${func.jsonFormat(result.debug)}`;
            return await m.reply(errorMessage);
        }

        const { filename, size, sizebytes, directlink, thumb } = result;
        const caption = `✦ *TERABOX DOWNLOADER*\n\n` +
                        `- Nama File: *${filename || 'Tidak Ada Nama'}*\n` +
                        `- Ukuran: ${size || 'Tidak Diketahui'}\n` +
                        `- Byte: ${sizebytes || 'Tidak Diketahui'}\n\n` +
                        `Mohon tunggu, media sedang dikirim...`;
        const messageResponse = await lulli.sendMessage(m.chat, {
            image: { url: thumb },
            caption: caption,
            mimetype: 'image/jpeg'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
        await lulli.sendMedia(m.chat, directlink, messageResponse, {
            fileName: filename || 'terabox_download',
            expiration: m.expiration
        });
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Terabox Downloader:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'terabox',
    alias: 'teraboxdl',
    use: 'link terabox',
    type: 'downloader',
    premium: true,
    location: 'plugins/downloader/terabox.js'
};