import axios from 'axios';

const run = async (m, lulli, { cfg, func }) => {
    let url = m.args[0];
    let downloadType;
    let apiResult;

    try {
        if (/yt?(a|mp3)/i.test(m.command)) {
            downloadType = 'audio';
        } else if (/yt?(v|mp4)/i.test(m.command)) {
            downloadType = 'video';
        } else {
            return m.reply('✗ Command tidak valid. Gunakan ytmp3v2/yta2 atau ytmp4v2/ytv2.');
        }
        if (!url) {
            return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'));
        }
        const youtubeRegex = /^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/;
        if (!youtubeRegex.test(url)) {
            return m.reply('✗ URL YouTube tidak valid.');
        }
        lulli.sendReact(m.chat, '🕒', m.key);
        apiResult = await func.fetchJson(`https://fs.fourmovie.my.id/api/download?url=${encodeURIComponent(url)}&type=${downloadType}`);
        if (apiResult.status !== 200 || !apiResult.data?.result?.success) {
            return m.reply(`✗ Gagal mengunduh: ${apiResult.message || apiResult.data?.result?.message || 'Terjadi kesalahan tidak diketahui.'}`);
        }
        if (!apiResult.details || !apiResult.result) {
            return m.reply('✗ Data unduhan tidak lengkap dari API.');
        }

        const { thumbnail, duration, channel, views, filesize } = apiResult.details;
        const caption = `✦ *YOUTUBE DOWNLOADER ${downloadType === 'video' ? 'MP4' : 'MP3'}*\n\n` +
                        `- Judul: *${apiResult.title || 'N/A'}*\n` +
                        `- Channel: *${channel || 'N/A'}*\n` +
                        `- Dilihat: ${views || 'N/A'}\n` +
                        `- Durasi: ${duration || 'N/A'}\n` +
                        `- Upload: ${apiResult.details.uploadDate || 'N/A'}\n` +
                        `- Deskripsi: ${apiResult.details.description ? apiResult.details.description.slice(0, 100) + '...' : 'N/A'}\n` +
                        `- Ukuran File: ${filesize || 'N/A'}\n\n` +
                        `✧ Mohon tunggu, file ${downloadType === 'video' ? 'video' : 'audio'} sedang dikirim...`;
        const thumbnailMessage = await lulli.sendMessage(m.chat, {
            image: { url: thumbnail },
            caption: caption,
            mimetype: 'image/jpeg'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
        if (downloadType === 'audio') {
            await lulli.sendMessage(m.chat, {
                audio: { url: apiResult.result.url },
                fileName: `${apiResult.title || 'audio_youtube'}.mp3`,
                mimetype: 'audio/mpeg',
            }, {
                quoted: thumbnailMessage,
                ephemeralExpiration: m.expiration
            });
        } else if (downloadType === 'video') {
            await lulli.sendMessage(m.chat, {
                video: { url: apiResult.result.url },
                caption: apiResult.title || '',
                fileName: `${apiResult.title || 'video_youtube'}.mp4`,
                mimetype: 'video/mp4',
            }, {
                quoted: thumbnailMessage,
                ephemeralExpiration: m.expiration
            });
        }
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada YouTube Downloader V2:', error);
        let errorMessage = error.message;

        if (errorMessage.includes('ENOSPC: no space left on device, write')) {
            await m.reply('✗ Ruang penyimpanan bot penuh! Mencoba mengirim sebagai dokumen...');
            if (apiResult && apiResult.result && apiResult.result.url) {
                try {
                    if (downloadType === 'audio') {
                        await lulli.sendMessage(m.chat, {
                            document: { url: apiResult.result.url },
                            fileName: `${apiResult.title || 'audio_youtube'}.mp3`,
                            mimetype: 'audio/mpeg',
                            caption: `✓ Audio dari: ${url}`
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        });
                    } else if (downloadType === 'video') {
                        await lulli.sendMessage(m.chat, {
                            document: { url: apiResult.result.url },
                            caption: `${apiResult.title || ''}\n✓ Video dari: ${url}`,
                            fileName: `${apiResult.title || 'video_youtube'}.mp4`,
                            mimetype: 'video/mp4',
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        });
                    }
                    return;
                } catch (docError) {
                    console.error('✗ Gagal mengirim sebagai dokumen juga:', docError.message);
                    errorMessage = `✗ Ruang penyimpanan bot penuh dan gagal mengirim sebagai dokumen: ${docError.message}`;
                }
            } else {
                errorMessage = `✗ Ruang penyimpanan bot penuh, namun tidak ada link unduhan yang tersedia untuk dikirim sebagai dokumen.`;
            }
        }
        await m.reply(`✗ Terjadi kesalahan: ${errorMessage}`);
    }
};

export default {
    run,
    cmd: ['ytmp3v2', 'ytmp4v2'],
    alias: ['yta2', 'ytv2'],
    use: 'link youtube',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/youtube2.js'
};