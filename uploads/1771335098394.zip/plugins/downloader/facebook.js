import axios from 'axios';
import * as cheerio from 'cheerio';
import { URLSearchParams } from 'node:url';

const SITE_URL = 'https://instatiktok.com/';

async function instaTiktokDownloader(platform, inputUrl) {
    if (!['instagram', 'tiktok', 'facebook'].includes(platform)) return {
        status: false,
        message: '✗ platform tidak valid.'
    };

    const form = new URLSearchParams();
    form.append('url', inputUrl);
    form.append('platform', platform);
    form.append('siteurl', SITE_URL);

    try {
        const res = await axios.post(`${SITE_URL}api`, form.toString(), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Origin': SITE_URL,
                'Referer': SITE_URL,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        const html = res?.data?.html;
        if (!html || res?.data?.status !== 'success') return {
            status: false,
            message: '✗ gagal mengambil data.'
        };

        const $ = cheerio.load(html);
        const links = [];

        $('a.btn[href^="http"]').each((_, el) => {
            const link = $(el).attr('href');
            if (link && !links.includes(link)) links.push(link);
        });

        if (links.length === 0) return {
            status: false,
            message: '✗ link tidak ada'
        };

        let download;

        if (platform === 'instagram') {
            download = links;
        } else if (platform === 'tiktok') {
            download = links.find(link => /hdplay/.test(link)) || links[0];
        } else if (platform === 'facebook') {
            download = links.at(-1);
        }

        return {
            status: true,
            platform,
            download
        };

    } catch (e) {
        return {
            status: false,
            message: `✗ Something went wrong: ${e.message || e}`
        };
    }
}

const run = async (m, lulli, {
    cfg,
    func
}) => {
    if (!m.text) return m.reply(`✗ Masukkan URL!\n\n✦ Contoh: *${m.cmd} https://www.facebook.com/watch/?v=1393572814172251*`);
    if (!m.args[0].match(/(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/)) return m.reply(cfg.mess.error.url);
    if (m.args[0].includes('https://l.facebook.com/l.php?u=')) return m.reply(cfg.mess.error.url);
    lulli.sendReact(m.chat, '🕒', m.key);
    const results = await instaTiktokDownloader('facebook', m.args[0]);
    if (!results.status) return m.reply(results.message);
    await lulli.sendMedia(m.chat, results.download, m, {
        expiration: m.expiration
    });
};

export default {
    run,
    cmd: 'facebook',
    alias: ['fbdl', 'fb'],
    use: 'link facebook',
    type: 'downloader',
    limit: 3,
    location: 'plugins/downloader/facebook.js'
};