import axios from 'axios';
import yts from 'yt-search';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'node:fs';
import path from 'node:path';

async function getBuffer(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer'
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('✗ Error fetching buffer:', error.message);
        return null;
    }
}

async function compressAudio(inputFileName, outputFileName) {
    const inputAudioPath = path.join(process.cwd(), inputFileName);
    const outputAudioPath = path.join(process.cwd(), outputFileName);

    return new Promise((resolve, reject) => {
        ffmpeg(inputAudioPath)
            .audioBitrate('128k')
            .toFormat('mp3')
            .on('end', () => {
                console.log('✓ Proses kompresi audio selesai.');
                if (fs.existsSync(inputAudioPath)) {
                    fs.unlinkSync(inputAudioPath);
                }
                resolve(outputAudioPath);
            })
            .on('error', (err) => {
                console.error('✗ Terjadi kesalahan saat kompresi audio:', err.message);
                reject(err);
            })
            .save(outputAudioPath);
    });
}

const processedAudio = new Set();

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'melukis senja'));
    }

    const query = m.text.trim();

    if (processedAudio.has(query)) {
        return m.reply('✦ Masih ada proses unduhan audio yang belum selesai. Mohon tunggu.');
    }
    processedAudio.add(query);
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const searchResults = await yts(query);
        const video = searchResults.videos[0];

        if (!video) {
            return m.reply('✗ Video tidak ditemukan dari pencarian.');
        }

        const durationParts = (video.timestamp || video.duration?.timestamp || '0:00').split(':').map(Number);
        const durationInSeconds = durationParts.reduce((acc, time) => (60 * acc) + time, 0);

        if (durationInSeconds >= 3600) {
            return m.reply('✗ Durasi video lebih dari 1 jam. Tidak dapat memutar audio.');
        }

        let caption = '✦ *YOUTUBE - PLAY*\n\n';
        caption += `- Judul: *${video.title || '-'}*\n`;
        caption += `- Durasi: ${video.timestamp || '-'}\n`;
        caption += `- Dilihat: ${video.views || '-'}\n`;
        caption += `- Upload: ${video.ago || '-'}\n`;
        caption += `- Penulis: *${video.author?.name || '-'}*\n`;
        caption += `- URL: ${video.url}\n`;
        caption += `- Deskripsi: ${video.description ? video.description.slice(0, 100) + '...' : '-'}\n\n`;
        caption += `✧ Mohon tunggu, file audio sedang dikirim...`;

        const thumbnailBuffer = await getBuffer(video.thumbnail);
        let messageResponse = await lulli.sendMessage(m.chat, {
            image: thumbnailBuffer,
            caption: caption,
            mimetype: 'image/jpeg'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

        const downloadApiUrl = `https://p.oceansaver.in/ajax/download.php?format=mp3&url=${encodeURIComponent(video.url)}&api=dfcb6d76f2f6a9894gjkege8a4ab232222`;
        const initialDownloadRes = await axios.get(downloadApiUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        });

        if (!initialDownloadRes.data || !initialDownloadRes.data.success) {
            return m.reply('✗ Gagal memulai unduhan audio dari API.');
        }

        const { id: taskId, title: audioTitle } = initialDownloadRes.data;

        let downloadUrl = null;
        while (true) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            const progressRes = await axios.get(`https://p.oceansaver.in/ajax/progress.php?id=${taskId}`, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
            });

            if (progressRes.data && progressRes.data.success && progressRes.data.progress === 1000) {
                downloadUrl = progressRes.data.download_url;
                break;
            }
            if (progressRes.data && progressRes.data.error) {
                throw new Error(progressRes.data.error);
            }
        }

        if (!downloadUrl) {
            throw new Error('✗ Gagal mendapatkan link unduhan audio.');
        }

        const audioBuffer = await getBuffer(downloadUrl);
        if (!audioBuffer) {
            throw new Error('✗ Gagal mengunduh file audio akhir.');
        }

        const tempInputFileName = func.filename('mp3');
        fs.writeFileSync(tempInputFileName, audioBuffer);
        const outputAudioPath = func.filename('mp3');
        await compressAudio(tempInputFileName, outputAudioPath);
        await lulli.sendMessage(m.chat, {
            audio: fs.readFileSync(outputAudioPath),
            mimetype: 'audio/mpeg',
            fileName: `${audioTitle || video.title}.mp3`,
            contextInfo: {
                externalAdReply: {
                    title: video.title,
                    body: video.timestamp || '-',
                    thumbnail: thumbnailBuffer,
                    mediaType: 2,
                    mediaUrl: video.url,
                    sourceUrl: video.url
                }
            }
        }, {
            quoted: messageResponse,
            ephemeralExpiration: m.expiration
        });
        fs.unlinkSync(outputAudioPath);
    } catch (error) {
        console.error('✗ Error dalam pemrosesan YouTube Play V2:', error);
        return lulli.reply(m.chat, `✗ Terjadi kesalahan: ${error.message}`, m, {
            expiration: m.expiration
        });
    } finally {
        processedAudio.delete(query);
    }
};

export default {
    run,
    cmd: 'play2',
    use: 'Judul lagu',
    type: 'downloader',
    restrict: true,
    limit: 3,
    location: 'plugins/downloader/play2.js'
};