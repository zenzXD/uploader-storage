import axios from 'axios';
import crypto from 'node:crypto';
import fetch from 'node-fetch';

async function tm() {
    try {
        const { data } = await axios.get('https://sssinstagram.com/msec');
        return Math.floor(data.msec * 1000);
    } catch (error) {
        console.error('✗ Error fetching time from sssinstagram.com:', error);
        return Date.now();
    }
}

async function generateSignature(url, secretKey) {
    const time = await tm();
    const ab = Date.now() - (time ? Date.now() - time : 0);
    const hashString = `${url}${ab}${secretKey}`;

    const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(hashString));
    const signature = Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');

    return { signature, ab, time };
}

async function ssig(url) {
    const secretKey = '19e08ff42f18559b51825685d917c5c9e9d89f8a5c1ab147f820f46e94c3df26';
    const { signature, ab, time } = await generateSignature(url, secretKey);

    const requestData = {
        url: url,
        ts: ab,
        _ts: 1739186038417,
        _tsc: time ? Date.now() - time : 0,
        _s: signature
    };

    const headers = {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://sssinstagram.com/',
        'authority': 'sssinstagram.com/',
        'Origin': 'https://sssinstagram.com/'
    };

    try {
        const response = await axios.post('https://sssinstagram.com/api/convert', requestData, {
            headers
        });
        return response.data;
    } catch (error) {
        console.error('✗ Error scraping data from sssinstagram.com:', error.message);
        return {
            error: '✗ Error scraping data',
            details: error.response ? error.response.data : error.message
        };
    }
}

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply('✗ Masukkan link Instagram!');
    }

    const inputUrl = func.isUrl(m.args[0]);
    if (!inputUrl || inputUrl.length === 0) {
        return m.reply('✗ Link Instagram tidak valid.');
    }
    const url = inputUrl[0];
    const regexPostReel = /https?:\/\/(?:www\.|m\.)?instagram\.com\/(?:p|reel)\/[A-z0-9_-]{1,11}/i;
    const regexTV = /https?:\/\/(?:www\.|m\.)?instagram\.com\/tv\/[A-z0-9_-]{1,11}/i;
    if (!url.match(regexPostReel) && !url.match(regexTV)) {
        return m.reply(`✗ Link tidak valid! Perintah ini untuk mengunduh postingan IG/Reel/TV.\n\n✦ Contoh:\n*${m.cmd} https://www.instagram.com/p/BmjK1KOD_UG/?utm_medium=copy_link*`);
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const result = await ssig(url);
        if (result.error) {
            return m.reply(`✗ Terjadi kesalahan: ${func.jsonFormat(result.details)}`);
        }
        const mediaArray = Array.isArray(result.result) ? result.result : [result.result];
        if (!mediaArray || mediaArray.length === 0) {
            return m.reply('✗ Tidak ditemukan media yang dapat diunduh.');
        }
        let captionSent = false;
        for (const item of mediaArray) {
            const meta = item.meta || {};
            const itemCaption = `✦ *INSTAGRAM DOWNLOADER*\n\n` +
                                `- Username: *${meta.username || '-'}*\n` +
                                `- Like: ${meta.like_count || 0}\n` +
                                `- Komentar: ${meta.comment_count || 0}\n` +
                                `- Caption: *${(meta.title || '-').slice(0, 1000)}*`;
            if (item.url?.[0]?.ext === 'mp4' && item.url?.[0]?.url) {
                await lulli.sendMessage(m.chat, {
                    video: { url: item.url[0].url },
                    caption: itemCaption,
                    mimetype: 'video/mp4'
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
                captionSent = true;
            } else if (item.url?.[0]?.url && (item.url?.[0]?.ext === 'jpg' || item.url?.[0]?.ext === 'jpeg' || item.url?.[0]?.ext === 'png')) {
                await lulli.sendMessage(m.chat, {
                    image: { url: item.url[0].url },
                    caption: captionSent ? '' : itemCaption,
                    mimetype: `image/${item.url[0].ext}`
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
                captionSent = true;
            } else if (item.thumb && !captionSent) {
                await lulli.sendMessage(m.chat, {
                    image: { url: item.thumb },
                    caption: captionSent ? '' : itemCaption,
                    mimetype: 'image/jpeg'
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
                captionSent = true;
            }
            await func.delay(1000);
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Instagram Downloader 3:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'instagram3',
    alias: ['igdl3', 'ig3'],
    use: 'link instagram (post, reel, TV)',
    type: 'downloader',
    premium: true,
    limit: 5,
    location: 'plugins/downloader/instagram3.js'
};