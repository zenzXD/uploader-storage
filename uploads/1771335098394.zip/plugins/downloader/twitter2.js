import qs from 'qs';
import * as cheerio from 'cheerio';
import axios from 'axios';

function twitter(link) {
    return new Promise((resolve, reject) => {
        let config = {
            URL: link,
        };
        axios.post("https://twdown.net/download.php", qs.stringify(config), {
            headers: {
                accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "sec-ch-ua": '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                cookie: "_ga=GA1.2.1388798541.1625064838; _gid=GA1.2.1351476739.1625064838; __gads=ID=7a60905ab10b2596-229566750eca0064:T=1625064837:RT=1625064837:S=ALNI_Mbg3GGC2b3oBVCUJt9UImup-j20Iw; _gat=1",
            },
        })
        .then(({ data }) => {
            const $ = cheerio.load(data);
            resolve({
                desc: $("div:nth-child(1) > div:nth-child(2) > p").text().trim(),
                thumb: $("div:nth-child(1) > img").attr("src"),
                video_sd: $("tr:nth-child(2) > td:nth-child(4) > a").attr("href"),
                video_hd: $("tbody > tr:nth-child(1) > td:nth-child(4) > a").attr("href"),
                audio: "https://twdown.net/" + $("body > div.jumbotron > div > center > div.row > div > div:nth-child(5) > table > tbody > tr:nth-child(3) > td:nth-child(4) > a").attr("href"),
            });
        })
        .catch(err => {
            console.error('✗ Error pada fungsi twitter downloader:', err.message);
            reject(new Error(`✗ Gagal mengunduh dari Twitter: ${err.message}`));
        });
    });
}

const run = async (m, lulli, { cfg }) => {
    if (!m.text) {
        return m.reply(`✗ Masukkan URL Twitter!\n\n✦ Contoh: *${m.cmd} https://twitter.com/akila_syafina1/status/1739769718318465429?t=LtQmZUNU2_lUkLqi91-UTQ&s=19*`);
    }

    const tweetUrl = m.args[0];
    const twitterRegex = /^(?:https?:\/\/)?(?:twitter\.com|t\.co|x\.com)\/(?:[^\/\?\s]+)\/status\/(\d+)(?:\?s=\d+)?/i;
    if (!twitterRegex.test(tweetUrl)) {
        return m.reply('✗ URL Twitter tidak valid. Mohon berikan link ke status tweet.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const results = await twitter(tweetUrl);
        const videoLink = results.video_hd || results.video_sd;
        if (!videoLink) {
            return m.reply('✗ Tidak ditemukan link video yang dapat diunduh.');
        }

        const videoMessage = await lulli.sendMedia(m.chat, videoLink, m, {
            caption: `✦ *TWITTER DOWNLOADER*\n\n- Deskripsi: *${results.desc || 'Tidak ada deskripsi'}*`,
            expiration: m.expiration,
            mimetype: 'video/mp4',
            fileName: 'twitter_video.mp4'
        });
        if (results.audio && results.audio.startsWith('https://')) {
            await lulli.sendMessage(m.chat, {
                audio: { url: results.audio },
                mimetype: 'audio/mpeg',
                fileName: 'twitter_audio.mp3'
            }, {
                quoted: videoMessage,
                ephemeralExpiration: m.expiration
            });
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Twitter Downloader:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'twitter2',
    alias: 'tw2',
    use: 'url twitter',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/twitter2.js'
};