import axios from 'axios';
import FormData from 'form-data';

class FSTIK {
    constructor() {
        this.api = {
            base: 'https://api.fstik.app',
            endpoints: {
                direct: '/getStickerSetByName',
                search: '/searchStickerSet'
            }
        };

        this.headers = {
            accept: 'application/json, text/plain, */*',
            'content-type': 'application/json',
            origin: 'https://webapp.fstik.app',
            referer: 'https://webapp.fstik.app/',
            'user-agent': 'NB Android/1.0.0'
        };
    }

    async name(name) {
        if (!name || typeof name !== 'string') {
            return {
                success: false,
                code: 400,
                message: '✗ Input tidak boleh kosong.'
            };
        }

        try {
            const res = await axios.post(
                this.api.base + this.api.endpoints.direct, {
                    name,
                    user_token: null
                }, {
                    headers: this.headers
                }
            );

            const set = res.data?.result;
            if (!set) {
                return {
                    success: false,
                    code: 404,
                    message: `✗ Sticker set "${name}" tidak ditemukan.`
                };
            }

            return {
                success: true,
                code: 200,
                result: {
                    source: 'database',
                    id: set.id,
                    title: set.title,
                    name: set.name,
                    description: set.description,
                    tags: set.tags,
                    kind: set.kind,
                    type: set.type,
                    public: set.public,
                    safe: set.safe,
                    verified: set.verified,
                    reaction: set.reaction,
                    installations: set.installations,
                    stickerCount: set.stickers?.length || 0,
                    stickers: set.stickers?.map((s, i) => {
                        const file_id = s.file_id ?? s.fileid;
                        const thumb_id = s.thumb?.file_id ?? s.thumb?.fileid;
                        return {
                            index: i + 1,
                            file_id,
                            thumb_id,
                            size: `${s.width}x${s.height}`,
                            image_url: thumb_id ? `${this.api.base}/file/${thumb_id}/sticker.webp` : null
                        };
                    })
                }
            };
        } catch (err) {
            console.error('✗ Error FSTIK.name:', err.message);
            return {
                success: false,
                code: err?.response?.status || 500,
                message: err.message
            };
        }
    }

    async search({ query = '', skip = 0, limit = 15, type = '', kind = 'regular' }) {
        try {
            const payload = {
                query,
                skip,
                limit,
                type,
                kind,
                user_token: null
            };

            const res = await axios.post(
                this.api.base + this.api.endpoints.search,
                payload, {
                    headers: this.headers
                }
            );

            const sets = res.data?.result?.stickerSets;
            if (!sets || sets.length === 0) {
                return {
                    success: false,
                    code: 404,
                    message: '✗ Sticker set tidak ditemukan.'
                };
            }

            return {
                success: true,
                code: 200,
                result: sets.map((set, i) => ({
                    index: i + skip + 1,
                    id: set.id,
                    name: set.name,
                    title: set.title,
                    description: set.description,
                    tags: set.tags,
                    kind: set.kind,
                    type: set.type,
                    public: set.public,
                    safe: set.safe,
                    verified: set.verified,
                    reaction: set.reaction,
                    installations: set.installations,
                    stickerCount: set.stickers?.length || 0,
                    stickers: set.stickers?.map((s, j) => {
                        const file_id = s.file_id ?? s.fileid;
                        const thumb_id = s.thumb?.file_id ?? s.thumb?.fileid;
                        return {
                            index: j + 1,
                            file_id,
                            thumb_id,
                            size: `${s.width}x${s.height}`,
                            image_url: thumb_id ? `${this.api.base}/file/${thumb_id}/sticker.webp` : null
                        };
                    })
                }))
            };
        } catch (err) {
            console.error('✗ Error FSTIK.search:', err.message);
            return {
                success: false,
                code: err?.response?.status || 500,
                message: err.message
            };
        }
    }

    async more(link, skip = 0, limit = 15) {
        if (!link?.startsWith('https://t.me/addstickers/')) {
            return {
                success: false,
                code: 400,
                message: '✗ Link Telegram tidak valid.'
            };
        }

        const name = link.split('/addstickers/')[1]?.trim();
        if (!name) {
            return {
                success: false,
                code: 400,
                message: '✗ Nama sticker tidak ditemukan.'
            };
        }

        const direct = await this.name(name);
        if (!direct.success) return direct;

        return await this.search({
            query: [direct.result.id],
            type: 'more',
            skip,
            limit
        });
    }

    async lookup(input) {
        if (!input || typeof input !== 'string') {
            return {
                success: false,
                code: 400,
                message: '✗ Input tidak boleh kosong.'
            };
        }

        let name = input.trim();
        const isLink = input.startsWith('https://t.me/addstickers/');
        if (isLink) {
            try {
                const url = new URL(name);
                name = url.pathname.replace('/addstickers/', '').trim();
                const direct = await this.name(name);
                if (direct.success) return direct;
            } catch (err) {
                return {
                    success: false,
                    code: 400,
                    message: '✗ Link Telegram tidak valid.'
                };
            }
        }

        return await this.search({
            query: name,
            type: '',
            kind: 'regular'
        });
    }

    async request(query, mode = 'lookup', options = {}) {
        if (!query || typeof query !== 'string' || !mode) {
            return {
                success: false,
                code: 400,
                message: '✗ Input tidak boleh kosong.'
            };
        }

        const input = query.trim();

        switch (mode) {
            case 'lookup':
                return await this.lookup(input);
            case 'more':
                return await this.more(input, options.skip || 0, options.limit || 15);
            case 'name':
                return await this.name(input);
            case 'search':
                return await this.search({
                    query: input,
                    skip: options.skip || 0,
                    limit: options.limit || 15,
                    type: options.type || '',
                    kind: options.kind || 'regular'
                });
            default:
                return {
                    success: false,
                    code: 400,
                    message: `✗ Mode "${mode}" tidak valid.`
                };
        }
    }
}

const fstik = new FSTIK();

const run = async (m, lulli, { cfg, func, packname, author }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'https://t.me/addstickers/Nekonyaaaa'));
    }
    const [url] = m.args;
    if (!func.isUrl(url) || !url.includes('t.me/addstickers/')) {
        return m.reply('✗ Link Telegram sticker tidak valid. Harus dimulai dengan `https://t.me/addstickers/`.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const results = await fstik.request(url, "lookup");
        if (!results.success || results.code !== 200) {
            return m.reply(`✗ Gagal mengambil sticker set: ${results.message || 'Terjadi kesalahan tidak diketahui.'}`);
        }
        const stickerSet = Array.isArray(results.result) ? results.result[0] : results.result;
        if (!stickerSet || !stickerSet.stickers || stickerSet.stickers.length === 0) {
            return m.reply('✗ Sticker set ditemukan, tetapi tidak ada stiker di dalamnya.');
        }
        const { name, title, description, reaction, stickerCount, stickers } = stickerSet;
        let caption = `✦ *TELESTICKER DOWNLOADER*\n\n` +
                      `- Nama Set: *${name || 'N/A'}*\n` +
                      `- Judul Set: *${title || 'N/A'}*\n` +
                      `- Deskripsi: ${description || 'N/A'}\n` +
                      `- Suka: ${reaction?.like || 0}\n` +
                      `- Tidak Suka: ${reaction?.dislike || 0}\n` +
                      `- Jumlah Stiker: ${stickerCount || 0}\n\n` +
                      `✦ Mohon tunggu, stiker sedang dikirim...`;
        await m.reply(caption);
        for (const item of stickers) {
            if (item.image_url) {
                await func.delay(1000);
                await lulli.sendStickerFromUrl(m.chat, item.image_url, m, {
                    packname: packname || 'Lulli Bot',
                    author: author || 'Developer',
                    expiration: m.expiration
                });
            }
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Telesticker Downloader:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'telesticker',
    alias: 'telestick',
    use: 'link sticker telegram',
    type: 'downloader',
    premium: true,
    location: 'plugins/downloader/telesticker.js'
};