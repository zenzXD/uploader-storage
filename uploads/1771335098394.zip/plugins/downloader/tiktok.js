import axios from 'axios';
import * as cheerio from 'cheerio';
import FormData from 'form-data';

function formatNumber(integer) {
    let numb = parseInt(integer);
    return Number(numb).toLocaleString('id-ID');
}

function formatDate(n, locale = 'en') {
    let d = new Date(n * 1000);
    return d.toLocaleDateString(locale, {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric'
    });
}

async function tiktokDl(url) {
    try {
        const domain = 'https://www.tikwm.com/api/';
        const res = await axios.post(domain, {}, {
            headers: {
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Origin': 'https://www.tikwm.com',
                'Referer': 'https://www.tikwm.com/',
                'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
                'Sec-Ch-Ua-Mobile': '?1',
                'Sec-Ch-Ua-Platform': 'Android',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
                'X-Requested-With': 'XMLHttpRequest'
            },
            params: {
                url: url,
                count: 12,
                cursor: 0,
                web: 1,
                hd: 1
            }
        });
        const dataRes = res.data.data;

        if (!dataRes) {
            return {
                status: false,
                message: '✗ Gagal mengambil data TikTok atau video tidak ditemukan.'
            };
        }

        let mediaData = [];
        if (dataRes?.duration === 0) {
            dataRes.images.map(v => {
                mediaData.push({
                    type: 'photo',
                    url: v
                });
            });
        } else {
            mediaData.push({
                type: 'watermark',
                url: 'https://www.tikwm.com' + (dataRes?.wmplay || "/undefined"),
            }, {
                type: 'nowatermark',
                url: 'https://www.tikwm.com' + (dataRes?.play || "/undefined"),
            }, {
                type: 'nowatermark_hd',
                url: 'https://www.tikwm.com' + (dataRes?.hdplay || "/undefined")
            });
        }

        const json = {
            status: true,
            title: dataRes.title,
            taken_at: formatDate(dataRes.create_time).replace('1970', ''),
            region: dataRes.region,
            id: dataRes.id,
            durations: dataRes.duration,
            duration: dataRes.duration + ' Seconds',
            cover: 'https://www.tikwm.com' + dataRes.cover,
            size_wm: dataRes.wm_size,
            size_nowm: dataRes.size,
            size_nowm_hd: dataRes.hd_size,
            data: mediaData,
            music_info: {
                id: dataRes.music_info.id,
                title: dataRes.music_info.title,
                author: dataRes.music_info.author,
                album: dataRes.music_info.album ? dataRes.music_info.album : null,
                url: 'https://www.tikwm.com' + (dataRes.music || dataRes.music_info.play)
            },
            stats: {
                views: formatNumber(dataRes.play_count),
                likes: formatNumber(dataRes.digg_count),
                comment: formatNumber(dataRes.comment_count),
                share: formatNumber(dataRes.share_count),
                download: formatNumber(dataRes.download_count)
            },
            author: {
                id: dataRes.author.id,
                fullname: dataRes.author.unique_id,
                nickname: dataRes.author.nickname,
                avatar: 'https://www.tikwm.com' + dataRes.author.avatar
            }
        };
        return json;
    } catch (e) {
        console.error('✗ Error pada tiktokDl:', e.message);
        return {
            status: false,
            message: `✗ Terjadi kesalahan: ${e.message}`
        };
    }
}

function generateLink(text) {
    const regex = /(https?:\/\/(?:www\.|(?!www))[^\s.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})/gi;
    return text.match(regex) || [];
}

function ttFixed(url) {
    if (!url.match(/(tiktok.com\/t\/)/g)) return url;
    let id = url.split('/t/')[1];
    return 'https://vm.tiktok.com/' + id;
}

function filterDuplicates(array) {
    return [...new Set(array)];
}

const run = async (m, lulli, { cfg, func }) => {
    let inputUrlText;

    if (m.args.length >= 1) {
        inputUrlText = m.args.join(' ');
    } else if (m.quoted && m.quoted.text) {
        inputUrlText = m.quoted.text;
    }

    if (!inputUrlText) {
        return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZSF4cWcA2/'));
    }
    if (!inputUrlText.includes('tiktok.com')) {
        return m.reply('✗ Link tidak valid. Harus link TikTok.');
    }

    const extractedLinks = generateLink(inputUrlText);
    const links = filterDuplicates(extractedLinks.filter(v => ttFixed(v).match(/^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/)));
    if (links.length < 1) {
        return m.reply('✗ Link TikTok tidak valid atau tidak ditemukan.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const result = await tiktokDl(links[0]);
        if (!result.status) {
            if (result.message && result.message.includes('slide')) {
                 return m.reply(`✗ URL tersebut adalah TikTok slide, gunakan \`${m.prefix}ttslide ${links[0]}\` untuk mengunduhnya.`);
            }
            return m.reply(`✗ ${result.message || 'Gagal mengunduh video TikTok.'}`);
        }
        const videoToDownload = m.isPrem
            ? result.data.find(x => x.type === 'nowatermark_hd') || result.data.find(x => x.type === 'nowatermark')
            : result.data.find(x => x.type === 'nowatermark') || result.data.find(x => x.type === 'nowatermark_hd');

        if (result.data.some(x => x.type === 'photo')) {
            let photoCaption = `✦ *TIKTOK DOWNLOADER (SLIDE)*\n\n` +
                               `- Judul: ${result.title || 'N/A'}\n` +
                               `- Author: *${result.author?.nickname || 'N/A'}*\n` +
                               `- View: ${result.stats?.views || 0}\n` +
                               `- Like: ${result.stats?.likes || 0}\n` +
                               `- Share: ${result.stats?.share || 0}\n` +
                               `- Komentar: ${result.stats?.comment || 0}\n\n` +
                               `Mengirim gambar slide...`;
            await m.reply(photoCaption);
            for (const photo of result.data.filter(x => x.type === 'photo')) {
                await lulli.sendMedia(m.chat, photo.url, null, {
                    expiration: m.expiration
                });
                await func.delay(1000);
            }
        } else if (videoToDownload) {
            let videoCaption = `✦ TIKTOK DOWNLOADER\n\n` +
                               `- Judul: ${result.title || 'N/A'}\n` +
                               `- Author: *${result.author?.nickname || 'N/A'}*\n` +
                               `- Durasi: ${result.durations || 'N/A'} detik\n` +
                               `- View: ${result.stats?.views || 0}\n` +
                               `- Like: ${result.stats?.likes || 0}\n` +
                               `- Share: ${result.stats?.share || 0}\n` +
                               `- Komentar: ${result.stats?.comment || 0}\n\n` +
                               `Mengirim video...`;
            const quotedMessage = await lulli.sendMessage(m.chat, {
                video: { url: videoToDownload.url },
                caption: videoCaption,
                mimetype: 'video/mp4'
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            /*if (result.music_info?.url) {
                await lulli.sendMessage(m.chat, {
                    audio: { url: result.music_info.url },
                    mimetype: 'audio/mpeg',
                    fileName: `${result.music_info.title || 'tiktok_audio'}.mp3`
                }, {
                    quoted: quotedMessage,
                    ephemeralExpiration: m.expiration
                });
            }*/
        } else {
            return m.reply('✗ Tidak ditemukan media yang dapat diunduh.');
        }
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada TikTok Downloader:', error);
        await m.reply(`✗ Terjadi kesalahan: ${cfg.mess.wrong(error.message)}`);
    }
};

export default {
    run,
    cmd: 'tiktok',
    alias: 'tt',
    use: 'link tiktok',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/tiktok.js'
};