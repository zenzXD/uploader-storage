import axios from 'axios';
import * as cheerio from 'cheerio';
import fetch from 'node-fetch';

String.prototype.budicanto = function (...args) {
    return String.fromCharCode(...args);
};

const decodeBase64 = (encoded) => {
    const key = 'Insb778';
    const decoder = Buffer.from(encoded, key.replace('Insb778', String.prototype.budicanto(98, 97, 115, 101, 54, 52)));
    return decoder.toString(String.prototype.budicanto(117, 116, 102, 45, 56));
};

const fetchInstagramMedia = async (url) => {
    try {
        const isVideo = url.includes('/reel/') || url.includes('/p/');
        const endpoint = 'https://indownloader.app/request';
        const type = isVideo ? 'video' : 'photo';

        const response = await axios.post(endpoint, `link=${encodeURIComponent(url)}&downloader=${type}`, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept': 'application/json, text/javascript,*/*; q=0.01',
                'X-Requested-With': 'XMLHttpRequest',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                'Referer': isVideo
                    ? 'https://indownloader.app/video-downloader'
                    : 'https://indownloader.app/download-instagram-photo'
            }
        });

        if (response.data.error === false) {
            const htmlContent = response.data.html;
            const mediaLinks = [];
            const regex = /<a\s+(?:[^>]*?\s+)?href=(["'])(.*?)\1/g;
            let match;

            while ((match = regex.exec(htmlContent)) !== null) {
                const link = match[2];
                if (link.includes('file?id=')) {
                    mediaLinks.push(link);
                }
            }
            return mediaLinks;
        } else {
            console.warn('✗ API indownloader.app mengembalikan error:', response.data.message);
            return null;
        }
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada fetchInstagramMedia:', error.message);
        return null;
    }
};

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA=='));
    }
    
    const igRegex = /https:\/\/(?:www\.)?instagram\.com\/(?:p|reel|tv)\/[A-Za-z0-9_-]+\/?(?:\?.+)?$/i;
    const inputUrl = m.args[0];

    if (!inputUrl.match(igRegex)) {
        return m.reply(`✗ Link tidak valid! Perintah ini untuk mengunduh postingan IG/Reel/TV, bukan highlight/story.\n\n✦ Contoh:\n*${m.cmd} https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA==*`);
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const mediaUrls = await fetchInstagramMedia(inputUrl);
        if (!mediaUrls || mediaUrls.length === 0) {
            return m.reply('✗ Gagal mengambil media dari link Instagram. Coba lagi nanti atau gunakan link lain.');
        }
        for (let [index, mediaUrl] of mediaUrls.entries()) {
            const messageQuoted = index === 0 ? m : null;
            const caption = (index === 0 && mediaUrls.length === 1) ? '✓ Berhasil mengunduh media Instagram.' : '';
            await lulli.sendMedia(m.chat, mediaUrl, messageQuoted, {
                caption: caption,
                expiration: m.expiration
            });
            await func.delay(1000);
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Instagram Downloader 2:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'instagram2',
    alias: ['igdl2', 'ig2'],
    use: 'link instagram (post, reel, TV)',
    type: 'downloader',
    premium: true,
    limit: 5,
    location: 'plugins/downloader/instagram2.js'
};