import axios from 'axios';

const ANABOT_API_BASE_URL = 'https://anabot.my.id/api/download';
const API_KEY = 'freeApikey';

const run = async (m, lulli, { func, cfg }) => {
    let url = m.args[0];
    let downloadType;

    try {
        if (/yt?(a|mp3)/i.test(m.command)) {
            downloadType = 'ytmp3';
        } else if (/yt?(v|mp4)/i.test(m.command)) {
            downloadType = 'ytmp4';
        } else {
            return m.reply('✗ Command tidak valid. Gunakan yta2 atau ytv2.');
        }

        if (!url) {
            return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'));
        }

        const youtubeRegex = /^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/;
        if (!youtubeRegex.test(url)) {
            return m.reply('✗ URL YouTube tidak valid.');
        }
        lulli.sendReact(m.chat, '🕒', m.key);
        const response = await axios.get(`${ANABOT_API_BASE_URL}/${downloadType}?url=${encodeURIComponent(url)}&apikey=${API_KEY}`);
        const { status, data, message: apiMessage } = response.data;
        if (status !== 200 || !data?.result?.success) {
            return m.reply(`✗ Gagal mengunduh: ${apiMessage || data?.result?.message || 'Terjadi kesalahan tidak diketahui.'}`);
        }
        const { mimetype, metadata, urls } = data.result;
        const { title, channel, views, duration, thumbnail, uploadDate, description } = metadata;
        const caption = `✦ *YOUTUBE DOWNLOADER ${downloadType === 'ytmp4' ? 'MP4' : 'MP3'}*\n\n` +
                        `- Judul: *${title || 'N/A'}*\n` +
                        `- Channel: *${channel || 'N/A'}*\n` +
                        `- Dilihat: ${views || 'N/A'}\n` +
                        `- Durasi: ${duration || 'N/A'}\n` +
                        `- Upload: ${uploadDate || 'N/A'}\n` +
                        `- Deskripsi: ${description ? description.slice(0, 100) + '...' : 'N/A'}\n\n` +
                        `✧ Mohon tunggu, file ${downloadType === 'ytmp4' ? 'video' : 'audio'} sedang dikirim...`;
        const thumbnailMessage = await lulli.sendMessage(m.chat, {
            image: { url: thumbnail },
            caption: caption,
            mimetype: 'image/jpeg'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
        if (downloadType === 'ytmp3') {
            await lulli.sendMessage(m.chat, {
                audio: { url: urls },
                fileName: `${title || 'audio_youtube'}.mp3`,
                mimetype: 'audio/mpeg',
            }, {
                quoted: thumbnailMessage,
                ephemeralExpiration: m.expiration
            });
        } else if (downloadType === 'ytmp4') {
            await lulli.sendMessage(m.chat, {
                video: { url: urls },
                caption: title || '',
                fileName: `${title || 'video_youtube'}.mp4`,
                mimetype: 'video/mp4',
            }, {
                quoted: thumbnailMessage,
                ephemeralExpiration: m.expiration
            });
        }
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada YouTube Downloader V2:', error);
        await m.reply(`✗ Terjadi kesalahan: ${error.message}`);
    }
};

export default {
    run,
    cmd: ['ytmp3v2', 'ytmp4v2'],
    alias: ['yta2', 'ytv2'],
    use: 'link youtube',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/youtube2.js'
};