import axios from 'axios';
import FormData from 'form-data';
import fs from 'node:fs';
import path from 'node:path';
import filetype from 'file-type';
const { fromBuffer } = filetype;

class Videy {
    static async upload(buffer) {
        try {
            const fileType = await fromBuffer(buffer);
            const ext = fileType ? fileType.ext : 'mp4';

            let form = new FormData();
            form.append("file", buffer, {
                filename: `video.${ext}`,
                contentType: `video/${ext}`
            });

            const response = await axios.post("https://videy.co/api/upload", form, {
                headers: {
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0',
                    ...form.getHeaders()
                }
            });

            if (response.data && response.data.id) {
                return `https://videy.co/v?id=${response.data.id}`;
            } else {
                throw new Error('✗ ID tidak ditemukan dalam respons JSON dari Videy.');
            }
        } catch (error) {
            console.error('✗ Error mengunggah ke Videy:', error.message);
            throw error;
        }
    }

    static async download(query) {
        try {
            const parsedURL = new URL(query);
            const id = parsedURL.searchParams.get('id');
            if (!id) {
                throw new Error("✗ URL tidak valid. Gunakan format: https://videy.co/v?id=ABC123");
            }
            const downloadURL = `https://cdn.videy.co/${id.trim()}.mp4`;
            const response = await axios({
                method: 'get',
                url: downloadURL,
                responseType: 'arraybuffer'
            });

            return response.data;
        } catch (error) {
            console.error('✗ Error mengunduh dari Videy:', error.message);
            throw error;
        }
    }
}

function generateLink(text) {
    const regex = /(https?:\/\/(?:www\.|(?!www))[^\s.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})/gi;
    return text.match(regex) || [];
}

function filterDuplicates(array) {
    return [...new Set(array)];
}

const run = async (m, lulli, { cfg, func, quoted }) => {
    switch (m.command) {
        case 'tovidey': {
            if (!quoted || !/video/i.test(quoted.mime)) {
                return m.reply(`✗ Mohon kirim/balas video dengan caption *${m.cmd}*`);
            }
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                const buffer = await quoted.download();
                if (!buffer) {
                    return m.reply('✗ Gagal mengunduh video.');
                }
                const url = await Videy.upload(buffer);
                if (!url) {
                    return m.reply('✗ Gagal mengunggah video ke Videy.');
                }
                await m.reply(`✓ Video berhasil diunggah ke Videy: ${url}`);
            } catch (e) {
                console.error('✗ Error tovidey:', e);
                await m.reply(`✗ Terjadi kesalahan saat mengunggah video: ${e.message}`);
            }
        }
        break;

        case 'videydl': {
            let inputUrlText;
            if (m.args.length >= 1) {
                inputUrlText = m.args.join(' ');
            } else if (m.quoted && m.quoted.text) {
                inputUrlText = m.quoted.text;
            }

            if (!inputUrlText) {
                return m.reply(func.example(m.cmd, 'https://videy.co/v?id=xxxxx'));
            }

            const extractedLinks = generateLink(inputUrlText);
            const links = filterDuplicates(extractedLinks.filter(v => /^https:\/\/videy\.co\/v\?id=.*$/i.test(v)));
            if (links.length < 1) {
                return m.reply('✗ Link Videy tidak valid. Harus dalam format `https://videy.co/v?id=ABC123`.');
            }
            lulli.sendReact(m.chat, '🕒', m.key);
            try {
                for (const url of links) {
                    await func.delay(1000);
                    const buffer = await Videy.download(url);
                    if (!buffer) {
                        await m.reply(`✗ Gagal mengunduh video dari: ${url}`);
                        continue;
                    }
                    await lulli.sendMedia(m.chat, buffer, m, {
                        expiration: m.expiration,
                        caption: `✓ Video berhasil diunduh dari Videy.`
                    });
                }
            } catch (e) {
                console.error('✗ Error videydl:', e);
                await m.reply(`✗ Terjadi kesalahan saat mengunduh video: ${e.message}`);
            }
        }
        break;
    }
};

export default {
    run,
    cmd: ['tovidey', 'videydl'],
    use: 'parameter atau link videy',
    type: 'downloader',
    limit: true,
    location: 'plugins/downloader/videy.js'
};