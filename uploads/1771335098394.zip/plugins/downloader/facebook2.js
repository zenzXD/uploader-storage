import axios from 'axios';

const fbVideoV2 = async (url) => {
    try {
        const encodedURL = encodeURIComponent(url);
        const { data } = await axios.get(`https://tooly.chative.io/facebook/video?url=${encodedURL}`);
        const { success, title, videos } = data;
        if (!success) {
            return {
                message: "✗ Pengunduhan Tidak Berhasil!",
                code: 500,
                success: false,
            };
        }
        const titleCheck = title === "Untitled" ? "Tidak ada judul tersedia." : title;
        return {
            success: true,
            title: titleCheck,
            sdVideos: {
                videoUrl: videos.sd?.url,
                sizeVideo: videos.sd?.size,
            },
            hdVideos: {
                videoUrl: videos.hd?.url,
                sizeVideo: videos.hd?.size,
            },
        };
    } catch (error) {
        console.error('✗ Error pada fbVideoV2:', error.message);
        return {
            message: `✗ Terjadi kesalahan teknis: ${error.message}`,
            code: 500,
            success: false,
        };
    }
};

const run = async (m, lulli, { cfg }) => {
    let inputUrlText;

    if (m.args.length >= 1) {
        inputUrlText = m.args.join(' ');
    } else if (m.quoted && m.quoted.text) {
        inputUrlText = m.quoted.text;
    }

    if (!inputUrlText) {
        return m.reply(`✗ Masukkan URL Facebook!\n\n✦ Contoh: *${m.cmd} https://www.facebook.com/watch/?v=1393572814172251*`);
    }

    const inputUrl = inputUrlText.trim();

    const fbUrlRegex = /(?:https?:\/\/(?:web\.|www\.|m\.)?(facebook|fb)\.(?:com|watch)\S+)/i;
    if (!inputUrl.match(fbUrlRegex)) {
        return m.reply('✗ URL Facebook tidak valid.');
    }
    if (inputUrl.includes('https://l.facebook.com/l.php?u=')) {
        return m.reply('✗ URL yang diberikan adalah link redirect. Mohon berikan link langsung ke video Facebook.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const results = await fbVideoV2(inputUrl);
        
        if (!results.success) {
            return m.reply(`✗ ${results.message || 'Terjadi kesalahan saat mengunduh video.'}`);
        }
        const { title, sdVideos, hdVideos } = results;
        const videoToDownload = hdVideos.videoUrl || sdVideos.videoUrl;
        const videoSize = hdVideos.sizeVideo || sdVideos.sizeVideo;
        const videoQuality = hdVideos.videoUrl ? 'HD' : (sdVideos.videoUrl ? 'SD' : 'N/A');
        if (!videoToDownload) {
            return m.reply('✗ Tidak ditemukan link video yang dapat diunduh.');
        }
        const caption = `✦ *FACEBOOK DOWNLOADER*\n\n` +
                        `- Judul: *${title}*\n` +
                        `- Ukuran: ${videoSize || 'Tidak Diketahui'}\n` +
                        `- Kualitas: ${videoQuality}`;
        await lulli.sendMessage(m.chat, {
            video: { url: videoToDownload },
            caption: caption,
            fileName: `${title}.mp4`,
            mimetype: 'video/mp4'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Downloader Facebook V2:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'facebook2',
    alias: ['fbdl2', 'fb2'],
    use: 'link facebook',
    type: 'downloader',
    limit: 3,
    location: 'plugins/downloader/facebook2.js'
};