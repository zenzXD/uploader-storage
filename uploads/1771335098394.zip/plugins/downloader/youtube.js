const run = async (m, lulli, {
    func,
    cfg,
    YT
}) => {
    let url = m.args[0];
    let downloadType;
    let apiResult;
    try {
        if (/yt?(a|mp3)/i.test(m.command)) {
            downloadType = 'audio';
        } else if (/yt?(v|mp4)/i.test(m.command)) {
            downloadType = 'video';
        } else {
            return m.reply('✗ Command tidak valid. Gunakan ytmp3/yta atau ytmp4/ytv.');
        }
        if (!url) {
            return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'));
        }
        const youtubeRegex = /^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/;
        if (!youtubeRegex.test(url)) {
            return m.reply('✗ URL YouTube tidak valid.');
        }
        lulli.sendReact(m.chat, '🕒', m.key);
        if (downloadType === 'audio') {
            const apiUrl = `https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(url)}`;
            const downloaderResponse = await fetch(apiUrl);
            const downloaderJson = await downloaderResponse.json();
            if (!downloaderJson.status || !downloaderJson.result || !downloaderJson.result.mp3) {
                return m.reply('Gagal mendapatkan link unduhan audio. API mungkin sedang down.');
            }
            apiResult = downloaderJson.result;
            const {
                title,
                thumbnail,
                duration,
                mp3
            } = apiResult;
            const caption = `✦ *YOUTUBE DOWNLOADER ${downloadType === 'video' ? 'MP4' : 'MP3'}*\n\n` + `- Judul: *${title || 'N/A'}*\n` + `- Durasi: ${formatDuration(duration) || 'N/A'}\n` + `Mohon tunggu, file ${downloadType === 'video' ? 'video' : 'audio'} sedang dikirim...`;
            const thumbnailMessage = await lulli.sendMessage(m.chat, {
                image: {
                    url: thumbnail
                },
                caption: caption,
                mimetype: 'image/jpeg'
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            await lulli.sendMessage(m.chat, {
                audio: {
                    url: mp3
                },
                fileName: `${title || 'audio_youtube'}.mp3`,
                mimetype: 'audio/mpeg',
            }, {
                quoted: thumbnailMessage,
                ephemeralExpiration: m.expiration
            });
        } else if (downloadType === 'video') {
            const apiUrl = `https://api-faa.my.id/faa/ytmp4?url=${encodeURIComponent(url)}`;
            const downloaderResponse = await fetch(apiUrl);
            const downloaderJson = await downloaderResponse.json();
            if (!downloaderJson.status || !downloaderJson.result || !downloaderJson.result.download_url) {
                return m.reply('Gagal mendapatkan link unduhan audio. API mungkin sedang down.');
            }
            apiResult = downloaderJson.result;
            await lulli.sendMessage(m.chat, {
                video: {
                    url: apiResult.download_url
                },
                caption: `✓ Video dari: ${url}`,
                fileName: `${Date.now()}.mp4`,
                mimetype: 'video/mp4',
            }, {
                quoted: thumbnailMessage,
                ephemeralExpiration: m.expiration
            });
        }
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada YouTube Downloader:', error);
        let errorMessage = error.message;
        if (errorMessage.includes('ENOSPC: no space left on device, write')) {
            await m.reply('✗ Ruang penyimpanan bot penuh! Mencoba mengirim sebagai dokumen...');
            if (apiResult) {
                try {
                    if (downloadType === 'audio') {
                        await lulli.sendMessage(m.chat, {
                            document: {
                                url: apiResult.mp3
                            },
                            fileName: `${apiResult.title || 'audio_youtube'}.mp3`,
                            mimetype: 'audio/mpeg',
                            caption: `✓ Audio dari: ${url}`
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        });
                    } else if (downloadType === 'video') {
                        await lulli.sendMessage(m.chat, {
                            document: {
                                url: apiResult.download_url
                            },
                            caption: `✓ Video dari: ${url}`,
                            fileName: `${Date.now()}.mp4`,
                            mimetype: 'video/mp4',
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        });
                    }
                    return;
                } catch (docError) {
                    console.error('✗ Gagal mengirim sebagai dokumen juga:', docError.message);
                    errorMessage = `✗ Ruang penyimpanan bot penuh dan gagal mengirim sebagai dokumen: ${docError.message}`;
                }
            } else {
                errorMessage = `✗ Ruang penyimpanan bot penuh, namun tidak ada link unduhan yang tersedia untuk dikirim sebagai dokumen.`;
            }
        }
        await m.reply(`✗ Terjadi kesalahan: ${errorMessage}`);
    }
};

function formatDuration(seconds) {
    // Menghitung menit
    const minutes = Math.floor(seconds / 60);
    // Menghitung sisa detik
    const remainingSeconds = seconds % 60;
    // Menggunakan padStart agar selalu 2 digit (misal: 01:38, bukan 1:38)
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(remainingSeconds).padStart(2, '0');
    return `${formattedMinutes}:${formattedSeconds}`;
}
export default {
    run,
    cmd: ['ytmp3', 'ytmp4'],
    alias: ['yta', 'ytv'],
    use: 'link YouTube',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/youtube.js'
};