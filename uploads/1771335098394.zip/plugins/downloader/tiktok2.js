import axios from 'axios';
import * as cheerio from 'cheerio';
import FormData from 'form-data';

async function tiktok2(url) {
    try {
        const encodedParams = new URLSearchParams();
        encodedParams.set('url', url);
        encodedParams.set('hd', '1');
        const response = await axios({
            method: 'POST',
            url: 'https://tikwm.com/api/',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Cookie': 'current_language=en',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
            },
            data: encodedParams
        });
        const videos = response.data.data;
        if (!videos) {
            throw new Error('✗ Gagal mengambil data video dari tikwm.com.');
        }

        const result = {
            title: videos.title,
            cover: videos.cover,
            origin_cover: videos.origin_cover,
            no_watermark: videos.play,
            watermark: videos.wmplay,
            music: videos.music
        };
        return result;
    } catch (error) {
        console.error('✗ Error pada tiktok2 downloader:', error.message);
        throw new Error(`✗ Terjadi kesalahan: ${error.message}`);
    }
}

function generateLink(text) {
    const regex = /(https?:\/\/(?:www\.|(?!www))[^\s.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})/gi;
    return text.match(regex) || [];
}

function ttFixed(url) {
    if (!url.match(/(tiktok.com\/t\/)/g)) return url;
    let id = url.split('/t/')[1];
    return 'https://vm.tiktok.com/' + id;
}

function filterDuplicates(array) {
    return [...new Set(array)];
}

const run = async (m, lulli, { cfg, func }) => {
    let inputUrlText;

    if (m.args.length >= 1) {
        inputUrlText = m.args.join(' ');
    } else if (m.quoted && m.quoted.text) {
        inputUrlText = m.quoted.text;
    }

    if (!inputUrlText) {
        return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZSF4cWcA2/'));
    }

    if (!inputUrlText.includes('tiktok.com')) {
        return m.reply('✗ Link tidak valid. Harus link TikTok.');
    }
    const extractedLinks = generateLink(inputUrlText);
    const links = filterDuplicates(extractedLinks.filter(v => ttFixed(v).match(/^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/)));
    if (links.length < 1) {
        return m.reply('✗ Link TikTok tidak valid atau tidak ditemukan.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const result = await tiktok2(links[0]);
        if (!result) {
            return m.reply('✗ Gagal mengunduh video TikTok.');
        }
        if (!result.no_watermark) {
            return m.reply('✗ Link video tanpa watermark tidak ditemukan. Mungkin ini TikTok slide atau masalah lain.');
        }
        let caption = `✦ *TIKTOK DOWNLOADER*\n\n` +
                      `- Judul: *${result.title || 'N/A'}*\n\n` +
                      `Mengirim video...`;
        const videoMessage = await lulli.sendMessage(m.chat, {
            video: { url: result.no_watermark },
            caption: caption,
            fileName: `${result.title || 'tiktok_video'}.mp4`,
            mimetype: 'video/mp4'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
        if (result.music && result.music.startsWith('https://')) {
            await lulli.sendMessage(m.chat, {
                audio: { url: result.music },
                mimetype: 'audio/mpeg',
                ptt: false
            }, {
                quoted: videoMessage,
                ephemeralExpiration: m.expiration
            });
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada TikTok Downloader (tikwm.com):', e);
        await m.reply(`✗ Terjadi kesalahan: ${cfg.mess.wrong(e.message)}`);
    }
};

export default {
    run,
    cmd: 'tiktok2',
    alias: 'tt2',
    use: 'link tiktok',
    type: 'downloader',
    limit: 5,
    location: 'plugins/downloader/tiktok2.js'
};