import axios from 'axios';
import yts from 'yt-search';
import fetch from 'node-fetch';

async function getBuffer(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer'
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('✗ Error fetching buffer:', error.message);
        return null;
    }
}

const processedAudio = new Set();

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'melukis senja'));
    }
    const query = m.text.trim();
    if (processedAudio.has(query)) {
        return m.reply('✦ Masih ada proses unduhan audio yang belum selesai. Mohon tunggu.');
    }
    processedAudio.add(query);
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const searchResults = await yts(query);
        const video = searchResults.videos[0];
        if (!video) {
            return m.reply('✗ Video tidak ditemukan dari pencarian.');
        }
        const durationParts = (video.timestamp || video.duration?.timestamp || '0:00').split(':').map(Number);
        const durationInSeconds = durationParts.reduce((acc, time) => (60 * acc) + time, 0);
        if (durationInSeconds >= 3600) {
            return m.reply('✗ Durasi video lebih dari 1 jam. Tidak dapat memutar audio.');
        }
        let caption = '✦ *YOUTUBE - PLAY*\n\n';
        caption += `- Judul: *${video.title || '-'}*\n`;
        caption += `- Durasi: ${video.timestamp || '-'}\n`;
        caption += `- Dilihat: ${video.views || '-'}\n`;
        caption += `- Upload: ${video.ago || '-'}\n`;
        caption += `- Penulis: *${video.author?.name || '-'}*\n`;
        caption += `- URL: ${video.url}\n`;
        caption += `- Deskripsi : ${video.description ? video.description.slice(0, 100) + '...' : '-'}\n\n`;
        caption += `✧ Mohon tunggu, file audio sedang dikirim...`;
        const thumbnailBuffer = await getBuffer(video.thumbnail);
        let messageResponse = await lulli.sendMessage(m.chat, {
            image: thumbnailBuffer,
            caption: caption,
            mimetype: 'image/jpeg'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

        const headers = {
            "accept": "*/*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": "\"Android\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            "Referer": "https://id.ytmp3.mobi/",
            "Referrer-Policy": "strict-origin-when-cross-site"
        };
        const format = 'mp3';
        const videoId = video.url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
        if (!videoId) {
            throw new Error('✗ Gagal mendapatkan Video ID YouTube.');
        }

        const initialRes = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, { headers });
        const initData = await initialRes.json();
        if (!initData || !initData.convertURL) {
            throw new Error('✗ Gagal menginisialisasi konversi.');
        }

        const convertURL = initData.convertURL + `&v=${videoId}&f=${format}&_=${Math.random()}`;
        const convertsRes = await fetch(convertURL, { headers });
        const convertData = await convertsRes.json();
        if (!convertData || !convertData.progressURL) {
            throw new Error('✗ Gagal memulai konversi.');
        }

        let downloadInfo = {};
        for (let i = 0; i < 10; i++) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            const progressRes = await fetch(convertData.progressURL, { headers });
            downloadInfo = await progressRes.json();
            if (downloadInfo.progress === 3) break;
        }
        if (!downloadInfo.progress || downloadInfo.progress !== 3 || !convertData.downloadURL) {
            throw new Error('✗ Gagal mendapatkan link unduhan audio.');
        }
        const audioResult = {
            url: convertData.downloadURL,
            title: downloadInfo.title || video.title
        };
        await lulli.sendMessage(m.chat, {
            audio: { url: audioResult.url },
            mimetype: 'audio/mpeg',
            fileName: `${audioResult.title}.mp3`,
            contextInfo: {
                externalAdReply: {
                    title: video.title,
                    body: video.timestamp || '-',
                    thumbnail: thumbnailBuffer,
                    mediaType: 2,
                    mediaUrl: video.url,
                    sourceUrl: video.url
                }
            }
        }, {
            quoted: messageResponse,
            ephemeralExpiration: m.expiration
        });
    } catch (error) {
        console.error('✗ Error dalam pemrosesan YouTube Play V4:', error);
        return lulli.reply(m.chat, `✗ Terjadi kesalahan: ${error.message}`, m, {
            expiration: m.expiration
        });
    } finally {
        processedAudio.delete(query);
    }
};

export default {
    run,
    cmd: 'play4',
    use: 'judul lagu',
    type: 'downloader',
    restrict: true,
    limit: 3,
    location: 'plugins/downloader/play4.js'
};