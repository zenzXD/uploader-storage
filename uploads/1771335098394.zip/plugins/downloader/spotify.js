import axios from 'axios';

const CLIENT_ID = "acc6302297e040aeb6e4ac1fbdfd62c3";
const CLIENT_SECRET = "0e8439a1280a43aba9a5bc0a16f3f009";
const BASIC_AUTH_TOKEN = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString("base64");
const TOKEN_ENDPOINT = "https://accounts.spotify.com/api/token";
const SEARCH_ENDPOINT = "https://api.spotify.com/v1/search";
const DOWNLOAD_API_ENDPOINT = "https://spotydown.media/api/download-track";

const getToken = async () => {
    try {
        const res = await axios.post(
            TOKEN_ENDPOINT,
            "grant_type=client_credentials", {
                headers: {
                    Authorization: "Basic " + BASIC_AUTH_TOKEN,
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            }
        );
        return res.data.access_token;
    } catch (error) {
        console.error('✗ Error fetching Spotify token:', error.message);
        throw new Error('✗ Gagal mendapatkan token Spotify.');
    }
};

const searchTrack = async (query, token) => {
    try {
        const res = await axios.get(
            `${SEARCH_ENDPOINT}?q=${encodeURIComponent(query)}&type=track&limit=1`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        if (res.data.tracks.items.length === 0) {
            throw new Error('✗ Lagu tidak ditemukan di Spotify.');
        }
        return res.data.tracks.items[0];
    } catch (error) {
        console.error('✗ Error searching Spotify track:', error.message);
        throw new Error(error.message || '✗ Gagal mencari lagu di Spotify.');
    }
};

const getDownloadLink = async (trackUrl) => {
    try {
        const res = await axios.post(
            DOWNLOAD_API_ENDPOINT, {
                url: trackUrl
            }, {
                headers: {
                    "Content-Type": "application/json"
                }
            }
        );
        if (!res.data.file_url) {
            throw new Error('✗ Link download tidak ditemukan dari spotydown.media.');
        }
        return res.data.file_url;
    } catch (error) {
        console.error('✗ Error getting download link from spotydown.media:', error.message);
        throw new Error('✗ Gagal mengambil link download lagu.');
    }
};

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'terbang bersamaku'));
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const token = await getToken();
        const track = await searchTrack(m.text, token);
        const downloadUrl = await getDownloadLink(track.external_urls.spotify);
        const artists = track.artists.map((a) => a.name).join(", ");
        const thumbnailUrl = track.album.images[0]?.url;
        await lulli.sendMessage(m.chat, {
            audio: {
                url: downloadUrl
            },
            mimetype: "audio/mpeg",
            ptt: false,
            contextInfo: {
                externalAdReply: {
                    title: track.name,
                    body: `Artis: ${artists}`,
                    thumbnailUrl: thumbnailUrl,
                    mediaType: 1,
                    mediaUrl: track.external_urls.spotify,
                    sourceUrl: track.external_urls.spotify,
                },
            },
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

    } catch (err) {
        console.error('✗ Error pada Spotify Downloader:', err);
        m.reply(`✗ Gagal mengambil lagu: ${err.message || 'Coba lagi nanti.'}`);
    }
};

export default {
    run,
    cmd: 'spotify',
    alias: 'spt',
    use: 'judul lagu',
    type: 'downloader',
    desc: 'mengunduh lagu dari spotify.',
    premium: true,
    location: 'plugins/downloader/spotify.js'
};