import axios from 'axios';
import canvafy from 'canvafy';

const SPOTIFY_API_BASE_URL = 'https://spotifyapi.caliphdev.com';

function formatSize(size) {
    function round(value, precision) {
        var multiplier = Math.pow(10, precision || 0);
        return Math.round(value * multiplier) / multiplier;
    }
    const kiloByte = 1024;
    const megaByte = kiloByte * kiloByte;
    const gigaByte = kiloByte * megaByte;
    const teraByte = kiloByte * gigaByte;

    if (size < kiloByte) {
        return size + "B";
    } else if (size < megaByte) {
        return round(size / kiloByte, 1) + "KB";
    } else if (size < gigaByte) {
        return round(size / megaByte, 1) + "MB";
    } else if (size < teraByte) {
        return round(size / gigaByte, 1) + "GB";
    } else {
        return round(size / teraByte, 1) + "TB";
    }
}

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply('✗ Masukkan link Spotify atau query lagu.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        if (/open\.spotify\.com/.test(m.text)) {
            const spotifyLink = m.text.trim();

            const metadataResponse = await axios.get(`${SPOTIFY_API_BASE_URL}/api/info/track`, {
                params: { url: spotifyLink }
            }).catch(e => e.response);
            const metadata = metadataResponse?.data;

            if (!metadata || metadata.error) {
                return m.reply(`✗ Gagal mendapatkan metadata lagu: ${metadata?.error || 'Tidak diketahui.'}`);
            }

            const downloadResponse = await axios.get(`${SPOTIFY_API_BASE_URL}/api/download/track`, {
                params: { url: spotifyLink },
                responseType: 'arraybuffer'
            }).catch(e => e.response);
            const downloadBuffer = downloadResponse?.data;

            if (!downloadBuffer || downloadBuffer.length === 0) {
                return m.reply('✗ Gagal mengunduh file audio.');
            }
            const fileSize = formatSize(downloadBuffer.length);
            let caption = `✦ *SPOTIFY DOWNLOADER*\n\n` +
                          `- Judul: *${metadata.title || 'N/A'}*\n` +
                          `- Artis: ${metadata.artist || 'N/A'}\n` +
                          `- Album: ${metadata.album || 'N/A'}\n` +
                          `- Durasi: ${metadata.duration || 'N/A'}\n` +
                          `- Ukuran: ${fileSize}\n` +
                          `- Link: ${metadata.url || 'N/A'}`;

            const spotifyImage = await new canvafy.Spotify()
                .setAuthor(metadata.artist)
                .setAlbum(metadata.album)
                .setTimestamp(0, metadata.durationMs || 0)
                .setImage(metadata.thumbnail)
                .setTitle(metadata.title)
                .setBlur(5)
                .setOverlayOpacity(0.7)
                .build();
            const replyMessage = await lulli.sendMessage(m.chat, {
                image: spotifyImage,
                caption: caption,
                contextInfo: {
                    isForwarded: false,
                    forwardingScore: 99999,
                    externalAdReply: {
                        title: metadata.title,
                        body: metadata.artist,
                        mediaType: 1,
                        thumbnailUrl: metadata.thumbnail,
                        renderLargerThumbnail: true,
                        sourceUrl: metadata.url
                    }
                }
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            await lulli.sendMessage(m.chat, {
                audio: downloadBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${metadata.title || 'spotify_audio'}.mp3`
            }, {
                quoted: replyMessage,
                ephemeralExpiration: m.expiration
            });
        } else {
            const searchQuery = m.text.trim();
            const { data: searchResults } = await axios.get(`${SPOTIFY_API_BASE_URL}/api/search/tracks`, {
                params: { q: searchQuery }
            });
            if (!searchResults || searchResults.length === 0) {
                return m.reply('✗ Maaf, lagu yang Anda cari tidak ditemukan.');
            }
            let message = `✦ *HASIL PENCARIAN SPOTIFY*\n\n`;
            message += searchResults.map((item, i) => 
                `${i + 1}. *${item.title}*\n` +
                `  - Artis: ${item.artist}\n` +
                `  - URL: ${item.url}`
            ).join("\n\n");
            await m.reply(message);
        }

    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Spotify Downloader 2:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'spotify2',
    alias: 'spdl',
    use: 'link spotify / judul lagu',
    type: 'downloader',
    desc: 'mengunduh atau mencari lagu dari spotify.',
    premium: true,
    location: 'plugins/downloader/spotify2.js'
};