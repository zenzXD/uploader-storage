import axios from 'axios';
import crypto from 'node:crypto';
import https from 'node:https';
import fake from 'fake-useragent';
import fetch from 'node-fetch';

const MSEC_URL = "https://igram.world/msec";
const USER_INFO_URL = "https://api-wh.igram.world/api/v1/instagram/userInfo";
const POST_URL = "https://api-wh.igram.world/api/v1/instagram/posts";
const STORY_URL = "https://api-wh.igram.world/api/v1/instagram/stories";
const HIGHLIGHT_URL = "https://api-wh.igram.world/api/v1/instagram/highlights";
const CONVERT_URL = "https://api.igram.world/api/convert";

const SECRET_KEY = "3526501d956b1c95459de077386711c0529330544d2d57ad6781cc33fa03c7a3";
const FIXED_TIMESTAMP = 1740129810449;

const agent = new https.Agent({
    keepAlive: true,
    rejectUnauthorized: false
});

let headersList = {
    "authority": "igram.world",
    "accept": "*/*",
    "accept-encoding": "gzip, deflate, br, zstd",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7,ru;q=0.6",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://igram.world/",
    "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "user-agent": fake()
};

async function request({ url, method = "GET", data = null, params = null, head = null, response = "json" }) {
    try {
        let currentHeaders = { ...headersList };
        let currentParams = {};
        let currentData = null;

        if (head === "original" || head === "ori") {
            const uri = new URL(url);
            currentHeaders = {
                authority: uri.hostname,
                origin: "https://" + uri.hostname,
                'Cache-Control': 'no-cache',
                "user-agent": fake()
            };
        } else if (head && typeof head === "object") {
            currentHeaders = { ...currentHeaders, ...head };
        }
        if (params && typeof params === "object") {
            currentParams = params;
        }
        if (data) {
            currentData = data;
        }

        const axiosOptions = {
            url: url,
            method: method,
            headers: currentHeaders,
            timeout: 30_000,
            responseType: response,
            httpsAgent: agent,
            validateStatus: (status) => status <= 500,
            ...(currentData && { data: currentData }),
            ...(Object.keys(currentParams).length > 0 && { params: currentParams })
        };
        const res = await axios.request(axiosOptions);
        return res;
    } catch (error) {
        console.error('✗ Error pada fungsi request:', error.message);
        throw error;
    }
}

function _sort(inputObject) {
    return Object.keys(inputObject).sort().reduce((accumulator, key) => {
        accumulator[key] = inputObject[key];
        return accumulator;
    }, {});
}

async function getSignature(payload) {
    const response = await request({ url: MSEC_URL, head: headersList });
    const { msec } = response.data;

    let timestampInMilliseconds = Math.floor(msec * 1000);
    let timeDifference = timestampInMilliseconds ? Date.now() - timestampInMilliseconds : 0;
    if (Math.abs(timeDifference) < 60000) {
        timeDifference = 0;
    }

    const currentTime = Date.now() - timeDifference;
    const digestString = `${typeof payload === "string" ? payload : JSON.stringify(_sort(payload))}${currentTime}${SECRET_KEY}`;
    
    const hashBuffer = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(digestString));
    const signature = Array.from(new Uint8Array(hashBuffer)).map(byte => byte.toString(16).padStart(2, "0")).join('');

    return {
        ts: currentTime,
        _ts: FIXED_TIMESTAMP,
        _tsc: timeDifference,
        _s: signature
    };
}

function getUsername(link) {
    let username = /https:\/\/(www\.|m\.)?/i.test(link) ? new URL(link) : link;
    if (username instanceof URL) {
        const pathnameParts = username.pathname.split('/').filter(Boolean);
        if (pathnameParts.length > 0) {
            username = pathnameParts[0];
        } else {
            username = '';
        }
    }
    return username;
}

async function getInfo(url) {
    const username = getUsername(url);
    const payload = { username };
    const sign = await getSignature(payload);
    const res = await request({
        url: USER_INFO_URL,
        method: "POST",
        data: { username, ...sign },
        head: headersList
    });
    return res.data;
}

async function getPosts(url) {
    const username = getUsername(url);
    const payload = { maxId: "", username };
    const sign = await getSignature(payload);
    const res = await request({
        url: POST_URL,
        method: "POST",
        data: { ...payload, ...sign },
        head: headersList
    });
    return res.data;
}

async function getStories(url) {
    const username = getUsername(url);
    const payload = { username };
    const sign = await getSignature(payload);
    const res = await request({
        url: STORY_URL,
        method: "POST",
        data: { ...payload, ...sign },
        head: headersList
    });
    return res.data;
}

async function getHighlights(url) {
    const info = await getInfo(url);
    const payload = { userId: info?.result?.[0]?.user?.id };
    const sign = await getSignature(payload);
    const res = await request({
        url: HIGHLIGHT_URL,
        method: "POST",
        data: { ...payload, ...sign },
        head: headersList
    });
    return res.data;
}

async function Download(url) {
    const sign = await getSignature(url);
    const payload = { url, ...sign };
    const res = await request({
        url: CONVERT_URL,
        method: "POST",
        data: payload,
        head: headersList
    });
    return res.data;
}

function formatComments(comments) {
    if (!comments || comments.length === 0) return 'Tidak ada komentar.';
    return comments.map((comment, index) => `✦ [ ${index + 1} ] ${comment.username}:\n  - ${comment.text}`).join('\n\n');
}

const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply('✗ Masukkan link Instagram!');
    }
    const inputUrl = func.isUrl(m.args[0]);
    if (!inputUrl || inputUrl.length === 0) {
        return m.reply('✗ Link Instagram tidak valid.');
    }
    const url = inputUrl[0];
    const regexPostReelTV = /https?:\/\/(?:www\.|m\.)?instagram\.com\/(?:p|reel|tv)\/[A-z0-9_-]{1,11}/i;
    if (!regexPostReelTV.test(url)) {
        return m.reply(`✗ Link tidak valid! Perintah ini untuk mengunduh postingan IG/Reel/TV.\n\n✦ Contoh:\n*${m.cmd} https://www.instagram.com/p/BmjK1KOD_UG/?utm_medium=copy_link*`);
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const result = await Download(url);
        
        if (result.error) {
            return m.reply(`✗ Terjadi kesalahan: ${func.jsonFormat(result.details)}`);
        }
        const mediaArray = Array.isArray(result.url) ? result.url : [result.url];
        if (!mediaArray || mediaArray.length === 0) {
            return m.reply('✗ Tidak ditemukan media yang dapat diunduh.');
        }
        const meta = result.meta || {};
        const captionInfo = `✦ *INSTAGRAM DOWNLOADER*\n\n` +
                            `- Username: *${meta.username || '-'}*\n` +
                            `- Judul: *${meta.title || '-'}*\n` +
                            `- Like: ${meta.like_count || 0}\n` +
                            `- Komentar: ${meta.comment_count || 0}\n\n` +
                            `✦ *COMMENTS LIST*\n${formatComments(meta.comments || [])}`;
        let firstMediaSent = false;
        for (const item of mediaArray) {
            if (!item.url) continue;
            const mediaType = item.ext === 'mp4' ? 'video' : 'image';
            await lulli.sendMedia(m.chat, item.url, firstMediaSent ? null : m, {
                caption: firstMediaSent ? '' : captionInfo,
                expiration: m.expiration,
                mimetype: mediaType === 'video' ? 'video/mp4' : 'image/jpeg',
                fileName: `instagram_media.${item.ext}`
            });
            firstMediaSent = true;
            await func.delay(500);
        }
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Instagram Downloader 4:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'instagram4',
    alias: ['igdl4', 'ig4'],
    use: 'link instagram (post, reel, TV)',
    type: 'downloader',
    premium: true,
    limit: 5,
    location: 'plugins/downloader/instagram4.js'
};