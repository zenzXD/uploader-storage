import fs from 'node:fs';
import path from 'node:path';
import {
    minify as htmlMinify
} from 'html-minifier-terser';
import UglifyJS from 'uglify-js';
import CleanCSS from 'clean-css';

const run = async (m, lulli, {
    cfg,
    func
}) => {
    const {
        command,
        args,
        chat,
        reply,
        cmd,
        expiration
    } = m;
    let inputString;
    let fileName = 'minify_output';
    let contentType = null;
    if (command === 'minhtml') {
        contentType = 'html';
        fileName += '.html';
    } else if (command === 'mincss') {
        contentType = 'css';
        fileName += '.css';
    } else if (command === 'minjs') {
        contentType = 'js';
        fileName += '.js';
    }
    /*else if (command === 'minify') {
         if (m.quoted && m.quoted.mimetype) {
             if (m.quoted.mimetype.includes('text/html') || m.quoted.mimetype.includes('application/xhtml+xml')) {
                 contentType = 'html';
                 fileName += '.html';
             } else if (m.quoted.mimetype.includes('text/css')) {
                 contentType = 'css';
                 fileName += '.css';
             }
         }
    }*/
    if (m.quoted) {
        if (m.quoted.text) {
            inputString = m.quoted.text;
            if (!contentType) {
                // Coba deteksi tipe konten dari isi teks
                if (/<html|<body|<!doctype html/i.test(inputString) || inputString.trim().startsWith('<')) {
                    contentType = 'html';
                    fileName += '.html';
                } else if (/{|}/.test(inputString) && /:/.test(inputString) && /;/.test(inputString)) { // Heuristic simple for CSS
                    contentType = 'css';
                    fileName += '.css';
                } else if (/(function|const|let|var|import|export|class)\s+[a-zA-Z0-9_$]+|\S+\(|\.then\(|\.catch\(/i.test(inputString)) { // Heuristic untuk JS
                    contentType = 'js';
                    fileName += '.js';
                }
            }
        } else if (m.quoted.mimetype) {
            if (m.quoted.fileName) {
                fileName = m.quoted.fileName;
            } else if (contentType === 'html') {
                fileName += '.html';
            } else if (contentType === 'css') {
                fileName += '.css';
            } else if (contentType === 'js') {
                fileName += '.js';
            }
            try {
                let buffer = await m.quoted.download();
                inputString = Buffer.from(buffer, 'base64').toString('utf-8');
            } catch (e) {
                return reply(`✗ Gagal mendownload file: ${e.message}`);
            }
        }
    } else if (args.length > 0) {
        inputString = args.join(' ');
        if (!contentType) {
            // Coba deteksi tipe konten dari argumen (misal: !minjs js <code>)
            if (args[0].toLowerCase() === 'html' && args.length > 1) {
                contentType = 'html';
                inputString = args.slice(1).join(' ');
                fileName += '.html';
            } else if (args[0].toLowerCase() === 'css' && args.length > 1) {
                contentType = 'css';
                inputString = args.slice(1).join(' ');
                fileName += '.css';
            } else if (args[0].toLowerCase() === 'js' && args.length > 1) {
                contentType = 'js';
                inputString = args.slice(1).join(' ');
                fileName += '.js';
            }
            // Fallback: coba deteksi dari inputString itu sendiri
            else if (/<html|<body|<!doctype html/i.test(inputString) || inputString.trim().startsWith('<')) {
                contentType = 'html';
                fileName += '.html';
            } else if (/{|}/.test(inputString) && /:/.test(inputString) && /;/.test(inputString)) {
                contentType = 'css';
                fileName += '.css';
            } else if (/(function|const|let|var|import|export|class)\s+[a-zA-Z0-9_$]+|\S+\(|\.then\(|\.catch\(/i.test(inputString)) { // <-- Heuristic untuk JS
                contentType = 'js';
                fileName += '.js';
            }
        }
    }
    if (!inputString || inputString.trim() === '') {
        return reply(`✗ Penggunaan:\n\n✧ 1. Reply file HTML/CSS dengan caption *${cmd}*\n✧ 2. Reply kode HTML/CSS dengan caption *${cmd}*\n✧ 3. Ketik *${cmd}* html/css [kode]`);
    }
    if (!contentType) {
        return reply('✗ Tipe konten (HTML/CSS) tidak dapat dideteksi. Mohon gunakan perintah *minhtml* atau *mincss*, atau pastikan input jelas HTML/CSS.');
    }
    lulli.sendReact(chat, '🕒', m.key);
    let minifiedContent = null;
    let error = null;
    try {
        if (contentType === 'html') {
            // Opsi minifikasi HTML, bisa disesuaikan
            minifiedContent = await htmlMinify(inputString, {
                removeComments: true,
                collapseWhitespace: true,
                removeRedundantAttributes: true,
                useShortDoctype: true,
                minifyJS: true,
                minifyCSS: true,
            });
        } else if (contentType === 'css') {
            // Opsi minifikasi CSS, bisa disesuaikan
            const output = new CleanCSS({
                level: 2,
            }).minify(inputString);
            minifiedContent = output.styles;
            if (output.errors.length > 0) {
                error = output.errors.join('\n');
            }
            if (output.warnings.length > 0) {
                console.warn("Clean-CSS Warnings:", output.warnings.join('\n'));
            }
        } else if (contentType === 'js') {
            const result = UglifyJS.minify(inputString);
            if (result.error) {
                // Menampilkan letak baris dan kolom error
                const err = result.error;
                error = `JS Error: ${err.message}\nLine: ${err.line}\nCol: ${err.col}`;
            } else {
                minifiedContent = result.code || null;
            }
        }

    } catch (e) {
        console.error("✗ Error during minify process:", e);
        error = e.message;
    }
    if (error) {
        return reply(`✗ An error occurred while minifying: ${error}`);
    }
    if (!minifiedContent || minifiedContent.trim() === '') {
        return reply(`✗ Failed to minify code. Result is empty or no significant changes.`);
    }
    if (minifiedContent.length >= 65536) {
        const tempOutputDir = cfg.path.trash;
        if (!fs.existsSync(tempOutputDir)) {
            fs.mkdirSync(tempOutputDir, {
                recursive: true
            });
        }
        const filePath = path.join(tempOutputDir, fileName);
        fs.writeFileSync(filePath, minifiedContent);
        await lulli.sendMessage(chat, {
            document: {
                url: filePath
            },
            mimetype: (contentType === 'html' ? 'text/html' : (contentType === 'css' ? 'text/css' : 'application/javascript')), // <-- Perubahan minimal di sini
            fileName: fileName
        }, {
            quoted: m,
            ephemeralExpiration: expiration
        });
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    } else {
        lulli.sendMessage(chat, {
            text: minifiedContent
        }, {
            quoted: m,
            ephemeralExpiration: expiration
        });
    }
}

export default {
    run,
    cmd: ['minjs', 'minhtml', 'mincss'],
    use: 'input or reply',
    type: 'tools',
    limit: true,
    location: 'plugins/tools/minify.js'
};