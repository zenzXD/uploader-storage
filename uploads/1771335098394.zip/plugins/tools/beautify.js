import jsbeautify from 'js-beautify';
const {
   js_beautify,
   css_beautify,
   html_beautify
} = jsbeautify;
import fs from 'node:fs';
import path from 'node:path';

const run = async (m, lulli) => {
   const instructions = `✗ Penggunaan:\n${m.cmd} --js [kode] / balas kode dengan *${m.cmd} --js*\n✧ Contoh: *${m.cmd} --js console.log('hello');*`;
   let inputText;
   let fileName = 'beautified_code.js';
   if (m.quoted && m.quoted.mime && /(text|application)\/(javascript|octet-stream|html|css)/i.test(m.quoted.mime)) {
      const buffer = await m.quoted.download();
      inputText = Buffer.from(buffer).toString('utf-8');
      fileName = m.quoted.fileName || fileName;
   } else if (m.quoted && m.quoted.text) {
      inputText = m.quoted.text;
   } else if (m.text && m.text.startsWith('--')) {
      inputText = m.text.substring(m.text.indexOf(' ') + 1);
      fileName = `beautified_code.txt`;
   } else {
      return m.reply(instructions);
   }
   if (!inputText) return m.reply('✗ Tidak ada kode yang diberikan untuk di-beautify.');
   let beautifiedContent;
   const formatType = m.args[0] ? m.args[0].toLowerCase() : '';
   const beautifyOptions = {
      indent_size: 4,
      space_in_empty_paren: true,
      preserve_newlines: false,
      max_preserve_newlines: 0
   };
   lulli.sendReact(m.chat, '🕒', m.key);
   if (['--js', 'js'].includes(formatType)) {
      beautifiedContent = js_beautify(inputText, beautifyOptions);
      fileName = fileName.replace(/\.(txt|css|html)$/i, '.js');
   } else if (['--css', 'css'].includes(formatType)) {
      beautifiedContent = css_beautify(inputText, beautifyOptions);
      fileName = fileName.replace(/\.(txt|js|html)$/i, '.css');
   } else if (['--html', 'html'].includes(formatType)) {
      beautifiedContent = html_beautify(inputText, beautifyOptions);
      fileName = fileName.replace(/\.(txt|js|css)$/i, '.html');
   } else {
      return m.reply(instructions);
   }
   if (!beautifiedContent) {
      return m.reply('✗ Gagal me-beautify kode. Mohon periksa sintaks.');
   }
   if (beautifiedContent.length >= 65536) {
      const tempFilePath = path.join(process.cwd(), 'sampah', fileName);
      fs.mkdirSync(path.dirname(tempFilePath), {
         recursive: true
      });
      fs.writeFileSync(tempFilePath, beautifiedContent);
      await lulli.sendMessage(m.chat, {
         document: {
            url: tempFilePath
         },
         mimetype: 'application/octet-stream',
         fileName: fileName,
         caption: '✓ Kode berhasil di-beautify (dikirim sebagai dokumen karena terlalu panjang).'
      }, {
         quoted: m,
         ephemeralExpiration: m.expiration
      });
      if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
   } else {
      await lulli.sendMessage(m.chat, {
         text: `${beautifiedContent}`
      }, {
         quoted: m,
         ephemeralExpiration: m.expiration
      });
   }
}

export default {
   run,
   cmd: 'beautify',
   alias: 'beauty',
   use: 'kode / balas kode [--js / --css / --html]',
   type: 'tools',
   premium: true,
   location: 'plugins/tools/beautify.js'
};