import fetch from 'node-fetch';
import ms from 'parse-ms';

function timeReverse(duration) {
    const time = ms(Date.now() - duration);
    if (time.days === 0 && time.hours === 0 && time.minutes === 0 && time.seconds === 0) {
        return 'Baru Saja';
    }
    return `${time.days} Hari ${time.hours} ${time.hours === 1 ? 'Jam' : 'Jam'} ${time.minutes} ${time.minutes === 1 ? 'Menit' : 'Menit'} ${time.seconds} ${time.seconds === 1 ? 'Detik' : 'Detik'}`;
}

function hitungmundur(tanggal, bulan, tahun) {
    let now = new Date();
    let from = new Date(`${bulan} ${tanggal}, ${tahun} 00:00:00`);

    if (from.getTime() < now.getTime()) {
        from.setFullYear(from.getFullYear() + 1);
    }

    let distance = from.getTime() - now.getTime();
    if (distance <= 0) return 'Hari ini!';

    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
    let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((distance % (1000 * 60)) / 1000);

    return `${days} Hari ${hours} Jam ${minutes} Menit ${seconds} Detik Lagi`;
}

const run = async (m, lulli, { func, setting, froms }) => {
    lulli.sendReact(m.chat, '🕒', m.key);

    if (!froms) {
        return m.reply('✗ Mohon mention atau balas pesan target.');
    }
    const targetJid = froms;

    try {
        const userData = global.db.users[targetJid];
        if (!userData) {
            return m.reply('✗ Data pengguna target tidak ditemukan.');
        }

        const {
            name, gender, age, limit, balance, premium, banned, jadibot,
            warning, register, date, pasangan, expired, level, exp, role, ultah
        } = userData;

        const about = (await lulli.fetchStatus(targetJid).catch(() => ({})) || {}).status || '-';
        const listblock = await lulli.fetchBlocklist().catch(() => []);

        let loversInfo = 'Jomblo Abadi';
        if (pasangan && pasangan.id) {
            const partnerData = global.db.users[pasangan.id];
            if (partnerData && partnerData.pasangan && partnerData.pasangan.id === targetJid) {
                loversInfo = `@${pasangan.id.split('@')[0]} (${timeReverse(pasangan.time)})`;
            } else {
                loversInfo = `Sedang digantung oleh @${pasangan.id.split('@')[0]}`;
            }
        }
        
        let birthdayInfo = '-';
        let ageInfo = age || '-';
        if (ultah && ultah.date && ultah.status) {
            const [day, month] = ultah.date.split('/').map(Number);
            const currentYear = new Date().getFullYear();
            birthdayInfo = hitungmundur(day, month, currentYear);
            ageInfo = func.getAgeFromDate(ultah.date);
        }
        
    let caption = `乂  *U S E R - P R O F I L E*

◈ *Name* : ${name || lulli.getName(targetJid)}
◈ *Gender* : ${gender || '-'}
◈ *Age* : ${ageInfo || 0}
◈ *Birthday* : ${birthdayInfo}
◈ *Limit* : ${limit || 0}
◈ *Balance* : ${func.formatNumber(balance)}
◈ *Level* : ${level || 0}
◈ *Exp* : ${exp || 0} / ${10 * Math.pow(level, 2) + 50 * level + 100}
◈ *Role* : ${role}
◈ *Device* : ${func.getDevice(m.key.id)}
◈ *Lovers* : ${loversInfo}
◈ *About* : ${about}

乂  *U S E R - S T A T U S*
◈ *Warning* : ${warning} / 3
◈ *Blocked* : ${listblock.includes(m.sender) ? 'Yes' : 'No'}
◈ *Banned* : ${banned ? 'Yes (' + (expired.banned == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.banned)) + ')' : 'No'}
◈ *Premium* : ${premium ? 'Yes (' + (expired.premium == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.premium)) + ')' : 'No'}
◈ *Jadibot* : ${jadibot ? 'Yes (' + (expired.jadibot == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.jadibot)) + ')' : 'No'}
◈ *Register* : ${register ? 'Yes (' + date + ')' : 'No'}`
        
        let ppUrl = await lulli.profilePictureUrl(targetJid, 'image').catch(() => 'https://files.catbox.moe/39hmb8.jpg');
        const thumbnailBuffer = await fetch(ppUrl).then(res => res.buffer());

        await lulli.sendMessageModify(m.chat, caption.trim(), m, {
            largeThumb: true,
            thumbnail: thumbnailBuffer,
            expiration: m.expiration,
            mentions: [targetJid]
        });
        lulli.sendReact(m.chat, '✅', m.key);

    } catch (error) {
        console.error('✗ Terjadi kesalahan pada Profil Pengguna:', error);
        lulli.sendReact(m.chat, '❌', m.key);
        await m.reply(`✗ Terjadi kesalahan: ${error.message}`);
    }
}

export default {
    run,
    cmd: 'profile',
    alias: 'profil',
    use: 'Mention atau balas pesan target',
    type: 'user',
    group: true,
    location: 'plugins/user/profile.js'
};
