const run = async (m, lulli, { users, froms, func }) => {
    lulli.sendReact(m.chat, '🕒', m.key);

    if (!users) {
        return m.reply('✗ Data pengguna tidak ditemukan. Mohon daftar terlebih dahulu.');
    }

    if (typeof users.sperma === 'undefined') users.sperma = 0;

    if (!froms) {
        const generatedSperma = Math.floor(Math.random() * 250) + 1;

        const initialMessage = await lulli.sendMessage(m.chat, {
            text: func.texted('monospace', `@${m.sender.split('@')[0]} sedang beraktivitas solo...`)
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration,
            mentions: [m.sender]
        });

        await new Promise(resolve => setTimeout(resolve, 20000));

        users.sperma += generatedSperma;

        await lulli.sendMessage(m.chat, {
            text: `@${m.sender.split('@')[0]} telah selesai beraktivitas solo dan mendapatkan *${generatedSperma}* sperma!`,
            mentions: [m.sender]
        }, {
            quoted: initialMessage,
            ephemeralExpiration: m.expiration
        });
        lulli.sendReact(m.chat, '✅', m.key);
        return;
    }

    let targetUser = global.db.users[froms];
    if (!targetUser) {
        return lulli.sendMessage(m.chat, {
            text: `✗ User yang disebutkan (@${froms.split('@')[0]}) tidak ditemukan dalam database.`,
            mentions: [froms]
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    }

    if (typeof targetUser.sperma === 'undefined') targetUser.sperma = 0;
    const generatedSpermaBersama = Math.floor(Math.random() * 500) + 2;
    const initialMessage = await lulli.reply(m.chat, func.texted('monospace', `@${m.sender.split('@')[0]} dan @${froms.split('@')[0]} sedang beraktivitas bersama...`), m, {
        expiration: m.expiration
    })
    await new Promise(resolve => setTimeout(resolve, 20000));

    users.sperma += generatedSpermaBersama;
    targetUser.sperma += generatedSpermaBersama;

    await lulli.sendMessage(m.chat, {
        text: `@${m.sender.split('@')[0]} dan @${froms.split('@')[0]} telah selesai beraktivitas bersama dan mendapatkan total *${generatedSpermaBersama}JT* sperma!`,
        mentions: [m.sender, froms]
    }, {
        quoted: initialMessage,
        ephemeralExpiration: m.expiration
    });
    lulli.sendReact(m.chat, '✅', m.key);
};

export default {
    run,
    cmd: 'ngocok',
    use: 'mention atau balas pesan target (opsional)',
    type: 'user',
    limit: true,
    group: true,
    location: 'plugins/user/ngocok.js'
};
