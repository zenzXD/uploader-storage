import fetch from 'node-fetch';
import ms from 'parse-ms';

function timeReverse(duration) {
    const time = ms(Date.now() - duration);
    if (time.days === 0 && time.hours === 0 && time.minutes === 0 && time.seconds === 0) {
        return 'Baru Saja';
    }
    return `${time.days} Hari ${time.hours} Jam ${time.minutes} Menit ${time.seconds} Detik`;
}

function hitungmundur(tanggal, bulan, tahun) {
    const now = new Date();
    let birthDate = new Date(`${bulan} ${tanggal}, ${tahun} 00:00:00`);

    if (birthDate.getTime() < now.getTime()) {
        birthDate.setFullYear(birthDate.getFullYear() + 1);
    }

    const distance = birthDate.getTime() - now.getTime();
    if (distance <= 0) return 'Hari ini!';

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    return `${days} Hari ${hours} Jam ${minutes} Menit ${seconds} Detik Lagi`;
}

async function run(m, lulli, { func, cfg }) {
    lulli.sendReact(m.chat, '🕒', m.key);

    try {
        const userData = global.db.users[m.sender];
        if (!userData) {
            return m.reply('✗ User data not found.');
        }

        const {
            name, gender, age, limit, balance, premium, banned, jadibot,
            warning, register, date, pasangan, expired, level, exp, role, ultah
        } = userData;

        const about = (await lulli.fetchStatus(m.sender).catch(() => ({})) || {}).status || '-';
        const listblock = await lulli.fetchBlocklist().catch(() => []);

        let loversInfo = 'Jomblo Abadi';
        if (pasangan && pasangan.id) {
            const partnerData = global.db.users[pasangan.id];
            if (partnerData && partnerData.pasangan && partnerData.pasangan.id === m.sender) {
                loversInfo = `@${pasangan.id.split('@')[0]} (${timeReverse(pasangan.time)})`;
            } else {
                loversInfo = `sedang di gantung @${pasangan.id.split('@')[0]}`;
            }
        }
        
        let birthdayInfo = '-';
        let ageInfo = age || '-';
        if (ultah && ultah.date && ultah.status) {
            const [day, month] = ultah.date.split('/').map(Number);
            const currentYear = new Date().getFullYear();
            birthdayInfo = hitungmundur(day, month, currentYear);
            ageInfo = func.getAgeFromDate(ultah.date);
        }

    let caption = `乂  *U S E R - P R O F I L E*

◈ *Name* : ${name || m.pushname}
◈ *Gender* : ${gender || '-'}
◈ *Age* : ${ageInfo}
◈ *Birthday* : ${birthdayInfo}
◈ *Limit* : ${limit || 0}
◈ *Balance* : ${func.formatNumber(balance)}
◈ *Level* : ${level || 0}
◈ *Exp* : ${exp || 0} / ${10 * Math.pow(level, 2) + 50 * level + 100}
◈ *Role* : ${role}
◈ *Device* : ${func.getDevice(m.key.id)}
◈ *Lovers* : ${loversInfo}
◈ *About* : ${about}

乂  *U S E R - S T A T U S*
◈ *Warning* : ${warning} / 3
◈ *Blocked* : ${listblock.includes(m.sender) ? 'Yes' : 'No'}
◈ *Banned* : ${banned ? 'Yes (' + (expired.banned == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.banned)) + ')' : 'No'}
◈ *Premium* : ${premium ? 'Yes (' + (expired.premium == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.premium)) + ')' : 'No'}
◈ *Jadibot* : ${jadibot ? 'Yes (' + (expired.jadibot == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.jadibot)) + ')' : 'No'}
◈ *Register* : ${register ? 'Yes (' + date + ')' : 'No'}`
        let ppUrl = await lulli.profilePictureUrl(m.sender, 'image').catch(() => 'https://files.catbox.moe/39hmb8.jpg');
        const thumbnailBuffer = await fetch(ppUrl).then(res => res.buffer());

        await lulli.sendMessageModify(m.chat, caption.trim(), m, {
            largeThumb: true,
            thumbnail: thumbnailBuffer,
            expiration: m.expiration,
            mentions: [m.sender]
        });
        lulli.sendReact(m.chat, '✅', m.key);

    } catch (error) {
        console.error('✗ Terjadi kesalahan pada Cek Profil (Me):', error);
        lulli.sendReact(m.chat, '❌', m.key);
        await m.reply(`✗ Terjadi kesalahan: ${error.message}`);
    }
}

export default {
    run,
    cmd: 'me',
    type: 'user',
    location: 'plugins/user/me.js'
};
