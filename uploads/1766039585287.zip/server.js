// api-script-bot.js (Backend REVISI TERAKHIR, bayar dulu baru buat kredensial)

import express from 'express';
import { fileURLToPath } from 'url';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import * as qris from './qris-logic.js'; // PASTIKAN FILE INI ADA DAN BERFUNGSI!
import moment from 'moment-timezone';
import chalk from 'chalk';
import { promises as fs } from 'fs';

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware untuk parsing JSON body
app.use(express.json());

// Untuk mengatasi CORS jika frontend dan backend di domain berbeda
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*'); // Sesuaikan dengan domain frontend kamu nanti
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

// __dirname equivalent for ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Konfigurasi API key Anabot.my.id (GANTI DENGAN DATA ASLI KAMU YA!)
const ANABOT_USERNAME = 'jabalsurya';
const ANABOT_TOKEN = '1361511:Ng7vZxuwoFacK0dzXIpW9lEjq1CyLMf4';

// Database lokal untuk menyimpan riwayat pembayaran
const PAYMENT_HISTORY_FILE_PATH = path.resolve(__dirname, "data", "payment-history.json");
let PAYMENT_HISTORY = [];

// Definisikan BOT_SCRIPTS kamu beserta harga, jenis akses, dan link download
const BOT_SCRIPTS = [
    {
        id: 1,
        name: 'LULLI BOT',
        price: 50000,
        description: 'Bot serbaguna. Download scriptnya, lalu buat kredensialmu untuk login di dalam bot.',
        type: 'credential-access', // Tipe akses: Download + Butuh username/password buatan user
        download_link: 'https://link.to.your.lulli.bot.script/lullibot.zip' // Ini download link untuk script bot Lulli
    },
    {
        id: 2,
        name: 'MECHA BOT',
        price: 50000,
        description: 'Bot otomatisasi. Download scriptnya, lalu buat kredensialmu untuk login di dalam bot.',
        type: 'credential-access', // Tipe akses: Download + Butuh username/password buatan user
        download_link: 'https://link.to.your.mecha.bot.script/mechabot.zip' // Ini download link untuk script bot Mecha
    },
    {
        id: 3,
        name: 'PRIVATE BOT',
        price: 100000,
        description: 'Bot eksklusif. Download scriptnya, langsung siap pakai.',
        type: 'download', // Tipe akses: Langsung download (tanpa kredensial khusus)
        download_link: 'https://link.to.your.private.bot.script/privatebot.zip' // Ini download link untuk script bot Private
    },
];

// Fungsi untuk menyimpan PAYMENT_HISTORY ke file
async function savePaymentHistory() {
    try {
        const dataDir = path.dirname(PAYMENT_HISTORY_FILE_PATH);
        await fs.mkdir(dataDir, { recursive: true });
        await fs.writeFile(PAYMENT_HISTORY_FILE_PATH, JSON.stringify(PAYMENT_HISTORY, null, 2), 'utf8');
        console.log(chalk.blue('[DB] Payment history saved to file.'));
    } catch (error) {
        console.error(chalk.red('[DB ERROR] Failed to save payment history to file:'), error);
    }
}

// Fungsi untuk memuat PAYMENT_HISTORY dari file
async function loadPaymentHistory() {
    try {
        const data = await fs.readFile(PAYMENT_HISTORY_FILE_PATH, 'utf8');
        PAYMENT_HISTORY = JSON.parse(data);
        console.log(chalk.blue('[DB] Payment history loaded from file.'));
    } catch (error) {
        if (error.code === 'ENOENT') {
            console.warn(chalk.yellow('[DB] payment-history.json not found, initializing empty history.'));
            PAYMENT_HISTORY = [];
            await savePaymentHistory();
        } else {
            console.error(chalk.red('[DB ERROR] Failed to load payment history from file:'), error);
            PAYMENT_HISTORY = [];
        }
    }
}

// Endpoint untuk mendapatkan daftar bot scripts
app.get('/api/products', (req, res) => {
    res.json({ success: true, products: BOT_SCRIPTS.map(({ id, name, price, description, type }) => ({ id, name, price, description, type })) });
});

// Endpoint untuk generate QRIS
// Endpoint ini tidak lagi menerima botUsername dan botPassword
app.post('/api/qris/generate', async (req, res) => {
    const { productId } = req.body;

    if (!productId) {
        return res.status(400).json({ success: false, message: 'ID produk tidak valid.' });
    }

    const selectedProduct = BOT_SCRIPTS.find(p => p.id === productId);
    if (!selectedProduct) {
        return res.status(404).json({ success: false, message: 'Produk bot tidak ditemukan.' });
    }

    const amount = selectedProduct.price;
    const sessionId = uuidv4();
    const sessionExpirationTime = 10 * 60 * 1000;

    try {
        const qrisString = await qris.generateQRIS(amount);
        const qrCodeImage = await qris.createQR(qrisString);

        // Simpan botType di session pembayaran sementara
        // Tidak perlu lagi botUsername dan botPassword di sini
        const paymentSession = qris.addPaymentSession(sessionId, amount, productId, selectedProduct.type);

        console.log(`[${sessionId}] QRIS generated for product: ${selectedProduct.name}, amount: ${amount}. Type: ${selectedProduct.type}.`);

        paymentSession.sessionTimeoutRef = setTimeout(() => {
            if (qris.temporaryDatabase[sessionId] && qris.temporaryDatabase[sessionId].status === 'pending') {
                qris.temporaryDatabase[sessionId].status = 'expired';
                console.log(`[${sessionId}] Sesi pembayaran berakhir (timeout 10 menit).`);
                qris.deleteSession(sessionId);
            }
        }, sessionExpirationTime);

        // Cek pembayaran instan setelah generate QRIS
        const latestMutations = await qris.getLatestQrisMutationsFromAnabot(ANABOT_USERNAME, ANABOT_TOKEN);
        const initialCheckResult = qris.checkPayment(sessionId, latestMutations);

        if (initialCheckResult.status === 'paid') {
            console.log(`[${sessionId}] Pembayaran dikonfirmasi saat QRIS dibuat!`);
            paymentSession.status = 'paid';

            let responseData = {
                success: true,
                sessionId: sessionId,
                product: selectedProduct,
                amount: amount,
                qrCodeImage: qrCodeImage,
                expiresIn: 0,
                paymentStatus: 'paid',
                message: 'Pembayaran Diterima!'
            };

            // Jika langsung paid, kita simpan di payment history tanpa kredensial dulu
            // Kredensial akan ditambahkan nanti setelah user input via endpoint baru
            PAYMENT_HISTORY.push({
                sessionId,
                productId: selectedProduct.id,
                productName: selectedProduct.name,
                amount,
                status: 'paid',
                timestamp: moment().tz('Asia/Jakarta').toISOString(),
                type: selectedProduct.type,
                downloadLink: selectedProduct.download_link,
                botCredentials: selectedProduct.type === 'credential-access' ? { username: null, password: null } : undefined // Placeholder
            });
            await savePaymentHistory();
            qris.deleteSession(sessionId); // Hapus sesi sementara
            res.json(responseData);

        } else { // Payment pending
            res.json({
                success: true,
                sessionId: sessionId,
                product: selectedProduct,
                amount: amount,
                qrCodeImage: qrCodeImage,
                expiresIn: sessionExpirationTime / 1000,
                paymentStatus: 'pending',
                message: 'Menunggu Pembayaran.'
            });
        }

    } catch (error) {
        console.error('Error generating QRIS or processing initial payment:', error);
        if (qris.temporaryDatabase[sessionId]) {
            qris.deleteSession(sessionId);
        }
        res.status(500).json({ success: false, message: 'Gagal membuat QRIS.', error: error.message });
    }
});

// Endpoint untuk cek status pembayaran secara berkala dari frontend
app.get('/api/qris/status/:sessionId', async (req, res) => {
    const { sessionId } = req.params;
    let session = qris.temporaryDatabase[sessionId];

    // Cek di riwayat pembayaran permanen dulu
    const historicalPayment = PAYMENT_HISTORY.find(p => p.sessionId === sessionId && p.status === 'paid');
    if (historicalPayment) {
        let responseData = { success: true, status: 'paid', message: 'Sesi sudah lunas.' };
        responseData.product = BOT_SCRIPTS.find(p => p.id === historicalPayment.productId);
        responseData.downloadLink = historicalPayment.downloadLink;
        if (historicalPayment.type === 'credential-access') {
            responseData.botCredentials = historicalPayment.botCredentials; // Ambil kredensial (mungkin masih null)
        }
        return res.json(responseData);
    }

    if (!session) {
        return res.json({ success: true, status: 'not_found', message: 'Sesi pembayaran tidak ditemukan atau telah berakhir.' });
    }

    const latestMutations = await qris.getLatestQrisMutationsFromAnabot(ANABOT_USERNAME, ANABOT_TOKEN);
    const checkResult = qris.checkPayment(sessionId, latestMutations);

    if (checkResult.status === 'paid') {
        session.status = 'paid';
        const confirmedProduct = BOT_SCRIPTS.find(p => p.id === session.productId);

        if (confirmedProduct) {
            console.log(`[${sessionId}] Payment Confirmed: ${confirmedProduct.name}`);
            let responseData = {
                success: true,
                status: 'paid',
                message: 'Pembayaran Diterima!',
                product: confirmedProduct
            };

            // Simpan pembayaran ke histori permanen
            PAYMENT_HISTORY.push({
                sessionId,
                productId: confirmedProduct.id,
                productName: confirmedProduct.name,
                amount: confirmedProduct.price,
                status: 'paid',
                timestamp: moment().tz('Asia/Jakarta').toISOString(),
                type: confirmedProduct.type,
                downloadLink: confirmedProduct.download_link,
                botCredentials: confirmedProduct.type === 'credential-access' ? { username: null, password: null } : undefined // Placeholder
            });
            await savePaymentHistory();
            qris.deleteSession(sessionId); // Hapus sesi sementara
            return res.json(responseData);

        } else { // Product not found, error
            return res.status(500).json({ success: false, status: 'error', message: 'Produk tidak ditemukan untuk sesi pembayaran ini.' });
        }
    } else { // Payment pending
        res.json({
            success: true,
            status: session.status,
            amount: session.amount,
            message: `Status pembayaran untuk sesi ${sessionId}: ${session.status}`
        });
    }
});

// Endpoint BARU untuk menyimpan kredensial bot setelah pembayaran berhasil
app.post('/api/credentials/save', async (req, res) => {
    const { sessionId, botUsername, botPassword } = req.body;

    if (!sessionId || !botUsername || !botPassword) {
        return res.status(400).json({ success: false, message: 'Data tidak lengkap (sessionId, username, password diperlukan).' });
    }

    // Validasi panjang kredensial di backend
    if (botUsername.length > 10) {
        return res.status(400).json({ success: false, message: 'Username tidak boleh lebih dari 10 karakter.' });
    }
    if (botPassword.length > 15) {
        return res.status(400).json({ success: false, message: 'Password tidak boleh lebih dari 15 karakter.' });
    }

    // Cari transaksi yang sudah paid tapi belum ada kredensialnya
    const transactionIndex = PAYMENT_HISTORY.findIndex(
        p => p.sessionId === sessionId && p.status === 'paid' && p.type === 'credential-access' && !p.botCredentials.username
    );

    if (transactionIndex === -1) {
        return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan atau sudah memiliki kredensial.' });
    }

    // Update kredensial di payment history
    PAYMENT_HISTORY[transactionIndex].botCredentials = { username: botUsername, password: botPassword };
    await savePaymentHistory();

    res.json({ success: true, message: 'Kredensial bot berhasil disimpan.', botCredentials: { username: botUsername, password: botPassword } });
});


// Jalankan server
loadPaymentHistory().then(() => {
    app.listen(PORT, () => {
        console.log(chalk.green(`Server backend berjalan di http://localhost:${PORT}`));
        console.log(chalk.yellow('Pastikan qris-logic.js sudah dikonfigurasi dengan benar!'));
    });
});
